# money_admin

## Project setup

node 14.21

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn run serve
```

### Compiles and minifies for production

```
yarn run build
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
