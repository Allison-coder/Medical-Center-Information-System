<template>
  <div class="patient-management">
    <!-- 表头搜索 -->
    <div class="patient-navbar">
      <span style="color: #666666">订单号</span>
      <el-input
        placeholder="请输入订单号"
        v-model="orderParams.orderSn"
        style="width: 180px; margin-left: 20px; margin-right: 30px"
        clearable
      />
      <span style="color: #333333">患者姓名</span>
      <el-input
        placeholder="请输入患者姓名"
        style="width: 212px; margin-right: 50px; margin-left: 40px"
        v-model="orderParams.patientName"
        clearable
      />
      <span>订单状态</span>
      <el-select
        style="width: 180px; margin-left: 20px; margin-right: 30px"
        placeholder="请选择订单状态"
        v-model="orderParams.statusList"
        clearable
        @change="doSearch"
      >
        <el-option
          v-for="item in orderStatusList"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <el-button type="primary" @click="doSearch" icon="el-icon-search"
        >搜索</el-button
      >
    </div>
    <!-- 订单列表 -->
    <div class="patient-form">
      <el-table style="width: 100%" :data="totalList" class="center-table">
        <el-table-column
          width="220"
          label="订单号"
          align="center"
          prop="orderSn"
        />
        <el-table-column
          label="创建时间"
          width="170"
          align="center"
          prop="createTime"
        >
        </el-table-column>
        <el-table-column
          label="订单类型"
          align="center"
          prop="orderType"
          :formatter="formatOrderType"
        />
        <el-table-column
          label="就诊人"
          align="center"
          prop="patientBaseInfoVO.name"
        />
        <el-table-column
          label="医生/治疗师"
          align="center"
          :formatter="formatDoctorName"
          width="150"
        />

        <el-table-column width="130" label="预约时间" align="center">
          <template #default="{ row }">
            <!-- 挂号单 -->
            <div v-if="row.orderType == 1">
              <div>{{ row.appointmentVO?.scheduleDate }}</div>
              <div>
                {{
                  row.appointmentVO?.startTime +
                  "-" +
                  row.appointmentVO?.endTime
                }}
              </div>
            </div>
            <!-- 治疗单 -->
            <div v-if="row.orderType == 2">
              <!-- <div v-if="row.orderStatus == 0 || row.orderStatus == 2">--</div>
              <div v-else> -->
              <!-- <div>完成进度</div>
                <div>
                  {{
                    (row?.medicalRecordStrageVO?.completed || "0") +
                    "/" +
                    row.treatmentVO?.treatmentItemVOS?.find(
                      (item) => item.projectType === 1
                    )?.totalSessions
                  }}
                </div> -->
              <div v-if="row.appointmentVO">
                {{ row.appointmentVO.scheduleDate }}
              </div>
              <div v-if="row.appointmentVO">
                {{ row.appointmentVO.startTime }}
              </div>
              <!-- </div> -->
            </div>
          </template>
        </el-table-column>
        <el-table-column label="就诊项目" align="center" width="150">
          <template #default="{ row }">
            <div
              v-if="row.orderType == 2 && row.scheduleType == 2"
              style="width: 110px"
            >
              {{ row.visitProject }}
            </div>
            <div v-else-if="row.orderType == 2 && row.scheduleType == 3">
              {{ row.visitProject }}
            </div>
            <div v-else>医生面诊</div>
          </template>
        </el-table-column>

        <el-table-column
          label="状态"
          align="center"
          prop="orderStatus"
          :formatter="formatOrderStatus"
        />
        <el-table-column label="订单金额" align="center" prop="orderAmount" />
        <el-table-column label="优惠券" align="center">
          <template #default="{ row }">
            <!-- 只用了一张 -->
            <div
              v-if="row.couponDetailList && row.couponDetailList.length == 1"
            >
              <!-- 现金券 -->
              <div v-if="row.couponDetailList[0]?.couponTypeName == '现金券'">
                {{ row.couponDetailList[0]?.couponParValue }}元
              </div>

              <!-- 兑换券 -->

              <!-- 折扣券 -->
              <div v-if="row.couponDetailList[0]?.couponTypeName == '折扣券'">
                {{ row.couponDetailList[0]?.discount }}折
              </div>
              <div>{{ row.couponDetailList[0]?.couponTypeName }}</div>
            </div>
            <!-- 使用了多张券 -->
            <div
              v-if="row.couponDetailList && row.couponDetailList.length > 1"
              style="
                display: flex;
                align-items: center;
                justify-content: center;
                width: 100%;
                height: 100%;
              "
            >
              <el-popover
                style="position: absolute"
                placement="top"
                width="150"
                trigger="click"
              >
                <div class="popover_box">
                  <div v-for="(ite, j) in row.couponDetailList" :key="j">
                    <!-- 现金券 -->
                    <span v-if="ite.couponTypeName == '现金券'">
                      {{ ite.couponParValue }}元 {{ " " }}
                    </span>

                    <!-- 兑换券 -->

                    <!-- 折扣券 -->
                    <span v-if="ite.couponTypeName == '折扣券'">
                      {{ ite.discount }}折 {{ " " + " " }}
                    </span>
                    <span>{{ ite.couponTypeName }}</span>
                  </div>
                </div>

                <span
                  slot="reference"
                  style="user-select: none; color: var(--primary-color)"
                >
                  {{ row.couponDetailList.length }}张券
                </span>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          label="手机号"
          width="140"
          align="center"
          prop="patientBaseInfoVO.phoneNumber"
        />
        <el-table-column label="操作" width="220" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              class="icon-wrapper"
              type="text"
              style="color: #ef2e2e"
              @click="cancelOrder(row.orderSn)"
              v-if="row.orderStatus === 0"
              >取消订单</el-button
            >
            <el-button
              class="icon-wrapper"
              type="text"
              @click="changePrice(row.orderAmount, row.orderSn, row)"
              v-if="row.orderStatus === 0 && row.orderType == 1"
              >调价</el-button
            >
            <el-button
              class="icon-wrapper"
              type="text"
              @click="changePriceZhiLiao(row.treatmentVO, row.orderSn, row)"
              v-if="row.orderStatus === 0 && row.orderType == 2"
              >调价</el-button
            >

            <el-button
              class="icon-wrapper"
              type="text"
              v-if="row.orderStatus === 0 && row.orderAmount > 0"
              @click="goPayCode(row.orderSn)"
              >支付码</el-button
            >
            <el-button
              class="icon-wrapper"
              type="text"
              v-if="row.orderStatus === 0 && row.orderAmount == 0"
              @click="goPayCodeIsZ(row.orderSn)"
              >0元支付</el-button
            >
            <el-button
              class="icon-wrapper"
              type="text"
              @click="
                goPatientInformation(
                  row.patientBaseInfoVO.patientSn,
                  row.orderSn
                )
              "
              v-if="
                row.orderStatus === 0 ||
                row.orderStatus === 1 ||
                row.orderStatus === 2 ||
                row.orderStatus === 4
              "
              >资料</el-button
            >
            <!-- 用了优惠券的面诊订单可以退款。 用了优惠券的治疗订单不可以退款。 -->
            <el-button
              class="icon-wrapper"
              type="text"
              style="color: #ef2e2e"
              @click="orderRefund(row.orderType, row.orderSn)"
              v-if="row.orderStatus === 1 && row.orderType == 1"
              >退款</el-button
            >
            <el-button
              class="icon-wrapper"
              type="text"
              style="color: #ef2e2e"
              @click="orderRefund(row.orderType, row.orderSn)"
              v-if="
                row.orderStatus === 1 && row.orderType == 2 && !row.isUseCoupon
              "
              >退款</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页器 -->
    <div class="page-container">
      <el-pagination
        layout="total, prev, pager, next"
        :total="pageTotal"
        :current-page="orderParams.pageNum"
        :page-size="orderParams.pageSize"
        @current-change="currentChange"
        background
      />
    </div>

    <!-- 调价dialog -->
    <el-dialog
      :class="'my-centered-dialog'"
      title="调价"
      :visible.sync="changePriceDialogVisible"
    >
      <el-form
        ref="formx"
        label-position="left"
        :model="form"
        label-width="130px"
      >
        <el-form-item label="原价金额：">
          <span>{{ originalPrice }}</span>
        </el-form-item>
        <el-form-item label="调价后金额：">
          <el-input
            placeholder="请输入调价后金额"
            v-model.trim="newPrice"
          ></el-input>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button @click="changePriceDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="updatePrice">确 认</el-button>
      </span>
    </el-dialog>

    <!-- 治疗调价dialog -->
    <el-dialog
      :class="'my-centered-dialog'"
      title="治疗调价"
      :visible.sync="ZhiLiaoChangePriceDialogVisible"
    >
      <div>
        <el-table
          :data="ZhiLiaoChangePriceItem.list"
          border
          highlight-current-row
          class="center-table"
        >
          <el-table-column
            type="index"
            prop="date"
            label="序号"
            align="center"
            width="50"
          >
          </el-table-column>
          <el-table-column label="项目名称" align="center" width="119">
            <template #default="{ row }">
              {{ row.itemName }}
            </template>
          </el-table-column>

          <el-table-column label="总次数" align="center">
            <template #default="{ row }">
              <span>{{ row.totalSessions }}</span>
            </template>
          </el-table-column>

          <el-table-column label="总价" align="center" width="130">
            <template #default="{ row }">
              <!-- <span v-if="row.projectType == 1">
                ￥
                {{ (row.unitPrice * row.totalSessions).toFixed(2) || "--" }}
              </span> -->
              <span>
                ￥
                {{ row.totalPrice }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="调价后总价" align="center" width="140">
            <template #default="{ row }">
              <span v-if="row.canAdjustAmount == true">
                ￥
                <el-input
                  style="display: inline-block; width: 90px"
                  v-model="row.NewTotalPrice"
                  @input="inputChange($event)"
                  size="small"
                />
              </span>
              <span v-else> 不可调价 </span>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="ZhiLiaoChangePriceDialogVisible = false"
          >取 消</el-button
        >
        <el-button type="primary" @click="ZhiLiaoUpdatePrice">确 认</el-button>
      </span>
    </el-dialog>

    <!-- 挂号订单--退款dialog -->
    <el-dialog
      title="挂号订单"
      width="40%"
      :visible.sync="registrationOrderDialogVisible"
    >
      <div style="text-align: left; padding-left: 80px; font-size: 16px">
        <span>订单金额：{{ nowOrderAmount }}</span>
        <br />
        <br />
        <span>退款金额：{{ refundAmount }} {{ remark }}</span>
      </div>
      <span slot="footer">
        <el-button @click="registrationOrderDialogVisible = false"
          >取 消</el-button
        >
        <el-button type="primary" @click="confirmRefund">确认退款</el-button>
      </span>
    </el-dialog>

    <!-- 治疗订单 -->
    <el-dialog
      title="治疗订单"
      width="40%"
      :visible.sync="treatOrderDialogVisible"
    >
      <div
        style="
          text-align: left;
          padding-left: 80px;
          line-height: 50px;
          font-size: 18px;
        "
      >
        <span>康复治疗项目金额：{{ nowOrderAmount }}</span>
        <br />
        <!-- <span>治疗总次数: {{ treatTotalCount }}</span>
        <br />
        <span>完成治疗: {{ finishCount }}</span>
        <br /> -->
        <span>退款金额: {{ refundAmount }}{{ remark }}</span>
      </div>
      <span slot="footer">
        <el-button @click="treatOrderDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirmRefund">确认退款</el-button>
      </span>
    </el-dialog>

    <!-- 订单取消二次弹框 -->
    <el-dialog
      title="订单取消"
      width="40%"
      :visible.sync="cancelOrderDialogVisible"
    >
      <div>确认取消当前用户订单吗？</div>
      <span slot="footer">
        <el-button @click="cancelOrderDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirmCancelOrder">确认</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  data() {
    return {
      // 处置方案-药物列表
      medicalList: [],
      // 取消订单的编号
      cancelOrderSn: "",
      // 退款订单的编号
      refundOrderSn: "",
      tiaoJiaOrderSn: "",
      form: null,
      // 用户订单取消dialog
      cancelOrderDialogVisible: false,
      // 调价dialog
      changePriceDialogVisible: false,
      ZhiLiaoChangePriceDialogVisible: false,
      ZhiLiaoChangePriceItem: {
        list: [],
        orderSn: "",
      },

      // 挂号订单退款dialog
      registrationOrderDialogVisible: false,
      // 治疗订单退款dialog
      treatOrderDialogVisible: false,
      totalList: [],
      pageTotal: 0,
      // 订单列表请求参数
      orderParams: {
        pageNum: 1,
        pageSize: 10,
        patientName: "",
        orderSn: "",
        statusList: "",
      },
      // 订单状态列表
      orderStatusList: [
        {
          value: "",
          label: "全部",
        },
        {
          value: 0,
          label: "待支付",
        },
        {
          value: 1,
          label: "已支付",
        },
        {
          value: 2,
          label: "已取消",
        },
        {
          value: 3,
          label: "退款中",
        },
        {
          value: 4,
          label: "已退款",
        },
      ],
      // 订单原价 / 原始订单金额
      originalPrice: "",
      // 订单金额(调价弹框调价后的新价格)
      newPrice: "",
      // 订单金额(退款dialog中的)
      nowOrderAmount: "",
      // 退款金额(退款dialog中的)
      refundAmount: "",
      // 退款tip(退款dialog中的)
      remark: "",
      // 完成治疗次数(治疗订单dialog中的)
      finishCount: "",
      // 治疗总次数(治疗订单dialog中的)
      treatTotalCount: "",
    };
  },
  computed: {
    ...mapState({
      equipment: (state) => state.equipment,
    }),
  },
  mounted() {
    if (this.equipment == "pad") {
      this.orderParams.pageSize = 6;
    } else {
      this.orderParams.pageSize = 9;
    }

    if (this.$route.query.patientName) {
      this.orderParams.patientName = this.$route.query.patientName;
    }
    if (this.$route.query.orderSn) {
      this.orderParams.orderSn = this.$route.query.orderSn;
    }
    this.getOrderList();
    this.getPlanProjectConfig();
  },
  methods: {
    // 获取就诊人处置方案的配置信息
    async getPlanProjectConfig() {
      const { data } = await this.$api.baseApis.getPlanProjectConfig();
      this.medicalList = data;

      console.log("获取到的处置方案的配置信息", data);
    },
    // 获取订单列表
    async getOrderList() {
      const { data } = await this.$api.baseApis.getOrderList(this.orderParams);
      console.log(data);
      this.totalList = data.list;
      this.pageTotal = data.total;
    },
    // 订单类型-转化
    formatOrderType(row) {
      const MAP = {
        1: "挂号",
        2: "治疗",
      };
      return MAP[row.orderType];
    },
    // 面诊医生-转化
    formatDoctorName(row) {
      if (row.orderType == 1) {
        return row.workerVO.name + "(医生)";
      }
      if (row.orderType == 2) {
        if (row.appointmentVO) {
          return row.appointmentVO.name + "(治疗师)";
        } else {
          return row.workerVO.name + "(医生)";
        }
      }
    },
    // 就诊项目-转化
    formatProjectName(row) {
      if (row.orderType == 1) {
        return "医生面诊";
      } else {
        return row.treatmentVO?.treatmentItemVOS?.find(
          (item) => item.projectType == 1
        ).itemName;
      }
    },
    // 订单状态-转化
    formatOrderStatus(row) {
      const MAP = {
        0: "待支付",
        1: "已支付",
        2: "已取消",
        3: "退款中",
        4: "已退款",
      };
      return MAP[row.orderStatus];
    },
    // 进度-转化
    formatProgress(row) {
      if (!row.appointmentVO && !row.medicalRecordStrageVO) return "--";
      else if (!row.appointmentVO && row.medicalRecordStrageVO)
        return `完成进度${row.medicalRecordStrageVO?.medicalRecordVOS[0]?.progress}/${row.medicalRecordStrageVO?.medicalRecordVOS[0]?.totalSessions}`;
      else
        return (
          row.appointmentVO?.scheduleDate +
          " " +
          row.appointmentVO?.startTime +
          "-" +
          row.appointmentVO?.endTime
        );
    },
    // 搜索订单
    doSearch() {
      this.orderParams.pageNum = 1;
      this.getOrderList();
    },
    // 切换页码
    currentChange(page) {
      this.orderParams.pageNum = page;
      this.getOrderList();
    },
    // 调价dialog
    changePrice(price, patientId, obj) {
      if (obj.canAdjustAmount === false) {
        this.$message.warning("当前订单不可调价");
        return;
      }
      this.originalPrice = price;
      this.tiaoJiaOrderSn = patientId;
      this.changePriceDialogVisible = true;
    },
    // 解决输入不了
    inputChange(e) {
      this.$forceUpdate(e);
    },
    // 治疗调价
    changePriceZhiLiao(item, orderSn, obj) {
      if (obj.canAdjustAmount === false) {
        this.$message.warning("当前订单不可调价");
        return;
      }

      this.ZhiLiaoChangePriceItem = {
        list: JSON.parse(JSON.stringify(item)).treatmentItemVOS,
        orderSn,
      };
      this.ZhiLiaoChangePriceDialogVisible = true;
    },

    // 调价-确定
    async updatePrice() {
      await this.$api.baseApis.updateOrderPrice({
        amount: this.newPrice,
        orderSn: this.tiaoJiaOrderSn,
      });
      this.changePriceDialogVisible = false;
      this.$message.success("调价成功");
      this.tiaoJiaOrderSn = "";

      let _this = this;
      setTimeout(function () {
        if (_this.orderParams.patientName || _this.orderParams.orderSn) {
          _this.getOrderList();
        } else {
          location.reload();
        }
      }, 600);
    },

    // 治疗调价确认
    async ZhiLiaoUpdatePrice() {
      console.log(772, this.ZhiLiaoChangePriceItem);
      let isFull = true;
      let isNotFu = true;
      let isSure = true;

      for (let item of this.ZhiLiaoChangePriceItem.list) {
        if (item.canAdjustAmount == true) {
          if (item.NewTotalPrice == "") {
            isFull = false;
          }
          if (Number(item.NewTotalPrice) < 0) {
            isNotFu = false;
          }
          if (Number(item.NewTotalPrice) >= 0) {
            isSure = true;
          } else {
            isSure = false;
          }
        }
      }
      if (!isFull) {
        this.$message.warning("请填写全部价格");
        return;
      }
      if (!isNotFu) {
        this.$message.warning("请填写大于等于0的价格");
        return;
      }
      if (!isSure) {
        this.$message.warning("请填写大于等于0的数字");
        return;
      }

      console.log(881, this.ZhiLiaoChangePriceItem);

      let postObj = {
        params: [],
        zlOrderSn: this.ZhiLiaoChangePriceItem.orderSn,
      };
      for (let item of this.ZhiLiaoChangePriceItem.list) {
        if (item.canAdjustAmount == true) {
          postObj.params.push({
            id: item.id,
            totalPrice: Number(item.NewTotalPrice),
          });
        }
      }

      console.log(11, postObj);

      const { data } = await this.$api.baseApis.modifyZlOrderPrice(postObj);

      if (data === true) {
        this.ZhiLiaoChangePriceDialogVisible = false;
        this.$message.success("调价成功");

        let _this = this;
        setTimeout(function () {
          if (_this.orderParams.patientName || _this.orderParams.orderSn) {
            _this.getOrderList();
          } else {
            location.reload();
          }
        }, 600);
      }
    },

    // 退款dialog
    async orderRefund(ordertype, patienId) {
      this.refundOrderSn = patienId;
      // 退款金额查询
      const { data } = await this.$api.baseApis.getRefundAmount({
        orderSn: patienId,
      });
      console.log(data);
      this.nowOrderAmount = data.orderAmount;
      this.refundAmount = data.refundAmount;
      this.remark = data.remark ? "(" + data.remark + ")" : "";
      this.finishCount = data.finishCount;
      this.treatTotalCount = data.total;
      // 区分挂号单退款dialog和治疗单dialog
      if (ordertype == 1) {
        this.registrationOrderDialogVisible = true;
      } else {
        this.treatOrderDialogVisible = true;
      }
    },
    // 退款
    async confirmRefund() {
      const { data } = await this.$api.baseApis.applyRefund({
        orderSn: this.refundOrderSn,
      });
      this.$message.success("退款成功");
      this.refundOrderSn = "";
      this.registrationOrderDialogVisible = false;
      this.treatOrderDialogVisible = false;
      let _this = this;
      setTimeout(function () {
        if (_this.orderParams.patientName || _this.orderParams.orderSn) {
          _this.getOrderList();
        } else {
          location.reload();
        }
      }, 600);
    },
    // 取消订单dialog
    async cancelOrder(orderSn) {
      this.cancelOrderDialogVisible = true;
      this.cancelOrderSn = orderSn;
    },
    // 确认取消订单
    async confirmCancelOrder() {
      const { data } = await this.$api.baseApis.cancelOrder({
        orderSn: this.cancelOrderSn,
      });
      if (data.code === 200) {
        this.$message.success("取消订单成功");
        this.cancelOrderSn = "";
      }
      this.cancelOrderDialogVisible = false;

      let _this = this;
      setTimeout(function () {
        if (_this.orderParams.patientName || _this.orderParams.orderSn) {
          _this.getOrderList();
        } else {
          location.reload();
        }
      }, 600);
    },
    // 跳转到用户资料页面
    goPatientInformation(patientSn, orderSn) {
      this.$router.push({
        name: "patientInformation",
        query: {
          patientSn: patientSn,
          orderSn: orderSn,
        },
      });
    },
    goPayCodeIsZ(orderSn) {
      this.$confirm("确认0元支付吗", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.goPayCode(orderSn);
          console.log("调0元接口");
        })
        .catch(() => {});
    },

    // 获取支付码
    async goPayCode(orderSn) {
      console.log("orderSn", orderSn);
      const { data } = await this.$api.baseApis.WeiXinQrcodePay({
        paymentType: "WEIXIN_QRCODE_PAY",
        orderNum: orderSn,
        subject: "medical_admin",
      });
      console.log("data", data);
      if (data.qrContent && data.qrContent == "支付成功") {
        this.$message.success("0元支付成功");
        let _this = this;
        setTimeout(function () {
          if (_this.orderParams.patientName || _this.orderParams.orderSn) {
            _this.getOrderList();
          } else {
            location.reload();
          }
        }, 600);

        return;
      }

      if (data.qrImg) {
        const h = this.$createElement;
        this.$msgbox({
          title: "付款二维码",
          message: h("p", null, [
            h("img", {
              attrs: {
                src: data.qrImg,
              },
              style:
                "width:200px;height:200px;box-sizing:border-box;margin-left:96px;",
            }),
          ]),
          showCancelButton: false,
          confirmButtonText: "下载二维码",
          // cancelButtonText: "关闭",
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = "下载中...";
              const link = document.createElement("a");
              link.href = data.qrImg;
              link.download = `付款二维码${orderSn}`;
              link.click();
              setTimeout(() => {
                done();
                setTimeout(() => {
                  instance.confirmButtonLoading = false;
                }, 300);
              }, 2000);
            } else {
              done();
            }
          },
        }).then((action) => {
          if (action == "confirm") {
            this.$message({
              type: "success",
              message: "下载成功",
            });
          }
        });
      }
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  width: 100%;
  .patient-navbar {
    padding-right: 10px;
    align-items: center;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    margin-bottom: 20px;

    .search-btn {
      cursor: pointer;
      text-align: center;
      width: 90px;
      height: 32px;
      border-radius: 2px;
      background: #2971eb;
      font-size: 14px;
      line-height: 32px;
      color: #ffffff;
      transition: transform 0.2s ease;
    }
    .search-btn:hover {
      transform: scale(1.1);
    }
  }
  // 表单样式
  .patient-form {
    box-sizing: border-box;
    overflow-y: auto;
    height: 710px;
    overflow: auto;
  }
  // 分页器样式
  .page-container {
    text-align: right;
    margin-right: -10px;
  }
}

// table表头的颜色
::v-deep(.center-table th) {
  background: #f7f8fa;
}

.changePriceBody {
  box-sizing: border-box;
  width: 100%;
  position: relative;
}

// 调价dialog居中样式
::v-deep(.my-centered-dialog .el-dialog__body) {
  display: flex;
  justify-content: center;
}

::v-deep(.icon-wrapper) {
  transition: transform 0.2s ease;
}

::v-deep(.icon-wrapper:hover) {
  transform: scale(1.2);
}

// 平板适配
@media screen and (max-width: 1300px) {
  .patient-form {
    box-sizing: border-box;
    overflow-y: auto;
    height: 521px !important;
    overflow: auto;
  }
}
</style>
