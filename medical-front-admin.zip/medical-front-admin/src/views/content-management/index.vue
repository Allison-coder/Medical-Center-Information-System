<template>
  <div class="content-management___page">
    <article class="article-banner">
      <header>
        <p class="title">Banner设置</p>
        <el-button type="primary" @click="updateBanners">更新</el-button>
      </header>
      <section v-if="bannerData.length >= 0">
        <div class="banner" v-for="(item, index) in bannerData" :key="item.id">
          <img class="banner-image" :src="item.url" />
          <div class="banner-handle">
            <span
              class="banner-handle--link"
              @click="handleOpenLinkDialog(item.link, index)"
              >设置链接</span
            >
            <div class="banner-handle--operate">
              <i
                v-if="index !== 0"
                class="el-icon-back"
                @click="handleBannerSort(index, 'backward')"
              ></i>
              <i
                v-if="index !== bannerData.length - 1"
                class="el-icon-right"
                @click="handleBannerSort(index, 'forward')"
              ></i>
              <i
                class="delete el-icon-delete"
                @click="handleDelBanner(index)"
              ></i>
            </div>
          </div>
        </div>
        <div class="banner banner__upload" v-if="bannerData.length < 5">
          <el-upload
            :auto-upload="false"
            action="/"
            :show-file-list="false"
            :before-upload="beforeUpload"
            :on-change="handleUpload('banner')"
          >
            <i class="el-icon-upload" style="font-size: 32px"></i>
            <div class="el-upload__text">
              <em>点击上传</em>
            </div>
          </el-upload>
        </div>
      </section>
    </article>
    <article class="article-category">
      <header>
        <p class="title">分类设置</p>
        <el-button type="primary" @click="updateCategories">更新</el-button>
        <el-button type="primary" round plain @click="handleDelCategory"
          >删除分类</el-button
        >
        <el-button type="primary" round plain @click="handleOpenCategoryDialog"
          >创建分类</el-button
        >
      </header>
      <section v-if="categoryData.length > 0">
        <div class="list">
          <div
            :class="['item', index == categoryIdx ? 'item__active' : '']"
            v-for="(item, index) in categoryData"
            :key="item.id"
            @click="handleClickCategory(index)"
          >
            <span>{{ item.name }}</span>
          </div>
        </div>
        <div class="content">
          <div class="name">
            <span>编辑名称：</span>
            <el-input
              :maxlength="10"
              v-model="categoryData[categoryIdx].name"
              style="width: 200px"
            ></el-input>
          </div>
          <div class="icon">
            <span>图标：</span>
            <el-upload
              action="/"
              :show-file-list="false"
              :before-upload="beforeUpload"
              :on-change="handleUpload('icon')"
            >
              <img
                v-if="categoryData[categoryIdx].url"
                :src="categoryData[categoryIdx].url"
              />
              <el-button type="primary" icon="el-icon-upload">上传</el-button>
            </el-upload>
            <span class="size">尺寸：40*40</span>
          </div>
          <div class="sort">
            <span>排序：</span>
            <i
              v-if="categoryIdx !== 0"
              class="el-icon-back"
              @click="handleCategorySort('backward')"
            ></i>
            <i
              v-if="categoryIdx !== categoryData.length - 1"
              class="el-icon-right"
              @click="handleCategorySort('forward')"
            ></i>
          </div>
        </div>
      </section>
    </article>
    <article class="content">
      <header>
        <p class="title">内容设置</p>
        <el-button
          type="primary"
          round
          plain
          @click="handleOpenContentDialog(null)"
          >创建内容</el-button
        >
      </header>
      <section v-if="recordData.length > 0">
        <el-table :data="recordData" :border="true" key="recordData">
          <el-table-column prop="title" label="内容标题" :align="'center'" />
          <el-table-column prop="url" label="图片" :align="'center'">
            <template slot-scope="scope">
              <img :src="scope.row.url" />
            </template>
          </el-table-column>
          <el-table-column
            prop="createTime"
            label="创建时间"
            :align="'center'"
          />
          <el-table-column
            prop="createUser"
            label="创建人账号"
            :align="'center'"
          >
            <template slot-scope="scope">
              <span>{{ scope.row.workerVO.name }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="homeShow" label="首页" :align="'center'">
            <template slot-scope="scope">
              <span v-if="scope.row.showStatus" style="color: #e95720">
                展示
              </span>
              <span v-else>不展示</span>
            </template>
          </el-table-column>
          <el-table-column prop="operate" label="操作" :align="'center'">
            <template slot-scope="scope">
              <el-button
                type="text"
                primary
                @click="handleOpenContentDialog(scope.row)"
                >编辑</el-button
              >
              <el-button type="text" primary @click="updateShow(scope.row)"
                >首页{{ scope.row.showStatus ? "隐藏" : "展示" }}</el-button
              >
              <el-button type="text" primary @click="deleteRecord(scope.row)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          style="text-align: right; margin-top: 12px"
          layout="prev, pager, next"
          :total="recordPages.total"
          :page-size="recordPages.pageSize"
          :current-page="recordPages.pageNum"
          @current-change="handlePageChange"
        >
        </el-pagination>
      </section>
    </article>

    <!-- banner链接 -->
    <el-dialog
      key="set-link"
      custom-class="set-link-dialog"
      title="提示"
      :visible="isShowLinkDialog"
      width="30%"
      :before-close="handleCloseLinkDialog"
    >
      <el-input v-model="bannerLink" placeholder="请输入链接"></el-input>
      <el-button type="primary" style="margin-top: 8px" @click="handleSetLink"
        >确定</el-button
      >
    </el-dialog>

    <!-- 创建分类 -->
    <el-dialog
      key="create-category"
      custom-class="create-category-dialog"
      title="提示"
      :visible="isShowCategoryDialog"
      width="30%"
      :before-close="handleCloseCategoryDialog"
    >
      <el-input v-model="categoryName" placeholder="请输入分类名称"></el-input>
      <el-button
        type="primary"
        style="margin-top: 8px"
        @click="handleCreateCategory"
        >确定</el-button
      >
    </el-dialog>

    <!-- 内容新增编辑 -->
    <el-dialog
      key="content"
      custom-class="content-dialog"
      title="编辑内容"
      :visible="isShowContentDialog"
      :before-close="handleCloseContentDialog"
    >
      <el-form
        class="content-form"
        ref="contentForm"
        key="contentForm"
        :model="contentForm"
        :rules="formRules"
        :label-position="'left'"
        label-width="80px"
      >
        <el-form-item label="内容标题" prop="title" size="small">
          <el-input
            type="textarea"
            :rows="3"
            resize="none"
            :maxlength="30"
            v-model="contentForm.title"
            placeholder="请输入内容标题"
          />
        </el-form-item>
        <el-form-item label="照片上传" prop="url">
          <el-upload
            :auto-upload="false"
            action="/"
            :show-file-list="false"
            :before-upload="beforeUpload"
            :on-change="handleUpload('content')"
          >
            <img v-if="contentForm.url" :src="contentForm.url" />
            <template v-else>
              <i class="el-icon-upload" style="font-size: 32px"></i>
              <em>点击上传</em>
            </template>
          </el-upload>
        </el-form-item>
        <el-form-item label="链接" prop="link" size="small">
          <el-input
            type="textarea"
            :rows="3"
            resize="none"
            v-model="contentForm.link"
            placeholder="请输入链接"
          />
        </el-form-item>
        <el-form-item class="btn-item">
          <el-button type="primary" @click="createOrUpdateRecord"
            >提交</el-button
          >
          <!-- <el-button @click="resetForm('ruleForm')">重置</el-button> -->
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import Axios from "axios";
export default {
  data() {
    return {
      isShowLinkDialog: false,
      isShowCategoryDialog: false,
      isShowContentDialog: false,

      bannerLink: "",
      bannerLinkIdx: 0,

      categoryIdx: 0,
      categoryName: "",

      bannerData: [],
      categoryData: [],
      recordData: [],
      recordPages: {
        pageNum: 1,
        pageSize: 5,
        total: 1,
      },

      // 上传图片表单
      contentForm: {
        id: null,
        title: "",
        link: "",
        urlKey: "",
        url: "",
      },
      // 上传图片校验规则
      formRules: {
        title: [{ required: true, message: "请输入标题", trigger: "blur" }],
        link: [{ required: true, message: "请输入链接", trigger: "blur" }],
        url: [{ required: true, message: "请上传图片", trigger: "blur" }],
      },
    };
  },
  watch: {},
  async mounted() {
    this.getBanners();
    await this.getCategories();
    this.getRecords();
  },
  methods: {
    // 接口请求
    async getBanners() {
      const { data } = await this.$api.contentApis.getBanners();
      this.bannerData = data;
    },
    async updateBanners() {
      // 按前端展示顺序改写rank
      this.bannerData.forEach((data, index) => {
        data.rank = index;
        if (data.urlKey) delete data.url; // url与urlKey互斥，url表示原来的扸，urlKey表示新增或修改过的
      });
      const { data } = await this.$api.contentApis.updateBanners(
        this.bannerData
      );
      this.$notify({
        title: "更新成功",
        type: "success",
      });
      this.getBanners();
    },

    async getCategories() {
      const { data } = await this.$api.contentApis.getCategories();
      this.categoryData = data;
    },
    async updateCategories() {
      let isValid = true;
      // 按前端展示顺序改写rank
      this.categoryData.forEach((data, index) => {
        data.rank = index;
        if (!data.name) isValid = false;
        if (data.urlKey) delete data.url; // url与urlKey互斥，url表示原来的扸，urlKey表示新增或修改过的
      });
      if (!isValid) return this.$notify({ title: "请补充名称", type: "error" });
      const { data } = await this.$api.contentApis.updateCategories(
        this.categoryData
      );
      this.$notify({
        title: "更新成功",
        type: "success",
      });
      // this.categoryIdx = 0
      this.getCategories();
    },

    async getRecords() {
      const { id: categoryId = "" } = this.categoryData[this.categoryIdx];
      // 如果新增则没有
      if (!categoryId) return (this.recordData = []);
      const { data } = await this.$api.contentApis.getRecords({
        categoryId,
        ...this.recordPages,
      });
      this.recordData = data.list;
      this.recordPages = {
        pageNum: data.currentPage,
        total: data.total,
        pageSize: data.pageSize,
      };
    },
    async createOrUpdateRecord() {
      let { id, title, url, urlKey, link } = this.contentForm;
      let { id: categoryId = "" } = this.categoryData[this.categoryIdx];
      this.$refs["contentForm"].validate(async (valid) => {
        if (valid) {
          const { data } = await this.$api.contentApis.createOrUpdateRecord({
            id,
            title,
            link,
            // url与urlKey互斥，url表示原来的扸，urlKey表示新增或修改过的
            url: urlKey ? null : url,
            urlKey,
            categoryId,
          });
          this.$notify({
            title: "编辑成功",
            type: "success",
          });
          this.handleCloseContentDialog();
          this.handleReloadRecords();
        } else {
          this.$notify({
            title: "请完善表单",
            type: "warn",
          });
        }
      });
    },
    async updateShow(rowData) {
      const { id, showStatus } = rowData;
      const show = showStatus ? 0 : 1;
      const { data } = await this.$api.contentApis.updateShow({ id, show });
      this.$notify({
        title: "更新成功",
        type: "success",
      });
      this.getRecords();
    },
    async deleteRecord(rowData) {
      const { id } = rowData;
      const { data } = await this.$api.contentApis.deleteRecord(id);
      this.$notify({
        title: "删除成功",
        type: "success",
      });
      this.handleReloadRecords();
    },

    // 用户交互

    // ---轮播图---
    handleBannerSort(index, type) {
      const data = this.bannerData[index];
      this.bannerData.splice(index, 1);
      if (type === "backward") this.bannerData.splice(index - 1, 0, data);
      else this.bannerData.splice(index + 1, 0, data);
    },
    // banner链接弹窗
    handleOpenLinkDialog(link, index) {
      this.bannerLink = link;
      this.bannerLinkIdx = index;
      this.isShowLinkDialog = true;
    },
    handleCloseLinkDialog() {
      this.isShowLinkDialog = false;
    },
    handleSetLink() {
      this.bannerData[this.bannerLinkIdx].link = this.bannerLink;
      this.handleCloseLinkDialog();
    },
    handleDelBanner(index) {
      this.bannerData.splice(index, 1);
    },

    // ---分类---
    handleClickCategory(index) {
      this.categoryIdx = index;
      this.handleReloadRecords();
    },
    // 创建分类弹窗
    handleOpenCategoryDialog() {
      this.isShowCategoryDialog = true;
    },
    handleCreateCategory() {
      this.categoryData.push({
        name: this.categoryName,
        url: "",
      });
      // this.categoryIdx = this.categoryData.length - 1
      // this.recordData = []
      this.handleCloseCategoryDialog();
    },
    handleCloseCategoryDialog() {
      this.isShowCategoryDialog = false;
      this.categoryName = "";
    },
    handleCategorySort(type) {
      const data = this.categoryData[this.categoryIdx];
      this.categoryData.splice(this.categoryIdx, 1);

      if (type === "backward") this.categoryIdx -= 1;
      else this.categoryIdx += 1;
      this.categoryData.splice(this.categoryIdx, 0, data);
    },
    handleDelCategory() {
      if (this.categoryData.length <= 0) return;
      this.categoryData.splice(this.categoryIdx, 1);
      this.categoryIdx = 0;
      this.handleReloadRecords();
    },

    // ---内容---
    // 创建内容弹窗
    handleOpenContentDialog(rowData) {
      if (rowData) {
        console.log("rowData", rowData);
        const { id, title, url, link } = rowData;
        this.contentForm = {
          id,
          title,
          url,
          link,
        };
        // 新增时直接关闭，校验会保持到编辑时还展示。编辑时立即触发一次表单校验
        this.$nextTick(() => this.$refs["contentForm"].validate());
      }
      this.isShowContentDialog = true;
    },
    handleCloseContentDialog() {
      this.isShowContentDialog = false;
      this.contentForm = this.$options.data.call(this).contentForm;
    },
    handleReloadRecords() {
      console.log("handleReloadRecords");
      this.recordPages = this.$options.data.call(this).recordPages;
      this.getRecords();
    },
    async handlePageChange(pageNum) {
      // 补充筛选信息
      this.recordPages = {
        ...this.recordPages,
        pageNum,
      };
      this.getRecords();
    },

    // 图片上传前校验
    async beforeUpload(file) {
      const allowImgType = ["image/jpeg", "image/png", "image/jpg"].includes(
        file.type
      );
      const isLt5M = file.size / 1024 / 1024 < 5;
      if (!allowImgType) {
        this.$message.error("上传图片只能是 PNG/JPG/JPEG 格式!");
      }
      if (!isLt5M) {
        this.$message.error("上传图片大小不能超过 5MB!");
      }
      return allowImgType && isLt5M;
    },
    // 图片自定义上传
    handleUpload(type) {
      return async (file) => {
        console.log("file.raw", file.raw);
        const { data } = await this.$api.baseApis.uploadFile();

        const formData = new FormData();
        formData.append("OSSAccessKeyId", data.accessid);
        formData.append("policy", data.policy);
        formData.append("Signature", data.signature);
        formData.append("key", data.key);
        formData.append("file", file.raw);
        formData.append("x-oss-content-type", file.raw.type);

        const response = await Axios.post(data.accessHost, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        if (response.status >= 200 && response.status < 300) {
          // 成功
          const url = data.accessHost + "/" + data.key;
          const urlKey = data.key;
          if (type == "banner") {
            this.bannerData.push({
              urlKey,
              url,
              link: "",
            });
          } else if (type == "icon") {
            this.categoryData[this.categoryIdx].url = url;
            this.categoryData[this.categoryIdx].urlKey = urlKey;
          } else if (type == "content") {
            this.contentForm.url = url;
            this.contentForm.urlKey = urlKey;
          }
        } else {
          throw response;
        }
      };
    },
  },
};
</script>

<style scoped lang="less">
.content-management___page {
  width: 100%;
  height: 842px !important;
  box-sizing: border-box;
  background: #fff;
  padding: 20px;
  border-radius: 6px;
  box-shadow: 0 10px 30px 0 rgba(85, 85, 85, 0.15);
  overflow-y: auto;
  // ::v-deep .el-table_1_column_2 {
  //     background-color: red;
  // }
  .el-button--primary.is-plain {
    color: white;
  }

  > article {
    margin-bottom: 20px;
    > header {
      display: flex;
      align-items: center;
      .title {
        font-size: 16px;
        font-weight: bold;
        margin-right: 12px;
      }
    }
    > section {
      margin-top: 12px;
    }
  }
  .article-banner {
    > section {
      width: 100%;
      display: flex;
      align-items: flex-start;
      flex-wrap: wrap;
      gap: 20px;

      .banner {
        &__upload {
          border: 1px solid #dcdfe6;
          border-radius: 4px;
          width: 370px;
          height: 128px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        &-image {
          border: 1px solid #e8e8e8;
          border-radius: 16px;
          width: 370px;
          height: 128px;
          // background-color: red;
          object-fit: contain;
        }
        &-handle {
          display: flex;
          justify-content: space-between;
          align-items: center;
          &--link {
            cursor: pointer;
            font-size: 12px;
            color: #435fde;
          }
          &--operate {
            .delete {
              color: red;
            }
          }
        }
      }
    }
  }
  .article-category {
    .list {
      display: flex;
      // justify-content: center;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
      .item {
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 8px 20px;
        background-color: #ebedf0;
        color: #646566;
        font-size: 14px;
        border-radius: 34px;
        &__active {
          background-color: rgba(233, 87, 32, 0.15);
          color: #e95720;
          font-weight: bold;
        }
      }
    }
    .content {
      display: flex;
      flex-direction: column;
      gap: 12px 0;
      > div {
        display: flex;
        align-items: center;
        .size {
          margin-left: 12px;
        }
      }
      .icon {
        display: flex;
        align-items: center;
        img {
          width: 40px;
          height: 40px;
          margin-right: 12px;
        }
      }
    }
  }
}
</style>

<style lang="less">
.content-management___page {
  .el-icon-delete {
    font-size: 18px;
  }
  .el-icon-back,
  .el-icon-right {
    font-size: 14px;
    color: #2c3e50;
    border: 1px solid #2c3e50;
    border-radius: 34px;
    padding: 4px;
    margin: 0 4px;
  }
  .el-upload {
    display: flex;
    align-items: center;
  }
  .set-link-dialog,
  .create-category-dialog {
    .el-dialog__body {
      text-align: right;
    }
  }
  .content-dialog {
    width: 700px !important;
    .content-form {
      display: flex;
      flex-direction: column;
      align-items: center;
      .el-form-item {
        // .el-form-item__label {
        //   width: 80px;
        // }
        .el-form-item__content {
          width: 400px;
          .el-input--small {
            width: 400px;
          }
        }
        &.btn-item {
          .el-form-item__content {
            text-align: right;
          }
        }
      }
    }
    img {
      width: 78px !important;
      height: 78px !important;
      object-fit: contain;
    }
  }
  .el-table__body-wrapper {
    img {
      width: 78px !important;
      height: 78px !important;
      object-fit: contain;
    }
  }
  .el-pager {
    .active {
      color: #fff !important;
    }
  }
}
</style>
