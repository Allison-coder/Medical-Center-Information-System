<template>
  <div class="patient-management">
    <div class="patient-navbar">
      <span style="font-size: 18px; margin-right: 100px">任务列表</span>
      <span style="color: #666666; margin-right: 18px">患者姓名:</span>
      <span style="color: #666666; margin-right: 80px">{{
        queryData.patientName
      }}</span>

      <span>任务状态</span>
      <el-select
        style="width: 160px; margin-left: 20px; margin-right: 20px"
        placeholder="请选择任务状态"
        v-model="params.taskStatus"
        clearable
        @change="doSearch"
      >
        <el-option
          v-for="item in orderStatusList"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>

      <el-button
        type="success"
        @click="
          goYuYueGuaHao(
            queryData.orderSn,
            queryData.patientSn,
            queryData.patientName
          )
        "
        icon="el-icon-plus"
        >预约新面诊</el-button
      >
      <el-button
        type="success"
        @click="goYuYue('', queryData.patientSn, 0)"
        icon="el-icon-plus"
        >预约新治疗</el-button
      >
      <el-button
        style="position: absolute; top: 0px; right: 0px"
        type="primary"
        @click="goBack()"
        icon="el-icon-circle-close"
        >关闭</el-button
      >
    </div>
    <div class="patient-form">
      <el-table
        style="width: 100%"
        :data="TaskList"
        class="center-table"
        row-key="orderSn"
        default-expand-all
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
        :span-method="arraySpanMethod"
      >
        <el-table-column
          label="任务类型"
          width="180"
          align="center"
          prop="taskDesc"
        />

        <el-table-column
          label="订单金额"
          align="center"
          :formatter="formatOrderAmount"
        />
        <el-table-column
          label="订单状态"
          align="center"
          :formatter="formatOrderStatus"
        />
        <el-table-column label="任务信息" align="center" width="180">
          <template #default="{ row }">
            <div v-if="row.adminName">
              {{ row.adminType + ":" + row.adminName }}
            </div>
            <div>{{ row.taskTime }}</div>
          </template>
        </el-table-column>

        <el-table-column
          label="任务状态"
          align="center"
          :formatter="formatTaskStatus"
        />

        <el-table-column label="操作" width="290" align="center" fixed="right">
          <template #default="{ row }">
            <div style="display: flex; justify-content: space-evenly">
              <!-- diagnosisFlag	能否预约问诊标识 0-能 1-不能 -->
              <!-- <el-button
                @click="goYuYueGuaHao(row.orderSn, patientSn, row.patientName)"
                class="icon-wrapper"
                type="text"
                v-if="row.diagnosisFlag === 0"
                >预约面诊</el-button
              > -->
              <el-button
                @click="reportPatient(row)"
                class="icon-wrapper"
                type="text"
                v-if="row.taskType === 1 && row.taskStatus === 3"
                >报到</el-button
              >

              <el-button
                @click="startTreat(row)"
                class="icon-wrapper"
                type="text"
                v-if="row.taskType === 1 && row.taskStatus === 4"
                >开始面诊</el-button
              >
              <el-button
                @click="endTreat(row)"
                class="icon-wrapper"
                type="text"
                v-if="row.taskType === 1 && row.taskStatus === 5"
                >完成面诊</el-button
              >

              <!-- 面诊 -->
              <div class="faceDoctor" v-if="row.taskType === 1">
                <el-button
                  type="text"
                  class="icon-wrapper"
                  @click="goPatientInformation(patientSn, row.orderSn)"
                  >资料</el-button
                >
                <el-button
                  type="text"
                  class="icon-wrapper"
                  @click="goOrder(row.patientName)"
                  >订单</el-button
                >
              </div>

              <!-- 治疗 -->
              <div
                class="treat"
                v-if="row.taskType === 2 || row.taskType === 3"
              >
                <el-button
                  class="icon-wrapper"
                  type="text"
                  @click="
                    goYuYue(
                      row.orderSn,
                      patientSn,
                      row.singleAppointmentDuration
                    )
                  "
                  v-if="row.taskType === 2 && row.taskStatus === 2"
                  >预约治疗</el-button
                >

                <!-- 任务状态： 1-待支付 2-待预约 3-待报到 4-候诊中（面诊单）/等候诊疗（治疗单） 5-就诊中（面诊单）/治疗中（治疗单） 6-已完成（面诊单）/完成治疗（治疗单）7-已取消 8-已退款 -->
                <el-button
                  class="icon-wrapper"
                  type="text"
                  @click="cancelAppointment(row)"
                  v-if="row.taskType === 2 && row.taskStatus === 3"
                  >取消预约治疗</el-button
                >

                <el-button
                  @click="reportPatient(row)"
                  class="icon-wrapper"
                  type="text"
                  v-if="
                    (row.taskType === 2 || row.taskType === 3) &&
                    row.taskStatus === 3
                  "
                  >报到</el-button
                >
                <el-button
                  @click="startMedical(row)"
                  class="icon-wrapper"
                  type="text"
                  v-if="
                    (row.taskType === 2 || row.taskType === 3) &&
                    row.taskStatus === 4
                  "
                  >开始治疗</el-button
                >
                <el-button
                  @click="endMedical(row)"
                  class="icon-wrapper"
                  type="text"
                  v-if="
                    (row.taskType === 2 || row.taskType === 3) &&
                    row.taskStatus === 5
                  "
                  >结束治疗</el-button
                >
                <el-button
                  class="icon-wrapper"
                  type="text"
                  @click="lookZhiLiaoOrderTopList(row)"
                  v-if="row.taskType === 2 && row.taskStatus === 1"
                  >治疗单</el-button
                >

                <el-button
                  type="text"
                  class="icon-wrapper"
                  @click="goPatientInformation(patientSn, row.orderSn)"
                  >资料</el-button
                >
                <el-button
                  type="text"
                  class="icon-wrapper"
                  @click="goOrder(row.patientName)"
                  >订单</el-button
                >
              </div>

              <!-- 近期任务是：-- ； 任务状态是：-- -->
              <div class="faceDoctor" v-if="row === undefined">
                <el-button
                  type="text"
                  class="icon-wrapper"
                  @click="goPatientInformation(patientSn, row.orderSn)"
                  >资料</el-button
                >
                <el-button
                  type="text"
                  class="icon-wrapper"
                  @click="goOrder(row.patientName)"
                  >订单</el-button
                >
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页器 -->
    <div class="page-container">
      <el-pagination
        layout="total, prev, pager, next"
        :current-page="params.pageNum"
        :total="total"
        :page-size="params.pageSize"
        @current-change="currentChange"
        background
      />
    </div>

    <!-- 预约治疗弹框 -->
    <el-dialog :visible.sync="isShowAppointment" width="1000px">
      <treatment-appointment
        v-if="isShowAppointment"
        @child-event="YuYueClose"
        @child-event-ok="YuYueCloseOk"
        :orderSn="YuYueOrderSn"
        :patientSn="YuYuePatientSn"
        :singleAppointmentDuration="YuYuesingleAppointmentDuration"
      ></treatment-appointment>
    </el-dialog>
    <!-- 预约面诊弹框 -->
    <el-dialog :visible.sync="isShowAppointmentGuaHao" width="1000px">
      <GuaHaoAppointment
        v-if="isShowAppointmentGuaHao"
        @child-event="YuYueCloseGuaHao"
        :orderSn="YuYueOrderSnGuaHao"
        :patientSn="YuYuePatientSnGuaHao"
        :patientName="YuYuePatientNameGuaHao"
      ></GuaHaoAppointment>
    </el-dialog>

    <!-- 专用治疗单弹框 -->
    <el-dialog
      v-if="detailTreatmentVisibleDialog"
      :visible.sync="detailTreatmentVisibleDialog"
      width="900px"
    >
      <treatmentSheet
        @child-event="ZhiLiaoClose"
        :ZhiLiaoOrderSn="ZhiLiaoOrderSn"
      >
      </treatmentSheet>
    </el-dialog>
  </div>
</template>

<script>
import TreatmentAppointment from "@/components/appointment/treatment-appointment.vue";
import TreatmentSheet from "@/components/treatmentSheet/treatmentSheet.vue";
import GuaHaoAppointment from "@/components/appointment/guahao-appointment.vue";

import { mapState } from "vuex";
export default {
  data() {
    return {
      lastPageNum: null,
      queryData: {
        // 患者姓名
        patientName: "",
        orderSn: "",
        patientSn: "",
      },
      patientSn: "",

      // 专用治疗单
      detailTreatmentVisibleDialog: false,
      treatmentDetailIsShow: true,
      ZhiLiaoOrderSn: "",
      roleForm: {
        name: "",
        roleId: "",
      },
      params: {
        taskStatus: "",
        pageNum: 1,
        pageSize: 10,
      },
      total: 0,
      // 患者列表
      TaskList: [],
      // 患者预约治疗弹框显示
      isShowAppointment: false,
      YuYueOrderSn: "",
      YuYuePatientSn: "",
      YuYuesingleAppointmentDuration: null,

      // 患者预约面诊弹框显示
      isShowAppointmentGuaHao: false,
      YuYueOrderSnGuaHao: "",
      YuYuePatientSnGuaHao: "",
      YuYuePatientNameGuaHao: "",

      // 任务状态列表
      orderStatusList: [
        {
          value: "",
          label: "全部",
        },
        {
          value: 2,
          label: "待预约",
        },
        {
          value: 3,
          label: "待报到",
        },
        {
          value: 4,
          label: "候诊中",
        },
        {
          value: 5,
          label: "就诊中",
        },
        {
          value: 6,
          label: "已完成",
        },
        {
          value: 7,
          label: "已取消",
        },
        {
          value: 8,
          label: "已退款",
        },
      ],
    };
  },
  components: {
    TreatmentAppointment,
    TreatmentSheet,
    GuaHaoAppointment,
  },
  mounted() {
    if (this.equipment == "pad") {
      this.params.pageSize = 6;
    } else {
      this.params.pageSize = 9;
    }

    if (this.$route.query) {
      this.queryData = this.$route.query;
      this.params.patientSn = this.queryData.patientSn;
      this.patientSn = this.queryData.patientSn;
      this.lastPageNum = this.$route.query.pageNum;
    }

    // 获取患者列表
    this.getTaskList();
  },
  computed: {
    ...mapState({
      equipment: (state) => state.equipment,
      roles: (state) => state.authInfo.roles,
    }),
  },
  methods: {
    doSearch() {
      this.params.pageNum = 1;
      this.getTaskList();
    },
    // 获取任务列表
    async getTaskList() {
      const { data } = await this.$api.baseApis.getPatientWorkPanel(
        this.params
      );
      console.log(9999, data.list);

      this.TaskList = data.list;

      this.total = data.total;
    },
    // 切换页码
    currentChange(page) {
      this.params.pageNum = page;
      this.getTaskList();
    },

    // 订单状态-转化
    formatOrderStatus(row) {
      const MAP = {
        0: "待支付",
        1: "已支付",
        2: "已取消",
        3: "退款中",
        4: "已退款",
      };
      return MAP[row.orderStatus];
    },
    formatTaskName(row) {
      // 任务类型，1：面诊，2：治疗方案 3-项目
      if (row.taskType == 1) {
        return "医生面诊";
      } else if (row.taskType == 2) {
        return "治疗方案";
      } else if (row.taskType == 3) {
        return "项目";
      }
    },
    formatOrderAmount(row) {
      if (row.orderAmount >= 0) {
        return "￥" + row.orderAmount;
      } else {
        return "--";
      }
    },
    formatTaskStatus(row) {
      // 1-待支付 2-待预约 3-待报到 4-候诊中（面诊单）/等候治疗（治疗单） 5-就诊中（面诊单）/治疗中（治疗单） 6-已完成（面诊单）/完成治疗（治疗单）7-已取消 8-已退款
      const MAP = {
        1: "待支付",
        2: "待预约",
        3: "待报到",
        7: "已取消",
        8: "已退款",
      };

      if (
        row.taskStatus == 1 ||
        row.taskStatus == 2 ||
        row.taskStatus == 3 ||
        row.taskStatus == 7 ||
        row.taskStatus == 8
      ) {
        return MAP[row.taskStatus];
      }

      if (row.taskType == 1) {
        const MAP2 = {
          4: "候诊中",
          5: "就诊中",
          6: "已完成",
        };

        if (row.taskStatus == 4 || row.taskStatus == 5 || row.taskStatus == 6) {
          return MAP2[row.taskStatus];
        }
      }
      if (row.taskType == 2 || row.taskType == 3) {
        const MAP3 = {
          4: "候诊中",
          5: "就诊中",
          6: "已完成",
        };

        if (row.taskStatus == 4 || row.taskStatus == 5 || row.taskStatus == 6) {
          return MAP3[row.taskStatus];
        }
      }
    },

    // 跳转-患者资料
    goPatientInformation(patientSn, orderSn) {
      this.$router.push({
        name: "patientInformation",
        query: {
          patientSn: patientSn,
          orderSn: orderSn,
        },
      });
    },
    // 跳转-订单管理(name命名路由跳转，动态路由传参)
    goOrder(patientName) {
      this.$router.push({
        name: "order-management",
        query: {
          patientName: patientName,
        },
        // params: {
        //   orderSn: orderSn,
        // },
      });
    },
    // 报到
    async reportPatient(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.orderSn,
        opeType: 1,
      });
      this.$message.success("报到成功");
      let _this = this;
      setTimeout(function () {
        _this.getTaskList();
      }, 500);
    },
    // 开始面诊
    async startTreat(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.orderSn,
        opeType: 2,
      });
      this.$message.success("开始面诊成功");
      let _this = this;
      setTimeout(function () {
        _this.getTaskList();
      }, 500);
    },
    // 开始治疗
    async startMedical(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.orderSn,
        opeType: 2,
      });
      this.$message.success("开始治疗成功");
      let _this = this;
      setTimeout(function () {
        _this.getTaskList();
      }, 500);
    },
    // 完成面诊
    async endTreat(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.orderSn,
        opeType: 3,
      });
      this.$message.success("完成面诊成功");
      let _this = this;
      setTimeout(function () {
        _this.getTaskList();
      }, 500);
    },
    // 结束治疗
    async endMedical(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.orderSn,
        opeType: 3,
      });
      this.$message.success("结束治疗成功");
      let _this = this;
      setTimeout(function () {
        _this.getTaskList();
      }, 500);
    },

    goYuYue(orderSn, patientSn, singleAppointmentDuration) {
      this.YuYueOrderSn = orderSn;
      this.YuYuePatientSn = patientSn;
      this.YuYuesingleAppointmentDuration = Number(singleAppointmentDuration);

      console.log(9999, orderSn);
      this.isShowAppointment = true;
    },

    goYuYueGuaHao(orderSn, patientSn, name) {
      this.YuYueOrderSnGuaHao = orderSn;
      this.YuYuePatientSnGuaHao = patientSn;
      this.YuYuePatientNameGuaHao = name;

      console.log(9999, orderSn);
      this.isShowAppointmentGuaHao = true;
    },

    // 预约治疗关闭
    YuYueClose() {
      this.isShowAppointment = false;
    },
    // 预约治疗成功后关闭
    YuYueCloseOk() {
      this.isShowAppointment = false;
      location.reload();
    },

    // 预约面诊关闭
    YuYueCloseGuaHao() {
      this.isShowAppointmentGuaHao = false;
    },

    // 列表里的查看治疗单
    lookZhiLiaoOrderTopList(item) {
      this.ZhiLiaoOrderSn = item.orderSn;
      this.detailTreatmentVisibleDialog = true;
    },
    // 治疗单关闭
    ZhiLiaoClose() {
      this.detailTreatmentVisibleDialog = false;
    },

    async cancleAppiont(orderSn) {
      const { data } = await this.$api.baseApis.cancleAppiont(orderSn);

      if (data == true) {
        this.$message.success("取消预约治疗成功");
        let _this = this;
        setTimeout(function () {
          _this.getTaskList();
        }, 500);
      }
    },

    // 取消治疗预约
    cancelAppointment(item) {
      console.log(996633, item);
      this.$confirm("确认取消预约治疗吗", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.cancleAppiont(item.orderSn);
        })
        .catch(() => {});
    },
    goBack() {
      // this.$router.go(-1);
      this.$router.push({
        name: "patient-management",
        query: {
          pageNum: this.lastPageNum,
        },
      });
    },
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      console.log(row, column, rowIndex, columnIndex);
      // 合并列
      // if (row.taskType == 2) {
      //   if (columnIndex === 0) {
      //     return [1, 6];
      //   }
      //   if (
      //     columnIndex === 1 ||
      //     columnIndex === 2 ||
      //     columnIndex === 3 ||
      //     columnIndex === 4 ||
      //     columnIndex === 5
      //   ) {
      //     return [1, 0];
      //   }
      // }
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  width: 100%;
  box-sizing: border-box;
  .patient-navbar {
    align-items: center;
    display: flex;
    width: 100%;
    margin-bottom: 20px;
    box-sizing: border-box;
    position: relative;
    .search-btn {
      cursor: pointer;
      text-align: center;
      width: 90px;
      height: 32px;
      border-radius: 2px;
      background: #2971eb;
      font-size: 14px;
      line-height: 32px;
      color: #ffffff;
      transition: transform 0.2s ease;
    }
    .search-btn:hover {
      transform: scale(1.1);
    }
  }
  .patient-form {
    box-sizing: border-box;
    height: 710px;
    overflow: auto;
    // scrollbar-width: none; /* 针对Firefox */
    // -ms-overflow-style: none; /* 针对Internet Explorer和Edge */
    .recentTask {
      justify-content: space-around;
      display: flex;
      .taskTime,
      .taskType,
      .adminName {
        margin-right: 3px;
      }
      .taskTime {
        width: 170px;
      }
      .taskType {
        width: 100px;
      }
      .adminName {
        width: 100px;
      }
    }
  }
  // 分页器
  .page-container {
    text-align: right;
    margin-right: -10px;
  }
}

// 预约治疗样式
.chinese-time {
  align-items: center;
  display: flex;
  width: 800px;
  height: 70px;
  margin-bottom: 15px;
  background-color: pink;
  .el-icon-back {
    cursor: pointer;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
  .content {
    text-align: center;
    width: 199px;
    height: 25px;
    line-height: 28px;
    font-size: 24px;
    font-weight: 600;
    color: #333333;
  }
  .el-icon-right {
    cursor: pointer;
    margin-right: 10px;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
}

// table表头的颜色
::v-deep(.center-table th) {
  background: #f7f8fa;
}

// 弹框居中显示
::v-deep(.el-dialog) {
  margin: auto !important;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

::v-deep(.el-dialog__wrapper) {
  overflow: auto;
}

::v-deep(.el-dialog__body) {
  overflow-y: auto; /* 添加垂直滚动条 */
  max-height: 680px; /* 自定义最大高度 */
  padding: 10px; /* 可选：添加适当的内边距 */
}

::v-deep(.icon-wrapper) {
  transition: transform 0.2s ease;
}

.addForm,
.editForm {
  padding-left: 26px;
  padding-right: 80px;
}
// 平板适配
@media screen and (max-width: 1300px) {
  .patient-form {
    box-sizing: border-box;
    overflow-y: auto;
    height: 521px !important;
    overflow: auto;
  }
}
</style>
