<template>
  <div class="patient-management">
    <div class="patient-navbar">
      <span style="color: #666666">患者姓名</span>
      <el-input
        v-model="params.name"
        placeholder="请输入患者姓名"
        style="width: 180px; margin-left: 20px; margin-right: 99px"
        clearable
      />
      <span style="color: #333333">手机号码</span>
      <el-input
        v-model="params.phoneNumber"
        placeholder="请输入手机号码"
        style="width: 212px; margin-right: 69px; margin-left: 20px"
        clearable
      />
      <el-button type="primary" @click="doSearch" icon="el-icon-search"
        >搜索</el-button
      >
      <el-button
        type="success"
        v-if="roles[0] == 'ADMINISTRATOR' || roles[0] == 'NURSE'"
        @click="addDialog"
        icon="el-icon-plus"
        >创建患者</el-button
      >
    </div>
    <div class="patient-form">
      <el-table style="width: 100%" :data="patientList" class="center-table">
        <el-table-column
          label="患者ID"
          width="180"
          align="center"
          prop="patientSn"
        />
        <el-table-column label="患者姓名" align="center" prop="patientName" />
        <el-table-column
          label="性别"
          align="center"
          prop="gender"
          :formatter="formatGender"
        />
        <el-table-column
          label="身份类型"
          align="center"
          prop="identityType"
          :formatter="formatIdentityType"
        />
        <el-table-column
          label="手机号"
          width="130"
          align="center"
          prop="phoneNumber"
        />
        <el-table-column label="累计消费" align="center" prop="totalCost" />
        <el-table-column
          label="任务列表"
          align="center"
          min-width="130"
          :formatter="formatTaskList"
        />

        <el-table-column label="操作" width="290" align="center" fixed="right">
          <template #default="{ row }">
            <div style="display: flex; justify-content: space-evenly">
              <el-button
                @click="goTask(row.orderSn, row.patientSn, row.patientName)"
                class="icon-wrapper"
                type="text"
                >查看任务</el-button
              >
              <el-button
                type="text"
                class="icon-wrapper"
                @click="goPatientInformation(row.patientSn, row.orderSn)"
                >资料</el-button
              >
              <el-button
                type="text"
                class="icon-wrapper"
                @click="goOrder(row.patientName)"
                >订单</el-button
              >
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页器 -->
    <div class="page-container">
      <el-pagination
        layout="total, prev, pager, next"
        :current-page="params.pageNum"
        :total="total"
        :page-size="params.pageSize"
        @current-change="currentChange"
        background
      />
    </div>

    <!-- 预约治疗弹框 -->
    <el-dialog :visible.sync="isShowAppointment" width="70%">
      <treatment-appointment
        @child-event="YuYueClose"
        @child-event-ok="YuYueCloseOk"
        :orderSn="YuYueOrderSn"
        :patientSn="YuYuePatientSn"
        :durationPerSession="YuYueDurationPerSession"
      ></treatment-appointment>
    </el-dialog>
    <!-- 预约面诊弹框 -->
    <el-dialog :visible.sync="isShowAppointmentGuaHao" width="70%">
      <GuaHaoAppointment
        v-if="isShowAppointmentGuaHao"
        @child-event="YuYueCloseGuaHao"
        :orderSn="YuYueOrderSnGuaHao"
        :patientSn="YuYuePatientSnGuaHao"
        :patientName="YuYuePatientNameGuaHao"
      ></GuaHaoAppointment>
    </el-dialog>

    <!-- 专用治疗单弹框 -->
    <el-dialog
      v-if="detailTreatmentVisibleDialog"
      :visible.sync="detailTreatmentVisibleDialog"
      width="900px"
    >
      <treatmentSheet
        @child-event="ZhiLiaoClose"
        :ZhiLiaoOrderSn="ZhiLiaoOrderSn"
      >
      </treatmentSheet>
    </el-dialog>

    <!-- 创建患者dialog -->
    <el-dialog title="创建患者" :visible.sync="addDialogVisible" width="700px">
      <div v-if="addDialogVisible">
        <el-form
          :model="pageDataParams"
          class="addForm"
          ref="addForm"
          :rules="addRules"
          label-width="160px"
        >
          <el-form-item label="身份" prop="identityType">
            <el-radio-group v-model="pageDataParams.identityType">
              <el-radio
                v-for="item in identityArr"
                :key="item.label"
                :label="item.value"
                >{{ item.label }}</el-radio
              >
            </el-radio-group>
          </el-form-item>
          <el-form-item label="患者姓名" prop="name">
            <el-input
              v-model="pageDataParams.name"
              placeholder="请输入患者姓名"
              maxlength="10"
            />
          </el-form-item>
          <el-form-item label="性别" prop="gender">
            <el-radio-group v-model="pageDataParams.gender">
              <el-radio
                v-for="item in genderArr"
                :key="item.label"
                :label="item.value"
                >{{ item.label }}</el-radio
              >
            </el-radio-group>
          </el-form-item>
          <el-form-item label="手机号" prop="phoneNumber">
            <el-input
              v-model="pageDataParams.phoneNumber"
              placeholder="请输入手机号"
              maxlength="11"
            />
          </el-form-item>
        </el-form>
        <el-row slot="footer" type="flex" justify="center">
          <el-button
            size="medium"
            @click="addDialogVisible = false"
            icon="el-icon-back"
            >取消</el-button
          >
          <el-button
            size="medium"
            type="primary"
            @click="addAccount"
            icon="el-icon-folder"
            >确认创建</el-button
          >
        </el-row>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import TreatmentAppointment from "@/components/appointment/treatment-appointment.vue";
import TreatmentSheet from "@/components/treatmentSheet/treatmentSheet.vue";
import GuaHaoAppointment from "@/components/appointment/guahao-appointment.vue";

import { mapState } from "vuex";
export default {
  data() {
    return {
      // 专用治疗单
      detailTreatmentVisibleDialog: false,
      treatmentDetailIsShow: true,
      ZhiLiaoOrderSn: "",
      roleForm: {
        name: "",
        roleId: "",
      },
      params: {
        pageNum: 1,
        pageSize: 10,
        name: "",
        phoneNumber: "",
      },
      total: 0,
      // 患者列表
      patientList: [],
      // 患者预约治疗弹框显示
      isShowAppointment: false,
      YuYueOrderSn: "",
      YuYuePatientSn: "",
      YuYueDurationPerSession: null,

      // 患者预约面诊弹框显示
      isShowAppointmentGuaHao: false,
      YuYueOrderSnGuaHao: "",
      YuYuePatientSnGuaHao: "",
      YuYuePatientNameGuaHao: "",

      // 时间
      dateDay: "",

      identityArr: [
        {
          label: "成人",
          value: 0,
        },
        {
          label: "儿童",
          value: 1,
        },
      ],
      genderArr: [
        {
          label: "男",
          value: 1,
        },
        {
          label: "女",
          value: 0,
        },
      ],

      // 创建患者
      addDialogVisible: false,
      // 新增、删除 账号-params
      pageDataParams: {},
      // 创建患者-rules
      addRules: {
        identityType: [
          { required: true, message: "请选择身份", trigger: "change" },
        ],
        name: [{ required: true, message: "请输入患者姓名", trigger: "blur" }],
        gender: [{ required: true, message: "请选择性别", trigger: "change" }],
        phoneNumber: [
          { required: true, message: "请输入手机号", trigger: "blur" },
          {
            required: true,
            pattern: /^[1][3,4,5,6,7,8,9][0-9]{9}$/,
            message: "手机号格式错误",
            trigger: "blur",
          },
        ],
      },
    };
  },
  components: {
    TreatmentAppointment,
    TreatmentSheet,
    GuaHaoAppointment,
  },
  mounted() {
    if (this.equipment == "pad") {
      this.params.pageSize = 6;
    } else {
      this.params.pageSize = 9;
    }

    // 如果有页码
    if (this.$route.query.pageNum) {
      this.lastPageNum = Number(this.$route.query.pageNum);
    }
    let _this = this;
    // 获取患者列表
    Promise.all([this.getPatientList()]).then((result) => {
      // 调第二次才能切换页码
      _this.doSearch2();
    });
  },
  computed: {
    ...mapState({
      equipment: (state) => state.equipment,
      roles: (state) => state.authInfo.roles,
    }),
  },
  methods: {
    doSearch2() {
      if (this.lastPageNum > 0) {
        this.params.pageNum = this.lastPageNum;
      } else {
        return;
      }

      this.getPatientList();
    },
    // 获取患者列表
    async getPatientList() {
      const { data } = await this.$api.baseApis.getPatientList(this.params);
      console.log(data.list.length);
      this.patientList = data.list;
      this.total = data.total;
    },
    // 切换页码
    currentChange(page) {
      this.params.pageNum = page;
      this.getPatientList();
    },
    // 搜索患者
    doSearch() {
      this.params.pageNum = 1;
      this.getPatientList();
    },
    // 性别格式-转化
    formatGender(row) {
      const MAP = {
        0: "女",
        1: "男",
      };
      return MAP[row.gender];
    },
    // 身份类型格式-转化
    formatIdentityType(row) {
      const MAP = {
        0: "成人",
        1: "儿童",
      };
      return MAP[row.identityType];
    },
    // 任务列表转化
    formatTaskList(row) {
      if (row.undoneTaskNum === 0) {
        return "无未完成";
      }
      if (row.undoneTaskNum > 0) {
        return row.undoneTaskNum + "项未完成";
      }
    },

    // 跳转-患者资料
    goPatientInformation(patientSn, orderSn) {
      this.$router.push({
        name: "patientInformation",
        query: {
          patientSn: patientSn,
          orderSn: orderSn,
        },
      });
    },
    // 跳转-订单管理(name命名路由跳转，动态路由传参)
    goOrder(patientName) {
      this.$router.push({
        name: "order-management",
        query: {
          patientName: patientName,
        },
        // params: {
        //   orderSn: orderSn,
        // },
      });
    },
    // 报到
    async reportPatient(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 1,
      });
      this.$message.success("报到成功");
      let _this = this;
      setTimeout(function () {
        _this.getPatientList();
      }, 500);
    },
    // 开始面诊
    async startTreat(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 2,
      });
      this.$message.success("开始面诊成功");
      let _this = this;
      setTimeout(function () {
        _this.getPatientList();
      }, 500);
    },
    // 开始治疗
    async startMedical(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 2,
      });
      this.$message.success("开始治疗成功");
      let _this = this;
      setTimeout(function () {
        _this.getPatientList();
      }, 500);
    },
    // 完成面诊
    async endTreat(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 3,
      });
      this.$message.success("完成面诊成功");
      let _this = this;
      setTimeout(function () {
        _this.getPatientList();
      }, 500);
    },
    // 结束治疗
    async endMedical(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 3,
      });
      this.$message.success("结束治疗成功");
      let _this = this;
      setTimeout(function () {
        _this.getPatientList();
      }, 500);
    },

    // 获取当前日期
    getCurrentChineseTime() {
      const now = new Date();
      const chineseYears = now.getFullYear();
      const chineseMonths = now.getMonth() + 1;
      // 获取日期
      const chinesedate = now.getDate();
      // 获取星期几（0-6），0代表周日。
      const chineseweek = this.toChineseNumber(now.getDay());
      return `${chineseYears}年${chineseMonths}月${chinesedate}日,星期${chineseweek}`;
    },
    toChineseNumber(num) {
      const chineseNumbers = ["日", "一", "二", "三", "四", "五", "六", "日"];
      const digits = num.toString().split("");
      return digits.map((digit) => chineseNumbers[parseInt(digit)]).join("");
      // 123 => '123' => ['1','2','3']
      // ['1','2','3']调用map方法,将一个数字num转换成其每一位数字的中文表示形式，并连接起来形成中文数字字符串。
    },
    dateChange(date) {
      console.log(date);
    },

    goYuYue(orderSn, patientSn, durationPerSession) {
      this.YuYueOrderSn = orderSn;
      this.YuYuePatientSn = patientSn;
      this.YuYueDurationPerSession = durationPerSession;

      console.log(9999, orderSn);
      this.isShowAppointment = true;
    },

    goYuYueGuaHao(orderSn, patientSn, name) {
      this.YuYueOrderSnGuaHao = orderSn;
      this.YuYuePatientSnGuaHao = patientSn;
      this.YuYuePatientNameGuaHao = name;

      console.log(9999, orderSn);
      this.isShowAppointmentGuaHao = true;
    },

    // 预约治疗关闭
    YuYueClose() {
      this.isShowAppointment = false;
    },
    // 预约治疗成功后关闭
    YuYueCloseOk() {
      this.isShowAppointment = false;
      location.reload();
    },

    // 预约面诊关闭
    YuYueCloseGuaHao() {
      this.isShowAppointmentGuaHao = false;
    },

    // 列表里的查看治疗单
    lookZhiLiaoOrderTopList(item) {
      this.ZhiLiaoOrderSn = item.taskLogVO.orderSn;
      this.detailTreatmentVisibleDialog = true;
    },
    // 治疗单关闭
    ZhiLiaoClose() {
      this.detailTreatmentVisibleDialog = false;
    },

    async cancleAppiont(orderSn) {
      const { data } = await this.$api.baseApis.cancleAppiont(orderSn);

      if (data == true) {
        this.$message.success("取消预约治疗成功");
        let _this = this;
        setTimeout(function () {
          _this.getPatientList();
        }, 500);
      }
    },

    // 取消治疗预约
    cancelAppointment(item) {
      console.log(996633, item);
      this.$confirm("确认取消预约治疗吗", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.cancleAppiont(item.orderSn);
        })
        .catch(() => {});
    },

    // 创建患者-dialog
    addDialog() {
      this.addDialogVisible = true;
      this.pageDataParams = {};
    },
    // 创建患者账号
    addAccount() {
      this.$refs.addForm.validate(async (valid) => {
        console.log(1122, valid);
        if (valid) {
          console.log("创建患者66", this.pageDataParams);

          // 调用创建患者接口
          const { data } = await this.$api.baseApis.createOrUpdatePatient(
            this.pageDataParams
          );
          if (data == true) {
            this.$message.success("创建患者成功");
            this.addDialogVisible = false;
            let _this = this;
            setTimeout(function () {
              _this.getPatientList();
            }, 500);
          }
        } else {
          this.$message.warning("请填写完整表单");
        }
      });
    },

    // 查看任务
    goTask(orderSn, patientSn, patientName) {
      this.$router.push({
        name: "patient-task",
        query: {
          patientSn,
          orderSn,
          patientName,
          pageNum: this.params.pageNum,
        },
      });
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  width: 100%;
  box-sizing: border-box;
  .patient-navbar {
    align-items: center;
    display: flex;
    width: 100%;
    margin-bottom: 20px;
    box-sizing: border-box;
    .search-btn {
      cursor: pointer;
      text-align: center;
      width: 90px;
      height: 32px;
      border-radius: 2px;
      background: #2971eb;
      font-size: 14px;
      line-height: 32px;
      color: #ffffff;
      transition: transform 0.2s ease;
    }
    .search-btn:hover {
      transform: scale(1.1);
    }
  }
  .patient-form {
    box-sizing: border-box;
    height: 710px;
    overflow: auto;
    // scrollbar-width: none; /* 针对Firefox */
    // -ms-overflow-style: none; /* 针对Internet Explorer和Edge */
    .recentTask {
      justify-content: space-around;
      display: flex;
      .taskTime,
      .taskType,
      .adminName {
        margin-right: 3px;
      }
      .taskTime {
        width: 170px;
      }
      .taskType {
        width: 100px;
      }
      .adminName {
        width: 100px;
      }
    }
  }
  // 分页器
  .page-container {
    text-align: right;
    margin-right: -10px;
  }
}

// 预约治疗样式
.chinese-time {
  align-items: center;
  display: flex;
  width: 800px;
  height: 70px;
  margin-bottom: 15px;
  background-color: pink;
  .el-icon-back {
    cursor: pointer;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
  .content {
    text-align: center;
    width: 199px;
    height: 25px;
    line-height: 28px;
    font-size: 24px;
    font-weight: 600;
    color: #333333;
  }
  .el-icon-right {
    cursor: pointer;
    margin-right: 10px;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
}

// table表头的颜色
::v-deep(.center-table th) {
  background: #f7f8fa;
}

// 弹框居中显示
::v-deep(.el-dialog) {
  margin: auto !important;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

::v-deep(.el-dialog__wrapper) {
  overflow: auto;
}

::v-deep(.el-dialog__body) {
  overflow-y: auto; /* 添加垂直滚动条 */
  max-height: 680px; /* 自定义最大高度 */
  padding: 10px; /* 可选：添加适当的内边距 */
}

::v-deep(.icon-wrapper) {
  transition: transform 0.2s ease;
}

.addForm,
.editForm {
  padding-left: 26px;
  padding-right: 80px;
}
// 平板适配
@media screen and (max-width: 1300px) {
  .patient-form {
    box-sizing: border-box;
    overflow-y: auto;
    height: 521px !important;
    overflow: auto;
  }
}
</style>
