<template>
  <div class="patient-management">
    <div class="_com_form_title_box">
      <div class="_com_form_title">基础设置</div>
    </div>
    <div class="form_box">
      <el-form
        :model="pageData"
        class="addForm"
        ref="addForm"
        :rules="addRules"
        label-width="160px"
      >
        <el-form-item label="活动名称" prop="activityName">
          <el-input
            maxlength="15"
            size="small"
            v-model="pageData.activityName"
            placeholder="请输入活动名称（15字以内）"
            style="width: 555px"
          />
        </el-form-item>
        <el-form-item label="渠道名称" prop="channelName">
          <el-input
            maxlength="10"
            size="small"
            v-model="pageData.channelName"
            placeholder="请输入渠道名称（10字以内）"
            style="width: 555px"
          />
        </el-form-item>
        <el-form-item label="活动时间" prop="foreverStatus">
          <el-radio-group
            v-model="pageData.foreverStatus"
            @change="activityTimeChange()"
          >
            <template v-for="(item, i) in foreverStatusArr">
              <el-radio :label="item.value" style="margin-right: 30px">{{
                item.label
              }}</el-radio>
              <el-date-picker
                v-if="pageData.foreverStatus == 0 && item.label == '截止时间'"
                v-model="pageData.expireDate"
                type="date"
                size="small"
                :editable="false"
                placeholder="请选择结束日期"
                value-format="yyyy-MM-dd"
                @input="inputChange()"
                style="width: 160px; margin-right: 20px"
              ></el-date-picker>
              <el-time-picker
                v-if="pageData.foreverStatus == 0 && item.label == '截止时间'"
                size="small"
                value-format="HH:mm"
                format="H:mm"
                v-model="pageData.expireTime"
                :editable="false"
                placeholder="请选择结束时间"
                @input="inputChange()"
                style="width: 160px; margin-right: 20px"
              >
              </el-time-picker>
            </template>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="领取条件" prop="gettingCondition">
          <el-radio-group
            v-model="pageData.gettingCondition"
            @change="YongHuChange(pageData.gettingCondition)"
          >
            <template v-for="(item, i) in gettingConditionArr">
              <el-radio :label="item.id" style="margin-right: 30px">{{
                item.name
              }}</el-radio>
              <el-button
                v-if="
                  pageData.gettingCondition == 2 &&
                  item.name == '指定用户可领取'
                "
                size="small"
                type="default"
                @click="openUploadDialog()"
                icon="el-icon-upload2"
                >批量导入</el-button
              >
            </template>
          </el-radio-group>
        </el-form-item>

        <!-- <el-form-item label="" v-if="pageData.phoneNumbers.length > 0">
          <el-collapse accordion style="width: 555px">
            <el-collapse-item title="已指定用户:">
              <div class="phone_list_box">
                <span v-for="(ite, j) in pageData.phoneNumbers" :key="j">
                  {{ ite }}</span
                >
              </div>
            </el-collapse-item>
          </el-collapse>
        </el-form-item> -->

        <el-form-item label="分享文案" prop="shareContent">
          <el-input
            maxlength="16"
            size="small"
            v-model="pageData.shareContent"
            placeholder="请输入分享文案（16字以内）"
            style="width: 555px"
          />
        </el-form-item>
        <el-form-item label="总价值" prop="totalValue">
          <el-input
            maxlength="4"
            size="small"
            v-model="pageData.totalValue"
            placeholder="请输入总价值"
            style="width: 555px"
          />
        </el-form-item>
      </el-form>
    </div>

    <div
      class="_com_form_title_box"
      style="position: relative; margin-top: 40px; margin-bottom: 20px"
    >
      <div class="_com_form_title">优惠券设置</div>
      <div class="form_title_btn">
        <el-popover
          style="position: absolute"
          placement="right"
          width="200"
          trigger="click"
          v-model="popoverVisible"
          @show="addCouponType = null"
          @hide="popoverHide()"
        >
          <div class="popover_box">
            <el-select
              style="width: 180px; margin-left: 20px"
              placeholder="请选择优惠券类型"
              v-model="addCouponType"
              @change="changeCouponType"
            >
              <el-option
                v-for="item in CouponTypeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </div>

          <el-button
            slot="reference"
            size="small"
            type="success"
            @click=""
            icon="el-icon-plus"
            >创建优惠券</el-button
          >
        </el-popover>
      </div>
    </div>
    <div class="coupon_list">
      <div
        class="coupon_card"
        v-for="(item, i) in pageData.activityCouponDetails"
        :key="i"
      >
        <template>
          <el-button
            class="del_btn"
            size="small"
            type="danger"
            @click="deleteCoupon(item)"
            icon="el-icon-delete"
            >删除</el-button
          >

          <el-form label-width="160px">
            <el-form-item label="优惠券类型">
              <span>{{ item.couponTypeName }}</span>
            </el-form-item>
            <el-form-item label="券名称">
              <el-input
                maxlength="10"
                size="small"
                v-model="item.couponName"
                placeholder="请输入券名称（10字以内）"
                style="width: 555px"
              />
            </el-form-item>
            <el-form-item
              label="优惠金额"
              v-if="item.couponTypeName == '现金券'"
            >
              <el-input
                maxlength="5"
                size="small"
                v-model="item.couponParValue"
                placeholder="请输入"
                style="width: 130px"
              />
              <span style="font-size: 14px; margin-left: 10px">元</span>
            </el-form-item>
            <el-form-item
              label="优惠折扣"
              v-if="item.couponTypeName == '折扣券'"
            >
              <el-input
                maxlength="4"
                size="small"
                v-model="item.discount"
                placeholder="请输入"
                style="width: 130px"
              />
              <span style="font-size: 14px; margin-left: 10px">折</span>
              <span style="font-size: 14px; margin-left: 10px; color: #999"
                >(折扣输入范围为0.1-9.9)</span
              >
            </el-form-item>
            <el-form-item
              label="兑换订单"
              v-if="item.couponTypeName == '兑换券'"
            >
              <el-radio-group
                v-model="item.exchangeOrder"
                @change="DuiHuanChange(item)"
              >
                <template v-for="(ite, i) in exchangeOrderArr">
                  <el-radio :label="ite.value" style="margin-right: 30px">{{
                    ite.label
                  }}</el-radio>

                  <el-select
                    multiple
                    style="margin-left: 20px; width: 370px"
                    v-if="item.exchangeOrder == 2 && ite.label == '治疗'"
                    v-model="item.projectId"
                    placeholder="请选择"
                    @change="XiangMuChangeSelect(item)"
                  >
                    <el-option
                      v-for="ite in ProjectConfigActivityArr"
                      :key="ite.id"
                      :label="ite.projectName"
                      :value="ite.id"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              label="使用门槛"
              v-if="
                item.couponTypeName == '现金券' ||
                item.couponTypeName == '折扣券'
              "
            >
              <el-radio-group
                v-model="item.thresholdNo"
                @change="MenKanChange(item)"
              >
                <template v-for="(ite, i) in MenKanTypeArr">
                  <el-radio :label="ite.value" style="margin-right: 30px">{{
                    ite.label
                  }}</el-radio>

                  <el-input
                    v-if="item.thresholdNo == 1 && ite.label == '订单满'"
                    maxlength="4"
                    size="small"
                    v-model="item.orderUseAmount"
                    placeholder="请输入"
                    style="width: 100px; margin-left: -16px"
                  />
                  <span
                    v-if="item.thresholdNo == 1 && ite.label == '订单满'"
                    style="font-size: 14px; margin-left: 10px"
                    >元</span
                  >
                </template>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              label="可用项目"
              v-if="
                item.couponTypeName == '现金券' ||
                item.couponTypeName == '折扣券'
              "
            >
              <el-checkbox-group
                v-model="item.availableProject"
                @change="KeYongXiangMuChange(item)"
              >
                <el-checkbox
                  v-for="ite in ProjectTypeArr"
                  :key="ite.value"
                  :label="ite.value"
                  >{{ ite.label }}</el-checkbox
                >

                <el-select
                  multiple
                  style="margin-left: 20px; width: 400px"
                  v-if="item.availableProject.includes(2)"
                  v-model="item.projectId"
                  placeholder="请选择"
                  @change="XiangMuChangeSelect(item)"
                >
                  <el-option
                    v-for="ite in ProjectConfigActivityArr"
                    :key="ite.id"
                    :label="ite.projectName"
                    :value="ite.id"
                  >
                  </el-option>
                </el-select>
              </el-checkbox-group>
            </el-form-item>

            <el-form-item label="有效期">
              <el-radio-group
                v-model="item.foreverStatus"
                @change="YouXiaoQiChange(item)"
              >
                <template v-for="(ite, i) in foreverStatusSonArr">
                  <el-radio :label="ite.value" style="margin-right: 30px">{{
                    ite.label
                  }}</el-radio>
                  <el-date-picker
                    v-if="item.foreverStatus == 0 && ite.label == '结束日期'"
                    v-model="item.expireDate"
                    type="date"
                    size="small"
                    :editable="false"
                    placeholder="请选择结束日期"
                    value-format="yyyy-MM-dd"
                    @input="inputChange()"
                    style="width: 160px; margin-right: 20px"
                  ></el-date-picker>
                </template>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="使用说明">
              <el-input
                maxlength="50"
                size="small"
                :rows="2"
                type="textarea"
                resize="none"
                v-model="item.instructions"
                placeholder="请输入使用说明（50字以内）"
                style="width: 555px"
              />
            </el-form-item>
          </el-form>
        </template>
      </div>
    </div>

    <el-row slot="footer" type="flex" justify="center">
      <el-button size="medium" @click="goBack()" icon="el-icon-back"
        >取消</el-button
      >
      <el-button
        size="medium"
        type="primary"
        @click="saveFn"
        icon="el-icon-folder"
        >保存</el-button
      >
    </el-row>

    <!-- 批量导入dialog -->
    <el-dialog
      title="上传文件"
      width="700px"
      :visible.sync="uploadDialogVisible"
    >
      <div v-if="uploadDialogVisible">
        <div class="form_line">
          <div class="form_line_lf">下载导入模板</div>
          <div class="form_line_rt">
            <div>
              <a :href="host + 'promotion/manage/download/template'">
                <el-button size="small" type="default" icon="el-icon-download"
                  >下载导入模板</el-button
                >
              </a>
            </div>
          </div>
        </div>
        <div class="form_line">
          <div class="form_line_lf">上传文件</div>
          <div class="form_line_rt">
            <div style="position: relative">
              <el-upload
                :action="host + 'promotion/manage/importExcel'"
                accept=".xlsx"
                :show-file-list="false"
                :before-upload="beforeAvatarUpload"
                :on-change="upload"
                :on-success="uploadSuccess"
              >
                <el-button
                  size="small"
                  type="success"
                  @click=""
                  icon="el-icon-upload2"
                  >选择文件</el-button
                >
              </el-upload>
              <div
                v-if="pageData.phoneNumbers.length > 0"
                style="
                  display: inline-block;
                  position: absolute;
                  top: 2px;
                  left: 130px;
                  font-size: 14px;
                  color: #666;
                "
              >
                已上传文件
              </div>
            </div>
            <div style="line-height: 18px; color: #999; font-size: 12px">
              目前支持格式xlsx，文件大小请控制在1MB 以内
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapState } from "vuex";
import Axios from "axios";

export default {
  data() {
    return {
      host: process.env.VUE_APP_API_HOST,
      saveBtnDisabled: false,

      uploadDialogVisible: false,
      addCouponType: null,
      popoverVisible: false,
      // pageData: {
      //   activityCouponDetails: [],
      //   activityName: "",
      //   channelName: "",
      //   expireDate: "",
      //   expireTime: "",
      //   foreverStatus: 0,
      //   gettingCondition: "",
      //   phoneNumbers: [],
      //   shareContent: "",
      //   totalValue: "",
      // },
      pageData: {
        activityCouponDetails: [
          // {
          //   couponType: 3,
          //   couponName: "6折优惠券",
          //   couponParValue: "",
          //   couponTypeName: "折扣券",
          //   discount: "6",
          //   exchangeOrder: "",
          //   expireDate: "",
          //   foreverStatus: 1,
          //   id: null,
          //   newId: 1721379529706,
          //   instructions: "这是6折优惠券的说明",
          //   orderUseAmount: "",
          //   thresholdNo: 0,
          // },
        ],
        activityName: "",
        channelName: "",
        expireDate: "",
        expireTime: "",
        foreverStatus: null,
        gettingCondition: "",
        phoneNumbers: [],
        shareContent: "",
        totalValue: "",
        gettingCondition: null,
      },
      foreverStatusArr: [
        { label: "截止时间", value: 0 },
        { label: "永久有效", value: 1 },
      ],
      foreverStatusSonArr: [
        { label: "结束日期", value: 0 },
        { label: "长期有效", value: 1 },
      ],

      gettingConditionArr: [
        {
          code: "default",
          id: 1,
          name: "所有用户均可领取",
        },
        {
          code: "specify_user",
          id: 2,
          name: "指定用户可领取",
        },
      ],
      CouponTypeList: [
        { value: 2, label: "现金券" },
        { value: 3, label: "兑换券" },
        { value: 4, label: "折扣券" },
      ],
      exchangeOrderArr: [
        { value: 1, label: "面诊" },
        { value: 2, label: "治疗" },
      ],
      MenKanTypeArr: [
        { value: 0, label: "无门槛" },
        { value: 1, label: "订单满" },
      ],
      ProjectConfigActivityArr: [{ projectName: "全部项目", id: 0 }],
      ProjectConfigActivityArrSingle: [],
      ProjectTypeArr: [
        { label: "面诊", value: 1 },
        { label: "治疗", value: 2 },
      ],

      // 券配置
      newCouponDetail: {
        couponType: null,
        couponName: "",
        couponParValue: "",
        couponTypeName: "",
        discount: "",
        exchangeOrder: "",
        expireDate: "",
        foreverStatus: null,
        id: null,
        newId: null,
        instructions: "",
        orderUseAmount: "",
        thresholdNo: 0,
        thresholdNo: "",
        availableProject: [],
        projectId: null,
      },

      addRules: {
        activityName: [
          { required: true, message: "请输入活动名称", trigger: "blur" },

          {
            required: true,
            min: 1,
            max: 15,
            message: "活动名称不超过15位",
            trigger: "blur",
          },
        ],
        foreverStatus: [
          { required: true, message: "请选择活动时间", trigger: "change" },
        ],
        gettingCondition: [
          { required: true, message: "请选择领取条件", trigger: "change" },
        ],
        shareContent: [
          {
            required: false,
            min: 1,
            max: 16,
            message: "分享文案不超过16位",
            trigger: "blur",
          },
        ],
        totalValue: [
          { required: true, message: "请输入总价值", trigger: "blur" },
        ],
      },
    };
  },
  components: {},
  computed: {
    ...mapState({
      roles: (state) => state.authInfo.roles,
    }),
  },

  async created() {
    let _this = this;
    Promise.all([
      _this.gettingCondition(),
      _this.getPlanProjectConfigActivity(),
    ]).then((result) => {
      if (_this.$route.query?.id) {
        _this.getActivityDetail();
      }
    });
  },

  methods: {
    // 获取详情
    async getActivityDetail() {
      const { data } = await this.$api.baseApis.getActivityDetail(
        this.$route.query.id
      );
      console.log(999, data);
      if (data) {
        this.pageData = data;
        // 优惠金额变整数
        if (this.pageData.activityCouponDetails) {
          for (let item of this.pageData.activityCouponDetails) {
            if (item.couponParValue) {
              item.couponParValue = Number(
                Number(item.couponParValue).toFixed(0)
              );
            }
          }
        }
      } else {
        this.$message.error("没有找到该活动信息");
      }
    },

    // 活动领取条件
    async gettingCondition() {
      const { data } = await this.$api.baseApis.gettingCondition();
      console.log(666, data);
      this.gettingConditionArr = data;
    },
    // 获取治疗项目
    async getPlanProjectConfigActivity() {
      const { data } = await this.$api.baseApis.getPlanProjectConfigActivity({
        // 项目类型 1-治疗项目 2-药物 不传则查全部
        // type: 1,
      });
      this.ProjectConfigActivityArr =
        this.ProjectConfigActivityArr.concat(data);
      this.ProjectConfigActivityArrSingle = data;
    },

    // 解决输入不了
    inputChange(e) {
      this.$forceUpdate(e);
    },

    openUploadDialog() {
      this.uploadDialogVisible = true;
    },
    async beforeAvatarUpload(file) {
      const isLt1M = file.size / 1024 / 1024 < 1;
      if (!isLt1M) {
        this.$message.error("上传表格大小不能超过 1MB!");
      }
      return isLt1M;
    },
    uploadSuccess(e) {
      if (e && e.length > 0) {
        this.$message.success("导入用户成功！");
        this.pageData.phoneNumbers = e;
        this.uploadDialogVisible = false;
      } else {
        this.pageData.phoneNumbers = [];
        this.$message.error("导入用户失败，请检查表格格式是否正确！");
      }
    },
    async upload(file) {
      // const formData = new FormData();
      // formData.append("file", file);
      // const { data } = await this.$api.baseApis.importExcel({ file: formData });
      // console.log(999, data);
    },

    popoverHide() {
      let _this = this;
      setTimeout(() => {
        _this.addCouponType = null;
      }, 200);
    },
    // 选择优惠券类型
    changeCouponType() {
      if (this.addCouponType) {
        let newCoupon = JSON.parse(JSON.stringify(this.newCouponDetail));
        newCoupon.couponType = this.addCouponType;
        newCoupon.newId = new Date().getTime();
        for (let item of this.CouponTypeList) {
          if (item.value === this.addCouponType) {
            newCoupon.couponTypeName = item.label;
          }
        }
        this.pageData.activityCouponDetails.unshift(newCoupon);

        // 关闭popover
        this.popoverVisible = false;
      }
    },
    // 删除优惠券
    deleteCoupon(item) {
      let _this = this;
      _this
        .$confirm(
          "是否删除" +
            (item.couponName ? item.couponName : "") +
            item.couponTypeName +
            "?",
          "提示",
          {
            confirmButtonText: "删除",
            cancelButtonText: "取消",
            type: "warning",
          }
        )
        .then(() => {
          if (item.newId) {
            for (
              let i = 0;
              i < _this.pageData.activityCouponDetails.length;
              i++
            ) {
              if (_this.pageData.activityCouponDetails[i].newId == item.newId) {
                _this.pageData.activityCouponDetails.splice(i, 1);
                this.$message.success("删除成功");
              }
            }
            return;
          }
          if (item.id) {
            _this.deleteCouponHave(item.id);
          }
        });
    },

    // 删除已有的优惠券
    async deleteCouponHave(id) {
      const { data } = this.$api.baseApis.delPromoCouponTemp({
        couPonTempId: id,
        promoId: this.pageData.id,
      });

      for (let i = 0; i < this.pageData.activityCouponDetails.length; i++) {
        if (this.pageData.activityCouponDetails[i].id == id) {
          this.pageData.activityCouponDetails.splice(i, 1);
          this.$message.success("删除成功");
        }
      }
    },
    goBack() {
      this.$router.go(-1);
    },

    saveFn() {
      this.$refs.addForm.validate(async (valid) => {
        console.log(1122, valid);
        if (valid) {
          console.log("保存66", this.pageData, JSON.stringify(this.pageData));
          if (this.pageData.foreverStatus == 0) {
            if (!this.pageData.expireDate || !this.pageData.expireTime) {
              this.$message.warning("请选择截止时间");
              return;
            }
          }
          console.log(3366, this.pageData);

          // 调用接口
          const { data } = await this.$api.baseApis.createOrUpdateActivity(
            this.pageData
          );
          if (data && Number(data) > 0) {
            this.$message.success("保存成功");
            let _this = this;
            setTimeout(function () {
              _this.$router.replace({
                name: "coupons",
              });
            }, 500);
          } else {
          }
        } else {
          this.$message.warning("请填写完整表单");
        }
      });
    },
    // 活动时间改变
    activityTimeChange() {
      if (this.pageData.foreverStatus == 1) {
        this.pageData.expireDate = "";
        this.pageData.expireTime = "";
      }
    },
    // 有效期改变
    YouXiaoQiChange(item) {
      if (item.foreverStatus == 1) {
        item.expireDate = "";
      }
    },

    // 可用项目改变
    KeYongXiangMuChange(item) {
      console.log(9933, item.availableProject);
      if (
        (item.availableProject.length == 1 && item.availableProject[0] == 2) ||
        item.availableProject.length == 2
      ) {
        console.log(9911);
        item.projectId = [0];
      }
      if (item.availableProject.length == 1 && item.availableProject[0] == 1) {
        console.log(9911);
        item.projectId = [];
      }
    },
    // 使用门槛选择
    MenKanChange(item) {
      if (item.thresholdNo == 0) {
        item.orderUseAmount = 0;
      }
    },

    // 兑换券选择
    DuiHuanChange(item) {
      console.log(9955, item.exchangeOrder);
      if (item.exchangeOrder == 1) {
        item.projectId = [];
      }
      if (item.exchangeOrder == 2) {
        // if (item.projectId == 0) {
        //   item.projectId = null;
        // }
      }
    },
    // 领取条件
    YongHuChange(type) {
      console.log(9955, type);
      if (type == 1) {
        this.pageData.phoneNumbers = [];
      }
    },

    // 下载导入模板
    getTemplate() {
      const { data } = this.$api.baseApis.getTemplate();
      console.log(666, data);
    },

    // 选择项目下拉
    XiangMuChangeSelect(item) {
      console.log("item.projectId", item.projectId);
      // let newList = JSON.parse(JSON.stringify(item.projectId));
      // console.log(777, item.projectId.length);
      // console.log(799, item.projectId[0]);

      if (item.projectId.length == 2 && item.projectId[0] === 0) {
        item.projectId.splice(0, 1);
      }
      if (item.projectId.includes(0)) {
        item.projectId = [0];
      }
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  position: relative;
  padding-bottom: 100px !important;
}
.form_line {
  display: flex;
  align-items: top;
  justify-content: flex-start;
  box-sizing: border-box;
  .form_line_lf {
    width: 180px;
    font-size: 16px;
    text-align: right;
    color: #333;
    line-height: 60px;
    box-sizing: border-box;
    padding-right: 16px;
  }
  .form_line_rt {
    width: 474px;
    font-size: 16px;
    text-align: left;
    color: #333;
    box-sizing: border-box;
    line-height: 60px;
    padding-left: 16px;
  }
}

.form_title_btn {
  position: absolute;
  top: -12px;
  left: 162px;
  z-index: 2;
}
.coupon_card {
  width: 735px;
  border-radius: 10px;
  padding: 20px 0;
  background-color: #f9f9f9;
  box-sizing: border-box;
  margin-bottom: 20px;
  position: relative;
  .del_btn {
    position: absolute;
    top: 24px;
    right: 22px;
    z-index: 99;
  }
}
::v-deep(.phone_list_box) {
  background: #f3f3f3;
  border-radius: 10px;
  padding: 20px;
}

// 平板适配
@media screen and (max-width: 1300px) {
}
</style>
