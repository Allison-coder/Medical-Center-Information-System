<template>
  <div class="patient-management">
    <!-- 表头搜索 -->
    <div class="patient-navbar">
      <span style="color: #666666">活动名称</span>
      <el-input
        placeholder="请输入活动名称"
        v-model="listParams.activityName"
        style="width: 180px; margin-left: 20px; margin-right: 99px"
        clearable
      />
      <span style="color: #333333">渠道名称</span>
      <el-input
        placeholder="请输入渠道名称"
        style="width: 212px; margin-right: 69px; margin-left: 20px"
        v-model="listParams.channelName"
        clearable
      />
      <el-button type="primary" @click="doSearch" icon="el-icon-search"
        >搜索</el-button
      >
      <el-button type="success" @click="addCoupons()" icon="el-icon-plus"
        >新增</el-button
      >
    </div>
    <!-- 订单列表 -->
    <div class="patient-form">
      <el-table style="width: 100%" :data="totalList" class="center-table">
        <el-table-column
          width="220"
          label="活动名称"
          align="center"
          prop="activityName"
        />
        <el-table-column
          width="150"
          label="渠道名称"
          align="center"
          prop="channelName"
        />
        <el-table-column
          width="100"
          label="创建人"
          align="center"
          prop="createOperator"
        />
        <el-table-column
          label="创建时间"
          width="170"
          align="center"
          prop="createTime"
        >
        </el-table-column>
        <el-table-column
          label="优惠券张数"
          width="140"
          align="center"
          prop="couponSheetNum"
        />
        <el-table-column
          label="截止时间"
          width="170"
          align="center"
          prop="expireDateTime"
        >
          <template #default="{ row }">
            <span v-if="row.expireDateTime">{{ row.expireDateTime }}</span>
            <span v-else>--</span>
          </template>
        </el-table-column>

        <el-table-column
          label="状态"
          align="center"
          :formatter="formatOrderStatus"
          prop="status"
        />
        <el-table-column label="操作" width="220" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              class="icon-wrapper"
              type="text"
              @click="addCoupons(row.id)"
              >编辑</el-button
            >
            <el-button
              class="icon-wrapper"
              type="text"
              @click="copyLink(row.id)"
              >复制链接</el-button
            >

            <el-button
              class="icon-wrapper"
              type="text"
              @click="getActivityCode(row.id, row)"
              >二维码</el-button
            >
            <el-button
              class="icon-wrapper"
              @click="toDelete(row.id)"
              type="text"
              style="color: #ef2e2e"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页器 -->
    <div class="page-container">
      <el-pagination
        layout="total, prev, pager, next"
        :total="pageTotal"
        :current-page="listParams.pageNum"
        :page-size="listParams.pageSize"
        @current-change="currentChange"
        background
      />
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  data() {
    return {
      totalList: [],
      pageTotal: 0,
      // 订单列表请求参数
      listParams: {
        pageNum: 1,
        pageSize: 10,
        activityName: "",
        channelName: "",
      },
    };
  },
  computed: {
    ...mapState({
      equipment: (state) => state.equipment,
    }),
  },
  mounted() {
    if (this.equipment == "pad") {
      this.listParams.pageSize = 6;
    } else {
      this.listParams.pageSize = 9;
    }

    if (this.$route.query.patientName) {
      this.listParams.patientName = this.$route.query.patientName;
    }
    if (this.$route.query.activityName) {
      this.listParams.activityName = this.$route.query.activityName;
    }
    this.getOrderList();
  },
  methods: {
    // 获取订单列表
    async getOrderList() {
      const { data } = await this.$api.baseApis.getCouponsList(this.listParams);
      console.log(data);
      this.totalList = data.list;
      this.pageTotal = data.total;
    },
    // 状态-转化
    formatOrderStatus(row) {
      const MAP = {
        0: "未开始",
        1: "进行中",
        2: "已结束",
      };
      return MAP[row.status];
    },

    // 搜索订单
    doSearch() {
      this.listParams.pageNum = 1;
      this.getOrderList();
    },
    // 切换页码
    currentChange(page) {
      this.listParams.pageNum = page;
      this.getOrderList();
    },
    // 解决输入不了
    inputChange(e) {
      this.$forceUpdate(e);
    },

    // 获取二维码
    async getActivityCode(id, item) {
      const loading = this.$loading({
        lock: true,
        text: "二维码生成中，请稍候",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.6)",
        color: "#fff",
      });

      const { data } = await this.$api.baseApis.getActivityQRCode(id);
      loading.close();
      if (data) {
        const h = this.$createElement;
        this.$msgbox({
          title: "优惠券二维码",
          message: h("p", null, [
            h("img", {
              attrs: {
                src: data.qrImg,
              },
              style:
                "width:200px;height:200px;box-sizing:border-box;margin-left:96px;",
            }),
          ]),
          showCancelButton: false,
          confirmButtonText: "下载二维码",
          // cancelButtonText: "关闭",
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = "下载中...";
              const link = document.createElement("a");
              link.href = data.qrImg;
              link.download = item.activityName + "优惠券二维码";
              link.click();
              setTimeout(() => {
                done();
                setTimeout(() => {
                  instance.confirmButtonLoading = false;
                }, 300);
              }, 2000);
            } else {
              done();
            }
          },
        }).then((action) => {
          if (action == "confirm") {
            this.$message({
              type: "success",
              message: "下载成功",
            });
          }
        });
      }
    },

    // 复制链接
    async copyLink(id) {
      const { data } = await this.$api.baseApis.getActivityLink(id);

      let input = document.createElement("input");
      input.value = data;
      document.body.appendChild(input);
      input.select();
      document.execCommand("Copy");
      this.$message({
        message: "复制成功",
        type: "success",
      });
      document.body.removeChild(input);

      // navigator.clipboard.writeText 该方法需要在安全域下才能够使用，比如：https 协议的地址、127.0.0.1、localhost
      // navigator.clipboard
      //   .writeText(str)
      //   .then(() => {
      //     this.$message.success("复制成功");
      //   })
      //   .catch((err) => {
      //     // 复制失败
      //     console.error("复制失败");
      //   });
    },
    // 删除优惠券
    toDelete(id) {
      this.$confirm("删除后活动链接即失效, 是否继续?", "提示", {
        confirmButtonText: "删除",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        this.$api.baseApis.delActivity(id).then((res) => {
          if (res.data == true) {
            this.$message.success("删除成功");
            let _this = this;
            setTimeout(() => {
              _this.getOrderList();
            }, 500);
          }
        });
      });
    },
    // 新增
    addCoupons(id) {
      this.$router.push({
        name: "coupons-edit",
        query: { id },
      });
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  width: 100%;
  .patient-navbar {
    padding-right: 10px;
    align-items: center;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    margin-bottom: 20px;

    .search-btn {
      cursor: pointer;
      text-align: center;
      width: 90px;
      height: 32px;
      border-radius: 2px;
      background: #2971eb;
      font-size: 14px;
      line-height: 32px;
      color: #ffffff;
      transition: transform 0.2s ease;
    }
    .search-btn:hover {
      transform: scale(1.1);
    }
  }
  // 表单样式
  .patient-form {
    box-sizing: border-box;
    overflow-y: auto;
    height: 710px;
    overflow: auto;
  }
  // 分页器样式
  .page-container {
    text-align: right;
    margin-right: -10px;
  }
}

// table表头的颜色
::v-deep(.center-table th) {
  background: #f7f8fa;
}

// 调价dialog居中样式
::v-deep(.my-centered-dialog .el-dialog__body) {
  display: flex;
  justify-content: center;
}

::v-deep(.icon-wrapper) {
  transition: transform 0.2s ease;
}

::v-deep(.icon-wrapper:hover) {
  transform: scale(1.2);
}

// 平板适配
@media screen and (max-width: 1300px) {
  .patient-form {
    box-sizing: border-box;
    overflow-y: auto;
    height: 521px !important;
    overflow: auto;
  }
}
</style>

<style lang="less">
.el-loading-spinner i {
  color: #fff !important;
}
.el-loading-spinner .el-loading-text {
  color: #fff !important;
}
</style>
