<template>
  <div class="patient-management">
    <el-container>
      <!-- 左边Tab栏 -->
      <div class="left-tab">
        <el-tabs v-model="activeName" class="custom-tabs">
          <el-tab-pane
            :label="roleItem.name"
            :name="roleItem.roleId"
            v-for="roleItem in roleList"
            :key="roleItem.roleId"
          >
            <el-table
              :data="roleItem.adminUserList"
              @row-click="handleRow"
              class="left-tab-table"
            >
              <el-table-column label="账号名称" width="119" align="center">
                <template #default="{ row }">
                  <div
                    style="display: flex; justify-content: space-evenly"
                    :class="currentAdminId == row.adminId ? 'active' : ''"
                  >
                    <span style="line-height: 40px">{{ row.userName }}</span>
                  </div>
                </template>
              </el-table-column>
              <el-table-column label="人员信息" width="181" align="left">
                <template #default="{ row }">
                  <div
                    style="display: flex; justify-content: left"
                    :class="currentAdminId == row.adminId ? 'active' : ''"
                  >
                    <el-avatar :src="row.avatarUrl"></el-avatar>
                    <span style="line-height: 40px; margin-left: 10px">{{
                      row.realName
                    }}</span>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </div>

      <!-- 右边日历 -->
      <div class="right-calendar">
        <!-- 设置排班时间 -->
        <div class="head">
          <div class="el-icon-back" @click="monthDistanceFn('sub')"></div>
          <div class="content" style="width: 86px">{{ monthText }}</div>
          <div class="el-icon-right" @click="monthDistanceFn('add')"></div>

          <span style="margin-left: 7px">批量设置：每周</span>
          <el-select
            multiple
            style="
              margin-right: 3px;
              margin-left: 7px;
              width: 170px;
              background-color: #fff;
            "
            placeholder="请选择星期"
            v-model="scheduleParams.daysOfWeek"
            class="weekSelect"
          >
            <el-option
              v-for="week in weekList"
              :key="week.value"
              :label="week.label"
              :value="week.value"
            >
            </el-option>
          </el-select>
          <span>从</span>
          <el-select
            class="input_time"
            style="margin-right: 7px; margin-left: 3px"
            placeholder="开始时间"
            v-model="scheduleParams.startTimeStr"
          >
            <el-option
              v-for="time in startTimes"
              :key="time"
              :label="time"
              :value="time"
            ></el-option>
          </el-select>
          <span>至</span>

          <el-select
            class="input_time"
            style="margin-right: 7px; margin-left: 3px"
            placeholder="结束时间"
            v-model="scheduleParams.endTimeStr"
          >
            <el-option
              v-for="time in endTimes"
              :key="time"
              :label="time"
              :value="time"
            ></el-option>
          </el-select>
          <el-button
            type="primary"
            class="confirmSchedule_btn"
            @click="confirmSchedule"
            >确认排班</el-button
          >
        </div>
        <!-- 设置日历 -->
        <div class="calendar">
          <el-calendar v-model="activeMonth" @input="handleDateClick">
            <template #dateCell="{ data }">
              <!-- :class="data.isSelected ? 'is-selected' : ''" -->
              <div class="style-calendar">
                <div>{{ data.day.split("-").slice(2).join("-") }}</div>
                <div
                  v-if="
                    calendarArray.find((item) => item.scheduleDate === data.day)
                  "
                >
                  <div
                    class="scheduleItems_out"
                    v-for="(son, i) in calendarArray.find(
                      (item) => item.scheduleDate === data.day
                    ).scheduleItems"
                    :key="i"
                    :style="{
                      backgroundColor: getStatusColor(son.scheduleStatus),
                    }"
                  >
                    <div>
                      <span>
                        {{ scheduleStatusText(son.scheduleStatus) }}
                        ：
                        <span class="text_time">
                          {{ son.startTime }}
                          --
                          {{ son.endTime }}
                        </span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </el-calendar>
        </div>
      </div>
    </el-container>

    <!-- 排班弹框 -->
    <el-dialog :title="datePopTitle" :visible.sync="scheduleDialogVisible">
      <el-table :data="dateScheduleItems" style="width: 100%">
        <el-table-column label="开始" align="center">
          <template slot-scope="scope">
            <!-- :disabled="
                new Date(
                  scope.row.scheduleDate + ' ' + scope.row.startTime
                ).getTime() < new Date().getTime()
              " -->
            <el-select
              v-model="scope.row.startTime"
              @change="validateTime(scope.row)"
            >
              <el-option
                v-for="item in startTimeCell"
                :key="item"
                :label="item"
                :value="item"
              >
              </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="结束" align="center">
          <template slot-scope="scope">
            <!-- :disabled="
                new Date(
                  scope.row.scheduleDate + ' ' + scope.row.startTime
                ).getTime() < new Date().getTime()
              " -->
            <el-select
              v-model="scope.row.endTime"
              @change="validateTime(scope.row)"
            >
              <el-option
                v-for="item in endTimeCell"
                :key="item"
                :label="item"
                :value="item"
              >
              </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="时长" align="center">
          <template slot-scope="scope">
            <span style="margin-right: 15px">{{
              calculateTimeDifference(scope.row.startTime, scope.row.endTime)
            }}</span>
            <span v-if="scope.row.scheduleStatus == 1 && scope.row.id"
              >已请假</span
            >
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center">
          <template
            slot-scope="scope"
            v-if="
              new Date(
                scope.row.scheduleDate + ' ' + scope.row.endTime
              ).getTime() > new Date().getTime()
            "
          >
            <el-button
              type="text"
              @click="delRow(scope.row.id, scope.row.newId)"
              >删除</el-button
            >
            <el-button
              type="text"
              style="color: #ff447c"
              @click="forLeave(scope.row.id, 1)"
              v-if="scope.row.scheduleStatus == 0 && scope.row.id"
              >请假</el-button
            >
            <el-button
              type="text"
              style="color: #ff447c"
              v-if="scope.row.scheduleStatus == 1 && scope.row.id"
              @click="forLeave(scope.row.id, 2)"
              >取消请假</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <div class="add-time">
        <el-button
          type="success"
          size="medium"
          @click="addTimeRow"
          icon="el-icon-plus"
          >新增时间段</el-button
        >
      </div>
      <div class="confirm">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm"
          icon="el-icon-folder"
          >保存</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dayjs from "dayjs";
export default {
  data() {
    return {
      // 左边Tab栏-角色列表
      activeName: "2",
      roleList: [
        { name: "医生", roleId: "2" },
        { name: "医疗助理", roleId: "3" },
        { name: "治疗师", roleId: "4" },
      ],
      weekList: [
        { value: "周一", label: "周一" },
        { value: "周二", label: "周二" },
        { value: "周三", label: "周三" },
        { value: "周四", label: "周四" },
        { value: "周五", label: "周五" },
        { value: "周六", label: "周六" },
        { value: "周日", label: "周日" },
      ], // 星期List
      scheduleParams: {
        adminId: null,
        currentMonth: "",
        daysOfWeek: [],
        startTimeStr: "",
        endTimeStr: "",
      },
      //当前时间相距的月数
      monthDistance: 0,
      monthText: "",
      activeMonth: null,
      startTimes: this.generateTimes(),
      endTimes: this.generateTimes(),
      // cell内部时间选择
      startTimeCell: this.generateTimesCell(),
      endTimeCell: this.generateTimesCell(),

      // 日历中有的数据
      calendarArray: [],

      // 当前选中的人
      currentAdminId: null,
      // 点击当前的cell，里面的数据
      cellData: {},
      // 单日弹窗
      scheduleDialogVisible: false,
      // 当前点的日期
      clickDate: "",
      // 标题
      datePopTitle: "",
      dateScheduleItems: [],
      scheduleOriItems: [],
      // 单日删除的
      delListArr: [],
    };
  },
  mounted() {
    this.monthText = this.getAddMonth(0);
    this.getRoleList();
  },

  methods: {
    pageInit() {
      this.monthText = this.getAddMonth(this.monthDistance);
      this.activeMonth = new Date(this.monthText);
      this.scheduleParams.currentMonth = this.monthText;
      this.scheduleParams.adminId = this.currentAdminId;

      //  重新获取数据
      this.getScheduleData(this.currentAdminId, this.monthText);
    },

    monthDistanceFn(str) {
      if (str == "add") {
        this.monthDistance++;
      }
      if (str == "sub") {
        this.monthDistance--;
      }
      this.pageInit();
    },
    // 获取距离当前n月的日期
    getAddMonth(num) {
      const today = dayjs();
      const date = today.add(num, "month").format("YYYY-MM");
      return date;
    },
    // 获取角色人员列表
    async getRoleList() {
      const { data } = await this.$api.baseApis.getRoleList();

      for (let item of data) {
        item.roleId = "" + item.roleId;
      }

      this.roleList = data;

      // 默认显示第一个
      this.currentAdminId = this.roleList[0].adminUserList[0].adminId;
      this.pageInit();
    },

    // 下拉框设置0:00 - 23:00 下拉框
    generateTimes() {
      let times = [];
      for (let i = 12; i < 48; i++) {
        let hour = Math.floor(i / 2);
        hour = hour < 10 ? "0" + hour : hour;
        let minute = i % 2 === 0 ? "00" : "30";
        times.push(hour + ":" + minute);
      }
      return times;
    },

    // 下拉框cell里面
    generateTimesCell() {
      let times = [];
      for (let i = 12; i < 48; i++) {
        let hour = Math.floor(i / 2);
        hour = hour < 10 ? "0" + hour : hour;
        let minute = i % 2 === 0 ? "00" : "30";
        times.push(hour + ":" + minute);
      }
      return times;
    },
    // 确认排班
    async confirmSchedule() {
      console.log("this.scheduleParams", this.scheduleParams);
      // 校验数据
      if (this.scheduleParams.daysOfWeek.length == 0) {
        this.$message.error("请选择星期");
        return;
      }
      if (this.scheduleParams.startTimeStr == "") {
        this.$message.error("请选择开始时间");
        return;
      }
      if (this.scheduleParams.endTimeStr == "") {
        this.$message.error("请选择结束时间");
        return;
      }
      if (
        new Date(
          "2023-04-01" + " " + this.scheduleParams.startTimeStr
        ).getTime() >
        new Date("2023-04-01" + " " + this.scheduleParams.endTimeStr).getTime()
      ) {
        this.$message.error("开始时间不能大于结束时间");
        return;
      }
      if (
        new Date(
          "2023-04-01" + " " + this.scheduleParams.startTimeStr
        ).getTime() ==
        new Date("2023-04-01" + " " + this.scheduleParams.endTimeStr).getTime()
      ) {
        this.$message.error("结束时间应大于开始时间");
        return;
      }

      const { data } = await this.$api.baseApis.manageSchedule(
        this.scheduleParams
      );
      if (data === true) {
        this.$message.success("排班成功");
        this.scheduleParams = {
          adminId: null,
          currentMonth: "",
          daysOfWeek: [],
          startTimeStr: "",
          endTimeStr: "",
        };
        this.pageInit();
      }
    },
    // 点击el-table,显示对应右边日历
    async handleRow(row) {
      this.currentAdminId = row.adminId;
      this.pageInit();
    },
    // 获取人员排班数据
    async getScheduleData(id, monthText) {
      const { data } = await this.$api.baseApis.getScheduleList({
        adminId: id,
        data: monthText,
      });
      this.calendarArray = data;
      // 如果当前用户没有排班，则显示空日历
      if (!this.calendarArray) this.calendarArray = [];
    },

    // 根据日期返回年月日星期
    getDayWeek(date) {
      const weekList = ["日", "一", "二", "三", "四", "五", "六"];
      let dayjsObj;
      if (date) {
        dayjsObj = dayjs(date);
      } else {
        dayjsObj = dayjs();
      }

      let dateLong =
        dayjsObj.format("YYYY-MM-DD") + " " + "星期" + weekList[dayjsObj.day()];
      return dateLong;
    },

    // 日历格子的点击事件
    handleDateClick(e) {
      // 清空原来的删除的
      this.delListArr = [];

      this.clickDate = dayjs(e).format("YYYY-MM-DD");
      console.log(this.calendarArray);

      this.cellData = {};
      for (let i = 0; i < this.calendarArray.length; i++) {
        if (this.calendarArray[i].scheduleDate == this.clickDate) {
          this.cellData = this.calendarArray[i];
        }
      }
      // 有数据
      if (this.cellData.scheduleDate) {
        this.datePopTitle = this.getDayWeek(this.cellData.scheduleDate);
        let newCellData = JSON.parse(JSON.stringify(this.cellData));

        this.dateScheduleItems = newCellData.scheduleItems;

        // 存入adminId和时间 改变请假状态 0正常  1请假
        for (let i = 0; i < this.dateScheduleItems.length; i++) {
          this.dateScheduleItems[i].adminId = this.currentAdminId;
          this.dateScheduleItems[i].scheduleDate = this.clickDate;
          if (this.dateScheduleItems[i].scheduleStatus == 4) {
            this.dateScheduleItems[i].scheduleStatus = 1;
          } else {
            this.dateScheduleItems[i].scheduleStatus = 0;
          }
        }
        this.scheduleOriItems = JSON.parse(
          JSON.stringify(this.dateScheduleItems)
        );

        this.scheduleDialogVisible = true;
      } else {
        // 没数据
        this.datePopTitle = this.getDayWeek(this.clickDate);
        this.dateScheduleItems = [];
        this.scheduleOriItems = [];
        this.scheduleDialogVisible = true;
        console.log(this.clickDate + "没有记录");
      }
    },

    scheduleStatusText(scheduleStatus) {
      const statusMap = {
        1: "出诊",
        2: "上班",
        3: "可预约",
        4: "请假",
      };
      return statusMap[scheduleStatus] || "";
    },
    getStatusColor(scheduleStatus) {
      const colorMap = {
        1: "#ebf1fc", // 出诊
        2: "#dddddd", // 上班
        3: "#eaf5f4", // 可预约
        4: "#fcf1f1", // 请假
      };
      return colorMap[scheduleStatus] || "white";
    },
    // 计算时差
    calculateTimeDifference(StartTime, EndTime) {
      if (!StartTime || !EndTime) {
        return "--";
      }

      // 设定一个基准日期,将时间字符串转换为Date对象
      const startDate = new Date(`2000-01-01T${StartTime}:00`);
      const endDate = new Date(`2000-01-01T${EndTime}:00`);
      // 计算时间差,结果以毫秒为单位
      const differenceInMilliseconds = endDate.getTime() - startDate.getTime();
      // 将毫秒转换为小时
      return differenceInMilliseconds / (1000 * 60 * 60) + "小时";
    },
    // 新增时间段
    addTimeRow() {
      console.log("新增时间段");
      this.dateScheduleItems.push({
        scheduleDate: this.clickDate,
        adminId: this.currentAdminId,
        startTime: "",
        endTime: "",
        newId: new Date().getTime(),
      });

      console.log(this.dateScheduleItems);
    },
    // 删除时间段
    delRow(id, newId) {
      console.log("删除时间段", id, newId);
      // 如果是新增的删除
      if (!id && newId) {
        console.log("这是删除新增的");
        for (let i = 0; i < this.dateScheduleItems.length; i++) {
          console.log(this.dateScheduleItems.newId);
          if (this.dateScheduleItems[i].newId == newId) {
            this.dateScheduleItems.splice(i, 1);
          }
        }
      }
      if (id) {
        console.log("这是删除原来的");
        for (let i = 0; i < this.dateScheduleItems.length; i++) {
          console.log(this.dateScheduleItems.newId);
          if (this.dateScheduleItems[i].id == id) {
            this.delListArr.push(this.dateScheduleItems[i]);
            this.dateScheduleItems.splice(i, 1);
          }
        }
      }
    },

    // 请假相关
    forLeave(id, type) {
      for (let i = 0; i < this.dateScheduleItems.length; i++) {
        if (this.dateScheduleItems[i].id == id) {
          // 请假
          if (type == 1) {
            this.dateScheduleItems[i].scheduleStatus = 1;
          }
          // 取消请假
          if (type == 2) {
            this.dateScheduleItems[i].scheduleStatus = 0;
          }
        }
      }
    },

    async submitForm() {
      console.log("单个日期保存的数据", this.dateScheduleItems);

      let addListArr = [];
      let editListArr = [];

      // Object.entries(object1).toString() === Object.entries(object2).toString();

      for (let i = 0; i < this.dateScheduleItems.length; i++) {
        if (this.dateScheduleItems[i].newId) {
          addListArr.push(this.dateScheduleItems[i]);
        } else {
          // 如果是未来的时间才进来
          // if (
          //   new Date(
          //     this.dateScheduleItems[i].scheduleDate +
          //       " " +
          //       this.dateScheduleItems[i].endTime
          //   ).getTime() > new Date().getTime()
          // ) {
          //   editListArr.push(this.dateScheduleItems[i]);
          // }

          for (let j = 0; j < this.scheduleOriItems.length; j++) {
            if (this.dateScheduleItems[i].id === this.scheduleOriItems[j].id) {
              // 判断属性是否有改变
              if (
                Object.entries(this.dateScheduleItems[i]).toString() ===
                Object.entries(this.scheduleOriItems[j]).toString()
              ) {
              } else {
                editListArr.push(this.dateScheduleItems[i]);
              }
            }
          }
        }
      }

      let postData = {
        addList: addListArr,
        delList: this.delListArr,
        editList: editListArr,
      };
      // 判断都是空数组就不保存
      if (
        postData.addList.length == 0 &&
        postData.delList.length == 0 &&
        postData.editList.length == 0
      ) {
        this.$message.warning("没有更改");
        return;
      }

      console.log("postData", postData);

      const { data } = await this.$api.baseApis.editSchedule(postData);

      if (data === true) {
        this.$message.success("排班成功");
        // 清空
        this.delListArr = [];
        this.scheduleDialogVisible = false;
        let _this = this;
        setTimeout(function () {
          _this.pageInit();
        }, 600);
      } else {
        this.$message.error("排班失败");
      }
    },
    validateTime(row) {
      if (row.startTime && row.endTime && row.startTime >= row.endTime) {
        this.$message.error("结束时间必须大于开始时间");
      }
    },
  },
  // watch: {
  //   dateScheduleItems: {
  //     immediate: true,
  //     deep: true,
  //     handler(newValue, oldValue) {
  //       console.log(99, newValue);
  //     },
  //   },
  // },
};
</script>

<style scoped lang="less">
.patient-management {
  display: flex;
  .left-tab {
    margin-right: 15px;
    background-color: #fff;
    box-sizing: border-box;
    width: 300px;
    align-items: center;
    justify-content: center;
    ::v-deep(.el-tabs__item) {
      width: 100px;
      height: 40px;
      color: #666666;
      text-align: center;
      line-height: 40px;
      font-size: 16px;
      background-color: #fceee8;
      transition: transform 0.2s;
    }
    ::v-deep(.el-tabs__item.is-active) {
      color: var(--primary-color); /* 被选中时的字体颜色 */
    }
  }
  .right-calendar {
    width: 100%;
    height: 900px;
    flex: 1;
    .head {
      padding: 0 8px;
      height: 35px;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      .content {
        margin-left: 5px;
        margin-right: 5px;
      }
      .arrow {
        cursor: pointer;
        width: 20;
        height: 20px;
        background-color: rgba(125, 141, 166, 0.1);
        text-align: center;
        line-height: 20px;
      }
      .confirm-btn {
        cursor: pointer;
        background-color: #f59a23;
        width: 82px;
        height: 39px;
        border-radius: 5px;
        display: inline-block;
        text-align: center;
        line-height: 39px;
        color: #fff;
        transition: transform 0.2s;
      }
    }
  }
}

::v-deep(.el-table thead) {
  color: #1a1a1a;
  font-size: 16px;
}
::v-deep(.left-tab-table .el-table__body) {
  cursor: pointer;
  tr > td {
    transition: transform 0.3s;
  }
  tr:hover > td {
    color: var(--primary-color);
  }
}

::v-deep(.el-tabs__header .is-top) {
  padding: 0;
  margin: 0;
}

.style-calendar {
  box-sizing: border-box;
}

// 日历被选中样式
.is-selected {
  color: var(--primary-color);
}
// 自定义日历格子的高度
::v-deep(.el-calendar-table .el-calendar-day) {
  // min-height: 115px;
  height: 100%;
}
// 弹框新增时间段样式
.add-time {
  margin-top: 20px;
  padding-left: 20px;
  margin-bottom: 24px;
  display: flex;
  align-items: center;
}
//弹框底部按钮样式
.confirm {
  display: flex;
  justify-content: flex-end;
}
// 弹框el-select样式
::v-deep(.el-select .el-input__inner) {
  border: none;
  width: 130px;
  box-shadow: none;
}
::v-deep(.input_time.el-select .el-input__inner) {
  border: none;
  width: 100px;
  box-shadow: none;
}
// 批量设置星期el-select
::v-deep(.el-input__inner) {
  width: 200px;
}

::v-deep(.el-calendar-table td.is-today) {
  color: #666;
}

.el-icon-back {
  cursor: pointer;
}
.el-icon-right {
  cursor: pointer;
}

.active span {
  color: var(--primary-color);
}

.scheduleItems_out {
  box-sizing: border-box;
  padding: 6px 10px;
  border-radius: 4px;
  margin-bottom: 10px;
  * {
    font-size: 13px;
    line-height: 24px;
  }
}

// 平板适配
@media screen and (max-width: 1300px) {
  .left-tab {
    width: 200px !important;
    align-items: center;
    justify-content: center;
    ::v-deep(.el-tabs__item) {
      width: 50px;
      height: 40px;
      color: #666666;
      text-align: center;
      line-height: 40px;
      font-size: 16px;
      background-color: #fceee8;
      transition: transform 0.2s;
    }
  }

  // 自定义日历格子的高度
  ::v-deep(.el-calendar-table .el-calendar-day) {
    // min-height: 60px;
    // height: auto;
  }

  ::v-deep(.el-tabs__item) {
    width: 66px !important;
  }
  ::v-deep(.el-table_1_column_1) {
    width: 66px !important;
  }

  ::v-deep(.el-input__inne) {
    width: 80px !important;
  }
  .left-tab {
    max-height: 650px;
    overflow-y: auto;
  }

  .scheduleItems_out {
    box-sizing: border-box;
    padding: 4px 6px;
    border-radius: 3px;
    margin-bottom: 6px;
    .text_time {
      display: block;
    }
    * {
      font-size: 12px;
      line-height: 22px;
    }
  }
}
</style>
<style lang="less">
.el-table__cell .cell {
  font-size: 14px !important;
  font-weight: normal !important;
}
.el-calendar__header {
  display: none !important;
}

.el-calendar-table:not(.is-range) td.next {
  pointer-events: none;
}
.el-calendar-table:not(.is-range) td.prev {
  pointer-events: none;
}

.right-calendar tbody .current {
  min-height: 100px;
  height: 100px;
}
</style>
