<template>
  <div class="money_login_page">
    <div class="login-content">
      <div class="login-content-title">医疗后台管理</div>
      <el-form
        :model="form"
        label-width="80px"
        label-position="top"
        size="medium"
        :rules="rules"
        ref="ruleForm"
      >
        <el-form-item label="账号" prop="username"
          ><el-input v-model="form.username" placeholder="请输入账号"></el-input
        ></el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input
            v-model="form.password"
            placeholder="请输入密码"
            show-password
          ></el-input
        ></el-form-item>
        <el-form-item label="验证码" prop="code">
          <div style="display: flex">
            <el-input
              v-model="form.code"
              placeholder="请输入验证码"
              style="width: 200px"
            ></el-input>
            <img
              :src="`data:image/jpeg;base64,${codeData.img}`"
              class="login-code pointer"
              @click="getCode"
            />
            <!-- <img class="login-code pointer" @click="getCode" /> -->
          </div>
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            class="login-button"
            @click="submitForm('ruleForm')"
            >登录</el-button
          >
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import md5 from "md5";
import router from "@/router";
export default {
  data() {
    return {
      // 动态验证码
      codeData: {
        img: "",
        uuid: "",
      },
      form: {
        username: "",
        password: "",
        code: "",
      },
      rules: {
        username: [{ required: true, message: "请输入账号", trigger: "blur" }],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        code: [
          {
            required: true,
            message: "请输入验证码",
            trigger: "blur",
          },
        ],
      },
    };
  },
  created() {
    // 一开始看到动态验证码
    this.getCode();
  },
  methods: {
    async getCode() {
      const { data } = await this.$api.baseApis.getCaptchaImage();
      this.codeData = data;
      this.form.code = "";
    },
    submitForm(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          try {
            const { data } = await this.$api.baseApis.loginClick({
              username: this.form.username,
              password: md5(this.form.password),
              code: this.form.code,
              uuid: this.codeData.uuid,
            });
            // this.$message("登录成功");
            // this.$router.push("/work-panel");

            if (data?.token) {
              const { data: userInfo } =
                await this.$api.baseApis.accountInformation(
                  {},
                  {
                    headers: {
                      Authorization: `Bearer ${data.token}`,
                    },
                  }
                );
              // data 的数据是token；userInfo是用户信息
              // console.log("data数据是：", data);
              // console.log("userInfo数据是：", userInfo);
              userInfo.token = data.token;
              // console.log("userInfo", userInfo);
              await this.$store.commit("SET_AUTH_INFO", userInfo);
              this.$message.success("登录成功！");
              this.$router.replace("/work-panel").catch(() => {});
            }
          } catch (err) {
            this.getCode();
          }
        } else {
          this.$message.error("信息不全！");
        }
      });
    },
  },
};
</script>
<style scoped>
.money_login_page {
  height: 100vh;
  width: 100%;
  background: linear-gradient(#fff -20%, var(--primary-color));
  position: relative;
}

.login-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 20px;
  background: #fff;
  border-radius: 10px;
}

.login-code {
  width: 100px;
  margin: 0 10px;
}

.login-content-title {
  text-align: center;
  font-size: 30px;
  font-weight: 600;
  letter-spacing: 2px;
  padding: 10px;
}

.login-button {
  width: 320px;
  display: block;
  margin: 30px auto 0;
}
</style>
