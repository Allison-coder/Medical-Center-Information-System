<template>
  <div class="patient-management">
    <!-- 患者姓名、头像 -->
    <BaseInfo :data="patientData" @save="getPatientInformation"/>

    <!-- 患者表格管理 -->
    <div class="patient-form">
      <el-table
        :data="patientTableArray"
        style="width: 100%"
        class="center-table"
      >
        <el-table-column
          label="患者ID"
          width="180"
          align="center"
          prop="patientSn"
        />
        <el-table-column label="患者姓名" align="center" prop="patientName" />
        <el-table-column
          label="性别"
          align="center"
          prop="gender"
          :formatter="formatGender"
        />
        <el-table-column
          label="身份类型"
          align="center"
          prop="identityType"
          :formatter="formatIdentityType"
        />
        <el-table-column
          label="手机号"
          width="130"
          align="center"
          prop="phoneNumber"
        />
        <el-table-column label="累计消费" align="center" prop="totalCost" />
        <el-table-column
          label="任务列表"
          align="center"
          min-width="130"
          :formatter="formatTaskList"
        />

        <el-table-column label="操作" width="290" align="center" fixed="right">
          <template #default="{ row }">
            <div style="display: flex; justify-content: space-evenly">
              <el-button
                @click="goTask(row.orderSn, row.patientSn, row.patientName)"
                class="icon-wrapper"
                type="text"
                >查看任务</el-button
              >
              <el-button
                type="text"
                class="icon-wrapper"
                @click="goOrder('', row.patientName)"
                >订单</el-button
              >
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 患者资料 -->

    <div class="_com_form_title_box">
      <div class="_com_form_title">患者资料</div>
    </div>

    <div class="patient-information" id="patient-base-info">
      <div class="information">
        <span class="text">身份:</span>
        <el-select
          class="custom-select-height"
          v-model="patientSaveData.identityType"
          placeholder="请选择"
          size="small"
          @change="savePatientBasicInfo"
        >
          <el-option
            v-for="item in identityArray"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div class="information">
        <span class="text">性别:</span>
        <el-select
          class="custom-select-height"
          v-model="patientSaveData.gender"
          placeholder="请选择"
          size="small"
          @change="savePatientBasicInfo"
        >
          <el-option
            v-for="item in genderArray"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div class="information">
        <span class="text">年龄:</span>
        <el-input
          placeholder="请输入"
          v-model="patientSaveData.age"
          size="small"
          @change="savePatientBasicInfo()"
        />
      </div>
      <div class="information">
        <span class="text">职业:</span>
        <el-input
          placeholder="请输入"
          v-model="patientSaveData.occupation"
          size="small"
          @change="savePatientBasicInfo"
        />
      </div>
      <div class="information">
        <span class="text">身高:</span>
        <el-input
          placeholder="请输入"
          v-model="patientSaveData.height"
          size="small"
          style="width: 94px"
          @change="savePatientBasicInfo"
        />
        <span> cm</span>
      </div>
      <div class="information">
        <span class="text">体重:</span>
        <el-input
          id="test-input"
          placeholder="请输入"
          v-model="patientSaveData.weight"
          size="small"
          style="width: 94px"
          @change="savePatientBasicInfo"
        />
        <span> kg</span>
      </div>
      <div class="information">
        <span class="text">国籍:</span>
        <el-input
          placeholder="请输入"
          v-model="patientSaveData.nationality"
          size="small"
          @change="savePatientBasicInfo"
        />
      </div>
      <div class="information">
        <span class="text">语言:</span>
        <el-input
          placeholder="请输入"
          v-model="patientSaveData.language"
          size="small"
          @change="savePatientBasicInfo"
        />
      </div>
      <div class="information">
        <span class="text">翻译:</span>
        <el-select
          class="custom-select-height"
          v-model="patientSaveData.translation"
          placeholder="请选择"
          size="small"
          @change="savePatientBasicInfo"
        >
          <el-option
            v-for="item in FanYiArray"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div class="information"></div>

      <div class="information" style="width: 80%">
        <span class="text">备注:</span>
        <el-input
          style="width: 60%"
          class="bzInput"
          placeholder="请输入"
          v-model="patientSaveData.remarks"
          maxlength="38"
          size="small"
          @change="savePatientBasicInfo"
        />
      </div>
      <div class="information" style="width: 99%">
        <span class="text">目的:</span>
        <el-checkbox-group
          style="display: inline-block; margin-right: 20px"
          v-model="MuDiList"
          @change="savePatientBasicInfo"
        >
          <el-checkbox
            v-for="item in MuDiArr"
            :key="item.value"
            :label="item.key"
            :value="item.value"
          ></el-checkbox>
        </el-checkbox-group>
        <el-input
          v-if="MuDiList.find((item) => item === '其他')"
          placeholder="请输入"
          v-model="MuDiQiTa"
          resize="none"
          size="small"
          maxlength="18"
          style="width: 270px"
          @input="inputChange($event)"
          @change="savePatientBasicInfo"
        />
      </div>
    </div>

    <!-- Tab栏切换 -->
    <div class="patient-tab">
      <el-tabs
        v-model="activeName"
        @tab-click="handleClick"
        class="custom-tab-label"
      >
        <!-- 病历资料 -->
        <el-tab-pane label="病历资料" name="first">
          <div class="tab-btns">
            <el-button type="primary" icon="el-icon-printer" @click="handleOpenPrintDialog('case')">打印</el-button>
          </div>
          
          <div id="patient-case-info">
            <div class="patient-information">
            <div class="information">
              <span class="text">体温:</span>
              <el-input
                placeholder="请输入"
                v-model="MedicalRecordSaveData.bodyTemperature"
                size="small"
                style="width: 100px"
                @change="saveOutpatientMedicalRecord"
              />
              <span> ℃</span>
            </div>
            <div class="information">
              <span class="text">血压:</span>
              <el-input
                placeholder="请输入"
                v-model="MedicalRecordSaveData.bloodPressure"
                size="small"
                style="width: 71px"
                @change="saveOutpatientMedicalRecord"
              />
              <span> mmHg</span>
            </div>
            <div class="information">
              <span class="text">脉搏:</span>
              <el-input
                placeholder="请输入"
                v-model="MedicalRecordSaveData.pulse"
                size="small"
                style="width: 71px"
                @change="saveOutpatientMedicalRecord"
              />
              <span> 次/分</span>
            </div>
            <div class="information">
              <span class="text">血氧:</span>
              <el-input
                placeholder="请输入"
                v-model="MedicalRecordSaveData.bloodOxygen"
                size="small"
                style="width: 72px"
                @change="saveOutpatientMedicalRecord"
              />
              <span> %</span>
            </div>
            <div class="information"></div>

            <!-- <div class="information">
              <span class="text">婚姻状况:</span>
              <el-select
                class="custom-select-height"
                v-model="patientSaveData.maritalStatus"
                placeholder="请选择"
                size="small"
                @change="savePatientBasicInfo"
              >
                <el-option
                  v-for="item in marryArray"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </div> -->
            </div>

            <div class="pic_box_out">
              <div ref="myDiv" class="pic_box" @click="getPicSpot($event)">
                <img class="diagram1" src="@/assets/diagram1.png" alt="" />
                <img class="diagram2" src="@/assets/diagram2.png" alt="" />
                <div
                  class="circle_spot"
                  v-for="(item, i) in MedicalRecordSaveData.imgCoordinate"
                  :key="i"
                  :style="{
                    width: circleSpot.r + 'px',
                    height: circleSpot.r + 'px',
                    top: item.y + 'px',
                    left: item.x + 'px',
                  }"
                ></div>

                <el-button
                  type="default"
                  class="cancelCircle"
                  @click="circleSpotCancel"
                  size="small"
                  icon="el-icon-refresh-left"
                  >撤销</el-button
                >
              </div>
              <div class="pic_box_rt">
                <div class="info_title">在什么时候出现症状的？</div>
                <el-input
                  v-model="MedicalRecordSaveData.initialSymptoms"
                  type="textarea"
                  :rows="7"
                  resize="none"
                  maxlength="200"
                  style="width: 100%"
                  @change="saveOutpatientMedicalRecord"
                ></el-input>
                <div class="info_title">疼痛持续时间/频率/性质：</div>
                <el-input
                  v-model="MedicalRecordSaveData.symptomNature"
                  type="textarea"
                  :rows="7"
                  maxlength="200"
                  resize="none"
                  style="width: 100%"
                  @change="saveOutpatientMedicalRecord"
                ></el-input>
                <div class="info_title">请勾选您的疼痛程度：</div>
                <div>
                  <el-radio-group v-model="MedicalRecordSaveData.painLevel">
                    <el-radio
                      v-for="item in TengTongChengDuArr"
                      :key="item.value"
                      :label="item.value"
                      @change="saveOutpatientMedicalRecord"
                      style="margin-right: 30px"
                      >{{ item.label }}</el-radio
                    >
                  </el-radio-group>
                </div>
              </div>
            </div>
          </div>
          <div id="patient-detail-info">
            <div v-for="(item, i) in ClinicCaseConfig" :key="i">
              <div class="_com_form_title_box">
                <div class="_com_form_title">{{ item.title }}</div>
              </div>

              <!-- 三层的数据 -->
              <div v-if="item.contents[0].value.length">
                <div v-for="(son, j) in item.contents" :key="j">
                  <div class="son_title">
                    {{ son.key }}
                  </div>
                  <div class="information3" v-if="son.category">
                    <template v-for="son2 in son.value">
                      <el-checkbox
                        :true-label="1"
                        :false-label="0"
                        :key="son2.key"
                        :label="son2.key"
                        v-model="son2.value"
                        @change="
                          saveOutpatientMedicalRecord(
                            son2.key,
                            son2.value,
                            son.value
                          )
                        "
                        style="margin-right: 30px"
                      ></el-checkbox>
                      <span
                        style="
                          margin-left: -20px;
                          font-size: 14px;
                          display: inline-block;
                          width: 82px;
                        "
                        v-if="'name' in son2 && son2.value"
                        >{{ son2.name }}</span
                      >
                      <el-input
                        v-if="'contents' in son2 && son2.value"
                        placeholder="请输入"
                        v-model="son2.contents"
                        style="
                          margin-right: 30px;
                          width: 160px;
                          margin-left: -20px;
                        "
                        size="small"
                        type="textarea"
                        resize="none"
                        maxlength="20"
                        :autosize="{ minRows: 1, maxRows: 2 }"
                        @input="inputChange($event)"
                        @change="saveOutpatientMedicalRecord"
                      />
                    </template>
                  </div>
                  <div class="information3" v-else>
                    <el-radio-group v-model="son.checked">
                      <template v-for="son2 in son.value">
                        <el-radio
                          :true-label="1"
                          :false-label="0"
                          :key="son2.key"
                          :label="son2.key"
                          @change="saveOutpatientMedicalRecord"
                          style="margin-right: 30px"
                        ></el-radio>
                        <span
                          style="
                            margin-left: -20px;
                            font-size: 14px;
                            display: inline-block;
                            width: 82px;
                          "
                          v-if="'name' in son2 && son.checked == son2.key"
                          >{{ son2.name }}</span
                        >
                        <el-input
                          v-if="'contents' in son2 && son.checked == son2.key"
                          placeholder="请输入"
                          v-model="son2.contents"
                          style="
                            margin-right: 30px;
                            width: 160px;
                            margin-left: -20px;
                          "
                          size="small"
                          type="textarea"
                          resize="none"
                          maxlength="20"
                          :autosize="{ minRows: 1, maxRows: 2 }"
                          @input="inputChange($event)"
                          @change="saveOutpatientMedicalRecord"
                        />
                      </template>
                    </el-radio-group>
                  </div>
                </div>
              </div>
              <div v-else>
                <div class="information3" v-if="item.category">
                  <template v-for="son in item.contents">
                    <template v-if="son.isText == 1">
                      <span
                        style="
                          font-size: 14px;
                          display: inline-block;
                          margin-right: 16px;
                        "
                        >{{ son.key }}</span
                      >
                      <el-input
                        placeholder="请输入"
                        v-model="son.contents"
                        size="small"
                        style="margin-right: 30px; width: 160px"
                        @input="inputChange($event)"
                        type="textarea"
                        resize="none"
                        maxlength="20"
                        :autosize="{ minRows: 1, maxRows: 2 }"
                        @change="saveOutpatientMedicalRecord"
                      />
                    </template>

                    <template v-else>
                      <el-checkbox
                        :true-label="1"
                        :false-label="0"
                        :key="son.key"
                        :label="son.key"
                        v-model="son.value"
                        @change="
                          saveOutpatientMedicalRecord(
                            son.key,
                            son.value,
                            item.contents
                          )
                        "
                        style="
                          margin-right: 30px;
                          margin-top: 10px;
                          margin-bottom: 10px;
                        "
                      ></el-checkbox>
                      <el-input
                        v-if="'contents' in son && son.value"
                        placeholder="请输入"
                        v-model="son.contents"
                        size="small"
                        style="
                          margin-right: 30px;
                          width: 160px;
                          margin-left: -20px;
                        "
                        type="textarea"
                        resize="none"
                        maxlength="20"
                        :autosize="{ minRows: 1, maxRows: 2 }"
                        @input="inputChange($event)"
                        @change="saveOutpatientMedicalRecord"
                        :style="son.key == '每周' ? 'width: 60px' : ''"
                      />
                      <span
                        style="
                          margin-left: -30px;
                          font-size: 14px;
                          margin-right: 30px;
                        "
                        v-if="'contents' in son && son.value && son.key == '每周'"
                      >
                        次</span
                      >
                      <br
                        v-if="item.title == '锻炼情况' && son.key == '完全没有'"
                      />
                      <br
                        v-if="item.title == '锻炼情况' && son.key == '完全没有'"
                      />
                    </template>
                  </template>
                </div>
                <div class="information3" v-else>
                  <el-radio-group v-model="item.checked">
                    <template v-for="son in item.contents">
                      <template v-if="son.isText == 1">
                        <span
                          style="
                            font-size: 14px;
                            display: inline-block;
                            margin-right: 16px;
                          "
                          >{{ son.key }}</span
                        >
                        <el-input
                          placeholder="请输入"
                          v-model="son.contents"
                          size="small"
                          style="margin-right: 30px; width: 160px"
                          @input="inputChange($event)"
                          type="textarea"
                          resize="none"
                          maxlength="20"
                          :autosize="{ minRows: 1, maxRows: 2 }"
                          @change="saveOutpatientMedicalRecord"
                        />
                      </template>
                      <template v-else>
                        <el-radio
                          :true-label="1"
                          :false-label="0"
                          :key="son.key"
                          :label="son.key"
                          @change="saveOutpatientMedicalRecord"
                          style="margin-right: 30px"
                        ></el-radio>
                        <el-input
                          v-if="'contents' in son && item.checked == son.key"
                          placeholder="请输入"
                          v-model="son.contents"
                          size="small"
                          style="
                            margin-right: 30px;
                            width: 160px;
                            margin-left: -20px;
                          "
                          type="textarea"
                          resize="none"
                          maxlength="20"
                          :autosize="{ minRows: 1, maxRows: 2 }"
                          @input="inputChange($event)"
                          @change="saveOutpatientMedicalRecord"
                          :style="son.key == '每周' ? 'width: 60px' : ''"
                        />
                        <span
                          style="
                            margin-left: -20px;
                            font-size: 14px;
                            margin-right: 30px;
                          "
                          v-if="
                            'contents' in son &&
                            item.checked == son.key &&
                            son.key == '每周'
                          "
                        >
                          次</span
                        >
                        <br
                          v-if="item.title == '锻炼情况' && son.key == '完全没有'"
                        />
                        <br
                          v-if="item.title == '锻炼情况' && son.key == '完全没有'"
                        />
                      </template>
                    </template>
                  </el-radio-group>
                </div>
              </div>
            </div>
          </div>
        </el-tab-pane>

        <!-- 面诊记录 -->
        <el-tab-pane label="面诊记录" name="second">
          <div class="tab-btns">
            <el-button type="primary" icon="el-icon-printer" @click="handleOpenPrintDialog('record')">打印</el-button>
            <el-button
            type="success"
            v-if="roles[0] == 'ADMINISTRATOR' || roles[0] == 'NURSE'"
            @click="publishInterviewRecords"
            >{{
              InterviewRecordsSaveData.releaseStatus == 1 ? "隐藏" : "发布"
            }}用户端</el-button
          >
          </div>

          
          <div class="face-record" id='patient-face-record'>
            <div class="detail">
              <div class="doctor-name">
                面诊医生:{{ InterviewRecordsSaveData?.adminName }}
              </div>
              <div class="treat-time">
                面诊时间：{{ InterviewRecordsSaveData?.diagnosisTime }}
              </div>
              <div class="order-number">
                <span>订单号：</span>
                <el-select
                  @change="SelectOrder"
                  v-model="orderSn"
                  placeholder="请选择"
                  style="width: 250px"
                >
                  <el-option
                    v-for="item in patientOrderSnList"
                    :key="item"
                    :label="item"
                    :value="item"
                  >
                  </el-option>
                </el-select>
              </div>
            </div>
            <div class="botttom-detail">
              <div class="info_title">患者主诉</div>
              <el-input
                v-model="InterviewRecordsSaveData.chiefComplaint"
                @input="inputChange($event)"
                type="textarea"
                :rows="3"
                resize="none"
                style="width: 100%"
                @change="saveInterviewRecords()"
              ></el-input>
              <div class="info_title">诊断</div>
              <el-input
                v-model="InterviewRecordsSaveData.diagnosis"
                @input="inputChange($event)"
                type="textarea"
                :rows="3"
                resize="none"
                style="width: 100%"
                @change="saveInterviewRecords()"
              ></el-input>

              <div class="info_title">病情发展预测</div>
              <el-input
                v-model="InterviewRecordsSaveData.forecast"
                @input="inputChange($event)"
                type="textarea"
                :rows="3"
                resize="none"
                style="width: 100%"
                @change="saveInterviewRecords()"
              ></el-input>
              <div class="info_title">医嘱</div>
              <el-input
                v-model="InterviewRecordsSaveData.advice"
                @input="inputChange($event)"
                @change="saveInterviewRecords()"
                type="textarea"
                :rows="3"
                resize="none"
                style="width: 100%"
              ></el-input>
            </div>
          </div>
        </el-tab-pane>

        <!-- 处置方案 -->
        <el-tab-pane label="处置方案" name="third">
          <TabScheme :patientSn="patientData.patientSn" />
        </el-tab-pane>

        <!-- 就诊记录 -->
        <el-tab-pane label="就诊记录" name="fouth">
          <el-table
            :data="treatRocordData"
            style="width: 100%"
            highlight-current-row
            class="center-table"
          >
            <el-table-column
              prop="completionTime"
              label="完成时间"
              min-width="150"
              align="center"
            >
            </el-table-column>
            <el-table-column
              prop="scheduleTime"
              label="预约时间段"
              align="center"
              min-width="180"
            >
            </el-table-column>
            <el-table-column
              prop="realName"
              label="诊疗人员(身份)"
              align="center"
              min-width="200"
            >
              <template #default="{ row }">
                <div>
                  {{ row.realName
                  }}{{
                    row.medicalType === 1
                      ? "(医生)"
                      : row.medicalType === 2
                      ? "(治疗师)"
                      : ""
                  }}
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="medicalType"
              label="就诊类型"
              align="center"
              :formatter="formatMedicalType"
            >
            </el-table-column>
            <!-- <el-table-column label="诊疗进度" align="center">
              <template #default="{ row }">
                <div>
                  {{ row.progress ? "第" + row.progress + "次" : "-" }}
                  {{
                    Number(row.progress) + Number(row.remainsSessions) > 0
                      ? "/" +
                        (Number(row.progress) + Number(row.remainsSessions))
                      : ""
                  }}
                </div>
              </template>
            </el-table-column> -->
            <el-table-column prop="projectName" label="就诊项目" align="center">
            </el-table-column>
            <!-- <el-table-column
              prop="remainsSessions"
              label="剩余次数"
              align="center"
            >
              <template #default="{ row }">
                <div>
                  {{ row.remainsSessions == 0 ? "-" : row.remainsSessions }}
                </div>
              </template>
            </el-table-column> -->
            <el-table-column
              prop="medicalStaffNotes"
              label="人员记录"
              align="center"
            >
              <template #default="{ row }">
                <el-button size="medium" type="text" @click="checkRecord(row)"
                  >查看</el-button
                >
              </template>
            </el-table-column>
            <el-table-column
              prop="statement"
              label="治疗师陈述"
              align="center"
              min-width="200"
            >
              <template #default="{ row }">
                <el-button
                  v-if="row.medicalType == 2"
                  size="medium"
                  type="text"
                  @click="checkZLRecord(row)"
                  >{{ row.releaseStatus ? "已" : "待" }}发布</el-button
                >
                <span v-else>-</span>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </div>

    <!-- 人员记录弹框 -->
    <el-dialog
      width="50%"
      class="record-dialog"
      :visible.sync="checkRecordDialogVisible"
    >
      <div class="manage-record" v-if="roles[0] == 'ADMINISTRATOR'">
        <div class="manage-head">
          <span
            style="
              font-size: 18px;
              font-weight: 600;
              color: #333333;
              margin-bottom: 10px;
            "
            >管理员记录</span
          >
          <span
            style="font-size: 14px; color: #3d3d3d"
            v-if="recordParams.adminModifyTime"
            >最近更新：{{ recordParams.adminOperator }}
            {{ recordParams.adminModifyTime }}</span
          >
        </div>
        <el-input
          type="textarea"
          :rows="7"
          resize="none"
          style="width: 100%"
          v-model="recordParams.adminNotes"
        ></el-input>
      </div>

      <div class="medical-record">
        <div class="medical-head">
          <span
            style="
              font-size: 18px;
              font-weight: 600;
              color: #333333;
              margin-bottom: 10px;
            "
            >医护人员记录</span
          >
          <span
            style="font-size: 14px; color: #3d3d3d"
            v-if="recordParams.medicalModifyTime"
            >最近更新：{{ recordParams.medicalOperator }}
            {{ recordParams.medicalModifyTime }}</span
          >
        </div>
        <el-input
          v-model="recordParams.medicalStaffNotes"
          type="textarea"
          :rows="7"
          resize="none"
          style="width: 100%"
          :disabled="roles[0] == 'ADMINISTRATOR'"
        ></el-input>
      </div>
      <!-- 底部按钮 -->
      <el-row slot="footer" type="flex" justify="end">
        <el-col>
          <el-button
            size="medium"
            type="primary"
            @click="saveTreatmentRecord"
            icon="el-icon-folder"
            >保存</el-button
          >
        </el-col>
      </el-row>
    </el-dialog>

    <!-- 治疗师陈述弹框 -->
    <el-dialog
      width="50%"
      class="record-dialog"
      :visible.sync="ZLcheckRecordDialogVisible"
    >
      <div class="manage-record">
        <div class="manage-head">
          <span
            style="
              font-size: 18px;
              font-weight: 600;
              color: #333333;
              margin-bottom: 10px;
            "
            >治疗师陈述</span
          >
          <span
            style="font-size: 14px; color: #3d3d3d"
            v-if="ZLrecordParams.statementModifyTime"
            >最近更新：{{ ZLrecordParams.statementOperator }}
            {{ ZLrecordParams.statementModifyTime }}</span
          >
        </div>
        <el-input
          type="textarea"
          :rows="7"
          resize="none"
          style="width: 100%"
          v-model="ZLrecordParams.statementContent"
        ></el-input>
      </div>

      <!-- 底部按钮 -->
      <el-row slot="footer" type="flex" justify="end">
        <el-col>
          <el-button
            size="medium"
            type="primary"
            @click="saveZLRecord"
            icon="el-icon-folder"
            >发布更新</el-button
          >
        </el-col>
      </el-row>
    </el-dialog>
    <!-- 预约弹框 -->
    <el-dialog :visible.sync="isShowAppointment" width="70%">
      <treatment-appointment
        @child-event="YuYueClose"
        @child-event-ok="YuYueCloseOk"
        :orderSn="YuYueOrderSn"
        :patientSn="YuYuePatientSn"
        :durationPerSession="YuYueDurationPerSession"
      ></treatment-appointment>
    </el-dialog>
    
    <PrintDialog :isShow="isShowPrintDialog" :data="patientData" :type="printType" @close="handleClosePrintDialog"/>
  </div>
</template>

<script>
import { mapState } from "vuex";
import BaseInfo from "./components/baseInfo/index.vue";
import PrintDialog from './components/printDialog/index.vue'
import TreatmentAppointment from "@/components/appointment/treatment-appointment.vue";
import TreatmentSheet from "@/components/treatmentSheet/treatmentSheet.vue";
import TabScheme from "./components/TabScheme/index.vue";
export default {
  components: {
    BaseInfo,
    PrintDialog,
    TreatmentAppointment,
    TreatmentSheet,
    TabScheme,
  },
  data() {
    return {
      doctorsAdvice: "",
      // 保存患者资料
      patientSaveData: {
        age: null,
        gender: null,
        height: "",
        maritalStatus: null,
        language: "",
        nationality: "",
        occupation: "",
        patientSn: "",
        weight: "",
        identityType: null,
        remarks: "",
        purpose: [],
        translation: null,
      },
      // 保存病历资料
      MedicalRecordSaveData: {
        allergyHistory: "",
        bloodOxygen: null,
        bloodPressure: "",
        bodyTemperature: null,
        exerciseHabits: "",
        femalePatientQuestions: "",
        imgCoordinate: [],
        initialSymptoms: "",
        medicalHistory: {},
        painLevel: null,
        patientSn: "",
        pulse: null,
        sourceChannel: "",
        symptomNature: "",
        treatmentContraindications: "",
      },
      // 保存面诊记录
      InterviewRecordsSaveData: {
        advice: "",
        chiefComplaint: "",
        diagnosis: "",
        expectedOutcomes: "",
        forecast: "",
        orderSn: "",
      },

      // 病历资料
      ClinicCaseConfig: [],

      // 目的其他
      MuDiQiTa: "",
      // 目的暂存
      MuDiList: [],

      // 目的
      MuDiArr: [
        { key: "损伤治疗", value: 1 },
        { key: "运动康复", value: 2 },
        { key: "体态矫正", value: 3 },
        { key: "运动前后抗阻", value: 4 },
        { key: "运动提升", value: 5 },
        { key: "其他", value: 6 },
      ],
      // 痛点坐标
      spotList: [],
      // spotList: [
      //   {
      //     x: 30,
      //     y: 30,
      //   },
      //   {
      //     x: 230,
      //     y: 310,
      //   },
      // ],
      // 圈圈
      circleSpot: {
        r: 50,
      },

      // 图片属性
      divSpot: {
        // 左上角坐标
        x: 0,
        y: 0,
        width: 700,
        height: 590,
      },

      // 单次治疗时长
      singleDurationArr: [
        { label: "0.5小时", value: 0.5 },
        { label: "1小时", value: 1 },
        { label: "1.5小时", value: 1.5 },
        { label: "2小时", value: 2 },
        { label: "2.5小时", value: 2.5 },
        { label: "3小时", value: 3 },
        { label: "3.5小时", value: 3.5 },
        { label: "4小时", value: 4 },
      ],
      // 病历资料label
      medicalLabel: [],

      // 治疗频率
      frequencyNumArr1: [
        { label: "1次", value: 1 },
        { label: "2次", value: 2 },
        { label: "3次", value: 3 },
        { label: "4次", value: 4 },
        { label: "5次", value: 5 },
      ],
      // 药物
      frequencyNumArr2: [
        { label: "1次", value: 1 },
        { label: "2次", value: 2 },
        { label: "3次", value: 3 },
      ],

      // 处置方案-params
      mock_patientData: {},
      addList: [], // 添加列表
      delList: [], // 删除列表
      editList: [], // 编辑列表
      // 保存处理方案-params
      saveParams: {
        description: "",
        durationPerSession: 0,
        frequency: "",
        frequencyNum: 0,
        id: 0,
        itemId: 0,
        itemName: "",
        patientSn: "",
        projectType: 0,
        totalPrice: 0,
        totalSessions: 0,
        unitPrice: 0,
      },
      // 处置方案-del当前行的Id
      currentDelId: "",

      // 患者table
      patientTableArray: [],
      // 患者资料
      patientData: {},
      // 患者订单集合Array
      patientOrderSnList: [],
      // 门诊病例-主诉-诊断
      ChiefComplaintAndDiagnosisObject: {
        taskLogVO: { adminName: "", taskTime: "" },
      },
      // 婚姻-select
      marryArray: [
        {
          label: "未婚",
          value: 1,
        },
        {
          label: "已婚",
          value: 2,
        },
        {
          label: "离异",
          value: 3,
        },
      ],
      // 身份-select
      identityArray: [
        {
          label: "成人",
          value: 0,
        },
        {
          label: "儿童",
          value: 1,
        },
      ],
      // 性别-select
      genderArray: [
        {
          label: "女",
          value: 0,
        },
        {
          label: "男",
          value: 1,
        },
      ],

      // 翻译-select
      FanYiArray: [
        {
          label: "不需要",
          value: 0,
        },
        {
          label: "需要",
          value: 1,
        },
      ],
      TengTongChengDuArr: [
        {
          label: "重度",
          value: 3,
        },
        {
          label: "中度",
          value: 2,
        },
        {
          label: "轻度",
          value: 1,
        },
      ],

      // 删除弹框显示
      deleteDialogVisible: false,
      activeName: "first",
      tableData: [],
      patientInformationData: [],
      // 药品下拉框
      options: [],
      value: "",

      // 人员记录弹框显示
      checkRecordDialogVisible: false,
      //治疗师陈述弹窗
      ZLcheckRecordDialogVisible: false,
      // 保存就诊记录的 管理员和医护人员的记录
      recordParams: {
        adminNotes: "",
        medicalStaffNotes: "",
        id: 0,
      },
      ZLrecordParams: {
        adminNotes: "",
        medicalStaffNotes: "",
        id: 0,
      },

      // 专用治疗单
      treatmentDetailIsShow: true,

      // 是否有处置方案
      haveTreatmentPlan: true,
      treatmentPlanList: [],
      //  删除的行
      delRowArr: [],

      // 患者预约弹框显示
      isShowAppointment: false,
      YuYueOrderSn: "",
      YuYuePatientSn: "",
      YuYueDurationPerSession: null,

      // 就诊记录数据
      treatRocordData: [],

      // 打印
      isShowPrintDialog: false,
      printType: '',

      // 面诊记录
      orderSn: '',
    };
  },
  computed: {
    ...mapState({
      roles: (state) => state.authInfo.roles,
    }),
  },

  async created() {
    // console.log(this.roles);
    // ADMINISTRATOR // 管理员
    // DOCTOR // 医生
    // NURSE // 医疗助理
    // HEAL // 治疗师.

    let _this = this;
    Promise.all([this.getClinicCaseConfig()])
      .then((result) => {
        console.log(996633, result);
        if (_this.$route.query.patientSn) {
          _this.patientData.patientSn = _this.$route.query.patientSn;
          _this.$nextTick(() => {
            // 获取患者基本资料
            _this.getPatientInformation();
            // 获取订单号集合
            _this.getOrderSnList();
            // 获取就诊记录
            _this.getPatientTreatRecords();
          });
        }
      })
      .catch((error) => {
        console.log("error: >>", error);
      });
  },

  methods: {
    handleClosePrintDialog() {
      this.isShowPrintDialog = false
    },
    handleOpenPrintDialog(type) {
      this.isShowPrintDialog = true
      this.printType = type
    },
    // 任务列表转化
    formatTaskList(row) {
      if (row.undoneTaskNum === 0) {
        return "无未完成";
      }
      if (row.undoneTaskNum > 0) {
        return row.undoneTaskNum + "项未完成";
      }
    },
    // 查看任务
    goTask(orderSn, patientSn, patientName) {
      this.$router.push({
        name: "patient-task",
        query: {
          patientSn,
          orderSn,
          patientName,
        },
      });
    },
    // 获取用户资料
    async getPatientInformation() {
      const { data } = await this.$api.baseApis.getPatientInformation(
        this.patientData.patientSn
      );

      this.patientData = data;
      this.$set(this.patientTableArray, 0, data);

      const patientSaveData = {
        age: data.age,
        gender: data.gender,
        height: data.height,
        maritalStatus: data.maritalStatus,
        occupation: data.occupation,
        patientSn: data.patientSn,
        weight: data.weight,
        identityType: data.identityType,
        remarks: data.remarks,
        purpose: data?.purpose || [],
        translation: data.translation,
        nationality: data.nationality,
        language: data.language,
      };

      this.MedicalRecordSaveData.patientSn = data.patientSn;

      this.ClinicCaseConfig = {
        ...this.ClinicCaseConfig,
        ...data.outpatientRecordsVO?.medicalHistory,
      };

      this.MedicalRecordSaveData = {
        ...this.MedicalRecordSaveData,
        ...data.outpatientRecordsVO,
      };

      this.patientSaveData = patientSaveData;
      this.MuDiList = JSON.parse(JSON.stringify(data.purpose));
      if (data.purpose?.length > 0) {
        for (let i = 0; i < data.purpose.length; i++) {
          if (data.purpose[i].indexOf("其他") == 0) {
            this.MuDiQiTa = data.purpose[i].slice(2);
            this.MuDiList[i] = "其他";
          }
        }
      } else {
        this.MuDiQiTa = "";
        this.MuDiList = [];
      }

      // 转换就诊记录完成时间
      if (this.patientData.medicalRecords) {
        for (let item of this.patientData.medicalRecords) {
          if (item.completionTime == "") {
            item.completionTime = "进行中";
          }
        }
      }

      this.ChiefComplaintAndDiagnosisObject.taskLogVO =
        this.patientData.taskLogVO;

      if (data.treatmentPlan && data.treatmentPlan.length > 0) {
        this.haveTreatmentPlan = true;
        this.treatmentPlanList = data.treatmentPlan;
      } else {
        this.haveTreatmentPlan = false;
      }
    },

    // 获取就诊记录
    async getPatientTreatRecords() {
      const { data } = await this.$api.baseApis.getMedicalRecord(
        this.patientData.patientSn
      );
      this.treatRocordData = data;
    },

    // 保存患者资料
    async savePatientBasicInfo() {
      if (this.patientSaveData.age == "") {
        this.$message.error("请输入年龄");
        return;
      }

      this.patientSaveData.purpose = JSON.parse(JSON.stringify(this.MuDiList));

      for (let i = 0; i < this.patientSaveData.purpose.length; i++) {
        if (this.patientSaveData.purpose[i].indexOf("其他") == 0) {
          this.patientSaveData.purpose[i] += this.MuDiQiTa;
        }
      }

      console.log("保存的数据", this.patientSaveData);
      const { data } = await this.$api.baseApis.savePatientBasicInfo(
        this.patientSaveData
      );
      if (data === true) {
        // this.$message.success("更新成功");
        // // 重新加载页面
        // setTimeout(() => {
        //   location.reload();
        // }, 1000);
      } else {
        this.$message.error("更新失败");
      }
    },


    // 获取门诊病例-订单号集合
    async getOrderSnList() {
      const { data } = await this.$api.baseApis.getOrderSnList(
        this.patientData.patientSn
      );
      this.patientOrderSnList = data;
      this.orderSn = data.length > 0 ? data[0] : ''
      this.SelectOrder()
    },
    
    // 门诊病例-选中某个订单号调取接口
    async SelectOrder() {
      const { data } = await this.$api.baseApis.getChiefComplaintAndDiagnosis(
        this.orderSn
      );
      console.log("根据订单获取到的", data);
      this.ChiefComplaintAndDiagnosisObject = data;
      this.patientData.chiefComplaint = data.chiefComplaint
        ? data.chiefComplaint
        : "";
      this.patientData.diagnosis = data.diagnosis ? data.diagnosis : "";

      this.InterviewRecordsSaveData = {
        ...this.InterviewRecordsSaveData,
        ...data,
      };

    },

    // 性别格式-转化
    formatGender(row) {
      const MAP = {
        0: "女",
        1: "男",
      };
      return MAP[row.gender];
    },
    // 身份格式-转化
    formatIdentityType(row) {
      const MAP = {
        0: "成年",
        1: "儿童",
      };
      return MAP[row.identityType];
    },

    handleClick(tab, event) {
      console.log(tab, event);
    },
    confirmTreatment() {
      this.$message("开具治疗单成功");
      this.dialogVisible = false;
      this.$router.push("/treatment-detail");
    },
    // 删除弹框点击叉号回调
    deleteHandleClose() {
      this.deleteDialogVisible = false;
      console.log("删除了");
    },
    // 删除处置方案
    confirmDelete() {
      this.deleteDialogVisible = false;
      console.log("删除了此次处置方案");
    },
    // 跳转-患者预约
    goAppointment() {
      console.log("预约");
    },
    // 跳转-订单管理(name命名路由跳转，动态路由传参)
    goOrder(orderSn, patientName) {
      this.$router.push({
        name: "order-management",
        query: {
          orderSn: orderSn,
          patientName: patientName,
        },
      });
    },
    // 报到
    async reportPatient(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 1,
      });
      this.$message.success("报到成功");
      setTimeout(() => {
        location.reload();
      }, 500);
    },
    // 开始面诊
    async startTreat(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 2,
      });
      this.$message.success("开始面诊成功");
      setTimeout(() => {
        location.reload();
      }, 500);
    },
    // 开始治疗
    async startMedical(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 2,
      });
      this.$message.success("开始治疗成功");
      setTimeout(() => {
        location.reload();
      }, 500);
    },
    // 完成面诊
    async endTreat(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 3,
      });
      this.$message.success("完成面诊成功");
      setTimeout(() => {
        location.reload();
      }, 500);
    },
    // 结束治疗
    async endMedical(row) {
      await this.$api.baseApis.reportPatient({
        orderSn: row.taskLogVO.orderSn,
        opeType: 3,
      });
      this.$message.success("结束治疗成功");
      setTimeout(() => {
        location.reload();
      }, 500);
    },

    // 处置方案 - add一行
    addRow(item) {
      item.items.push({
        description: "",
        durationPerSession: 1,
        frequency: "",
        frequencyNum: null,
        id: null,
        itemId: null,
        itemName: "",
        projectType: null,
        totalSessions: null,
        unitPrice: null,
        totalPrice: null,
        newItemId: new Date().getTime(),
      });
    },
    // 处置方案 - delete一行
    deleteRow(item, row) {
      console.log("当前rowId：", row.id);
      console.log("当前row：", row);
      console.log("当前item：", item);

      console.log(this["row" + row.newItemId]);

      // 删除新增的
      if (row.newItemId) {
        for (let i = 0; i < item.items.length; i++) {
          if (item.items[i].newItemId == row.newItemId) {
            item.items.splice(i, 1);
          }
        }
        return;
      }
      // 删除已有的
      if (row.id) {
        let _this = this;
        this.$confirm("确定删除当前处置方案吗?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(() => {
            this.delRowArr.push(row);
            for (let i = 0; i < item.items.length; i++) {
              if (item.items[i].id == row.id) {
                item.items.splice(i, 1);
              }
            }
          })
          .catch(() => {});
      }

      // this.deleteDialogVisible = true;
      // this.currentDelId = row.id;
    },
    // 就诊记录-format
    formatMedicalType(row) {
      const MAP = {
        1: "面诊",
        2: "治疗",
      };
      return MAP[row.medicalType];
    },
    // 人员记录-查看
    checkRecord(row) {
      this.checkRecordDialogVisible = true;
      // 当前记录的id
      this.recordParams.id = row.id;

      this.getTreatmentRecordNotes(row.id);
    },
    // 根据就诊记录id获取 管理员和医护人员的记录
    async getTreatmentRecordNotes(id) {
      const { data } = await this.$api.baseApis.getTreatmentRecordNotes(id);
      console.log("记录", data);
      this.recordParams = data;
    },
    // 治疗师陈述
    async checkZLRecord(row) {
      if (
        this.roles[0] !== "ADMINISTRATOR" &&
        this.roles[0] !== "DOCTOR" &&
        this.roles[0] !== "NURSE" &&
        this.roles[0] !== "HEAL"
      ) {
        this.$message({
          message: "需要管理员权限或医护人员账号权限",
          type: "warning",
        });
        return;
      }
      this.ZLcheckRecordDialogVisible = true;

      const { data } = await this.$api.baseApis.getTTherapistStatement(row.id);
      this.ZLrecordParams = data;
    },

    // 保存人员记录
    async saveTreatmentRecord() {
      let postData = {};
      // 管理员保存
      if (this.roles[0] == "ADMINISTRATOR") {
        postData = {
          id: this.recordParams.id,
          adminNotes: this.recordParams.adminNotes,
        };
      }

      // 医护人员保存
      if (
        this.roles[0] == "DOCTOR" ||
        this.roles[0] == "NURSE" ||
        this.roles[0] == "HEAL"
      ) {
        postData = {
          id: this.recordParams.id,
          medicalStaffNotes: this.recordParams.medicalStaffNotes,
        };
      }

      try {
        await this.$api.baseApis.saveTreatmentRecordNotes(postData);
        this.$message.success("保存成功");
        this.checkRecordDialogVisible = false;
      } catch (error) {
        console.log(error);
      }
    },

    async saveZLRecord() {
      // 医护人员保存
      if (
        this.roles[0] !== "ADMINISTRATOR" &&
        this.roles[0] !== "NURSE" &&
        this.roles[0] !== "HEAL"
      ) {
        this.$message.error("暂无操作权限~");
        return;
      }

      const { id, statementContent } = this.ZLrecordParams;
      await this.$api.baseApis.saveTherapistStatement({ id, statementContent });
      this.$notify({
        title: "更新成功",
        type: "success",
      });
      this.ZLcheckRecordDialogVisible = false;
      this.getPatientTreatRecords();
    },

    goYuYue(orderSn, patientSn, durationPerSession) {
      this.YuYueOrderSn = orderSn;
      this.YuYuePatientSn = patientSn;
      this.YuYueDurationPerSession = durationPerSession;

      this.isShowAppointment = true;
    },

    // 预约治疗关闭
    YuYueClose() {
      this.isShowAppointment = false;
    },
    // 预约成功后关闭

    YuYueCloseOk() {
      this.isShowAppointment = false;
      location.reload();
    },

    // 解决输入不了
    inputChange(e) {
      this.$forceUpdate(e);
    },

    async cancleAppiont(orderSn) {
      const { data } = await this.$api.baseApis.cancleAppiont(orderSn);

      if (data == true) {
        this.$message.success("取消预约成功");
        let _this = this;
        setTimeout(function () {
          location.reload();
        }, 500);
      }
    },

    // 取消治疗预约
    cancelAppointment(item) {
      console.log(996633, item);
      this.$confirm("确认取消预约吗", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.cancleAppiont(item.orderSn);
        })
        .catch(() => {});
    },

    // 点击坐标
    getPicSpot(event) {
      console.log("点击了div区域", 19999);
      const div = this.$refs.myDiv;
      const rect = div.getBoundingClientRect();
      this.divSpot.x = rect.left;
      this.divSpot.y = rect.top;
      const x = event.clientX;
      const y = event.clientY;
      if (x > this.divSpot.x && x < this.divSpot.x + this.divSpot.width) {
        if (y > this.divSpot.y && y < this.divSpot.y + this.divSpot.height) {
          // this.$message.success("点击了div区域");
          let pushObj = {
            x: x - this.divSpot.x - 0.5 * this.circleSpot.r,
            y: y - this.divSpot.y - 0.5 * this.circleSpot.r,
          };
          this.MedicalRecordSaveData.imgCoordinate.push(pushObj);
          this.saveOutpatientMedicalRecord();
        }
      }
      console.log("圈圈坐标", this.MedicalRecordSaveData.imgCoordinate);
    },
    // 撤销圈
    circleSpotCancel() {
      if (this.MedicalRecordSaveData.imgCoordinate.length > 0) {
        this.MedicalRecordSaveData.imgCoordinate.pop();
        this.saveOutpatientMedicalRecord();
      } else {
        this.$message.warning("没有可以撤销的操作");
      }
    },
    // 初始化门诊病历配置项
    async getClinicCaseConfig() {
      const { data } = await this.$api.baseApis.getClinicCaseConfig();
      // this.ClinicCaseConfig = { ...data, ...this.medicalLabel };
      this.ClinicCaseConfig = { ...data };
    },

    // 保存病历资料
    async saveOutpatientMedicalRecord(key, value, item) {
      console.log(key, value, item);
      // 有“无”互斥
      if (item) {
        if (key == "无" && value == 1) {
          for (let i = 0; i < item.length; i++) {
            if (item[i].key != "无") {
              item[i].value = 0;
            }
          }
        }
        if (key != "无" && value == 1) {
          for (let i = 0; i < item.length; i++) {
            if (item[i].key == "无") {
              item[i].value = 0;
            }
          }
        }
      }

      this.MedicalRecordSaveData.medicalHistory = this.ClinicCaseConfig;
      console.log(999, this.MedicalRecordSaveData);

      const { data } = await this.$api.baseApis.saveOutpatientMedicalRecord(
        this.MedicalRecordSaveData
      );
      if (data === true) {
        // this.$message.success("更新成功");
        // // 重新加载页面
        // setTimeout(() => {
        //   location.reload();
        // }, 1000);
      } else {
        this.$message.error("更新失败");
      }
    },

    async publishInterviewRecords() {
      if (
        this.roles[0] !== "ADMINISTRATOR" &&
        this.roles[0] !== "DOCTOR" &&
        this.roles[0] !== "NURSE" &&
        this.roles[0] !== "HEAL"
      ) {
        this.$message({
          message: "需要管理员权限或医护人员账号权限",
          type: "warning",
        });
        return;
      }
      const { 
        // interviewRecordsId, 
        orderSn,
        releaseStatus 
      } =
        this.InterviewRecordsSaveData;
      await this.$api.baseApis.releaseOrHideInterviewRecords({
        // interviewRecordsId,
        orderSn,
        releaseStatus: releaseStatus == 1 ? 0 : 1,
      });
      this.$notify({
        title: "发布成功",
        type: "success",
      });

      this.SelectOrder();
    },
    // 保存面诊记录
    async saveInterviewRecords() {
      console.log(996, this.InterviewRecordsSaveData);
      // 去掉治疗方案
      this.InterviewRecordsSaveData.treatmentPlan = null;
      console.log(
        "this.InterviewRecordsSaveData",
        this.InterviewRecordsSaveData
      );
      
      const { data } = await this.$api.baseApis.saveInterviewRecords(
        this.InterviewRecordsSaveData
      );
      if (data === true) {
        // this.$message.success("更新成功");
        // // 重新加载页面
        // setTimeout(() => {
        //   location.reload();
        // }, 1000);
      } else {
        this.$message.error("更新失败");
      }
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  width: 98%;
  // height: 1000px !important;
  position: relative;
  .patient-form {
    width: 100%;
    margin-bottom: 17px;
    .recentTask {
      justify-content: space-around;
      display: flex;
      .taskTime,
      .taskType,
      .adminName {
        margin-right: 3px;
      }
    }
  }
  .information-head {
    width: 100px;
    height: 25px;
    font-size: 18px;
    color: #3d3d3d;
    margin-bottom: 5px;
  }
  .patient-information {
    position: relative;
    box-sizing: border-box;
    padding-top: 14px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    width: 100%;
    padding-bottom: 10px;

    .information {
      width: 19%;
      margin-right: 5px;
      margin-bottom: 15px;
      .text {
        margin-right: 2px;
      }
    }
  }

  .information3 {
    display: flex;
    align-items: center;
    .el-radio-group {
      display: flex;
      align-items: center;
    }
  }

  .patient-tab {
    padding-bottom: 20px;
    width: 100%;
    background-color: #fff;
    position: relative;
    box-sizing: border-box;
    position: relative;
    .tab-btns {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
  // 门诊病例CSS
  .face-record {
    width: 100%;
    margin-top: 12px;
    .detail {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      margin-bottom: 5px;
      width: 850px;
      height: 55px;
      border: 1px solid #000000;
      border-radius: 2px;
      .doctor-name {
        width: 180px;
        margin-right: 30px;
        text-align: left;
        padding-left: 20px;
        box-sizing: border-box;
        line-height: 55px;
        font-size: 16px;
        color: #333333;
        margin-right: 20px;
      }
      .treat-time {
        width: 280px;
        margin-right: 20px;
        text-align: center;
        line-height: 55px;
        height: 55px;
        font-size: 16px;
        color: #333333;
        overflow: hidden;
      }
      .order-number {
        width: 320px;
        text-align: center;
        line-height: 55px;
        height: 55px;
        font-size: 16px;
        color: #333333;
        overflow: hidden;
      }
    }
  }
  .createNewSchedule-btn {
    z-index: 100;
    position: absolute;
    right: 0;
    top: 0;
  }
}

// 管理员记录弹框
.manage-record {
  margin-bottom: 40px;
  .manage-head {
    display: flex;
    justify-content: space-between;
  }
}

// 医护人员记录弹框
.medical-record {
  margin-bottom: 5px;
  .medical-head {
    display: flex;
    justify-content: space-between;
  }
}

// 设置table表头th的背景颜色
::v-deep(.center-table th) {
  background-color: #f7f8fa;
}

::v-deep(.information .el-input) {
  width: 121px;
}

::v-deep(.el-textarea__inner) {
  padding: 5px 8px !important;
}

// Tab栏文字的大小
::v-deep(.custom-tab-label) {
  font-size: 16px;
  font-weight: 500;
}
.information .text {
  font-size: 16px !important;
}

// 订单下拉框的样式
.el-dropdown-link {
  cursor: pointer;
  color: #333333;
}
.el-icon-arrow-down {
  font-size: 18px;
}

.el-dropdown-link {
  font-size: 18px;
}

::v-deep(.icon-wrapper) {
  transition: transform 0.2s ease;
}

::v-deep(.icon-wrapper:hover) {
  transform: scale(1.2);
}

// select样式
// .custom-select-height {
//   /* 设置外层容器高度 */
//   height: 26px;

//   /* 深度选择器调整内部样式 */
//   ::v-deep(.el-input) {
//     .el-input__inner {
//       height: 27px; /* 调整输入框高度 */
//       width: 119px;
//       border: 1px solid #000;
//       border-radius: 0 !important;
//     }
//     .el-input__prefix,
//     .el-input__suffix {
//       height: 27px; /* 调整前后缀高度 */
//       width: 85px;
//     }
//     .el-input__suffix {
//       /* 确保右侧图标居中 */
//       top: 0;
//       display: flex;
//       justify-content: center;
//       align-items: center;
//       flex-wrap: nowrap;
//       flex-direction: row;
//       align-content: flex-start;
//     }
//     .el-input__icon {
//       line-height: 27px; /* 调整图标行高以适应新高度 */
//       color: #000 !important;
//     }
//   }
// }

.treatment-detail {
  margin: 0 auto;
  width: 80%;
  background-color: #fff;
  padding: 20px;
  border: 1px solid #000;
  .treatment-title {
    margin-bottom: 10px;
    text-align: center;
    font-size: 32px;
    font-weight: 600;
    color: #333333;
  }
  .patient-detail {
    display: flex;
    flex-wrap: wrap;
    border-bottom: 2px solid grey;
    border-top: 2px solid grey;
    width: 100%;
    .patient-content {
      width: 284px;
      height: 35px;
      line-height: 35px;
      margin-right: 40px;
    }
  }
  .medical-detail {
    border-bottom: 2px solid grey;
    padding: 15px;
  }
  .total-payment {
    height: 150px;
    .payment {
      height: 100px;
      display: flex;
      align-items: center;
      .number {
        margin-right: 50px;
      }
      .image {
        background-color: pink;
        width: 85px;
        height: 68.8px;
      }
    }
    .QRcode {
      padding-left: 800px;
    }
    .effect {
      padding-left: 50px;
      font-weight: 500;
      font-size: 15px;
      color: #333;
    }
  }
}

.second_box {
  position: relative;
}
.second_box.havePadding {
  padding-top: 40px;
}

.two_btns {
  width: 249px;
  position: absolute;
  bottom: 0;
  right: 0;
}

.information2_out {
  box-sizing: border-box;
  padding-top: 7px;
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  align-items: center;
  width: 100%;

  .information2 {
    width: 48%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    .text {
      margin-right: 2px;
    }
  }
}

// 痛点坐标 此部分不要动 动了 会错位！！
.pic_box {
  width: 660px !important;
  min-width: 660px !important;
  height: 660px;
  position: relative;
  background-color: #f5f7fa;
  position: relative;
  box-sizing: border-box;
  user-select: none;
  * {
    user-select: none;
  }

  .cancelCircle {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    box-sizing: border-box;
  }

  // 图像尺寸严格282px*554px不然坐标会错位
  .diagram1 {
    position: absolute;
    border: 1px dashed #ddd;
    box-sizing: border-box;

    width: 282px;
    height: 554px;
    top: 30px;
    left: 30px;
    z-index: 1;
    pointer-events: none;
  }
  .diagram2 {
    position: absolute;
    border: 1px dashed #ddd;
    width: 282px;
    height: 554px;
    top: 30px;
    right: 30px;
    box-sizing: border-box;
    z-index: 1;
    pointer-events: none;
  }

  .circle_spot {
    position: absolute;
    z-index: 2;
    border-radius: 50%;
    background-color: rgba(233, 87, 32, 0.08);
    box-sizing: border-box;
    &::after {
      position: absolute;
      content: "";
      width: 31px;
      height: 31px;
      border-radius: 50%;
      background-color: rgba(233, 87, 32, 0.4);
      z-index: 3;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    &::before {
      position: absolute;
      content: "";
      width: 15px;
      height: 15px;
      border-radius: 50%;
      background-color: rgba(233, 87, 32, 1);
      z-index: 4;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }
}

.pic_box_out {
  display: flex;
  align-items: top;
  justify-content: space-between;
  .pic_box_rt {
    box-sizing: border-box;
    padding-left: 20px;
    flex-grow: 1;
  }
}
.info_title {
  font-size: 16px;
  color: #303133;
  line-height: 45px;
}

.son_title {
  font-size: 16px;
  color: #333;
  font-weight: 500;
  line-height: 40px;
}

// 平板适配
@media screen and (max-width: 1300px) {
  .bzInput {
    width: 65% !important;
  }
}
</style>
