<template>
  <div class="patient-info" v-if="data">
    <div class="portrait">
      <img
        v-if="data.avatarUrl"
        :src="data.avatarUrl"
        alt=""
        class="avatar"
      />
      <img v-else src="@/assets/head.png" alt="" class="avatar" />
    </div>
    <template v-if="editing">
        <el-input placeholder="请输入姓名" v-model="baseInfo.patientName">
        <template slot="prepend">姓名</template>
      </el-input>
        <el-input placeholder="请输入手机号" v-model="baseInfo.phoneNumber">
        <template slot="prepend">手机号</template>
      </el-input>
    </template>
    <template v-else>
      <div class="name">{{ baseInfo.patientName }}</div>
      <div class="phone">{{ baseInfo.phoneNumber }}</div>
    </template>
    <el-button icon="el-icon-magic-stick" @click="handleToggleEdit('cancel')" v-if="editing">取消</el-button>
    <el-button type="primary" icon="el-icon-check" @click="handleSave" v-if="editing">保存</el-button>
    <el-button type="primary" class="el-icon-edit" @click="handleToggleEdit('edit')" v-else>编辑</el-button>
  </div>
</template>

<script>
export default {
  props: ['data'],
  data() {
    return {
      baseInfo: {
        patientName: '',
        phoneNumber: '',
        patientSn: ''
      },
      editing: false,
    }
  },
  watch: {
    data(data) {
      if (data) {
        const { patientName , phoneNumber, patientSn } = data
        this.baseInfo = {
          patientName,
          phoneNumber,
          patientSn
        }
      }
    }
  },
  methods: {
    handleToggleEdit(type) {
      this.editing = !this.editing
      // 恢复数据
      if (type == 'cancel') {
        const { patientName , phoneNumber, patientSn } = this.data
        this.baseInfo = {
          patientName,
          phoneNumber,
          patientSn
        }

      }
    },
    async handleSave() {
      const { data } = await this.$api.baseApis.updatePatientAccount({
        ...this.baseInfo
      });
      this.$notify({
        title: "保存成功",
        type: "success",
      });
      this.handleToggleEdit('save')
      this.$emit('save')
    }
  },
}
</script>

<style lang="less" scoped>
.patient-info {
  align-items: center;
  display: flex;
  height: 60px;
  // background-color: green;
  margin-bottom: 10px;
  gap: 8px;
  .portrait {
    width: 50px;
    height: 50px;
    .avatar {
      width: 50px;
      height: 50px;
      object-fit: cover; /* 保持图像比例并填充 */
      border-radius: 50%;
    }
  }
  .name,.phone {
    text-align: center;
    list-style: 50px;
    height: 50px;
    font-size: 18px;
    line-height: 50px;
    color: #3d3d3d;
  }
}
</style>