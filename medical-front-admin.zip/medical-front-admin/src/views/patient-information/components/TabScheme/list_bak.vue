<template>
  <div class="scheme-list___com">
    <div class="scheme-list" v-for="(form, formIdx) in list" :key="formIdx">
      <div class="scheme-list--item">
        <div class="scheme-form">
          <header class="scheme-title">
            <div class="name">治疗方案：{{ form.planSn }}</div>
            <div class="time">创建时间：{{ form.createTime }}</div>
            <div class="doctor-order">
              <p class="label">医嘱：</p>
              <div class="content">
                <!-- :disabled="
                    !(form.speedStatus == 1 && form.isPlanIssued == false)
                  " -->
                <el-input
                  type="textarea"
                  :rows="5"
                  resize="none"
                  :maxlength="400"
                  v-model="form.advice"
                  :style="{ width: '500px' }"
                  placeholder="请输入医嘱"
                />
              </div>
            </div>
          </header>
          <main class="scheme-content">
            <div
              class="process-item"
              v-for="(data, index) in form.planItems"
              :key="index"
            >
              <div class="process-item--section process-item--title">
                <div class="title">
                  <img src="@/assets/plan.png" />
                  <span>第{{ index + 1 }}次治疗</span>
                </div>
                <div
                  class="handle"
                  v-if="form.speedStatus == 1 && form.isPlanIssued == false"
                >
                  <el-button
                    class="del-plan-btn"
                    icon="el-icon-close"
                    @click="handleDelPlan(formIdx, index)"
                    >删除次数</el-button
                  >
                  <el-button
                    class="add-btn"
                    icon="el-icon-plus"
                    type="primary"
                    @click="handleAddPlan(formIdx)"
                    v-if="
                      form.speedStatus == 1 &&
                      form.isPlanIssued == false &&
                      index == 0
                    "
                    >添加次数</el-button
                  >
                </div>
              </div>
              <div class="process-item--section process-item--time">
                <p>推荐治疗时间</p>
                <!-- :disabled="
                    !(form.speedStatus == 1 && form.isPlanIssued == false)
                  " -->
                <el-date-picker
                  v-if="!data.noRecommended"
                  v-model="data.recommendedTime"
                  align="right"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="pickerOptions"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <!-- :disabled="
                    !(form.speedStatus == 1 && form.isPlanIssued == false)
                  " -->
                <el-checkbox v-model="data.noRecommended">不推荐</el-checkbox>
              </div>
              <div class="process-item--section process-item--project">
                <el-table :data="data.items" :border="true" :key="form.id">
                  <el-table-column
                    label="项目名称"
                    width="200"
                    :align="'center'"
                  >
                    <template slot-scope="scope">
                      <!-- 兼容旧数据 -->
                      <span
                        v-if="
                          scope.row.itemId &&
                          !projectConfig.find(
                            (config) => config.id == scope.row.itemId
                          )
                        "
                        >{{ scope.row.itemName }}</span
                      >
                      <el-select
                        v-else
                        :disabled="
                          !form.planItems[index].items[scope.$index].editing
                        "
                        :key="form.id + '' + scope.$index"
                        placeholder="请选择项目"
                        v-model="scope.row.itemId"
                        @change="
                          handleSelectProject(
                            formIdx,
                            index,
                            scope.$index,
                            $event
                          )
                        "
                        size="medium"
                      >
                        <el-option
                          v-for="item in projectConfig"
                          :key="item.id"
                          :label="item.projectName"
                          :value="item.id"
                          :disabled="!!form.planItems[index].items.find(project => project.itemId == item.id)"
                        >
                        </el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column label="单次价格" :align="'center'">
                    <template slot-scope="scope">
                      <!-- 编辑状态 -->
                      <div
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index].editing
                        "
                      >
                        <template
                          v-if="
                            form.planItems[index].items[scope.$index]
                              .expectedDuration &&
                            form.planItems[index].items[scope.$index]
                              .singleAppointmentDuration
                          "
                        >
                          <el-checkbox
                            ref="priceHour_checkbox"
                            v-model="
                              form.planItems[index].items[scope.$index]
                                .priceHour_checked
                            "
                            :disabled="
                              form.planItems[index].items[scope.$index]
                                .preferentialPrice_checked
                            "
                            @change="
                              handleSelectPrice(
                                formIdx,
                                index,
                                scope.$index,
                                'priceHour',
                                $event
                              )
                            "
                            >{{
                              form.planItems[index].items[scope.$index]
                                .priceHour
                            }}</el-checkbox
                          >
                        </template>
                        <template v-else>
                          <el-input
                            :disabled="
                              form.planItems[index].items[scope.$index]
                                .preferentialPrice_checked
                            "
                            v-model="
                              form.planItems[index].items[scope.$index]
                                .priceHour
                            "
                          >
                            <template slot="append">元</template>
                          </el-input>
                        </template>
                      </div>
                      <!-- 展示状态 -->
                      <div v-else>
                        <span
                          v-if="
                            !form.planItems[index].items[scope.$index].editing &&
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice.length >= 0 &&
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice_checked
                          "
                          >-</span
                        >
                        <span
                          v-else-if="
                            form.planItems[index].items[scope.$index].itemId &&
                            form.planItems[index].items[scope.$index].priceHour
                              .length > 0
                          "
                          >{{
                            form.planItems[index].items[scope.$index].priceHour
                          }}</span
                        >
                        <span v-else>-</span>
                      
                      </div>
                      
                    </template>
                  </el-table-column>
                  <el-table-column label="优惠价" :align="'center'">
                    <template slot-scope="scope">
                      <!-- 编辑状态 -->
                      <div
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index].editing &&
                          form.planItems[index].items[scope.$index]
                            .expectedDuration &&
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        "
                      >
                        <el-checkbox
                          ref="preferentialPrice_checkbox"
                          :disabled="
                            form.planItems[index].items[scope.$index]
                              .priceHour_checked
                          "
                          v-model="
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice_checked
                          "
                          @change="
                            handleSelectPrice(
                              formIdx,
                              index,
                              scope.$index,
                              'preferentialPrice',
                              $event
                            )
                          "
                        >
                          <el-input
                            :disabled="
                              form.planItems[index].items[scope.$index]
                                .priceHour_checked
                            "
                            v-model="
                              form.planItems[index].items[scope.$index]
                                .preferentialPrice
                            "
                          >
                            <template slot="append">元</template>
                          </el-input>
                        </el-checkbox>
                      </div>
                      <!-- 展示状态 -->
                      <div v-else>
                        <span
                          v-if="
                            !form.planItems[index].items[scope.$index].editing &&
                            form.planItems[index].items[scope.$index].priceHour
                              .length >= 0 &&
                            form.planItems[index].items[scope.$index]
                              .priceHour_checked
                          "
                          >-</span
                        >
                        <span
                          v-else-if="
                            form.planItems[index].items[scope.$index].itemId &&
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice.length > 0
                          "
                          >{{
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice
                          }}</span
                        >
                        <span v-else>-</span>
                      </div>
                      
                    </template>
                  </el-table-column>
                  <el-table-column label="预计时长" :align="'center'">
                    <template slot-scope="scope">
                      <span
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index]
                            .expectedDuration
                        "
                        >{{
                          form.planItems[index].items[scope.$index]
                            .expectedDuration
                        }}分钟</span
                      >
                      <span v-else>-</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="单次预约时长" :align="'center'">
                    <template slot-scope="scope">
                      <span
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        "
                        >{{
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        }}小时</span
                      >
                      <span v-else>-</span>
                    </template>
                  </el-table-column>
                  <el-table-column
                    prop="operate"
                    label="操作"
                    :align="'center'"
                  >
                    <template
                      slot-scope="scope"
                      v-if="form.speedStatus == 1 && form.isPlanIssued == false"
                    >
                      <el-button
                        v-if="form.planItems[index].items[scope.$index].editing"
                        type="text"
                        primary
                        @click="handleSaveProject(formIdx, index, scope.$index)"
                        >保存</el-button
                      >
                      <el-button
                        v-else
                        type="text"
                        primary
                        @click="handleEditProject(formIdx, index, scope.$index)"
                        >编辑</el-button
                      >
                      <el-button
                        type="text"
                        primary
                        @click="handleDelProject(formIdx, index, scope.$index)"
                        >删除</el-button
                      >
                    </template>
                    <template slot-scope="scope" v-else>
                      <span>-</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div
                class="process-item--section process-item--add"
                v-if="form.speedStatus == 1 && form.isPlanIssued == false"
              >
                <div @click="handleAddProject(formIdx, index)">
                  <i class="el-icon-plus"></i>
                  <span>增加项目</span>
                </div>
              </div>
              <div class="process-item--section process-item--effect">
                <div>
                  <p class="label">作用机理</p>
                  <div class="content">
                    <!-- :disabled="
                        !(form.speedStatus == 1 && form.isPlanIssued == false)
                      " -->
                    <el-input
                      type="textarea"
                      :rows="5"
                      resize="none"
                      :maxlength="400"
                      v-model="form.planItems[index].mechanization"
                      :style="{ width: '500px' }"
                      placeholder="请输入作用机理"
                    />
                  </div>
                </div>
                <div>
                  <p class="label">预期效果</p>
                  <div class="content">
                    <!-- :disabled="
                        !(form.speedStatus == 1 && form.isPlanIssued == false)
                      " -->
                    <el-input
                      type="textarea"
                      :rows="5"
                      resize="none"
                      :maxlength="400"
                      v-model="form.planItems[index].expectedOutcomes"
                      :style="{ width: '500px' }"
                      placeholder="请输入预期效果"
                    />
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>

        <div class="scheme-handle" v-if="form.speedStatus == 2">
          <!-- <div></div> -->
          <div>
            <el-button
              disabled
              icon="el-icon-warning"
              :style="{ 'background-color': '#f5f7fa' }"
              >已取消方案</el-button
            >
          </div>
        </div>
        <div class="scheme-handle" v-else>
          <!-- <div></div> -->
          <div>
            <el-button
              v-if="form.isPlanIssued"
              @click="handleCancelScheme(formIdx)"
              >取消治疗方案</el-button
            >
            <el-button @click="handleSaveScheme(formIdx)">保存方案</el-button>

            <el-button
              v-if="form.isPlanIssued"
              type="primary"
              @click="handleShowPopup(formIdx)"
              >合并治疗订单</el-button
            >
            <el-button v-else type="primary" @click="handleFetchScheme(formIdx)"
              >开具方案</el-button
            >
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      key="merge"
      custom-class="merge-dialog"
      title="合并治疗订单"
      :visible="isShowMergeDialog"
      :before-close="handleClosePopup"
    >
      <el-table key="merge-dialog" :data="mergeDialogData">
        <el-table-column
          :align="'center'"
          label="序号"
          prop="sortNum"
        ></el-table-column>
        <el-table-column :align="'center'" label="总价" prop="orderAmount">
          <template slot-scope="scope">
            <span>￥{{ scope.row.orderAmount }}</span>
          </template>
        </el-table-column>
        <el-table-column
          :align="'center'"
          label="订单号"
          prop="orderSn"
        ></el-table-column>
        <el-table-column :align="'center'" label="订单状态" prop="orderStatus">
          <template slot-scope="scope">
            <span v-if="scope.row.orderStatus == 0">待支付</span>
            <span
              v-else-if="scope.row.orderStatus == 1"
              :style="{ color: '#e95720' }"
              >已支付</span
            >
          </template>
        </el-table-column>
        <el-table-column :align="'center'" label="选择" prop="opreate">
          <template slot-scope="scope">
            <el-checkbox
              :disabled="scope.row.orderStatus !== 0 || scope.row.orderAmount == 0"
              v-model="dialogChecked[scope.$index]"
              @change="handlePaySelect(scope.$index)"
            ></el-checkbox>
          </template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="merge-dialog-footer">
        <el-button @click="handleClosePopup">取消</el-button>
        <el-button type="primary" @click="handleConfirmPopup">确认</el-button>
      </span>
    </el-dialog>

    <PayDialog
      :data="payDialogData"
      :isShow="isShowPayDialog"
      @close="isShowPayDialog = false"
    />
  </div>
</template>

<script>
import PayDialog from "./payDialog.vue";
import { mapState } from "vuex";
export default {
  components: {
    PayDialog,
  },
  data() {
    return {
      list: [],
      pickerOptions: {
        disabledDate: (time) => {
          const today = new Date();
          today.setHours(0, 0, 0, 0); // 去掉时间部分，只比较日期
          return time.getTime() < today.getTime();
        },
      },
      projectConfig: [],
      mergeDialogData: [],
      dialogFormId: "",
      isShowMergeDialog: false,
      dialogChecked: [],

      isShowPayDialog: false,
      payDialogData: null,
    };
  },
  mounted() {
    this.getDisposalPlanList();
    this.getPlanProjectConfig();
  },
  computed: {
    ...mapState({
      roles: (state) => state.authInfo.roles,
    }),
  },
  methods: {
    async getDisposalPlanList() {
      const loading = this.$loading({ lock: true, text: '加载中' })
      const { patientSn } = this.$route.query;
      const { data } = await this.$api.baseApis.getDisposalPlanList(patientSn);
      this.list = data;
      loading.close()
    },
    // 获取可直接预约治疗项目
    async getPlanProjectConfig() {
      const { data } = await this.$api.baseApis.getPlanProjectConfig();
      this.projectConfig = data;
      console.log("this.projectConfig", this.projectConfig);
    },
    // 添加项目
    handleAddProject(formIdx, planIdx) {
      const form = this.list[formIdx];
      const { id } = form.planItems[planIdx];
      if (form.planItems.length >= 10) {
        this.$notify({
          title: "单次最多选择10个项目",
          type: "error",
        });
        return;
      }
      form.planItems[planIdx].items.push({
        id: "",
        itemId: "",
        planId: id,
        expectedDuration: "",
        singleAppointmentDuration: "",
        priceHour: "",
        preferentialPrice: "",
        priceHour_checked: true,
        preferentialPrice_checked: false,
        editing: false,
      });
    },
    // 选择项目
    handleSelectProject(formIdx, planIdx, projectIdx, configId) {
      const form = this.list[formIdx];

      // id是子项id，itemId是下拉框项目id，planId是治疗次数id
      const { id = "", itemId = "" } =
        form.planItems[planIdx].items[projectIdx];
      const { id: planId } = form.planItems[planIdx];

      // 取出下拉框内容
      const {
        expectedDuration = "",
        singleAppointmentDuration = "",
        priceHour = "",
        preferentialPrice = "",
      } = this.projectConfig.find((config) => config.id == configId);

      //
      this.$set(form.planItems[planIdx].items, projectIdx, {
        ...{
          // 保存当前次数，下拉框选项，次数的关系
          id,
          itemId,
          planId,

          // 下拉框内容
          expectedDuration,
          singleAppointmentDuration,
          priceHour,
          preferentialPrice,

          // 交互数据
          priceHour_checked: true,
          preferentialPrice_checked: false,
          editing: true,
        },
      });
    },
    // 选择价格
    handleSelectPrice(formIdx, planIdx, projectIdx, type, value) {
      const form = this.list[formIdx];
      console.log(
        "handleSelectPrice",
        planIdx,
        projectIdx,
        type,
        value,
        form.planItems[planIdx].items[projectIdx]
      );

      if (type == "priceHour") {
        form.planItems[planIdx].items[projectIdx][`preferentialPrice_checked`] =
          !value;
      } else {
        form.planItems[planIdx].items[projectIdx][`priceHour_checked`] = !value;
      }
    },
    // 删除方案中的某一次治疗
    async handleDelPlan(formIdx, planIdx) {
      const form = this.list[formIdx];
      const { id } = form.planItems[planIdx];
      // if (form.planItems.length == 1) {
      //   this.$notify({
      //     title: "需要至少保留一次治疗",
      //     type: "error",
      //   });
      //   return;
      // }
      await this.$api.baseApis.delDisposalPlanNum(id);
      form.planItems.splice(planIdx, 1);

      if (form.planItems.length == 0) {
        this.getDisposalPlanList();
        this.$notify({
          title: "方案删除成功",
          type: "success",
        });
      } else {
        this.$notify({
          title: "次数删除成功",
          type: "success",
        });
      }
    },
    // 编辑某个项目
    handleEditProject(formIdx, planIdx, projectIdx) {
      this.$set(
        this.list[formIdx].planItems[planIdx].items[projectIdx],
        "editing",
        true
      );
      const preferentialPrice_checked = this.list[formIdx].planItems[planIdx].items[projectIdx].preferentialPrice.length > 0
      this.$set(
        this.list[formIdx].planItems[planIdx].items[projectIdx],
        "priceHour_checked",
         !preferentialPrice_checked
      );
      this.$set(
        this.list[formIdx].planItems[planIdx].items[projectIdx],
        "preferentialPrice_checked",
        preferentialPrice_checked
      );

      // form.planItems[planIdx].items[projectIdx].editing = true;
      console.log(
        "handleEditProject",
        this.list[formIdx].planItems[planIdx].items[projectIdx]
      );
    },
    // 保存某个项目
    async handleSaveProject(formIdx, planIdx, projectIdx) {
      const form = this.list[formIdx];
      const data = form.planItems[planIdx].items[projectIdx];
      console.log("handleSaveProject", data);
      const { id, itemId, planId, preferentialPrice, priceHour } = data;

      const params = {
        id,
        itemId,
        planId,
      };
      if (form.planItems[planIdx].items[projectIdx].preferentialPrice_checked) {
        params.preferentialPrice = preferentialPrice;
      } else {
        params.priceHour = priceHour;
      }
      const res = await this.$api.baseApis.saveDisposalPlanItem(params);
      this.$notify({
        title: "保存成功",
        type: "success",
      });

      form.planItems[planIdx].items[projectIdx].id = res.data.id || "";
      form.planItems[planIdx].items[projectIdx].editing = false;
    },
    // 删除项目
    async handleDelProject(formIdx, planIdx, projectIdx) {
      const form = this.list[formIdx];
      const { id = "" } = form.planItems[planIdx].items[projectIdx];
      form.planItems[planIdx].items.splice(projectIdx, 1);
      if (id) await this.$api.baseApis.delDisposalPlanItem(id);

      this.$notify({
        title: "项目删除成功",
        type: "success",
      });
      // if (form.planItems[planIdx].items.length == 0 && form.planItems.length > 1) {
      //   this.handleDelPlan(formIdx, planIdx)
      // }
    },
    // 增加方案中的治疗次数
    async handleAddPlan(formIdx) {
      const form = this.list[formIdx];
      const { id } = form;
      const { data } = await this.$api.baseApis.addDisposalPlanTimes(id);
      this.$notify({
        title: "治疗添加成功",
        type: "success",
      });
      form.planItems.push(data);
    },
    // 保存方案
    async handleSaveScheme(formIdx) {
      const form = this.list[formIdx];
      const { id, advice, planItems } = form;
      const { patientSn } = this.$route.query;
      const disposalPlanDetailList = planItems.map((planItem) => {
        const {
          id,
          expectedOutcomes,
          mechanization,
          noRecommended,
          recommendedTime,
        } = planItem;
        return {
          id,
          expectedOutcomes,
          mechanization,
          noRecommended,
          recommendedTime,
        };
      });
      const params = {
        id,
        patientSn,
        advice,
        disposalPlanDetailList,
      };
      await this.$api.baseApis.saveDisposalPlan(params);
      this.$notify({
        title: "保存成功",
        type: "success",
      });

      this.getDisposalPlanList();
    },
    // 开具方案
    async handleFetchScheme(formIdx) {
      if (this.roles[0] !== "DOCTOR") {
        this.$message({
          message: "需要医生账号权限",
          type: "warning",
        });
        return;
      }

      this.$confirm('确认开具方案?', '提示').then(async () => {
        const form = this.list[formIdx];
        const { id } = form;
        await this.$api.baseApis.openDisposalPlan(id);
        this.$notify({
          title: "开具方案成功",
          type: "success",
        });

        this.getDisposalPlanList();
      })
      // const form = this.list[formIdx];
      // const { id } = form;
      // await this.$api.baseApis.openDisposalPlan(id);
      // this.$notify({
      //   title: "开具方案成功",
      //   type: "success",
      // });

      // this.getDisposalPlanList();
    },
    // 取消治疗方案
    async handleCancelScheme(formIdx) {
      this.$confirm('确认取消治疗方案?', '提示').then(async () => {
        const form = this.list[formIdx];
        const { id } = form;
        await this.$api.baseApis.cancelDisposalPlan(id);
        this.$notify({
          title: "取消成功",
          type: "success",
        });
        this.getDisposalPlanList();
      })
    },
    async handleShowPopup(formIdx) {
      const { id } = this.list[formIdx];
      const { data } = await this.$api.baseApis.mergeDisposalPlan(id);
      this.mergeDialogData = data;
      this.dialogFormId = id;
      this.isShowMergeDialog = true;
      this.dialogChecked = new Array(data.length).fill(false);
      console.log("dialogChecked", this.dialogChecked);
    },
    handleClosePopup() {
      this.isShowMergeDialog = false;
    },
    async handleConfirmPopup() {
      let orderSns = this.dialogChecked
        .map((check, index) => {
          if (check) return this.mergeDialogData[index].orderSn;
        })
        .filter((num) => num);

      if (orderSns.length == 0) {
        this.$notify({
          title: "请选择治疗订单",
          type: "error",
        });
        return;
      }
      const params = {
        id: this.dialogFormId,
        orderSns,
      };
      const { data } = await this.$api.baseApis.mergeDisposalPlanConfirm(
        params
      );

      this.isShowPayDialog = true;
      this.isShowMergeDialog = false;
      this.payDialogData = data;
    },
    handlePaySelect(checkIdx) {
      // 单选
      // this.dialogChecked = this.dialogChecked.map((check, index) => {
      //   if (checkIdx == index) return check;
      //   else return false;
      // });

      console.log("handlePaySelect", checkIdx, this.dialogChecked);
    },
  },
};
</script>

<style lang="less">
.scheme-list___com {
  .scheme-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
    .scheme-list--item {
      // border: 1px dashed #000000;
      padding: 12px;
      margin-bottom: 12px;
      position: relative;
      &::before {
        content: "";
        position: absolute;
        left: 0;
        top: 10px;
        width: 5px;
        height: 40px;
        background-color: #e95720;
        border-radius: 4px;
      }
      .scheme-form {
        .scheme-title {
          padding-bottom: 10px;
          > div {
            margin-top: 8px;
          }
          .name {
            font-weight: bold;
            font-size: 18px;
          }
          .time {
            color: #a8abb2;
            font-size: 12px;
          }
          .doctor-order {
            display: flex;
            font-size: 14px;
            color: #303133;
          }
        }
        .scheme-content {
          border: 1px solid #ebedf0;
          border-radius: 4px;
          padding: 0 20px;
          .process-item {
            font-size: 14px;
            padding-bottom: 20px;
            margin-bottom: 20px;
            &--title {
              display: flex;
              justify-content: space-between;
              box-sizing: border-box;
              display: flex;
              align-items: center;
              color: #303133;
              width: calc(100% + 40px);
              // width: 100%;
              transform: translateX(-20px);
              background: #f5f7fa;
              padding: 14px 20px;
              font-size: 16px;
              border-radius: 4px;
              .title {
                display: flex;
                align-items: center;
                img {
                  width: 22px;
                  height: 22px;
                  margin-right: 8px;
                }
              }
              .handle {
                margin-left: 8px;
                .del-plan-btn {
                  border: 1px solid #e95720;
                  color: #e95720;
                }
              }
            }
            &--time {
              display: flex;
              align-items: center;
              margin: 24px 0;
              gap: 8px;
            }
            &--project {
              .el-table thead tr th {
                background-color: #f5f7fa;
              }
            }
            &--add {
              border: 1px solid #ebeef5;
              padding: 16px 12px;
              cursor: pointer;
              > div {
                padding: 8px;
                text-align: center;
                background: rgba(233, 87, 32, 0.11);
                border-radius: 4px;
                border: 1px solid rgba(233, 87, 32, 0.22);
                font-size: 14px;
                color: #e95720;
              }
            }
            &--effect {
              display: flex;
              flex-direction: column;
              margin-top: 16px;
              gap: 10px;
              .label {
                margin-bottom: 4px;
              }
            }
          }
        }
      }
      .scheme-handle {
        margin-top: 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
    }
  }
  .content-dialog {
    width: 700px !important;
  }
}
</style>
