<template>
  <div class="scheme-form___com">
    <div class="scheme-btns">
      <el-button
      @click="handleCreateNewForm"
      class="create-btn"
      type="primary"
      icon="el-icon-plus"
      >创建新方案
    </el-button>
    </div>
    <div class="scheme-form" v-if="form">
      <div class="form">
        <header class="title">
          <div class="name">治疗方案：{{ form.planSn }}</div>
          <div class="time">创建时间：{{ form.createTime }}</div>
          <div class="doctor-order">
            <p class="label">医嘱：</p>
            <div class="content">
              <el-input
                type="textarea"
                :rows="5"
                resize="none"
                :maxlength="400"
                v-model="form.advice"
                :style="{ width: '500px' }"
                placeholder="请输入医嘱"
              />
            </div>
          </div>
        </header>
        <main class="content">
          <div
            class="process-item"
            v-for="(data, index) in form.planItems"
            :key="index"
          >
            <div class="process-item--section process-item--title">
              <div class="title">
                <img src="@/assets/plan.png" />
                <span>第{{ index + 1 }}次治疗</span>
              </div>
              <div class="handle">
                <el-button
                  class="del-plan-btn"
                  icon="el-icon-close"
                  @click="handleDelPlan(index)"
                  >删除次数</el-button
                >
                <el-button
                  v-if="index == 0"
                  class="add-btn"
                  type="primary"
                  icon="el-icon-plus"
                  @click="handleAddPlan"
                  >添加次数</el-button
                >
              </div>
            </div>
            <div class="process-item--section process-item--time">
              <p>推荐治疗时间</p>
              <el-date-picker
                v-if="!data.noRecommended"
                v-model="data.recommendedTime"
                align="right"
                type="date"
                placeholder="选择日期"
                :picker-options="pickerOptions"
                value-format="yyyy-MM-dd"
              >
              </el-date-picker>
              <el-checkbox v-model="data.noRecommended">不推荐</el-checkbox>
            </div>
            <div class="process-item--section process-item--project">
              <el-table :data="data.items" :border="true">
                <el-table-column label="项目名称" width="200" :align="'center'">
                  <template slot-scope="scope">
                    <el-select
                      :disabled="
                        !form.planItems[index].items[scope.$index].editing
                      "
                      :key="form.id + '' + scope.$index"
                      placeholder="请选择项目"
                      v-model="scope.row.itemId"
                      @change="handleSelectProject(index, scope.$index, $event)"
                      size="medium"
                    >
                      <el-option
                        v-for="item in projectConfig"
                        :key="item.id"
                        :label="item.projectName"
                        :value="item.id"
                        :disabled="!!form.planItems[index].items.find(project => project.itemId == item.id)"
                      >
                      </el-option>
                    </el-select>
                  </template>
                </el-table-column>
                <el-table-column label="单次价格" :align="'center'">
                  <template slot-scope="scope">
                    <!-- 编辑状态 -->
                    <div
                      v-if="
                        form.planItems[index].items[scope.$index].itemId &&
                        form.planItems[index].items[scope.$index].editing
                      "
                    >
                      <template
                        v-if="
                          form.planItems[index].items[scope.$index]
                            .expectedDuration &&
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        "
                      >
                        <el-checkbox
                          ref="priceHour_checkbox"
                          v-model="
                            form.planItems[index].items[scope.$index]
                              .priceHour_checked
                          "
                          @change="
                            handleSelectPrice(
                              index,
                              scope.$index,
                              'priceHour',
                              $event
                            )
                          "
                          >{{
                            form.planItems[index].items[scope.$index].priceHour
                          }}</el-checkbox
                        >
                      </template>
                      <template v-else>
                        <el-input
                          :disabled="
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice_checked
                          "
                          v-model="
                            form.planItems[index].items[scope.$index].priceHour
                          "
                        >
                          <template slot="append">元</template>
                        </el-input>
                      </template>
                    </div>
                    <!-- 展示状态 -->
                    <div v-else>
                      <span
                        v-if="
                          !form.planItems[index].items[scope.$index].editing &&
                          form.planItems[index].items[scope.$index]
                            .preferentialPrice.length >= 0 &&
                          form.planItems[index].items[scope.$index]
                            .preferentialPrice_checked
                        "
                        >-</span
                      >
                      <span
                        v-else-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index].priceHour
                            .length > 0
                        "
                        >{{
                          form.planItems[index].items[scope.$index].priceHour
                        }}</span
                      >
                      <span v-else>-</span>
                    </div>
                    
                  </template>
                </el-table-column>
                <el-table-column label="优惠价" :align="'center'">
                  <template slot-scope="scope">
                    <!-- 编辑状态 -->
                    <div
                      v-if="
                        form.planItems[index].items[scope.$index].itemId &&
                        form.planItems[index].items[scope.$index].editing &&
                        form.planItems[index].items[scope.$index]
                          .expectedDuration &&
                        form.planItems[index].items[scope.$index]
                          .singleAppointmentDuration
                      "
                    >
                      <el-checkbox
                        ref="preferentialPrice_checkbox"
                        v-model="
                          form.planItems[index].items[scope.$index]
                            .preferentialPrice_checked
                        "
                        @change="
                          handleSelectPrice(
                            index,
                            scope.$index,
                            'preferentialPrice',
                            $event
                          )
                        "
                      >
                        <el-input
                          :disabled="
                            form.planItems[index].items[scope.$index]
                              .priceHour_checked
                          "
                          v-model="
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice
                          "
                        >
                          <template slot="append">元</template>
                        </el-input>
                      </el-checkbox>
                    </div>
                    <!-- 展示状态 -->
                    <div v-else>
                      <span
                        v-if="
                          !form.planItems[index].items[scope.$index].editing &&
                          form.planItems[index].items[scope.$index].priceHour
                            .length >= 0 &&
                          form.planItems[index].items[scope.$index]
                            .priceHour_checked
                        "
                        >-</span
                      >
                      <span
                        v-else-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index]
                            .preferentialPrice.length > 0
                        "
                        >{{
                          form.planItems[index].items[scope.$index]
                            .preferentialPrice
                        }}</span
                      >
                      <span v-else>-</span>
                    </div>
                    
                  </template>
                </el-table-column>
                <el-table-column label="预计时长" :align="'center'">
                  <template slot-scope="scope">
                    <span
                      v-if="
                        form.planItems[index].items[scope.$index].itemId &&
                        form.planItems[index].items[scope.$index]
                          .expectedDuration
                      "
                      >{{
                        form.planItems[index].items[scope.$index]
                          .expectedDuration
                      }}分钟</span
                    >
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column label="单次预约时长" :align="'center'">
                  <template slot-scope="scope">
                    <span
                      v-if="
                        form.planItems[index].items[scope.$index].itemId &&
                        form.planItems[index].items[scope.$index]
                          .singleAppointmentDuration
                      "
                      >{{
                        form.planItems[index].items[scope.$index]
                          .singleAppointmentDuration
                      }}小时</span
                    >
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column prop="operate" label="操作" :align="'center'">
                  <template slot-scope="scope">
                    <el-button
                      v-if="form.planItems[index].items[scope.$index].editing"
                      type="text"
                      primary
                      @click="handleSaveProject(index, scope.$index)"
                      >保存</el-button
                    >
                    <el-button
                      v-else
                      type="text"
                      primary
                      @click="handleEditProject(index, scope.$index)"
                      >编辑</el-button
                    >
                    <el-button
                      type="text"
                      primary
                      @click="handleDelProject(index, scope.$index)"
                      >删除</el-button
                    >
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="process-item--section process-item--add">
              <div @click="handleAddProject(index)" class="add">
                <i class="el-icon-plus"></i>
                <span>增加项目</span>
              </div>
              <el-dropdown placement="bottom-start" trigger="click">
                  <el-button type="primary">
                  复用项目<i class="el-icon-arrow-down el-icon--right"></i>
                  </el-button>
                  <el-dropdown-menu slot="dropdown" class="copy-dropdown">
                    <el-dropdown-item
                      class="copy-dropdown-item"
                      v-for="(plan, idx) in form.planItems"
                      :key="idx" 
                      @click.native="handleCopyPlan(index, plan, idx)"
                    >
                      <template v-if="index !== idx">
                        <span>{{ `第${idx + 1}次` }}</span>
                        <span>{{ `${plan.items.length}个项目` }}</span>
                      </template>
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
            </div>
            <div class="process-item--section process-item--effect">
              <div>
                <p class="label">作用机理</p>
                <div class="content">
                  <el-input
                    type="textarea"
                    :rows="5"
                    resize="none"
                    :maxlength="400"
                    v-model="form.planItems[index].mechanization"
                    :style="{ width: '500px' }"
                    placeholder="请输入作用机理"
                  />
                </div>
              </div>
              <div>
                <p class="label">预期效果</p>
                <div class="content">
                  <el-input
                    type="textarea"
                    :rows="5"
                    resize="none"
                    :maxlength="400"
                    v-model="form.planItems[index].expectedOutcomes"
                    :style="{ width: '500px' }"
                    placeholder="请输入预期效果"
                  />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      <div class="handle">
        <!-- <div class="handle-left"></div> -->
        <div class="handle-right">
          <el-button @click="handleSaveScheme">保存方案</el-button>
          <el-button type="primary" @click="handleFetchScheme"
            >开具方案</el-button
          >
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState } from "vuex";
export default {
  data() {
    return {
      form: null,
      pickerOptions: {
        disabledDate: (time) => {
          const today = new Date();
          today.setHours(0, 0, 0, 0); // 去掉时间部分，只比较日期
          return time.getTime() < today.getTime();
        },
      },
      projectConfig: [],
    };
  },
  mounted() {
    this.getPlanProjectConfig();
  },
  computed: {
    ...mapState({
      roles: (state) => state.authInfo.roles,
    }),
  },
  methods: {
    // 创建新方案
    async handleCreateNewForm() {
      if (this.form) {
        this.$message({
          message: "请对当前新方案进行开具再尝试创建",
          type: "warning",
        });
        return;
      }
      if (this.roles[0] !== "DOCTOR") {
        this.$message({
          message: "需要医生账号权限",
          type: "warning",
        });
        return;
      }
      const { patientSn } = this.$route.query;
      const { data } = await this.$api.baseApis.createNewDisposalPlan(
        patientSn
      );
      this.form = data;
      // 基于方案的治疗次数，自定义创建项目列表
    },
    // 获取可直接预约治疗项目
    async getPlanProjectConfig() {
      const { data } = await this.$api.baseApis.getPlanProjectConfig();
      this.projectConfig = data;
      console.log("this.projectConfig", this.projectConfig);
    },
    // 添加项目
    handleAddProject(planIdx) {
      const { id } = this.form.planItems[planIdx];
      if (this.form.planItems.length >= 10) {
        this.$notify({
          title: "单次最多选择10个项目",
          type: "error",
        });
        return;
      }
      this.form.planItems[planIdx].items.push({
        id: "",
        itemId: "",
        planId: id,
        priceHour: "",
        preferentialPrice: "",
        priceHour_checked: true,
        preferentialPrice_checked: false,
      });
    },
    handleCopyPlan(planIdx, targetPlan, idx) {
      const form = this.form
      const { id } = form.planItems[planIdx];

      // 将原来的id置空，且默认保存状态
      const items = JSON.parse(JSON.stringify(targetPlan)).items.map(item => ({ ...item, planId: id, editing: false }))
      
      // 确保每个项目都有数据
      if (items.find(item => !item.itemId)) {
        this.$notify({
          title: `请确保第${idx + 1}次项目编辑完成`,
          type: "success",
        });
        return
      }

      form.planItems[planIdx].items = items
      // this.$set(form.planItems[planIdx], 'items', items)

      this.$nextTick(async () => {
        await this.$api.baseApis.copyDisposalPlanItem({
          itemProjectReqList: items.map(item => {
            const { id, itemId, planId, preferentialPrice, priceHour, preferentialPrice_checked = false } = item
            const itemProjectReq = {
              id,
              itemId,
              planId
            }

            // 如果是后端数据，那么判断具体值。如果是前端数据那么判断复选值
            if (preferentialPrice_checked) itemProjectReq.preferentialPrice = preferentialPrice
            else if (preferentialPrice) itemProjectReq.preferentialPrice = preferentialPrice
            else itemProjectReq.priceHour = priceHour
            
            return itemProjectReq
          })
        })
        this.$notify({
          title: "项目复用成功",
          type: "success",
        });
        // form.planItems[planIdx].items.forEach((project, projectIdx) => this.handleEditProject(planIdx, projectIdx))
      })
    },
    // 选择项目
    handleSelectProject(planIdx, projectIdx, configId) {
      // id是子项id，itemId是下拉框项目id，planId是治疗次数id
      const { id = "", itemId = "" } =
        this.form.planItems[planIdx].items[projectIdx];
      const { id: planId } = this.form.planItems[planIdx];

      // 取出下拉框内容
      const {
        expectedDuration = "",
        singleAppointmentDuration = "",
        priceHour = "",
        preferentialPrice = "",
      } = this.projectConfig.find((config) => config.id == configId);

      this.$set(this.form.planItems[planIdx].items, projectIdx, {
        ...{
          // 保存当前次数，下拉框选项，次数的关系
          id,
          itemId,
          planId,

          // 下拉框内容
          expectedDuration,
          singleAppointmentDuration,
          priceHour,
          preferentialPrice,

          // 交互数据
          priceHour_checked: true,
          preferentialPrice_checked: false,
          editing: true,
        },
      });
    },
    // 选择价格
    handleSelectPrice(planIdx, projectIdx, type, value) {
      console.log(
        "handleSelectPrice",
        planIdx,
        projectIdx,
        type,
        value,
        this.form.planItems[planIdx].items[projectIdx]
      );

      if (type == "priceHour") {
        this.form.planItems[planIdx].items[projectIdx][
          `preferentialPrice_checked`
        ] = !value;
      } else {
        this.form.planItems[planIdx].items[projectIdx][`priceHour_checked`] =
          !value;
      }
    },
    // 删除方案中的某一次治疗
    async handleDelPlan(planIdx) {
      const { id } = this.form.planItems[planIdx];
      await this.$api.baseApis.delDisposalPlanNum(id);
      this.form.planItems.splice(planIdx, 1);

      // 次数全部删除需要重载列表由后端删除方案
      if (this.form.planItems.length == 0) {
        this.form = null;
        this.$emit("reload");
        this.$notify({
          title: "方案删除成功",
          type: "success",
        });
      } else {
        this.$notify({
          title: "次数删除成功",
          type: "success",
        });
      }
    },
    // 编辑某个项目
    handleEditProject(planIdx, projectIdx) {
      this.$set(
        this.form.planItems[planIdx].items[projectIdx],
        "editing",
        true
      );
      const preferentialPrice_checked = this.form.planItems[planIdx].items[projectIdx].preferentialPrice.length > 0
      this.$set(
        this.form.planItems[planIdx].items[projectIdx],
        "priceHour_checked",
         !preferentialPrice_checked
      );
      this.$set(
        this.form.planItems[planIdx].items[projectIdx],
        "preferentialPrice_checked",
        preferentialPrice_checked
      );
      console.log(
        "handleEditProject",
        this.form.planItems[planIdx].items[projectIdx].editing
      );
    },
    // 保存某个项目
    async handleSaveProject(planIdx, projectIdx) {
      const data = this.form.planItems[planIdx].items[projectIdx];
      console.log("handleSaveProject", data);
      const { id, itemId, planId, preferentialPrice, priceHour } = data;

      const params = {
        id,
        itemId,
        planId,
      };
      if (
        this.form.planItems[planIdx].items[projectIdx].preferentialPrice_checked
      ) {
        params.preferentialPrice = preferentialPrice;
      } else {
        params.priceHour = priceHour;
      }

      const res = await this.$api.baseApis.saveDisposalPlanItem(params);
      this.$notify({
        title: "保存成功",
        type: "success",
      });

      this.form.planItems[planIdx].items[projectIdx].id = res.data.id || "";
      this.form.planItems[planIdx].items[projectIdx].editing = false;
    },
    // 删除项目
    async handleDelProject(planIdx, projectIdx) {
      const { id = "" } = this.form.planItems[planIdx].items[projectIdx];
      this.form.planItems[planIdx].items.splice(projectIdx, 1);
      if (id) await this.$api.baseApis.delDisposalPlanItem(id);

      this.$notify({
        title: "项目删除成功",
        type: "success",
      });
      // if (this.form.planItems[planIdx].items.length == 0 && this.form.planItems.length > 1) {
      //   this.handleDelPlan(planIdx)
      // }
    },
    // 增加方案中的治疗次数
    async handleAddPlan() {
      const { id } = this.form;
      const { data } = await this.$api.baseApis.addDisposalPlanTimes(id);
      this.$notify({
        title: "治疗添加成功",
        type: "success",
      });
      this.form.planItems.push(data);
    },
    // 保存方案
    async handleSaveScheme() {
      const { id, advice, planItems } = this.form;
      const { patientSn } = this.$route.query;
      const disposalPlanDetailList = planItems.map((planItem) => {
        const {
          id,
          expectedOutcomes,
          mechanization,
          noRecommended,
          recommendedTime,
        } = planItem;
        return {
          id,
          expectedOutcomes,
          mechanization,
          noRecommended, // 取反值
          recommendedTime,
        };
      });
      const params = {
        id,
        patientSn,
        advice,
        disposalPlanDetailList,
      };
      await this.$api.baseApis.saveDisposalPlan(params);
      this.$notify({
        title: "保存成功",
        type: "success",
      });
      this.form = null;
      this.$emit("reload");
    },
    // 开具方案
    async handleFetchScheme() {
      if (this.roles[0] !== "DOCTOR") {
        this.$message({
          message: "需要医生账号权限",
          type: "warning",
        });
        return;
      }
      this.$confirm('确认开具方案?', '提示').then(async () => {
        const { id } = this.form;
        await this.$api.baseApis.openDisposalPlan(id);
        this.$notify({
          title: "开具方案成功",
          type: "success",
        });
        this.form = null;
        this.$emit("reload");
      })
      // const { id } = this.form;
      // await this.$api.baseApis.openDisposalPlan(id);
      // this.$notify({
      //   title: "开具方案成功",
      //   type: "success",
      // });
      // this.form = null;
      // this.$emit("reload");
    },
  },
};
</script>
<style lang="less">
.copy-dropdown {
  height: 100px;
  overflow-y: scroll;
  .copy-dropdown-item {
    width: 12ch;
    display: flex;
    justify-content: space-between;
    // gap: 8px;
  }
}
.scheme-form___com {
  .scheme-btns {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
  .scheme-form {
    border: 1px dashed #000000;
    padding: 12px;
    margin-bottom: 12px;
    > .form {
      > .title {
        padding-bottom: 10px;
        > div {
          margin-top: 8px;
        }
        .name {
          font-weight: bold;
          font-size: 18px;
        }
        .time {
          color: #a8abb2;
          font-size: 12px;
        }
        .doctor-order {
          display: flex;
          font-size: 14px;
          color: #303133;
        }
      }
      > .content {
        border: 1px solid #ebedf0;
        border-radius: 4px;
        padding: 0 20px;
        .process-item {
          font-size: 14px;
          padding-bottom: 20px;
          margin-bottom: 20px;
          &--title {
            display: flex;
            justify-content: space-between;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            color: #303133;
            width: calc(100% + 40px);
            // width: 100%;
            transform: translateX(-20px);
            background: #f5f7fa;
            padding: 14px 20px;
            font-size: 16px;
            border-radius: 4px;
            .title {
              display: flex;
              align-items: center;
              img {
                width: 22px;
                height: 22px;
                margin-right: 8px;
              }
            }
            .handle {
              margin-left: 8px;
              .del-plan-btn {
                border: 1px solid #e95720;
                color: #e95720;
              }
            }
          }
          &--time {
            display: flex;
            align-items: center;
            margin: 24px 0;
            gap: 8px;
          }
          &--project {
            .el-table thead tr th {
              background-color: #f5f7fa;
            }
          }
          &--add {
            border: 1px solid #ebeef5;
            padding: 16px 12px;
            cursor: pointer;
            display: flex;
            gap: 10px;
            .add {
              flex: 1;
              padding: 8px;
              text-align: center;
              background: rgba(233, 87, 32, 0.11);
              border-radius: 4px;
              border: 1px solid rgba(233, 87, 32, 0.22);
              font-size: 14px;
              color: #e95720;
            }
          }
          &--effect {
            display: flex;
            flex-direction: column;
            margin-top: 16px;
            gap: 10px;
            .label {
              margin-bottom: 4px;
            }
          }
        }
      }
    }
    > .handle {
      margin-top: 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
</style>
