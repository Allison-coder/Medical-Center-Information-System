<template>
  <div class="scheme___com">
    <!-- 新增治疗方案 -->
    <SchemeForm @reload="handleReloadList" />
    <!-- 治疗方案列表 -->
    <SchemeList ref="scheme-list" />
  </div>
</template>
<script>
import SchemeForm from "./form.vue";
import SchemeList from "./list.vue";
export default {
  components: {
    SchemeForm,
    SchemeList,
  },
  data() {
    return {};
  },
  methods: {
    handleReloadList() {
      this.$refs["scheme-list"].getDisposalPlanList();
    },
  },
};
</script>
<style lang="less">
.scheme___com {
}
</style>
