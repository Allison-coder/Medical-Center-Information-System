<template>
  <div class="scheme-list___com">
    <!-- v1.5.1不再展示列表，而通过下拉框选择 -->
    <!-- <div class="scheme-list" v-for="(form, formIdx) in list" :key="formIdx"> -->
    <div class="scheme-list" v-if="form">
      <div class="scheme-list--item">
        <div class="scheme-form">
          <header class="scheme-header">
            <div class="title">
              <p class="name">治疗方案：{{ form.planSn }}</p>
              <el-dropdown placement="bottom-start" trigger="click">
                <el-button type="primary">
                  切换方案<i class="el-icon-arrow-down el-icon--right"></i>
                </el-button>
                <el-dropdown-menu slot="dropdown" class="form-dropdown">
                  <el-dropdown-item
                    class="form-dropdown-item"
                    v-for="plan in list"
                    :key="plan.planSn" 
                    @click.native="handleSelectForm(plan)"
                  >
                    <span>{{ `治疗方案${plan.planSn}` }}</span>
                    <span>{{ `${plan.createTime}` }}</span>
                    <span>{{ `${status2Str(plan.status)}` }}</span>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
              <!-- <el-select v-model="form" value-key="planSn">
                <el-option 
                  v-for="plan in list" 
                  :key="plan.planSn" 
                  :label="`治疗方案${plan.planSn}   ${plan.createTime}   ${status2Str(plan.status)}`"
                  :value="plan"
                >
                </el-option>
              </el-select> -->
            </div>
            <div class="time">创建时间：{{ form.createTime }}</div>
            <div class="doctor-order">
              <p class="label">医嘱：</p>
              <div class="content">
                <!-- :disabled="
                    !(form.speedStatus == 1 && form.isPlanIssued == false)
                  " -->
                <el-input
                  type="textarea"
                  :rows="5"
                  resize="none"
                  :maxlength="400"
                  v-model="form.advice"
                  :style="{ width: '500px' }"
                  placeholder="请输入医嘱"
                />
              </div>
            </div>
          </header>
          <main class="scheme-content">
            <div
              class="process-item"
              v-for="(data, index) in form.planItems"
              :key="index"
            >
              <div class="process-item--section process-item--title">
                <div class="title">
                  <img src="@/assets/plan.png" />
                  <span>第{{ index + 1 }}次治疗</span>
                </div>
                <div
                  class="handle"
                  v-if="form.speedStatus == 1 && form.isPlanIssued == false"
                >
                  <el-button
                    class="del-plan-btn"
                    icon="el-icon-close"
                    @click="handleDelPlan(index)"
                    >删除次数</el-button
                  >
                  <el-button
                    class="add-btn"
                    icon="el-icon-plus"
                    type="primary"
                    @click="handleAddPlan()"
                    v-if="
                      form.speedStatus == 1 &&
                      form.isPlanIssued == false &&
                      index == 0
                    "
                    >添加次数</el-button
                  >
                </div>
              </div>
              <div class="process-item--section process-item--time">
                <p>推荐治疗时间</p>
                <!-- :disabled="
                    !(form.speedStatus == 1 && form.isPlanIssued == false)
                  " -->
                <el-date-picker
                  v-if="!data.noRecommended"
                  v-model="data.recommendedTime"
                  align="right"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="pickerOptions"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <!-- :disabled="
                    !(form.speedStatus == 1 && form.isPlanIssued == false)
                  " -->
                <el-checkbox v-model="data.noRecommended">不推荐</el-checkbox>
              </div>
              <div class="process-item--section process-item--project">
                <el-table :data="data.items" :border="true" :key="form.id">
                  <el-table-column
                    label="项目名称"
                    width="200"
                    :align="'center'"
                  >
                    <template slot-scope="scope">
                      <!-- 兼容旧数据 -->
                      <span
                        v-if="
                          scope.row.itemId &&
                          !projectConfig.find(
                            (config) => config.id == scope.row.itemId
                          )
                        "
                        >{{ scope.row.itemName }}</span
                      >
                      <el-select
                        v-else
                        :disabled="
                          !form.planItems[index].items[scope.$index].editing
                        "
                        :key="form.id + '' + scope.$index"
                        placeholder="请选择项目"
                        v-model="scope.row.itemId"
                        @change="
                          handleSelectProject(
                            index,
                            scope.$index,
                            $event
                          )
                        "
                        size="medium"
                      >
                        <el-option
                          v-for="item in projectConfig"
                          :key="item.id"
                          :label="item.projectName"
                          :value="item.id"
                          :disabled="!!form.planItems[index].items.find(project => project.itemId == item.id)"
                        >
                        </el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column label="单次价格" :align="'center'">
                    <template slot-scope="scope">
                      <!-- 编辑状态 -->
                      <div
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index].editing
                        "
                      >
                        <template
                          v-if="
                            form.planItems[index].items[scope.$index]
                              .expectedDuration &&
                            form.planItems[index].items[scope.$index]
                              .singleAppointmentDuration
                          "
                        >
                          <el-checkbox
                            ref="priceHour_checkbox"
                            v-model="
                              form.planItems[index].items[scope.$index]
                                .priceHour_checked
                            "
                            @change="
                              handleSelectPrice(
                                index,
                                scope.$index,
                                'priceHour',
                                $event
                              )
                            "
                            >{{
                              form.planItems[index].items[scope.$index]
                                .priceHour
                            }}</el-checkbox
                          >
                        </template>
                        <template v-else>
                          <el-input
                            :disabled="
                              form.planItems[index].items[scope.$index]
                                .preferentialPrice_checked
                            "
                            v-model="
                              form.planItems[index].items[scope.$index]
                                .priceHour
                            "
                          >
                            <template slot="append">元</template>
                          </el-input>
                        </template>
                      </div>
                      <!-- 展示状态 -->
                      <div v-else>
                        <span
                          v-if="
                            !form.planItems[index].items[scope.$index].editing &&
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice.length >= 0 &&
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice_checked
                          "
                          >-</span
                        >
                        <span
                          v-else-if="
                            form.planItems[index].items[scope.$index].itemId &&
                            form.planItems[index].items[scope.$index].priceHour
                              .length > 0
                          "
                          >{{
                            form.planItems[index].items[scope.$index].priceHour
                          }}</span
                        >
                        <span v-else>-</span>
                      
                      </div>
                      
                    </template>
                  </el-table-column>
                  <el-table-column label="优惠价" :align="'center'">
                    <template slot-scope="scope">
                      <!-- 编辑状态 -->
                      <div
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index].editing &&
                          form.planItems[index].items[scope.$index]
                            .expectedDuration &&
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        "
                      >
                        <el-checkbox
                          ref="preferentialPrice_checkbox"
                          v-model="
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice_checked
                          "
                          @change="
                            handleSelectPrice(
                              index,
                              scope.$index,
                              'preferentialPrice',
                              $event
                            )
                          "
                        >
                          <el-input
                            :disabled="
                              form.planItems[index].items[scope.$index]
                                .priceHour_checked
                            "
                            v-model="
                              form.planItems[index].items[scope.$index]
                                .preferentialPrice
                            "
                          >
                            <template slot="append">元</template>
                          </el-input>
                        </el-checkbox>
                      </div>
                      <!-- 展示状态 -->
                      <div v-else>
                        <span
                          v-if="
                            !form.planItems[index].items[scope.$index].editing &&
                            form.planItems[index].items[scope.$index].priceHour
                              .length >= 0 &&
                            form.planItems[index].items[scope.$index]
                              .priceHour_checked
                          "
                          >-</span
                        >
                        <span
                          v-else-if="
                            form.planItems[index].items[scope.$index].itemId &&
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice.length > 0
                          "
                          >{{
                            form.planItems[index].items[scope.$index]
                              .preferentialPrice
                          }}</span
                        >
                        <span v-else>-</span>
                      </div>
                      
                    </template>
                  </el-table-column>
                  <el-table-column label="预计时长" :align="'center'">
                    <template slot-scope="scope">
                      <span
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index]
                            .expectedDuration
                        "
                        >{{
                          form.planItems[index].items[scope.$index]
                            .expectedDuration
                        }}分钟</span
                      >
                      <span v-else>-</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="单次预约时长" :align="'center'">
                    <template slot-scope="scope">
                      <span
                        v-if="
                          form.planItems[index].items[scope.$index].itemId &&
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        "
                        >{{
                          form.planItems[index].items[scope.$index]
                            .singleAppointmentDuration
                        }}小时</span
                      >
                      <span v-else>-</span>
                    </template>
                  </el-table-column>
                  <el-table-column
                    prop="operate"
                    label="操作"
                    :align="'center'"
                  >
                    <template
                      slot-scope="scope"
                      v-if="form.speedStatus == 1 && form.isPlanIssued == false"
                    >
                      <el-button
                        v-if="form.planItems[index].items[scope.$index].editing"
                        type="text"
                        primary
                        @click="handleSaveProject(index, scope.$index)"
                        >保存</el-button
                      >
                      <el-button
                        v-else
                        type="text"
                        primary
                        @click="handleEditProject(index, scope.$index)"
                        >编辑</el-button
                      >
                      <el-button
                        type="text"
                        primary
                        @click="handleDelProject(index, scope.$index)"
                        >删除</el-button
                      >
                    </template>
                    <template slot-scope="scope" v-else>
                      <span>-</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div
                class="process-item--section process-item--add"
                v-if="form.speedStatus == 1 && form.isPlanIssued == false"
              >
                <div @click="handleAddProject(index)" class="add">
                  <i class="el-icon-plus"></i>
                  <span>增加项目</span>
                </div>
                <el-dropdown placement="bottom-start" trigger="click">
                  <el-button type="primary">
                  复用项目<i class="el-icon-arrow-down el-icon--right"></i>
                  </el-button>
                  <el-dropdown-menu slot="dropdown" class="copy-dropdown">
                    <el-dropdown-item
                      class="copy-dropdown-item"
                      v-for="(plan, idx) in form.planItems"
                      :key="idx" 
                      @click.native="handleCopyPlan(index, plan, idx)"
                    >
                      <template v-if="index !== idx">
                        <span>{{ `第${idx + 1}次` }}</span>
                        <span>{{ `${plan.items.length}个项目` }}</span>
                      </template>
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </div>
              <div class="process-item--section process-item--effect">
                <div>
                  <p class="label">作用机理</p>
                  <div class="content">
                    <!-- :disabled="
                        !(form.speedStatus == 1 && form.isPlanIssued == false)
                      " -->
                    <el-input
                      type="textarea"
                      :rows="5"
                      resize="none"
                      :maxlength="400"
                      v-model="form.planItems[index].mechanization"
                      :style="{ width: '500px' }"
                      placeholder="请输入作用机理"
                    />
                  </div>
                </div>
                <div>
                  <p class="label">预期效果</p>
                  <div class="content">
                    <!-- :disabled="
                        !(form.speedStatus == 1 && form.isPlanIssued == false)
                      " -->
                    <el-input
                      type="textarea"
                      :rows="5"
                      resize="none"
                      :maxlength="400"
                      v-model="form.planItems[index].expectedOutcomes"
                      :style="{ width: '500px' }"
                      placeholder="请输入预期效果"
                    />
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>

        <!-- 方案状态---进行中 -->
        <div class="scheme-handle" v-if="form.speedStatus == 1">
          <!-- <div class="handle-left"></div> -->
          <div class="handle-right">
            <!-- 方案开具---已开具 -->
            <template v-if="form.isPlanIssued">
              <el-button
                @click="handleCancelScheme()"
                >取消治疗方案</el-button
              >
              <el-button @click="handleSaveScheme()">保存方案</el-button>

              <el-button
                type="primary"
                @click="handleShowPopup()"
                >合并治疗订单</el-button
              >
              <el-button
                type="primary"
                @click="handlePrintScheme()"
                >打印治疗订单</el-button
              >
            </template>
            <!-- 方案开具---未开具 -->
            <template v-else>
              <el-button @click="handleSaveScheme()">保存方案</el-button>
              <el-button type="primary" @click="handleFetchScheme()"
                >开具方案</el-button
              >
            </template>
          </div>
        </div>
        <!-- 方案状态---已结束 -->
        <div class="scheme-handle" v-else>
          <!-- <div class="handle-left"></div> -->
          <div class="handle-right">
            <el-button
              type="primary"
              @click="handlePrintScheme()"
              >打印治疗订单</el-button
            >
            <!-- <el-tag type="info">方案已结束</el-tag> -->
            <el-button
              round
              disabled
              icon="el-icon-warning"
              :style="{ 'background-color': '#f5f7fa' }"
              >方案已结束</el-button
            >
          </div>
        </div>
        
      </div>
    </div>
    <el-dialog
      key="merge"
      custom-class="merge-dialog"
      title="合并治疗订单"
      :visible="isShowMergeDialog"
      :before-close="handleClosePopup"
    >
      <el-table key="merge-dialog" :data="mergeDialogData">
        <el-table-column
          :align="'center'"
          label="序号"
          prop="sortNum"
        >
          <template slot-scope="scope">
            <span>第{{ scope.row.sortNum }}次</span>
          </template>
        </el-table-column>
        <el-table-column :align="'center'" label="总价" prop="orderAmount">
          <template slot-scope="scope">
            <span>￥{{ scope.row.orderAmount }}</span>
          </template>
        </el-table-column>
        <el-table-column
          :align="'center'"
          label="订单号"
          prop="orderSn"
        ></el-table-column>
        <el-table-column :align="'center'" label="订单状态" prop="orderStatus">
          <template slot-scope="scope">
            <span>{{ orderStatus2Str(scope.row.orderStatus) }}</span>
            <!-- <span v-if="scope.row.orderStatus == 0">待支付</span>
            <span
              v-else-if="scope.row.orderStatus == 1"
              :style="{ color: '#e95720' }"
              >已支付</span
            > -->
          </template>
        </el-table-column>
        <el-table-column :align="'center'" label="选择" prop="opreate">
          <template slot-scope="scope">
            <el-checkbox
              :disabled="scope.row.orderStatus !== 0 || scope.row.orderAmount == 0"
              v-model="dialogChecked[scope.$index]"
              @change="handlePaySelect(scope.$index)"
            ></el-checkbox>
          </template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="merge-dialog-footer">
        <el-button @click="handleClosePopup">取消</el-button>
        <el-button type="primary" @click="handleConfirmPopup">确认</el-button>
      </span>
    </el-dialog>

    <printDialog
      :data="dialogData"
      :isShow="isShowDialog"
      :type="dialogType"
      @close="isShowDialog = false"
    />
  </div>
</template>

<script>
import printDialog from "./printDialog.vue";
import { mapState } from "vuex";
export default {
  components: {
    printDialog,
  },
  data() {
    return {
      list: [],
      form: null,

      pickerOptions: {
        disabledDate: (time) => {
          const today = new Date();
          today.setHours(0, 0, 0, 0); // 去掉时间部分，只比较日期
          return time.getTime() < today.getTime();
        },
      },
      projectConfig: [],
      mergeDialogData: [],
      dialogFormId: "",
      isShowMergeDialog: false,
      dialogChecked: [],

      isShowDialog: false,
      dialogData: null,
      dialogType: 'pay'
    };
  },
  mounted() {
    this.getDisposalPlanList();
    this.getPlanProjectConfig();
  },
  computed: {
    ...mapState({
      roles: (state) => state.authInfo.roles,
    }),
  },
  methods: {
    orderStatus2Str(status) {
      let str = ''
      switch(status) {
        case 0:
          str = '待支付'
          break
        case 1:
          str = '已支付'
          break
        case 2:
          str = '已取消'
          break
        case 3:
          str = '退款中'
          break
        case 4:
          str = '已退款'
          break
        default:
          str = '未知'
      }
      return str
    },
    status2Str(status) {
      let str = ''
      switch(status) {
        case 0:
          str = '未开具'
          break
        case 1:
          str = '进行中'
          break
        case 2:
          str = '已结束'
          break
        default:
          str = '未知'
      }
      return str
    },
    async handleSelectForm(form) {
      this.form = form
    },
    async getDisposalPlanList() {
      const loading = this.$loading({ lock: true, text: '加载中' })
      const { patientSn } = this.$route.query;
      const { data } = await this.$api.baseApis.getDisposalPlanList(patientSn);
      this.list = data;
      
      // 已存在方案需要停留在当前方案
      if (this.form) {
        this.form = data.find(scheme => scheme?.planSn == this.form.planSn)
      } else {
        this.form = data.length > 0 ? this.form = data[0] : this.form
      }

      loading.close()
    },
    // 获取可直接预约治疗项目
    async getPlanProjectConfig() {
      const { data } = await this.$api.baseApis.getPlanProjectConfig();
      this.projectConfig = data;
      console.log("this.projectConfig", this.projectConfig);
    },
    // 添加项目
    handleAddProject(planIdx) {
      const form = this.form;
      const { id } = form.planItems[planIdx];
      if (form.planItems.length >= 10) {
        this.$notify({
          title: "单次最多选择10个项目",
          type: "error",
        });
        return;
      }
      form.planItems[planIdx].items.push({
        id: "",
        itemId: "",
        planId: id,
        expectedDuration: "",
        singleAppointmentDuration: "",
        priceHour: "",
        preferentialPrice: "",
        priceHour_checked: true,
        preferentialPrice_checked: false,
        editing: false,
      });
    },
    handleCopyPlan(planIdx, targetPlan, idx) {
      const form = this.form
      console.log('targetPlan', targetPlan)
      const { id } = form.planItems[planIdx];
      console.log('form.planItems[planIdx]', form.planItems[planIdx])

      // 将原来的id置空，且默认保存状态
      const items = JSON.parse(JSON.stringify(targetPlan)).items.map(item => ({ ...item, planId: id, id: '', editing: false }))
      
      // 确保每个项目都有数据
      if (items.find(item => !item.itemId)) {
        this.$notify({
          title: `请确保第${idx + 1}次项目编辑完成`,
          type: "success",
        });
        return
      }

      // 静态前端展示
      form.planItems[planIdx].items = items
      console.log('items', items)
      // this.$set(form.planItems[planIdx], 'items', items)

      this.$nextTick(async () => {
        await this.$api.baseApis.copyDisposalPlanItem({
          itemProjectReqList: items.map(item => {
            const { id, itemId, planId, preferentialPrice, priceHour, preferentialPrice_checked = false } = item
            const itemProjectReq = {
              id,
              itemId,
              planId
            }

            // 如果是后端数据，那么判断具体值。如果是前端数据那么判断复选值
            if (preferentialPrice_checked) itemProjectReq.preferentialPrice = preferentialPrice
            else if (preferentialPrice) itemProjectReq.preferentialPrice = preferentialPrice
            else itemProjectReq.priceHour = priceHour

            return itemProjectReq
          })
        })
        this.$notify({
          title: "项目复用成功",
          type: "success",
        });
        // form.planItems[planIdx].items.forEach((project, projectIdx) => this.handleEditProject(planIdx, projectIdx))
        // form.planItems[planIdx].items.forEach((project, projectIdx) => this.handleSaveProject(planIdx, projectIdx))
      })
    },
    // 选择项目
    handleSelectProject(planIdx, projectIdx, configId) {
      const form = this.form;

      // id是子项id，itemId是下拉框项目id，planId是治疗次数id
      const { id = "", itemId = "" } =
        form.planItems[planIdx].items[projectIdx];
      const { id: planId } = form.planItems[planIdx];

      // 取出下拉框内容
      const {
        expectedDuration = "",
        singleAppointmentDuration = "",
        priceHour = "",
        preferentialPrice = "",
      } = this.projectConfig.find((config) => config.id == configId);

      //
      this.$set(form.planItems[planIdx].items, projectIdx, {
        ...{
          // 保存当前次数，下拉框选项，次数的关系
          id,
          itemId,
          planId,

          // 下拉框内容
          expectedDuration,
          singleAppointmentDuration,
          priceHour,
          preferentialPrice,

          // 交互数据
          priceHour_checked: true,
          preferentialPrice_checked: false,
          editing: true,
        },
      });
    },
    // 选择价格
    handleSelectPrice(planIdx, projectIdx, type, value) {
      const form = this.form;
      console.log(
        "handleSelectPrice",
        planIdx,
        projectIdx,
        type,
        value,
        form.planItems[planIdx].items[projectIdx]
      );

      if (type == "priceHour") {
        form.planItems[planIdx].items[projectIdx][`preferentialPrice_checked`] =
          !value;
      } else {
        form.planItems[planIdx].items[projectIdx][`priceHour_checked`] = !value;
      }
    },
    // 删除方案中的某一次治疗
    async handleDelPlan(planIdx) {
      const form = this.form;
      const { id } = form.planItems[planIdx];
      // if (form.planItems.length == 1) {
      //   this.$notify({
      //     title: "需要至少保留一次治疗",
      //     type: "error",
      //   });
      //   return;
      // }
      await this.$api.baseApis.delDisposalPlanNum(id);
      form.planItems.splice(planIdx, 1);

      if (form.planItems.length == 0) {
        this.getDisposalPlanList();
        this.$notify({
          title: "方案删除成功",
          type: "success",
        });
      } else {
        this.$notify({
          title: "次数删除成功",
          type: "success",
        });
      }
    },
    // 编辑某个项目
    handleEditProject(planIdx, projectIdx) {
      this.$set(
        this.form.planItems[planIdx].items[projectIdx],
        "editing",
        true
      );
      const preferentialPrice_checked = this.form.planItems[planIdx].items[projectIdx].preferentialPrice.length > 0
      this.$set(
        this.form.planItems[planIdx].items[projectIdx],
        "priceHour_checked",
         !preferentialPrice_checked
      );
      this.$set(
        this.form.planItems[planIdx].items[projectIdx],
        "preferentialPrice_checked",
        preferentialPrice_checked
      );

      // form.planItems[planIdx].items[projectIdx].editing = true;
      console.log(
        "handleEditProject",
        this.form.planItems[planIdx].items[projectIdx]
      );
    },
    // 保存某个项目
    async handleSaveProject(planIdx, projectIdx) {
      const form = this.form;
      const data = form.planItems[planIdx].items[projectIdx];
      console.log("handleSaveProject", data);
      const { id, itemId, planId, preferentialPrice, priceHour } = data;

      const params = {
        id,
        itemId,
        planId,
      };
      if (form.planItems[planIdx].items[projectIdx].preferentialPrice_checked) {
        params.preferentialPrice = preferentialPrice;
      } else {
        params.priceHour = priceHour;
      }
      const res = await this.$api.baseApis.saveDisposalPlanItem(params);
      this.$notify({
        title: "保存成功",
        type: "success",
      });

      form.planItems[planIdx].items[projectIdx].id = res.data.id || "";
      form.planItems[planIdx].items[projectIdx].editing = false;
    },
    // 删除项目
    async handleDelProject(planIdx, projectIdx) {
      const form = this.form;
      const { id = "" } = form.planItems[planIdx].items[projectIdx];
      form.planItems[planIdx].items.splice(projectIdx, 1);
      if (id) await this.$api.baseApis.delDisposalPlanItem(id);

      this.$notify({
        title: "项目删除成功",
        type: "success",
      });
      // if (form.planItems[planIdx].items.length == 0 && form.planItems.length > 1) {
      //   this.handleDelPlan(formIdx, planIdx)
      // }
    },
    // 增加方案中的治疗次数
    async handleAddPlan() {
      const form = this.form;
      const { id } = form;
      const { data } = await this.$api.baseApis.addDisposalPlanTimes(id);
      this.$notify({
        title: "治疗添加成功",
        type: "success",
      });
      form.planItems.push(data);
    },
    // 保存方案
    async handleSaveScheme() {
      const form = this.form;
      const { id, advice, planItems } = form;
      const { patientSn } = this.$route.query;
      const disposalPlanDetailList = planItems.map((planItem) => {
        const {
          id,
          expectedOutcomes,
          mechanization,
          noRecommended,
          recommendedTime,
        } = planItem;
        return {
          id,
          expectedOutcomes,
          mechanization,
          noRecommended,
          recommendedTime,
        };
      });
      const params = {
        id,
        patientSn,
        advice,
        disposalPlanDetailList,
      };
      await this.$api.baseApis.saveDisposalPlan(params);
      this.$notify({
        title: "保存成功",
        type: "success",
      });

      this.getDisposalPlanList();
    },
    // 开具方案
    async handleFetchScheme() {
      if (this.roles[0] !== "DOCTOR") {
        this.$message({
          message: "需要医生账号权限",
          type: "warning",
        });
        return;
      }

      this.$confirm('确认开具方案?', '提示').then(async () => {
        const form = this.form;
        const { id } = form;
        await this.$api.baseApis.openDisposalPlan(id);
        this.$notify({
          title: "开具方案成功",
          type: "success",
        });

        this.getDisposalPlanList();
      })
      // const form = this.form;
      // const { id } = form;
      // await this.$api.baseApis.openDisposalPlan(id);
      // this.$notify({
      //   title: "开具方案成功",
      //   type: "success",
      // });

      // this.getDisposalPlanList();
    },
    // 取消治疗方案
    async handleCancelScheme() {
      this.$confirm('确认取消治疗方案?', '提示').then(async () => {
        const form = this.form;
        const { id } = form;
        await this.$api.baseApis.cancelDisposalPlan(id);
        this.$notify({
          title: "取消成功",
          type: "success",
        });
        this.getDisposalPlanList();
      })
    },
    // 合并治疗单弹窗-打开
    async handleShowPopup() {
      const { id } = this.form;
      const { data } = await this.$api.baseApis.mergeDisposalPlan(id);
      this.mergeDialogData = data;
      this.dialogFormId = id;
      this.isShowMergeDialog = true;
      this.dialogChecked = new Array(data.length).fill(false);
      console.log("dialogChecked", this.dialogChecked);
    },
    // 合并治疗单弹窗-关闭
    handleClosePopup() {
      this.isShowMergeDialog = false;
    },
    // 合并治疗单弹窗-确认按钮
    async handleConfirmPopup() {
      let orderSns = this.dialogChecked
        .map((check, index) => {
          if (check) return this.mergeDialogData[index].orderSn;
        })
        .filter((num) => num);

      if (orderSns.length == 0) {
        this.$notify({
          title: "请选择治疗订单",
          type: "error",
        });
        return;
      }
      const params = {
        id: this.dialogFormId,
        orderSns,
      };
      const { data } = await this.$api.baseApis.mergeDisposalPlanConfirm(
        params
      );
      Object.assign(this.$data, {
        isShowDialog: true,
        dialogData: data,
        dialogType: 'pay',
        isShowMergeDialog: false
      })
      // this.isShowDialog = true;
      // this.isShowMergeDialog = false;
      // this.dialogData = data;
      // this.dialogType = 'pay'
    },
    // 合并治疗单弹窗-选择
    handlePaySelect(checkIdx) {
      // 单选
      // this.dialogChecked = this.dialogChecked.map((check, index) => {
      //   if (checkIdx == index) return check;
      //   else return false;
      // });

      console.log("handlePaySelect", checkIdx, this.dialogChecked);
    },

    // 打印方案
    async handlePrintScheme() {
      const form = this.form;
      const { id } = form
      const { data } = await this.$api.baseApis.printTreatOrder(id)
      // this.isShowDialog = true;
      // this.dialogData = data;
      // this.dialogType = 'check'
      Object.assign(this.$data, {
        isShowDialog: true,
        dialogData: data,
        dialogType: 'check'
      })
    },
  },
};
</script>

<style lang="less">
.copy-dropdown {
  height: 100px;
  overflow-y: scroll;
  .copy-dropdown-item {
    width: 12ch;
    display: flex;
    justify-content: space-between;
    // gap: 8px;
  }
}
.form-dropdown {
  height: 100px;
  overflow-y: scroll;
  .form-dropdown-item {
    width: 45ch;
    display: flex;
    justify-content: space-between;
    // gap: 8px;
  }
}
.scheme-list___com {
  .scheme-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
    .scheme-list--item {
      // border: 1px dashed #000000;
      padding: 12px;
      margin-bottom: 12px;
      position: relative;
      &::before {
        content: "";
        position: absolute;
        left: 0;
        top: 10px;
        width: 5px;
        height: 40px;
        background-color: #e95720;
        border-radius: 4px;
      }
      .scheme-form {
        .scheme-header {
          padding-bottom: 10px;
          > div {
            margin-top: 8px;
          }
          .title {
            display: flex;
            align-items: center;
            .name {
              font-weight: bold;
              font-size: 18px;
              margin-right: 40px;
            }
            .el-input__inner {
              width: 45ch;
            }
          }
          .time {
            color: #a8abb2;
            font-size: 12px;
          }
          .doctor-order {
            display: flex;
            font-size: 14px;
            color: #303133;
          }
        }
        .scheme-content {
          border: 1px solid #ebedf0;
          border-radius: 4px;
          padding: 0 20px;
          .process-item {
            font-size: 14px;
            padding-bottom: 20px;
            margin-bottom: 20px;
            &--title {
              display: flex;
              justify-content: space-between;
              box-sizing: border-box;
              display: flex;
              align-items: center;
              color: #303133;
              width: calc(100% + 40px);
              // width: 100%;
              transform: translateX(-20px);
              background: #f5f7fa;
              padding: 14px 20px;
              font-size: 16px;
              border-radius: 4px;
              .title {
                display: flex;
                align-items: center;
                img {
                  width: 22px;
                  height: 22px;
                  margin-right: 8px;
                }
              }
              .handle {
                margin-left: 8px;
                .del-plan-btn {
                  border: 1px solid #e95720;
                  color: #e95720;
                }
              }
            }
            &--time {
              display: flex;
              align-items: center;
              margin: 24px 0;
              gap: 8px;
            }
            &--project {
              .el-table thead tr th {
                background-color: #f5f7fa;
              }
            }
            &--add {
              border: 1px solid #ebeef5;
              padding: 16px 12px;
              cursor: pointer;
              display: flex;
              gap: 10px;
              .add {
                flex: 1;
                padding: 8px;
                text-align: center;
                background: rgba(233, 87, 32, 0.11);
                border-radius: 4px;
                border: 1px solid rgba(233, 87, 32, 0.22);
                font-size: 14px;
                color: #e95720;
              }
            }
            &--effect {
              display: flex;
              flex-direction: column;
              margin-top: 16px;
              gap: 10px;
              .label {
                margin-bottom: 4px;
              }
            }
          }
        }
      }
      .scheme-handle {
        margin-top: 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
    }
  }
  .content-dialog {
    width: 700px !important;
  }
}
</style>
