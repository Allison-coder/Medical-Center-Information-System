<template>
  <el-dialog :visible="isShow" :before-close="handleClose" width="900px">
    <div class="treatment-dialog--content" id="print-box" v-if="data && data.treatmentPlan">
      <div class="print-header">
          <img class="banner" src="@/assets/header/logo2.png" alt="" />
          <div class="title">专用治疗单</div>
        <div class="patient">
          <div class="patient-msg patient-msg__name">患者姓名：{{ data.patientName }}</div>
          <div class="patient-msg patient-msg__gender">
            性别：{{ data.gender == 0 ? "女" : "男" }}
          </div>
          <div class="patient-msg patient-msg__age">
            年龄：{{
              (data.age == 0 || data.age == "null" || !data.age) ? '--' : data.age + "岁"
            }}
          </div>
          <div class="patient-msg patient-msg__patientSn">
            患者ID：{{ data?.patientSn || "-" }}
          </div>
          <div class="patient-msg patient-msg__planSn">
            治疗方案：{{ data?.planSn || "-" }}
          </div>
        </div>
      </div>
      
      <!-- <div class="print-title">治疗方案：{{ data?.planSn || "-" }}</div> -->
      <div class="print-main">
        <div>
          <el-table :data="data.treatmentPlan" highlight-current-row border>
            <el-table-column label="序号" width="150" align="center">
              <template slot-scope="scope">
                <span>第{{ scope.row.sortNum }}次</span>
              </template>
            </el-table-column>

            <el-table-column prop="projectNames" label="项目" align="center">
            </el-table-column>
            <el-table-column prop="totalPrice" label="单次总价" align="center">
              <template slot-scope="scope">
                <span>￥{{ scope.row.totalPrice }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="orderStatus" label="状态" align="center">
              <template slot-scope="scope">
                <span>{{ orderStatus2Str(scope.row.orderStatus) }}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div
          style="
            margin-top: 18px;
            margin-bottom: 5px;
            font-weight: 500;
            font-size: 18px;
            color: #333;
          "
        >
          <span style="font-size: 18px; font-weight: 600">医嘱：</span
          >{{ data?.advice || "-" }}
        </div>
        <div
          style="
            text-align: right;
            padding-right: 150px;
            font-weight: 500;
            font-size: 16px;
            margin-top: 20px;
            color: #333;
          "
        >
          <span style="font-size: 16px; font-weight: 600">医生签名：</span>

          <div class="doc_line"></div>
        </div>
      </div>
      <div class="pay-detail" v-if="type == 'pay'">
          <div class="image_box" v-if="qrImg">
            <img :src="qrImg" alt="" />
            <div class="QRcode">付款二维码</div>
          </div>
          <div class="desc">
            合计<span class='num'>
              {{ data.treatmentPlan.length }}
            </span>
            项,
            <span class='num'
              >￥{{ data.orderAmount }}</span
            >
            元
          </div>
      </div>
    </div>
    <div class="treatment-dialog--tip">
      <span>注：处方当日有效</span>
    </div>
    
    <div class="treatment-dialog--footer">
      <el-button
        size="medium"
        @click="handleClose"
        icon="el-icon-circle-close"
        >关闭</el-button
      >
      <el-button
        type="primary"
        size="medium"
        @click="handlePrint()"
        icon="el-icon-printer"
        >打印</el-button
      >
    </div>

  </el-dialog>
</template>

<script>
import html2canvas from "html2canvas";
export default {
  props: ["isShow", "data", "type"],

  data() {
    return {
      qrImg: "",
      payed: false,
    };
  },
  watch: {
    data(val) {
      if (this.type == 'check') return
      this.mergePay(val);
    },
  },
  methods: {
    orderStatus2Str(status) {
      let str = ''
      switch(status) {
        case 0:
          str = '待支付'
          break
        case 1:
          str = '已支付'
          break
        case 2:
          str = '已取消'
          break
        case 3:
          str = '退款中'
          break
        case 4:
          str = '已退款'
          break
        default:
          str = '未知'
      }
      return str
    },
    // 获取支付码
    async mergePay(data) {
      console.log("orderSn", data);
      // 旧版-单选
      // const orderNum = data.treatmentPlan[0].orderSn
      // const res = await this.$api.baseApis.WeiXinQrcodePay({
      //   paymentType: "WEIXIN_QRCODE_PAY",
      //   orderNum,
      //   subject: "medical_admin",
      // });
      // if (res.data.qrImg) {
      //   this.qrImg = res.data.qrImg;
      // }

      // 新版-多选
      const orderSns = data.treatmentPlan.map(plan => plan?.orderSn)
      const res = await this.$api.baseApis.mergePay({
        paymentType: "WEIXIN_QRCODE_PAY",
        orderSns,
        subject: "medical_admin",
      });
      this.qrImg = res?.data?.qrImg || '';
    },

    handleClose() {
      this.$emit("close");
    },
    handlePrint() {
      // 定义打印方法
      const dom = document.getElementById("print-box");
      html2canvas(dom, {
        scale: 2,
        width: dom?.offsetWidth,
        height: dom?.offsetHeight,
      }).then((canvas) => {
        const src64 = canvas.toDataURL();
        const contentWidth = canvas.width;
        const contentHeight = canvas.height;

        const imgWidth = 800; // 根据纸张宽度设定
        const imgHeight = (780 / contentWidth) * contentHeight;
        const img = new Image();
        const div = document.createElement("div");
        console.log(imgWidth, imgHeight, contentWidth, contentHeight, "data");
        div.appendChild(img);
        img.setAttribute("src", src64);
        img.setAttribute("width", imgWidth.toString());
        img.setAttribute("height", imgHeight.toString());
        img.setAttribute("id", "imgs");
        div.setAttribute("id", "printImg");
        img.onload = () => {
          var newWindow = window.open("参数医疗", "_blank");
          newWindow.document.write(div.innerHTML);
          newWindow.document.close();
          newWindow.focus();
          newWindow.print();
          newWindow.close();
        };
      });
    },
  },
};
</script>

<style scoped lang="less">
.treatment-dialog--content {
  margin: 0 auto;
  width: 800px;
  background-color: #fff;
  padding: 20px;
  // border: 1px solid #000;
  .print-header {
    .banner {
      display: block;
      width: 300px;
      margin: 20px auto 40px;
    }
    .title {
      margin-bottom: 10px;
      text-align: center;
      font-size: 38px;
      color: #333333;
      line-height: 60px;
      font-weight: 600;
    }
    .patient {
      display: flex;
      flex-wrap: wrap;
      border-bottom: 2px solid #eee;
      width: 100%;
      padding: 20px 0;
      font-size: 16px;

      .patient-msg {
        width: 33%;
        line-height: 35px;
        font-size: 16px;
        color: #323233;
      }
    }
  }
  // .print-title {
  //   font-size: 24px;
  //   font-weight: bold;
  //   color: #323233;
  //   margin-top: 24px;
  // }
  .print-main {
    // border-bottom: 2px solid #eee;
    margin-top:30px;
    padding-bottom: 57px;
    position: relative;

    .doc_line {
      position: absolute;
      bottom: 0;
      right: 0;
      height: 2px;
      width: 230px;
      background-color: #dcdee0;
    }
  }
  .pay-detail {
    display: flex;
    align-items: center;
    margin-top: 48px;
    .desc {
      margin-right: 50px;
      font-size: 18px;
      .num {
        color: red;
        font-weight: bold;
      }
    }
    .image_box {
      margin-right: 30px;
      img {
        display: block;
        width: 119px;
        height: 119px;
      }
    }
    .QRcode {
      font-size: 14px;
      width: 119px;
      text-align: center;
      color: #666;
      line-height: 30px;
    }
  }
  
  .cell * {
    color: #000 !important;
  }
  .cell {
    color: #000 !important;
  }
  ::v-deep(th.el-table__cell.is-leaf) {
    background-color: #e95720;
    color: #fff;
  }
}
.treatment-dialog--tip {
  text-align: center;
  color: #646566;
  font-size: 13px;
  margin-top: 36px;
}
.treatment-dialog--footer {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  margin-top: 40px;
}
</style>
