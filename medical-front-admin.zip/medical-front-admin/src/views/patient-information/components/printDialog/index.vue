<template>
  <div class="print-dialog__com">
    <el-dialog :visible="isShow" :before-close="handleClose">
      <div class="print-box" id="print-box">
        <div class="print-header" id="print-header">
          <img class="banner" src="@/assets/header/logo2.png" alt="" />
          <div class="title">{{ type == 'case' ? '病历资料' : '面诊记录' }}</div>
          <div class="patient">
            <div class="patient-msg patient-msg__name">
              患者姓名：{{ data.patientName }}
            </div>
            <div class="patient-msg patient-msg__id">
              患者ID：{{ data?.patientSn || "-" }}
            </div>
          </div>
        </div>
        
        <div class="print-content" id="print-content">
          <!-- 打印填充，详情查看watch -->
        </div>
      </div>
      <div class="print-btns">
        <el-button
          size="medium"
          @click="handleClose"
          icon="el-icon-circle-close"
          >关闭</el-button
        >
        <el-button
          type="primary"
          size="medium"
          @click="handlePrint"
          icon="el-icon-printer"
          >打印</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import html2canvas from "html2canvas";
import printJS from 'print-js'

function isSelectInput(input, fragment) {
  let isSelectInput = false
  const selects = fragment.querySelectorAll('.el-select')
  selects.forEach(select => {
    if (select.contains(input)) isSelectInput = true
  })
  return isSelectInput
}
function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = src;
    img.onload = () => resolve(src);
    img.onerror = () => reject(new Error(`Failed to load image at ${src}`));
  });
}
export default {
  props: ["isShow", "data", "type"],

  data() {
    return {};
  },

  watch: {
    // 将原文档中需要打印的内容填充到弹窗中
    isShow(val) {
      if (val) {
        this.$nextTick(() => {
          const printContent = document.getElementById("print-content");
          printContent.innerHTML = "";

          const fragment = document.createDocumentFragment();
          if (this.type == "case") {
            const patientBaseInfo = document
              .getElementById("patient-base-info")
              .cloneNode(true);
            const patientCaseInfo = document
              .getElementById("patient-case-info")
              .cloneNode(true);
            const patientDetailInfo = document
              .getElementById("patient-detail-info")
              .cloneNode(true);
            fragment.append(patientBaseInfo, patientCaseInfo, patientDetailInfo);

            // // 分页
            // const picBoxOut = fragment.querySelector('.pic_box_out')
            // const pageBreakDom = document.createElement('div')
            // pageBreakDom.classList.add('page-break');     
            // picBoxOut.insertAdjacentElement('afterend', pageBreakDom);
          } else {
            const patientRecordInfo = document
              .getElementById("patient-face-record")
              .cloneNode(true);
            fragment.append(patientRecordInfo);
          }
          
          // const testInput = fragment.querySelector('#test-input')
          // console.log('testInput', testInput, testInput.value)
          // testInput.value = 321

          // 处理input和textarea
          const inputs = fragment.querySelectorAll('.el-input__inner')
          inputs.forEach(input => {
            // 避免处理到el-select
            if (isSelectInput(input, fragment)) return
            // console.log('input', input)
            // console.log('input.value', input.value)
            input.value = input.value || '---'
            // input.parentNode.replaceChild(span, input)
          })

          // 处理input和textarea
          const textareas = fragment.querySelectorAll('textarea')
          textareas.forEach(textarea => {
            const div = document.createElement('div')
            div.textContent = textarea.value || '---'
            div.style.borderRadius = '4px'
            div.style.border = '1px solid #dcdfe6'
            div.style.padding = '5px 8px'
            textarea.parentNode.replaceChild(div, textarea)
          })

          // 处理箭头
          const icons = fragment.querySelectorAll('.el-input__suffix')
          icons.forEach(icon => {
            icon.remove()
          })

          // 按钮
          const btns = fragment.querySelectorAll('button')
          btns.forEach(btn => {
            btn.remove()
          })

          printContent.append(fragment);
        });
      }
    },
  },
  methods: {
    handleClose() {
      this.$emit("close");
    },
    
    async handleMulPrint(...domIds) {
      domIds.unshift('print-header')
      console.log('domIds', domIds)
      const printBox = document.getElementById("print-box");
      
      const imgPromises = domIds.map(async (id) => {
        const dom = printBox.querySelector(`#${id}`)
        return (
          await html2canvas(dom, {
            scale: 2,
            width: dom.offsetWidth,
            height: dom.offsetHeight
          })
        ).toDataURL("image/png");
      })

      const imagePromises = imgPromises.map(async (promise) => loadImage(await promise));
      Promise.all(imagePromises)
      .then(imgUrls => {
        console.log('imgUrls', imgUrls)
        const printWindow = window.open("参数医疗", "_blank");
        printWindow.document.write(`
          <!DOCTYPE html>
          <html lang="en">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>参数医疗</title>
              <style>
                  body {
                      padding: 0;
                      margin: 0;
                  }
                  img {
                    width: 100%;
                  }
                  // 用标签作为分页的判断
                  .page-break {
                      page-break-after: always;
                      margin-bottom: 20px; /* Ensure some space after the page break */
                  }

                  // 打印页面(纸张)的样式
                  @page {}
                  /* 打印样式 */
                  @media print {
                      body {
                          margin: 0;
                          padding: 0;
                      }
                  }
              </style>
          </head>
          <body>
              <img src="${imgUrls[0]}" />
              <img src="${imgUrls[1]}" />
              <img src="${imgUrls[2]}" />
              <div class="page-break"></div> 
              <img src="${imgUrls[3]}" />
          </body>
          </html>
        `)
        
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
      })
    },
    
    handleSinglePrint() {
      // 定义打印方法
      const printBox = document.getElementById("print-box");
      console.log("printBox?.offsetWidth", printBox?.offsetWidth);
      console.log("printBox?.offsetHeight", printBox?.offsetHeight);
      
      html2canvas(printBox, {
        scale: 2,
        width: printBox?.offsetWidth,
        height: printBox?.offsetHeight,
      }).then((canvas) => {
        const canvasBase64 = canvas.toDataURL("image/png");
        const imgDom = new Image();
        imgDom.src = canvasBase64;
        imgDom.style.width = "100%";
        // imgDom.style.width = '50px'
        const div = document.createElement("div");
        div.appendChild(imgDom);
        imgDom.onload = () => {
          var printWindow = window.open("参数医疗", "_blank");
          
          printWindow.document.write(div.innerHTML);
          const style = document.createElement("style");
          style.textContent = `
              body {
                padding: 0;
                margin: 0;
              }
              @media print {
                body {
                  padding: 0;
                  margin: 0;
                }
              }
              img {
                width: 100%;
              }
          `;
          printWindow.document.head.appendChild(style);
          printWindow.document.close();
          printWindow.focus();
          printWindow.print();
          printWindow.close();
        };
      });
    },
    
    handlePrint() {
      if (this.type == 'case') this.handleMulPrint('patient-base-info', 'patient-case-info', 'patient-detail-info')
      else this.handleSinglePrint()
    },

    // handlePrint() {
    //   const printContent = document.querySelector('#print-content');

    //   printJS({
    //     printable: 'print-box',
    //     type: 'html',
    //     targetStyles: ['*']
    //   })
    // }
  },
};
</script>

<style scoped lang="less">
/deep/ .page-break {
  page-break-after: always;
  margin-bottom: 20px;
}

@page {
  width: 1200px;
}
@media print {
  #print-box {
    width: 100%; /* 确保设置了打印宽度 */
    margin: 0 auto; /* 居中打印内容 */
    /* 添加其他样式以适应打印布局 */
  }
  #patient-case-info {
    margin: 8px;
  }
}
.print-dialog__com {
  .el-dialog__wrapper {
    /deep/.el-dialog {
      max-width: 1100px;
      width: fit-content;
    }
  }

  .print-box {
    margin: 0 auto;
    width: fit-content;
    background-color: #fff;
    padding: 20px;
    // border: 1px solid #000;
    .banner {
      display: block;
      width: 300px;
      margin: 20px auto 40px;
    }
    .title {
      margin-bottom: 10px;
      text-align: center;
      font-size: 38px;
      color: #333333;
      line-height: 60px;
      font-weight: 600;
    }
    .patient {
      display: flex;
      flex-wrap: wrap;
      border-bottom: 2px solid #eee;
      width: 100%;
      padding: 20px 0;
      font-size: 16px;
      color: #323233;
      .patient-msg {
        width: 50%;
      }
    }
    .print-content {
      padding-top: 30px;
      position: relative;
      min-width: 800px;
      &::after {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        content: "";
        background-color: black;
        opacity: 0;
        z-index: 1;
      }
      // /deep/ input {
      //   pointer-events: none!important;
      // }
      // /deep/ textarea {
      //   pointer-events: none!important;
      // }
    }
  }
  .print-btns {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 40px;
  }
}
</style>
