<template>
  <div class="patient-management">
    <!-- <div class="patient-management-head">人员管理</div> -->
    <div class="patient-management-body">
      <!-- 表格头 -->
      <div class="table-head">
        <!-- <div class="head-left">人员列表</div> -->
        <div class="head-right">
          <span style="color: #333333">人员名称</span>
          <el-input
            clearable
            v-model="getPeopleListParams.realName"
            placeholder="请输入人员名称"
            style="width: 180px; margin-right: 90px; margin-left: 20px"
          />
          <span>角色</span>
          <el-select
            style="width: 180px; margin-left: 20px; margin-right: 62px"
            placeholder="请选择角色"
            v-model="getPeopleListParams.roleId"
            clearable
          >
            <el-option
              v-for="item in roleList"
              :key="item.roleId"
              :label="item.name"
              :value="item.roleId"
            >
            </el-option>
          </el-select>

          <el-button type="primary" @click="doSearch" icon="el-icon-search"
            >搜索</el-button
          >
          <el-button type="success" @click="addDialog" icon="el-icon-plus"
            >新增账号</el-button
          >
        </div>
      </div>
      <div class="table-body">
        <el-table style="width: 100%" :data="peopleList" class="center-table">
          <el-table-column label="账号名称" align="center" prop="userName" />
          <el-table-column label="人员信息" align="center">
            <template #default="{ row }">
              <div style="display: flex; justify-content: space-around">
                <img
                  :src="row.avatarUrl"
                  v-if="row.avatarUrl"
                  alt=""
                  class="avatar"
                />
                <div v-else class="avatar"></div>
                <span class="name">{{ row.realName }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column label="工号" align="center" prop="employeeId" />
          <el-table-column label="角色" align="center" prop="role.name" />
          <el-table-column
            label="挂号数"
            align="center"
            prop="registrationCount"
            :formatter="formatRegistrationCount"
          />
          <el-table-column label="操作" width="180" align="center">
            <template #default="{ row }">
              <!-- 编辑按钮 -->
              <el-button
                @click="editCount(row)"
                size="medium"
                type="text"
                class="el-icon-edit-outline icon-wrapper"
                style="color: #8146ff; font-size: 22px"
              ></el-button>
              <!-- 人员信息按钮 -->
              <el-button
                @click="peopleInformationDialog(row)"
                size="medium"
                type="text"
                class="el-icon-user icon-wrapper"
                style="color: #8146ff; font-size: 22px"
              ></el-button>
              <!-- 删除按钮 -->
              <el-button
                size="medium"
                type="text"
                class="el-icon-delete icon-wrapper"
                style="color: #f26e6e; font-size: 22px"
                @click="deleteCount(row.adminId)"
              ></el-button>
            </template>
          </el-table-column>
          <el-table-column
            label="首页展示"
            align="center"
            prop="registrationCount"
          >
            <template #default="{ row }">
              <div
                class="show"
                v-if="row.homepageDisplaySwitch === 1"
                @click="whetherShow(row)"
              >
                已展示
              </div>
              <div
                class="hidden"
                v-if="row.homepageDisplaySwitch === 0"
                @click="whetherHide(row)"
              >
                隐藏
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!-- 分页器 -->
    <div class="page-container">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        :current-page="getPeopleListParams.pageNum"
        :page-size="getPeopleListParams.pageSize"
        @current-change="currentChange"
        background
      />
    </div>

    <!-- 新增账号dialog -->
    <el-dialog title="新增账号" :visible.sync="addDialogVisible" width="700px">
      <el-form
        :model="accountParams"
        class="addForm"
        ref="addForm"
        :rules="addRules"
        label-width="160px"
      >
        <el-form-item label="账号名称" prop="userName">
          <el-input
            v-model="accountParams.userName"
            placeholder="不能超过10位，只支持英文和数字"
          />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="accountParams.password"
            placeholder="密码长度至少6位，只支持英文和数字"
          />
        </el-form-item>
        <el-form-item label="工号" prop="employeeId">
          <el-input
            v-model="accountParams.employeeId"
            placeholder="支持1至10位的数字"
          />
        </el-form-item>
        <el-form-item
          label="挂号数(每半小时)"
          v-if="accountParams.roleId == 2"
          prop="registrationCount"
        >
          <el-input
            v-model="accountParams.registrationCount"
            placeholder="支持输入1至5"
          />
        </el-form-item>
        <el-form-item label="角色类型" prop="roleId">
          <el-radio-group v-model="accountParams.roleId">
            <el-radio
              v-for="item in roleList"
              :key="item.roleId"
              :label="item.roleId"
              >{{ item.name }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
      </el-form>
      <el-row slot="footer" type="flex" justify="center">
        <el-button
          size="medium"
          @click="addDialogVisible = false"
          icon="el-icon-back"
          >取消</el-button
        >
        <el-button
          size="medium"
          type="primary"
          @click="addAccount"
          icon="el-icon-folder"
          >保存</el-button
        >
      </el-row>
    </el-dialog>

    <!-- 编辑账号弹框 -->
    <el-dialog title="编辑账号" :visible.sync="editDialogVisible" width="45%">
      <el-form
        class="editForm"
        ref="editForm"
        :model="editParams"
        :rules="editRules"
        label-width="160px"
      >
        <el-form-item label="账号名称">
          <el-input disabled v-model="editParams.userName" />
        </el-form-item>
        <el-form-item label="密码" prop="password" autocomplete="off">
          <el-input
            v-model.trim="editParams.password"
            placeholder="密码长度至少6位，只支持英文和数字"
          />
        </el-form-item>
        <el-form-item label="工号" prop="employeeId">
          <el-input
            v-model.trim="editParams.employeeId"
            placeholder="支持1至10位的数字"
          />
        </el-form-item>
        <!-- 挂号(只对医生显示) -->
        <el-form-item
          label="挂号数(每半小时)"
          prop="registrationCount"
          v-if="editParams.roleId === 2"
        >
          <el-input
            v-model.trim="editParams.registrationCount"
            placeholder="只支持输入1至5"
          />
        </el-form-item>
      </el-form>
      <el-row slot="footer" type="flex" justify="center">
        <el-button
          size="medium"
          @click="editDialogVisible = false"
          icon="el-icon-back"
          >取消</el-button
        >
        <el-button
          size="medium"
          type="primary"
          @click="confirmEditCount"
          icon="el-icon-folder"
          >保存</el-button
        >
      </el-row>
    </el-dialog>

    <!-- 人员信息dialog -->
    <el-dialog
      title="人员信息"
      :visible.sync="peopleInformationDialogVisible"
      width="45%"
    >
      <el-form
        ref="informationForm"
        :model="peopleInformationParams"
        :rules="informationRules"
        label-width="120px"
      >
        <el-form-item>
          <el-upload
            class="avatar-uploader"
            action=""
            :show-file-list="false"
            :before-upload="beforeAvatarUpload"
            :on-change="upload"
          >
            <img
              v-if="peopleInformationParams.avatarUrl"
              :src="peopleInformationParams.avatarUrl"
              class="avatar"
            />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="姓名" prop="">
          <el-input
            v-model="peopleInformationParams.realName"
            style="width: 30%"
            placeholder="请输入姓名"
          />
        </el-form-item>
        <el-form-item label="性别" prop="">
          <el-select v-model="peopleInformationParams.sex" style="width: 16%">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="介绍" prop="">
          <el-input
            type="textarea"
            :rows="5"
            v-model="peopleInformationParams.introduction"
            class="content"
          />
        </el-form-item>
      </el-form>
      <el-row slot="footer" type="flex" justify="center">
        <el-button
          size="medium"
          @click="peopleInformationDialogVisible = false"
          icon="el-icon-back"
          >取消</el-button
        >
        <el-button
          size="medium"
          type="primary"
          @click="savePeopleInformation"
          icon="el-icon-folder"
          >保存</el-button
        >
      </el-row>
    </el-dialog>

    <!-- 删除二次确认dialog -->
    <el-dialog title="人员信息" width="45%" :visible.sync="deleteDialogVisible">
      <span>您确认删除当前账号吗？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirmDelete">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 是否展示dialog -->
    <el-dialog title="人员信息" width="45%" :visible.sync="whetherShowDialog">
      <span>您确认切换成隐藏状态吗？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="whetherShowDialog = false">取 消</el-button>
        <el-button type="primary" @click="confirmWhetherShow">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 首页展示dialog -->
    <el-dialog
      :visible.sync="whetherHideDialog"
      width="35%"
      title="确认首页展示位置"
      :center="true"
    >
      <div class="sort-body">
        <div class="sort" v-for="(homeItem, i) in homeShowList">
          <el-avatar class="head-img"
            ><img :src="homeItem.avatarUrl" alt="" srcset=""
          /></el-avatar>

          <div class="name">{{ homeItem.realName }}</div>
          <el-button
            @click="upOrder(homeItem)"
            circle
            class="up-order el-icon-caret-top"
            :disabled="homeItem.adminId !== activeAdminId"
          ></el-button>
          <el-button
            @click="buttomOrder(homeItem)"
            circle
            class="down-order el-icon-caret-bottom"
            :disabled="homeItem.adminId !== activeAdminId"
          ></el-button>
        </div>
      </div>

      <el-row slot="footer" type="flex" justify="center">
        <el-button
          size="medium"
          @click="whetherHideDialog = false"
          icon="el-icon-back"
          >取消</el-button
        >
        <el-button
          size="medium"
          type="primary"
          @click="confirmWhetherHide"
          icon="el-icon-folder"
          >确认</el-button
        >
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
import { last } from "lodash";
import Axios from "axios";
import { mapState } from "vuex";
export default {
  data() {
    // 忽略******密码的校验
    const validatePassword = (rule, value, callback) => {
      if (value === "******") {
        callback();
      } else {
        const regex = /^[A-Za-z0-9]{6,}$/;
        if (!regex.test(value)) {
          callback(new Error("密码至少6位，且只包含英文字符和数字"));
        } else {
          callback();
        }
      }
    };
    return {
      total: null,
      // 人员管理列表
      peopleList: [],
      getPeopleListParams: {
        pageNum: 1,
        pageSize: 10,
        realName: "",
        roleId: "",
      },
      // 人员角色-select
      roleList: [],
      orderStatusList: [
        {
          value: 0,
          label: "待支付",
        },
        {
          value: 1,
          label: "已支付",
        },
        {
          value: 2,
          label: "已取消",
        },
        {
          value: 3,
          label: "退款中",
        },
        {
          value: 4,
          label: "已退款",
        },
      ],
      addDialogVisible: false,
      // 新增、删除 账号-params
      accountParams: {
        employeeId: "",
        password: "",
        registrationCount: null,
        roleId: null,
        userName: "",
        adminId: null,
      },
      // 新增账号-rules
      addRules: {
        userName: [
          { required: true, message: "请输入账号名称", trigger: "blur" },
          {
            pattern: /^[A-Za-z0-9]+$/,
            message: "请输入英文和数字",
          },
          {
            required: true,
            min: 1,
            max: 10,
            message: "账号名称不超过10位",
            trigger: "blur",
          },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          {
            required: true,
            pattern: /^[\da-zA-Z]{6,}$/,
            message: "密码至少6位，且只包含英文字符和数字",
            trigger: "blur",
          },
        ],
        employeeId: [
          { required: true, message: "请输入工号", trigger: "blur" },
          {
            required: true,
            pattern: /^\d{1,10}$/,
            message: "只支持1至10位的数字",
            trigger: "blur",
          },
        ],
        registrationCount: [
          { required: true, message: "请输入挂号数", trigger: "blur" },
          {
            required: true,
            pattern: /^(1|2|3|4|5)$/,
            message: "只支持输入1至5",
            trigger: "blur",
          },
        ],
        roleId: [
          { required: true, message: "请选择恰当角色", trigger: "change" },
        ],
      },
      // 人员信息-dialog
      peopleInformationDialogVisible: false,
      // 删除按钮-dialog
      deleteDialogVisible: false,
      // 人员信息-params
      peopleInformationParams: {
        realName: "",
        adminId: null,
        fileKey: "",
        introduction: "",
        sex: null,
        avatarUrl: "",
        homepageDisplaySwitch: 0,
        // 首页展示，第一一个人的排名
        firstRank: null,
      },
      // 人员信息-rules
      informationRules: {
        realName: [
          { required: true, message: "请输入姓名", trigger: "blur" },
          {
            required: true,
            min: 1,
            max: 5,
            message: "姓名不超过5位汉字",
            trigger: "blur",
          },
        ],
        introduction: [
          { required: true, message: "请填写介绍信息", trigger: "blur" },
        ],
      },
      // 性别
      options: [
        { value: 0, label: "女" },
        { value: 1, label: "男" },
      ],
      editDialogVisible: false,
      // 编辑账号-params
      editParams: {
        employeeId: "",
        registrationCount: null,
        userName: "",
        password: "******",
        adminId: null,
        roleId: "",
      },
      // 编辑账号-rules
      editRules: {
        userName: [
          { required: true, message: "请输入账号名称", trigger: "blur" },
          {
            required: true,
            min: 1,
            max: 7,
            message: "账号名称不超过7位汉字",
            trigger: "blur",
          },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { validator: validatePassword, trigger: "blur" },
        ],
        employeeId: [
          { required: true, message: "请输入工号", trigger: "blur" },
          {
            required: true,
            pattern: /^\d{1,10}$/,
            message: "只支持1至10位的数字",
            trigger: "blur",
          },
        ],
        registrationCount: [
          { required: true, message: "请输入挂号数", trigger: "blur" },
          {
            required: true,
            pattern: /^(1|2|3|4|5)$/,
            message: "只支持输入1至5",
            trigger: "blur",
          },
        ],
      },
      // 点击已展示-dialog
      whetherShowDialog: false,
      // 点击隐藏-dialog
      whetherHideDialog: false,
      // 首页展示列表
      homeShowList: [],
      // 对医生排序当前id
      activeAdminId: null,
    };
  },
  computed: {
    ...mapState({
      equipment: (state) => state.equipment,
    }),
  },
  created() {
    if (this.equipment == "pad") {
      this.getPeopleListParams.pageSize = 6;
    } else {
      this.getPeopleListParams.pageSize = 9;
    }

    // 获取人员管理列表
    this.getPeopleList();
    // 获取角色列表
    this.getRoleList();
  },
  methods: {
    // 获取人员列表
    async getPeopleList() {
      const { data } = await this.$api.baseApis.getPeopleList(
        this.getPeopleListParams
      );
      this.peopleList = data.list;
      this.total = data.total;
    },
    // 获取用户所有角色
    async getRoleList() {
      const { data } = await this.$api.baseApis.getRoleLists();
      this.roleList = data;
    },
    // 搜索
    doSearch() {
      this.getPeopleListParams.pageNum = 1;
      this.getPeopleList();
    },
    // format挂号数
    formatRegistrationCount(row) {
      if (row.registrationCount) {
        return row.registrationCount;
      } else {
        return "--";
      }
    },
    // 切换页面
    currentChange(page) {
      this.getPeopleListParams.pageNum = page;
      this.getPeopleList();
    },
    // 编辑账号-dialog
    editCount(row) {
      // 每次点击进来，密码重新设置成******
      this.editParams.password = "******";
      this.editDialogVisible = true;
      this.editParams.userName = row.userName;
      this.editParams.employeeId = row.employeeId;
      this.editParams.registrationCount = row.registrationCount;
      this.editParams.adminId = row.adminId;
      // 用角色id区分编辑栏item
      this.editParams.roleId = row.role.roleId;
    },
    // 编辑账号-confirm
    confirmEditCount() {
      this.$refs.editForm.validate(async (valid) => {
        if (valid) {
          if (this.editParams?.password !== "******") {
            // 当修改密码了
            await this.$api.baseApis.editAccount({
              password: this.editParams.password,
              adminId: this.editParams.adminId,
              employeeId: this.editParams.employeeId,
              registrationCount: this.editParams.registrationCount,
            });
            console.log("修改密码了");
            this.$message.success("编辑账号成功");
            this.editDialogVisible = false;
            this.getPeopleList();
          } else {
            // 没有修改密码
            const { adminId, employeeId, registrationCount } = this.editParams;
            await this.$api.baseApis.editAccount({
              adminId,
              employeeId,
              password: null,
              registrationCount,
            });
            this.$message.success("编辑账号成功");
            this.editDialogVisible = false;
            this.getPeopleList();
            console.log("没有修改密码");
          }
        }
      });
    },
    // 新增账号-dialog
    addDialog() {
      this.addDialogVisible = true;
      this.accountParams = {};
    },
    // 新增账号账号
    addAccount() {
      this.$refs.addForm.validate(async (valid) => {
        if (valid) {
          // 调用新增账号接口
          const res = await this.$api.baseApis.addAccount(this.accountParams);
          this.$message.success("添加账号成功");
          this.addDialogVisible = false;
          this.getPeopleList();
        } else {
          this.$message.warning("请填写完整表单");
        }
      });
    },
    // 人员信息-dialog
    peopleInformationDialog(row) {
      this.peopleInformationDialogVisible = true;
      this.peopleInformationParams.adminId = row.adminId;
      this.peopleInformationParams.realName = row.realName;
      this.peopleInformationParams.sex = row.sex;
      this.peopleInformationParams.avatarUrl = row.avatarUrl;
      this.peopleInformationParams.introduction = row.introduction;
    },
    // 图片上传前校验
    beforeAvatarUpload(file) {
      const allowImgType = ["image/jpeg", "image/png", "image/jpg"].includes(
        file.type
      );
      const isLt5M = file.size / 1024 / 1024 < 5;
      if (!allowImgType) {
        this.$message.error("上传图片只能是 PNG/JPG/JPEG 格式!");
      }
      if (!isLt5M) {
        this.$message.error("上传图片大小不能超过 5MB!");
      }
      return allowImgType && isLt5M;
    },
    // 图片自定义上传
    async upload(file) {
      console.log("file.raw", file.raw);
      const { data } = await this.$api.baseApis.uploadFile();

      const formData = new FormData();
      formData.append("OSSAccessKeyId", data.accessid);
      formData.append("policy", data.policy);
      formData.append("Signature", data.signature);
      formData.append("key", data.key);
      formData.append("file", file.raw);
      formData.append("x-oss-content-type", file.raw.type);

      const response = await Axios.post(data.accessHost, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      if (response.status >= 200 && response.status < 300) {
        // 成功

        this.peopleInformationParams.avatarUrl =
          data.accessHost + "/" + data.key;

        this.peopleInformationParams.fileKey = data.key;
      } else {
        throw response;
      }
    },
    // confirm-保存人员信息
    async savePeopleInformation() {
      this.$refs.informationForm.validate(async (valid) => {
        if (valid) {
          const { data } = await this.$api.baseApis.savePeopleInformation(
            this.peopleInformationParams
          );
          console.log(data);
          this.$message.success("保存人员信息成功");
          this.peopleInformationDialogVisible = false;
          this.getPeopleList();
        } else {
          this.$message.fail("保存人员信息失败");
        }
      });
    },
    // 删除账号-dialog
    async deleteCount(adminId) {
      this.deleteDialogVisible = true;
      this.accountParams.adminId = adminId;
    },
    // 确认删除
    async confirmDelete() {
      await this.$api.baseApis.deleteAccount(this.accountParams.adminId);
      this.$message.success("删除当前账号成功");
      this.deleteDialogVisible = false;
      this.getPeopleList();
    },
    // 是否展示
    whetherShow(row) {
      this.whetherShowDialog = true;
      this.peopleInformationParams.adminId = row.adminId;
      this.peopleInformationParams.homepageDisplaySwitch =
        row.homepageDisplaySwitch;
    },
    // confirm-点击已展示
    async confirmWhetherShow() {
      await this.$api.baseApis.isHomeShow({
        adminId: this.peopleInformationParams.adminId,
        homepageDisplaySwitch: 0,
      });
      this.$message.success("首页成功切换成隐藏状态");
      this.whetherShowDialog = false;
      this.getPeopleList();
    },

    //是否隐藏
    async whetherHide(row) {
      console.log("点击隐藏");
      this.peopleInformationParams.adminId = row.adminId;
      const { data } = await this.$api.baseApis.getHomeShowList(
        this.peopleInformationParams.adminId
      );
      this.homeShowList = data;
      this.activeAdminId = row.adminId;

      // 记录并且返回首页展示第一一项的排序号
      this.firstRank = data[0].homepageDisplaySort;
      this.whetherHideDialog = true;
    },
    // confirm-点击隐藏
    async confirmWhetherHide() {
      await this.$api.baseApis.saveHomeShow(this.homeShowList);
      this.whetherHideDialog = false;
      this.$message.success("更改首页成功了");
      let _this = this;
      setTimeout(() => {
        _this.getPeopleList();
      }, 500);
    },

    upOrder(item) {
      let index = this.homeShowList.indexOf(item);
      if (index === 0) {
        this.$message.warning("已经是第一项了");
        return;
      }
      if (index > 0) {
        let newArr = JSON.parse(JSON.stringify(this.homeShowList));
        let newArr2 = JSON.parse(JSON.stringify(this.homeShowList));
        let arr1 = newArr[index];
        let arr2 = newArr2[index - 1];
        arr1.homepageDisplaySort = newArr[index - 1].homepageDisplaySort;
        arr2.homepageDisplaySort = newArr2[index].homepageDisplaySort;
        this.homeShowList[index] = arr2;
        this.homeShowList[index - 1] = arr1;
        this.$set(this.homeShowList, index, arr2);
        this.$set(this.homeShowList, index - 1, arr1);
      }
    },
    buttomOrder(item) {
      let index = this.homeShowList.indexOf(item);

      if (index === this.homeShowList.length - 1) {
        this.$message.warning("已经是最后项了");
        return;
      }
      if (index >= 0 && index < this.homeShowList.length - 1) {
        let newArr = JSON.parse(JSON.stringify(this.homeShowList));
        let newArr2 = JSON.parse(JSON.stringify(this.homeShowList));
        let arr1 = newArr[index];
        let arr2 = newArr2[index + 1];
        arr1.homepageDisplaySort = newArr[index + 1].homepageDisplaySort;
        arr2.homepageDisplaySort = newArr2[index].homepageDisplaySort;
        this.homeShowList[index] = arr2;
        this.homeShowList[index + 1] = arr1;
        this.$set(this.homeShowList, index, arr2);
        this.$set(this.homeShowList, index + 1, arr1);
      }
    },
  },
};
</script>

<style scoped lang="less">
.patient-management {
  width: 100%;
  // padding-left: 15px;
  // padding-right: 15px;
  height: 785px;
  box-sizing: border-box;
  // .patient-management-head {
  //   font-size: 25px;
  //   font-weight: 500;
  //   color: #191635;
  //   box-sizing: border-box;
  // }
  .patient-management-body {
    box-sizing: border-box;
    border-radius: 14px;
    height: 775px;
    .table-head {
      width: 100%;
      background-color: #fff;
      display: flex;
      margin-bottom: 20px;

      // padding-left: 20px;
      box-sizing: border-box;
      .head-left {
        margin-right: 41px;
        box-sizing: border-box;
        font-size: 18px;
        font-weight: 500;
        line-height: 80px;
        color: #191635;
      }
      .head-right {
        width: 90%;
        display: flex;
        align-items: center;
        .search-btn {
          cursor: pointer;
          text-align: center;
          width: 90px;
          height: 32px;
          border-radius: 2px;
          background: #ffffff;
          font-size: 14px;
          line-height: 32px;
          color: #169bd5;
          border: 1px solid #169bd5;
          border-radius: 5px;
          transition: transform 0.2s;
        }
        .search-btn:hover {
          transform: scale(1.1);
        }
        .add-btn {
          margin-right: 10px;
          margin-left: 120px;
          cursor: pointer;
          text-align: center;
          width: 113px;
          height: 40px;
          border-radius: 6px;
          background: #8146ff;
          font-size: 14px;
          line-height: 40px;
          color: #ffffff;
          transition: transform 0.2s;
        }
        .add-btn:hover {
          transform: scale(1.1);
        }
      }
    }
    .table-body {
      box-sizing: border-box;
      height: 690px;
      overflow: auto;
      .avatar {
        width: 40px;
        height: 40px;
        border-radius: 5px;
      }
      .name {
        line-height: 40px;
      }
      // 首页展示条
      .show {
        background-color: #c7edcc;
        width: 70px;
        height: 35px;
        border-radius: 6px;
        line-height: 35px;
        color: #56c456;
        display: inline-block;
        cursor: pointer;
        transition: transform 0.3s;
      }
      .show:hover {
        transform: scale(1.2);
        border-radius: 8px;
      }
      .hidden {
        background-color: #ffc0cb;
        width: 70px;
        height: 35px;
        border-radius: 6px;
        line-height: 35px;
        color: #f26e6e;
        display: inline-block;
        cursor: pointer;
        transition: transform 0.3s;
      }
      .hidden:hover {
        transform: scale(1.2);
        border-radius: 8px;
      }
    }
  }
  // 分页器
  .page-container {
    text-align: right;
    margin-right: -10px;
  }
}

.addForm,
.editForm {
  padding-left: 26px;
  padding-right: 80px;
}

.content {
  border-radius: 5px;
  width: 90%;
  border: 1px solid #dddddd;
}

// 头像
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 113px;
  height: 108px;
  line-height: 108px;
  text-align: center;
  border-radius: 2px;
  border: 1px solid #f9f9f9;
  box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.0999);
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
.sort-body {
  // height: 555px;
  border-radius: 10px;
  background: #ffffff;

  overflow-y: auto;
  overflow-x: hidden;
}
// table表头的颜色
::v-deep(.center-table th) {
  background: #f7f8fa;
}
// 操作-按钮放大样式
::v-deep(.icon-wrapper) {
  transition: transform 0.2s;
}
::v-deep(.icon-wrapper:hover) {
  transform: scale(1.2);
}

// 首页展示列表title样式
::v-deep(.el-dialog__title) {
  color: #000000;
  font-size: 18px;
  font-weight: 500;
}

::v-deep(.el-dialog) {
  border-radius: 10px;
}

.sort {
  width: 100%;
  // background-color: pink;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #dddddd;
  justify-content: space-evenly;
  .head-img {
    img {
      width: 100%;
      height: 100%;
      display: block;
      border-radius: 50%;
      margin: 0 auto;
    }
  }
  .name {
    width: 140px;
    height: 35px;
    line-height: 35px;
    // background-color: yellow;
    font-size: 14px;
    color: #333333;
  }
  .up-order,
  .down-order {
    height: 22px;
    width: 22px;
    font-size: 21px;
    font-weight: bold;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
// 平板适配
@media screen and (max-width: 1300px) {
  .patient-management-body {
    box-sizing: border-box;
    overflow-y: auto;
    height: 580px !important;
    overflow: auto;
  }
  .table-body {
    box-sizing: border-box;
    height: auto !important;
    overflow: auto;
  }
}
</style>
