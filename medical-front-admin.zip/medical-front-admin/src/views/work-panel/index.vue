<template>
  <div class="patient-management">
    <!-- 左边中文时间 -->
    <div class="chinese-time">
      <div class="el-icon-back" @click="dayDistanceFn('sub')"></div>
      <div class="content">{{ dayStrLong }}</div>
      <div class="el-icon-right" @click="dayDistanceFn('add')"></div>

      <div class="date_box" style="display: inline-block; position: relative">
        <label
          for="dateId"
          style="
            margin-right: 20px;
            position: absolute;
            left: 32px;
            top: 11px;
            z-index: 999;
            cursor: pointer;
          "
        >
          <i style="font-size: 18px" class="el-icon-date"></i
        ></label>

        <el-date-picker
          style="pointer-events: none"
          id="dateId"
          :clearable="false"
          v-model="patientScheduleParams.dataStr"
          type="date"
          @change="dateChange($event)"
          placeholder="选择日期"
          value-format="yyyy-MM-dd"
        >
        </el-date-picker>
      </div>
    </div>
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="挂号预约" name="first">
        <div style="width: 100%" v-if="noData">
          <img
            src="@/assets/yuyue_ico.png"
            style="display: block; margin: 50px auto"
            alt=""
          />
          <div style="margin: 50px atuo; text-align: center; color: #666">
            暂无记录
          </div>
        </div>
        <div v-else style="overflow-x: auto; width: 100%">
          <table class="my_table">
            <thead>
              <tr>
                <th style="font-size: 20px">医生</th>

                <th v-for="(item, i) in docObj" :key="i">
                  <div class="GuaHao_line">挂号人数: {{ item.allNum }}</div>
                  <div class="YiSheng_line">{{ item.name }}</div>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, i) in newArr" :key="i">
                <td>
                  <div class="time_line">{{ item.scheduleDataTime }}</div>
                </td>
                <td v-for="(son, j) in item.adminList" :key="j">
                  <div class="cell_box" v-if="son.patientList">
                    <div v-if="son.patientList.length == 0">
                      <div
                        class="cell_box_in"
                        style="cursor: default"
                        v-for="(son2, n) in son.registrationCount"
                        :key="n"
                      >
                        <div class="cell_box_in_title">空闲</div>
                        <div class="cell_box_in_text _color_warning">
                          待预约
                        </div>
                      </div>
                    </div>
                    <div v-if="son.patientList.length > 0">
                      <div
                        class="cell_box_in"
                        v-for="(pat, k) in son.patientList"
                        :key="k"
                        @click="
                          goPatientInformation(pat.patientSn, pat.orderSn)
                        "
                      >
                        <div class="cell_box_in_title" style="cursor: pointer">
                          {{ pat.name }}
                        </div>
                        <div
                          style="cursor: pointer"
                          class="cell_box_in_text"
                          :class="
                            pat.taskStatus === 1
                              ? '_color_error'
                              : pat.taskStatus === 2
                              ? '_color_warning'
                              : pat.taskStatus === 6
                              ? '_color_grey'
                              : '_color_success'
                          "
                        >
                          {{ formatState(pat) }}
                        </div>
                      </div>
                      <div
                        class="cell_box_in"
                        style="cursor: default"
                        v-for="(son2, n) in son.registrationCount -
                          son.patientList.length >=
                        0
                          ? son.registrationCount - son.patientList.length
                          : 0"
                        :key="n"
                      >
                        <div class="cell_box_in_title">空闲</div>
                        <div class="cell_box_in_text _color_warning">
                          待预约
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </el-tab-pane>
      <el-tab-pane label="治疗预约" name="second">
        <div style="width: 100%" v-if="noData">
          <img
            src="@/assets/yuyue_ico.png"
            style="display: block; margin: 50px auto"
            alt=""
          />
          <div style="margin: 50px atuo; text-align: center; color: #666">
            暂无记录
          </div>
        </div>

        <div v-else style="overflow-x: auto; width: 100%">
          <table class="my_table">
            <thead>
              <tr>
                <th style="font-size: 20px">康复师</th>

                <th v-for="(item, i) in docObj" :key="i">
                  <div class="YiSheng_line">{{ item.name }}</div>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, i) in newArr" :key="i">
                <td>
                  <div class="time_line">
                    {{ item.startTime + "-" + item.endTime }}
                  </div>
                </td>
                <td v-for="(son, j) in item.adminList" :key="j">
                  <div class="cell_box" v-if="son.patientList">
                    <div
                      class="cell_box_in"
                      v-if="son.patientList.length == 0"
                      style="cursor: default"
                    >
                      <div class="cell_box_in_title">空闲</div>
                      <div class="cell_box_in_text _color_warning">待预约</div>
                    </div>
                    <div v-if="son.patientList.length > 0">
                      <div
                        class="cell_box_in"
                        v-for="(pat, k) in son.patientList"
                        :key="k"
                        @click="
                          goPatientInformation(pat.patientSn, pat.orderSn)
                        "
                      >
                        <div class="cell_box_in_title" style="cursor: pointer">
                          {{ pat.name }}
                        </div>
                        <!--<div-->
                        <!--  style="cursor: pointer"-->
                        <!--  class="cell_box_in_text _color_success"-->
                        <!--&gt;-->
                        <!--  已预约-->
                        <!--</div>-->
                        <div
                          style="cursor: pointer"
                          class="cell_box_in_text"
                          :class="
                            pat.taskStatus === 1
                              ? '_color_error'
                              : pat.taskStatus === 2
                              ? '_color_warning'
                              : pat.taskStatus === 6
                              ? '_color_grey'
                              : '_color_success'
                          "
                        >
                          {{ formatState(pat) }}
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import dayjs from "dayjs";
export default {
  data() {
    return {
      noData: false,
      todayStr: "",
      //当前时间相距的天数
      dayDistance: 0,
      dayStrLong: "",
      // 当前选的日期
      dataStr: "",

      // 患者预约列表-params
      patientScheduleParams: {
        dataStr: "",
        type: 1,
      },
      newArr: [],
      docObj: [],
      // 某时间段内预约患者-list
      appointmentList: [],
      // 时间
      time_slot: [],
      // 医生名字
      // doctorNames: [],

      activeName: "first",
      // isShow: true,
      date: "",
      pickerOptions: {
        // 配置选项，例如禁用日期
      },
      calendar: "",
    };
  },
  created() {
    this.todayStr = dayjs().format("YYYY-MM-DD");
    this.docObj = this.transformData(this.appointmentList);
    //初始化
    this.pageInit();
  },
  methods: {
    pageInit() {
      this.patientScheduleParams.dataStr = this.getAddDay(this.dayDistance);
      this.dataStr = this.patientScheduleParams.dataStr;
      this.dayStrLong = this.getDayLong(this.patientScheduleParams.dataStr);
      //  重新获取数据
      this.getPatientSchedule(
        this.patientScheduleParams.dataStr,
        this.patientScheduleParams.type
      );
    },
    // 生成表头
    transformData(arr) {
      const result = [];
      arr.forEach((data) => {
        data.adminList.forEach((admin) => {
          let allNum = admin.scheduleNum || 0;
          if (!result.find((item) => item.adminId === admin.adminId)) {
            result.push({ name: admin.name, adminId: admin.adminId, allNum });
          } else {
            // 如果存在同名同ID的管理员，更新其allNum
            result.find((item) => item.adminId === admin.adminId).allNum +=
              allNum;
          }
        });
      });
      return result;
    },
    // 生成需要的数据
    transformNeedData(arr) {
      let newArr = [];
      for (let i = 0; i < arr.length; i++) {
        newArr[i] = {
          scheduleDataTime: arr[i].scheduleDataTime,
        };
        if (arr[i].startTime) {
          newArr[i].startTime = arr[i].startTime;
        }
        if (arr[i].endTime) {
          newArr[i].endTime = arr[i].endTime;
        }

        newArr[i].adminList = [];
        for (let j = 0; j < this.docObj.length; j++) {
          newArr[i].adminList[j] = {
            adminId: this.docObj[j].adminId,
            name: this.docObj[j].name,
          };
          for (let k = 0; k < arr[i].adminList.length; k++) {
            if (arr[i].adminList[k].adminId == this.docObj[j].adminId) {
              newArr[i].adminList[j].patientList =
                arr[i].adminList[k].patientList;
              newArr[i].adminList[j].registrationCount =
                arr[i].adminList[k].registrationCount;
            }
          }
        }
      }
      return newArr;
    },
    // 获取患者预约时间
    async getPatientSchedule(dataStr, type) {
      const { data } = await this.$api.baseApis.getPatientSchedule({
        dataStr,
        type,
      });
      this.appointmentList = data;
      this.docObj = this.transformData(this.appointmentList);
      if (this.docObj.length == 0) {
        this.noData = true;
      }
      if (this.docObj.length > 0) {
        this.noData = false;
      }
      this.newArr = this.transformNeedData(this.appointmentList);
    },
    handleClick(tab) {
      if (tab.index == 0) {
        this.patientScheduleParams.type = 1;
      }
      if (tab.index == 1) {
        this.patientScheduleParams.type = 2;
      }
      //初始化
      this.pageInit();
    },
    // 日期
    dateChange(date) {
      this.patientScheduleParams.dataStr = date;

      const date1 = dayjs(date);
      const date2 = dayjs(this.todayStr);
      // 计算两个日期之间相差的天数
      this.dayDistance = date1.diff(date2, "day");
      this.pageInit();
    },
    dayDistanceFn(str) {
      if (str == "add") {
        this.dayDistance++;
      }
      if (str == "sub") {
        this.dayDistance--;
      }
      this.pageInit();
    },
    // 获取距离当前n天的日期
    getAddDay(num) {
      const today = dayjs();
      const date = today.add(num, "day").format("YYYY-MM-DD");
      return date;
    },
    // 根据日期返回年月日星期
    getDayLong(date) {
      const weekList = ["日", "一", "二", "三", "四", "五", "六"];
      let dayjsObj;
      if (date) {
        dayjsObj = dayjs(date);
      } else {
        dayjsObj = dayjs();
      }

      let dateLong =
        dayjsObj.format("YYYY-MM-DD") +
        ", " +
        "星期" +
        weekList[dayjsObj.day()];
      return dateLong;
    },
    // 跳转-患者资料
    goPatientInformation(patientSn, orderSn) {
      this.$router.push({
        name: "patientInformation",
        query: {
          patientSn: patientSn,
          orderSn: orderSn,
        },
      });
    },
    // 性别格式-转化
    formatState(pat) {
      let MAP;
      if (this.patientScheduleParams.type == 1) {
        MAP = {
          0: "待支付",
          1: "待支付",
          2: "待预约",
          3: "待报到",
          4: "候诊中",
          5: "面诊中",
          6: "已完成",
        };
      }
      if (this.patientScheduleParams.type == 2) {
        MAP = {
          0: "待支付",
          1: "待支付",
          2: "待预约",
          3: "待报到",
          4: "等候治疗",
          5: "开始时间：" + this.getDynamicValue(pat),
          6: "完成治疗",
        };
      }
      return MAP[pat.taskStatus];
    },
    getDynamicValue(pat) {
      console.log(pat.startTime);
      return pat.startTime;
    },
  },
};
</script>

<style scoped lang="less">
.my_table {
  border-collapse: collapse;
  border-spacing: 0;
  td,
  th {
    border: 1px solid #d1d1d1;
  }
  .time_line {
    text-align: center;
    width: 100px;
    line-height: 30px;
    font-size: 14px;
    color: #333;
    font-weight: 400;
  }

  .GuaHao_line {
    text-align: center;
    width: 160px;
    line-height: 30px;
    font-size: 14px;
    color: #333;
    font-weight: 400;
    border-bottom: 1px solid #d1d1d1;
    background: #f9f9f9;
  }
  .YiSheng_line {
    text-align: center;
    width: 160px;
    line-height: 50px;
    font-size: 20px;
    color: #333;
    background: #f9f9f9;
  }
  .cell_box {
    width: 100%;
    min-height: 50px;
    box-sizing: border-box;
    // background-color: red;
    padding: 0 6px;
    .cell_box_in {
      width: 100%;
      height: 50px;
      box-sizing: border-box;
      background-color: #eaf1fd;
      border-radius: 3px;
      margin-top: 6px;
      margin-bottom: 6px;
      text-align: center;
      padding: 6px 0;
      .cell_box_in_title {
        line-height: 26px;
        font-size: 16px;
        color: #333;
      }
      .cell_box_in_text {
        line-height: 12px;
        font-size: 12px;
        color: #666;
      }
    }
  }
}

.chinese-time {
  align-items: center;
  display: flex;
  width: 450px;
  height: 28px;
  margin-bottom: 15px;
  .el-icon-back {
    cursor: pointer;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
  .content {
    text-align: center;
    width: 199px;
    height: 25px;
    line-height: 28px;
  }
  .el-icon-right {
    cursor: pointer;
    margin-right: 10px;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
}

.hide_input {
  position: relative !important;
  background-color: transparent;
  height: 30px;
}
//修改控件自带的css
.hide_input .el-date-editor {
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0; //设置完全透明
  width: 30px;
  height: 30px;
}

._color_success {
  color: #1f8379 !important;
}
._color_warning {
  color: #fed191 !important;
}
._color_error {
  color: red !important;
}
._color_grey {
  color: #969799 !important;
}

::v-deep(.date_box .el-input--prefix .el-input__inner) {
  opacity: 0;
  width: 0 !important;
}
::v-deep(.date_box .el-input__prefix) {
  opacity: 0;
  width: 0 !important;
}
</style>

<style lang="less">
.date_box .el-picker-panel {
  left: 435px !important;
}
</style>
