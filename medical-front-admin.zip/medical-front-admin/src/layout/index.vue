<template>
  <el-container>
    <el-header class="my-header">
      <img src="@/assets/header/logo.png" class="logo" alt="" srcset="" />
      <div class="right-view">
        <div class="user-info">
          <div class="user-name">
            <span v-if="authInfo?.user?.nickname">
              <i style="font-size: 18px" class="el-icon-user-solid"></i>
              {{ authInfo.user.nickname }}</span
            >
            <!-- <span v-if="authInfo && authInfo.user.mobile"
              >({{ authInfo.user.mobile }})</span
            > -->
          </div>
          <!-- <div
            class="edit-pwd pointer"
            @click="showPasswordDialog = true"
            style="margin-right: 20px"
          >
            <i style="font-size: 18px" class="el-icon-lock"></i>
            修改密码
          </div> -->
          <div class="login-out pointer" @click="loginOut">
            <i style="font-size: 18px" class="el-icon-sort"></i> 退出登录
          </div>
        </div>
      </div>
    </el-header>
    <el-container class="content-box">
      <!-- 左边路由菜单 -->
      <el-aside class="xs-aside">
        <Menu></Menu>
      </el-aside>
      <!-- 右边显示区域 -->
      <el-main style="background-color: #f8f8f8">
        <!-- <breadcrumb-item></breadcrumb-item> -->
        <!-- 二级路由 -->
        <router-view />
      </el-main>
    </el-container>

    <changePassword
      :show="showPasswordDialog"
      @close="showPasswordDialog = false"
    />
  </el-container>
</template>

<script>
import Menu from "@/components/menu.vue";
import { mapState } from "vuex";
import BreadcrumbItem from "@/components/breadcrumb-item.vue";
import changePassword from "@/components/change-password.vue";
import Watermark from "@/assets/watermark";
export default {
  components: { Menu, BreadcrumbItem, changePassword },
  data() {
    return {
      showPasswordDialog: false,
    };
  },
  computed: {
    ...mapState({
      authInfo: (state) => state.authInfo,
    }),
  },
  created() {
    let _this = this;
    // 水印
    setTimeout(() => {
      Watermark.set(_this.authInfo?.user?.nickname);
    }, 500);
  },
  methods: {
    async loginOut() {
      await this.$api.baseApis.logout();
      this.$store.commit("CLEAR_AUTH_INFO", {});
      Watermark.set("");

      this.$router.push("/login");
      this.$message.success("成功退出登录");
    },
  },
};
</script>

<style lang="less" scoped>
@import url("@/style/variable.less");

.el-aside {
  width: 200px !important;
  height: 100%;
  overflow-y: auto;
  background-color: #fff;
}
.content-box {
  height: ~"calc(100vh - @{headerHeight})";
}
.logo {
  display: block;
  width: 150px;
  height: 40px;
  margin-top: 10px;
  margin-left: 30px;

  box-sizing: border-box;
}
.my-header {
  display: flex;
  padding: 0;
  text-align: left;
  opacity: 1;
  background: var(--primary-color) !important;
  box-sizing: border-box;
  .right-view {
    text-align: right;
    flex: 1;
    background: var(--primary-color) !important;
    height: 60px;
    width: 971px;
    box-sizing: border-box;
  }
}
.user-info {
  display: flex;
  height: 100%;
  align-items: center;
  justify-content: flex-end;
  font-size: 16px;
  .user-name {
    color: #fff;
    padding-right: 20px;
  }
  .edit-pwd {
    margin-left: 10px;
    color: #fff;
  }
  .login-out {
    margin: 0 20px 0 10px;
    color: #fff;
  }
  .my-code {
    margin-left: 10px;
    color: #fff;
  }
}

@media only screen and (max-width: 767px) {
  .xs-aside {
    display: none;
  }
  .my-header {
    display: none;
  }
  .content-box {
    height: 100vh;
  }
}

// 平板适配
@media screen and (max-width: 1300px) {
  .el-aside {
    width: 130px !important;
  }
  .my-menu[data-v-a380d422] {
    width: 130px;
    overflow: hidden;
  }
}
</style>
