import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import $api from './request/apis'
import ElementUI, { Message } from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import "@/style/index.less"
import "../theme/index.css"

import vant, { Toast } from "vant";
// 2. 引入组件样式
import "vant/lib/index.css";

Vue.config.productionTip = false
Vue.prototype.$api = $api;
Vue.prototype.ElMessage = Message;
Vue.prototype.Toast = Toast;

Vue.use(ElementUI);
Vue.use(vant);

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
