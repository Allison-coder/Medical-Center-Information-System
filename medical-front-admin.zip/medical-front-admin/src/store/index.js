import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

const authInfo = JSON.parse(localStorage.getItem("medical_auth")) || {};

if (screen) {
  if (screen.width < 1300) {
    localStorage.setItem("equipment", "pad");
  } else {
    localStorage.setItem("equipment", "pc");
  };

} else {
  localStorage.setItem("equipment", "pc");
}



const equipment = localStorage.getItem("equipment")

export default new Vuex.Store({
  state: {
    authInfo,
    equipment
  },
  getters: {},
  mutations: {
    SET_AUTH_INFO(state, authInfo) {
      state.authInfo = authInfo;
      localStorage.setItem("medical_auth", JSON.stringify(authInfo));
    },
    CLEAR_AUTH_INFO(state) {
      state.authInfo = null;
      localStorage.removeItem("medical_auth");
    },
  },
  actions: {},
  modules: {},
});
