import Vue from "vue";
import VueRouter from "vue-router";
import Layout from "@/layout/index.vue";
import store from "@/store";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    component: Layout,
    redirect: "/work-panel",
    meta: {
      requireAuth: true,
    },
    children: [
      {
        path: "/order-management/:orderSn?",
        component: () => import("@/views/order-management/index"),
        name: "order-management",
        meta: { title: "订单管理", icon: "dashboard", affix: true },
      },
      {
        path: "/patient-management",
        component: () => import("@/views/patient-management/index"),
        name: "patient-management",
        meta: { title: "患者管理", icon: "dashboard", affix: true },
      },
      {
        path: "/patient-task",
        component: () => import("@/views/patient-management/task_list"),
        name: "patient-task",
        meta: { title: "患者任务列表" },
      },

      {
        path: "/people-management",
        component: () => import("@/views/people-management/index"),
        name: "people-management",
        meta: { title: "人员管理" },
      },
      {
        path: "/work-panel",
        component: () => import("@/views/work-panel/index"),
        name: "work-panel",
        meta: { title: "工作面板" },
      },
      {
        path: "/schedule-management",
        component: () => import("@/views/schedule-management/index"),
        name: "schedule-management",
        meta: { title: "排班管理" },
      },
      // 患者基础信息
      {
        name: "patientInformation",
        path: "/patient-information/:patientSn?",
        component: () => import("@/views/patient-information/index.vue"),
        meta: { title: "患者信息" },
      },
      // 优惠券活动
      {
        path: "/coupons",
        component: () => import("@/views/coupons/index"),
        name: "coupons",
        meta: { title: "优惠券活动", icon: "dashboard", affix: true },
        beforeEnter: (to, from, next) => {
          if (store.state.authInfo.roles.includes('ADMINISTRATOR')) {
            next()
          } else {
            next('/work-panel')
          }
        }
      },
      // 优惠券活动新增、编辑
      {
        path: "/coupons-edit",
        component: () => import("@/views/coupons/edit"),
        name: "coupons-edit",
        meta: { title: "优惠券活动", icon: "dashboard", affix: true },
        beforeEnter: (to, from, next) => {
          if (store.state.authInfo.roles.includes('ADMINISTRATOR')) {
            next()
          } else {
            next('/work-panel')
          }
        }
      },
      // 内容管理
      {
        path: "/content-management",
        component: () => import("@/views/content-management/index"),
        name: "content-management",
        meta: { title: "内容管理", icon: "dashboard", affix: true },
        beforeEnter: (to, from, next) => {
          if (store.state.authInfo.roles.includes('ADMINISTRATOR')) {
            next()
          } else {
            next('/work-panel')
          }
        }
      },
    ],
  },
  {
    path: "/login",
    component: () => import("@/views/login.vue"),
    name: "login",
    meta: { title: "登录" },
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location, onResolve, onReject) {
  if (onResolve || onReject)
    return originalPush.call(this, location, onResolve, onReject);
  return originalPush.call(this, location).catch((err) => err);
};
router.beforeEach((to, from, next) => {
  const auth = localStorage.getItem("medical_auth");
  const requireAuth = to.matched.find(
    (route) => route.meta.requireAuth === true
  );
  if (requireAuth && !auth) {
    next({
      path: "/login",
      query: {
        redirect: to.fullPath,
      },
    });
    return;
  }
  // 已登录就不给去登录页面
  if (auth && to.path === "/login") {
    next(from.fullPath);
    return;
  }
  next();
});
export default router;
