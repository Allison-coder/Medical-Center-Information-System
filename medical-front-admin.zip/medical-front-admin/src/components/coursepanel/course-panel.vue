<template>
  <div class="course-panel" @click="routerToPatientInformation(patientSn)">
    <h1>{{ courseName }}</h1>
    <slot name="patientStatus"></slot>
  </div>
</template>

<script>
export default {
  props: {
    courseName: {
      type: String,
      default: "空闲",
    },
    patientSn: {
      type: Number,
      default: 0,
    },
  },
  methods: {
    routerToPatientInformation() {
      this.$router.push({
        name: "patientInformation",
        // query: {
        //   patientSn: patientSn,
        // },
      });
    },
  },
};
</script>

<style scoped lang="less">
.course-panel {
  width: 100%;
  height: 50px;
  background: #eaf1fd;
  box-sizing: border-box;
  cursor: move;
  cursor: pointer;
  h1 {
    height: 33px;
    font-size: 20px;
    font-weight: normal;
    text-align: center;
    line-height: 33px;
    // background-color: grey;
  }
}
</style>
