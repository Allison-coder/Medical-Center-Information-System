<template>
  <div class="YuYueBox" style="height: 600px">
    <!-- 左边中文时间 -->
    <div class="chinese-time">
      <div class="el-icon-back" @click="dayDistanceFn('sub')"></div>
      <div class="content">{{ dayStrLong }}</div>
      <div class="el-icon-right" @click="dayDistanceFn('add')"></div>
      <div class="date_box" style="display: inline-block; position: relative">
        <label
          for="dateId"
          style="
            margin-right: 20px;
            position: absolute;
            left: 32px;
            top: 11px;
            z-index: 999;
            cursor: pointer;
          "
        >
          <i style="font-size: 18px" class="el-icon-date"></i
        ></label>
        <el-date-picker
          id="dateId"
          :clearable="false"
          v-model="patientScheduleParams.dataStr"
          type="date"
          @change="dateChange($event)"
          placeholder="选择日期"
          value-format="yyyy-MM-dd"
        >
        </el-date-picker>
      </div>
      <div class="YuYue_project" v-if="isDirect">
        <div class="item_text">预约项目:</div>
        <el-select
          style="width: 180px; margin-left: 20px"
          placeholder="请选择项目"
          v-model="CheckedProject.id"
          @change="changeProject"
          clearable
          size="medium"
        >
          <el-option
            v-for="item in medicalList"
            :key="item.id"
            :label="item.projectName"
            :value="item.id"
          >
          </el-option>
        </el-select>
      </div>
      <div class="YiYuYue_text">
        已预约{{ YuYueTime }}小时
        <span v-if="singleAppointmentDuration > 0"
          >需预约{{ singleAppointmentDuration }}小时</span
        >
      </div>
    </div>

    <div class="tab_box">
      <div style="width: 100%" v-if="noData">
        <img
          src="@/assets/yuyue_ico.png"
          style="display: block; margin: 50px auto"
          alt=""
        />
        <div style="margin: 50px atuo; text-align: center; color: #666">
          暂无记录
        </div>
      </div>

      <div v-else style="overflow-x: auto; width: 100%">
        <table class="my_table">
          <thead>
            <tr>
              <th style="font-size: 20px">康复师</th>

              <th v-for="(item, i) in docObj" :key="i">
                <div class="YiSheng_line">{{ item.name }}</div>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, i) in newArr" :key="i">
              <td>
                <div class="time_line">
                  {{ item.startTime }}-{{ item.endTime }}
                </div>
              </td>
              <td v-for="(son, j) in item.adminList" :key="j">
                <div class="cell_box" v-if="son.patientList">
                  <div
                    @click="YuYueFn(item, son)"
                    class="cell_box_in"
                    :class="
                      YuYueItems.find(
                        (item) => item.scheduleDataId === son.scheduleDataId
                      )
                        ? 'active'
                        : ''
                    "
                    v-if="son.patientList.length == 0"
                    style="cursor: default"
                  >
                    <div class="cell_box_in_title">空闲</div>
                    <div class="cell_box_in_text _color_warning">待预约</div>
                  </div>
                  <div v-if="son.patientList.length > 0">
                    <div
                      class="cell_box_in"
                      v-for="(pat, k) in son.patientList"
                      :key="k"
                    >
                      <div class="cell_box_in_title">
                        {{ pat.name }}
                      </div>
                      <div
                        style="
                          display: flex;
                          align-items: center;
                          justify-content: space-around;
                        "
                      >
                        <div class="cell_box_in_text _color_success">
                          已预约
                        </div>
                        <!-- 任务状态： 1-待支付 2-待预约 3-待报到 4-候诊中（面诊单）/等候诊疗（治疗单） 5-面诊中（面诊单）/治疗中（治疗单） 6-已完成（面诊单）/完成治疗（治疗单）7-已取消 8-已退款 -->

                        <!-- <div
                          v-if="
                            pat.taskStatus != 5 &&
                            pat.taskStatus != 6 &&
                            pat.taskStatus != 7 &&
                            pat.taskStatus != 8
                          "
                          @click="cancelAppointment(pat)"
                          class="cell_box_in_text text_btn"
                          style="cursor: pointer"
                        >
                          取消预约
                        </div> -->
                      </div>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="two_btns">
      <el-button size="medium" @click="cancle()" icon="el-icon-back"
        >取消</el-button
      >
      <el-button
        type="primary"
        size="medium"
        @click="saveYuYue()"
        icon="el-icon-folder"
        >确认预约</el-button
      >
    </div>
  </div>
</template>

<script>
import dayjs from "dayjs";
export default {
  name: "TreatmentAppointment",
  props: {
    orderSn: {
      type: String,
      default: "",
    },
    patientSn: {
      type: String,
      default: "",
    },
    singleAppointmentDuration: {
      type: Number,
      default: 0,
    },
  },

  data() {
    return {
      // 是否是预约可直接预约治疗项目
      isDirect: false,
      noData: false,
      todayStr: "",
      //当前时间相距的天数
      dayDistance: 0,
      dayStrLong: "",
      // 当前选的日期
      dataStr: "",

      // 患者预约列表-params
      patientScheduleParams: {
        dataStr: "",
        type: 2,
      },
      newArr: [],
      docObj: [],
      // 某时间段内预约患者-list
      appointmentList: [],
      // 时间
      time_slot: [],
      // 医生名字
      // doctorNames: [],

      activeName: "first",
      // isShow: true,
      date: "",
      pickerOptions: {
        // 配置选项，例如禁用日期
      },
      calendar: "",

      // 已预约时长
      YuYueTime: 0,
      YuYueItems: [],

      medicalList: [],
      // 已选的治疗项目
      CheckedProject: {
        id: null,
      },
    };
  },

  created() {
    this.todayStr = dayjs().format("YYYY-MM-DD");
    this.docObj = this.transformData(this.appointmentList);

    console.log(999, this.orderSn);
    // 可直接预约治疗项目
    if (!this.orderSn) {
      this.isDirect = true;
      // 获取可直接预约治疗项目
      this.getPlanProjectConfig();
    }

    //初始化
    this.pageInit();
  },
  methods: {
    pageInit() {
      this.patientScheduleParams.dataStr = this.getAddDay(this.dayDistance);
      this.dataStr = this.patientScheduleParams.dataStr;
      this.dayStrLong = this.getDayLong(this.patientScheduleParams.dataStr);
      //  重新获取数据
      this.getPatientSchedule(
        this.patientScheduleParams.dataStr,
        this.patientScheduleParams.type
      );
    },
    // 获取可直接预约治疗项目
    async getPlanProjectConfig() {
      const { data } = await this.$api.baseApis.getPlanProjectConfig({
        projectType: 2,
      });
      this.medicalList = [];
      for (let item of data) {
        if (item.projectType == 2) {
          this.medicalList.push(item);
        }
      }

      console.log("获取可直接预约治疗项目的配置信息", data);
    },
    // 生成表头
    transformData(arr) {
      const result = [];
      arr.forEach((data) => {
        data.adminList.forEach((admin) => {
          let allNum = admin.scheduleNum || 0;
          if (!result.find((item) => item.adminId === admin.adminId)) {
            result.push({ name: admin.name, adminId: admin.adminId, allNum });
          } else {
            // 如果存在同名同ID的管理员，更新其allNum
            result.find((item) => item.adminId === admin.adminId).allNum +=
              allNum;
          }
        });
      });
      return result;
    },
    // 生成需要的数据
    transformNeedData(arr) {
      let newArr = [];
      for (let i = 0; i < arr.length; i++) {
        newArr[i] = {
          scheduleDataTime: arr[i].scheduleDataTime,
          startTime: arr[i].startTime,
          endTime: arr[i].endTime,
        };
        newArr[i].adminList = [];
        for (let j = 0; j < this.docObj.length; j++) {
          newArr[i].adminList[j] = {
            adminId: this.docObj[j].adminId,
            name: this.docObj[j].name,
          };
          for (let k = 0; k < arr[i].adminList.length; k++) {
            if (arr[i].adminList[k].adminId == this.docObj[j].adminId) {
              newArr[i].adminList[j].scheduleDataId =
                arr[i].adminList[k].scheduleDataId;
              newArr[i].adminList[j].patientList =
                arr[i].adminList[k].patientList;
            }
          }
        }
      }
      return newArr;
    },
    // 获取患者预约时间
    async getPatientSchedule(dataStr, type) {
      const { data } = await this.$api.baseApis.getPatientSchedule({
        dataStr,
        type,
      });
      this.appointmentList = data;
      this.docObj = this.transformData(this.appointmentList);
      if (this.docObj.length == 0) {
        this.noData = true;
      }
      if (this.docObj.length > 0) {
        this.noData = false;
      }
      this.newArr = this.transformNeedData(this.appointmentList);
    },
    // 日期
    dateChange(date) {
      this.patientScheduleParams.dataStr = date;

      const date1 = dayjs(date);
      const date2 = dayjs(this.todayStr);
      // 计算两个日期之间相差的天数
      this.dayDistance = date1.diff(date2, "day");
      this.pageInit();
    },
    dayDistanceFn(str) {
      if (str == "add") {
        this.dayDistance++;
      }
      if (str == "sub") {
        this.dayDistance--;
      }
      this.pageInit();
    },
    // 获取距离当前n天的日期
    getAddDay(num) {
      const today = dayjs();
      const date = today.add(num, "day").format("YYYY-MM-DD");
      return date;
    },
    // 根据日期返回年月日星期
    getDayLong(date) {
      const weekList = ["日", "一", "二", "三", "四", "五", "六"];
      let dayjsObj;
      if (date) {
        dayjsObj = dayjs(date);
      } else {
        dayjsObj = dayjs();
      }

      let dateLong =
        dayjsObj.format("YYYY-MM-DD") +
        ", " +
        "星期" +
        weekList[dayjsObj.day()];
      return dateLong;
    },
    // 跳转-患者资料
    goPatientInformation(patientSn, orderSn) {
      this.$router.push({
        name: "patientInformation",
        query: {
          patientSn: patientSn,
          orderSn: orderSn,
        },
      });
    },
    // 性别格式-转化
    formatState(state) {
      let MAP;
      if (this.patientScheduleParams.type == 1) {
        MAP = {
          0: "待支付",
          1: "待支付",
          2: "待预约",
          3: "待报到",
          4: "候诊中",
          5: "面诊中",
          6: "已完成",
        };
      }
      if (this.patientScheduleParams.type == 2) {
        MAP = {
          0: "待支付",
          1: "待支付",
          2: "待预约",
          3: "待报到",
          4: "等候治疗",
          5: "治疗中",
          6: "完成治疗",
        };
      }
      return MAP[state];
    },

    // 表格里预约点击
    YuYueFn(item, son) {
      console.log(1122, item, son);

      let addItem = {
        adminId: son.adminId,
        scheduleDataId: son.scheduleDataId,
        appointmentDate: this.dataStr,
        orderSn: this.orderSn,
        patientSn: this.patientSn,
      };

      if (this.YuYueItems.length == 0) {
        this.YuYueItems.push(addItem);
      } else {
        if (addItem.adminId != this.YuYueItems[0].adminId) {
          this.$message.error("请选择相同治疗师");
          this.YuYueItems.pop();
          return;
        }
        if (addItem.appointmentDate != this.YuYueItems[0].appointmentDate) {
          this.$message.error("请选择相同日期");
          this.YuYueItems.pop();
          return;
        }

        let isSame = false;
        for (let i = 0; i < this.YuYueItems.length; i++) {
          if (this.YuYueItems[i].scheduleDataId == addItem.scheduleDataId) {
            this.YuYueItems.splice(i, 1);
            isSame = true;
          }
        }
        if (!isSame) {
          this.YuYueItems.push(addItem);
        }
      }

      this.YuYueTime = 0.5 * this.YuYueItems.length;

      console.log(9966, this.YuYueItems);
    },

    // 确认预约
    async saveYuYue() {
      // 直接预约的项目
      if (this.isDirect) {
        if (!this.CheckedProject.id) {
          this.$message.error("请选择预约项目");
          return;
        }
        if (
          this.singleAppointmentDuration > 0 &&
          this.YuYueTime !== Number(this.singleAppointmentDuration)
        ) {
          this.$message.error("时间长度不符");
          return;
        }

        let postObj = {
          adminId: this.YuYueItems[0].adminId,
          appointmentDate: this.YuYueItems[0].appointmentDate,
          projectId: this.CheckedProject.id,
          patientSn: this.YuYueItems[0].patientSn,
          // 预约类型 2-治疗方案预约 3-项目预约
          scheduleType: 3,
          scheduleDetailIds: [],
          source: "HEALTH_ADMIN",
          couponCode: null,
          isUseCoupon: false,
        };

        for (let i = 0; i < this.YuYueItems.length; i++) {
          postObj.scheduleDetailIds.push(this.YuYueItems[i].scheduleDataId);
        }
        console.log("gfdhgfd", postObj);

        const res = await this.$api.baseApis.addNewTreatment(postObj);
        if (res.code == 200) {
          this.$message.success("预约成功");
          // this.pageInit();
          let _this = this;
          setTimeout(() => {
            _this.YuYueItems = [];
            _this.YuYueTime = 0;
            _this.$emit("child-event-ok");
          }, 1000);
        }
      } else {
        console.log(this.YuYueTime, this.singleAppointmentDuration);
        if (
          this.singleAppointmentDuration > 0 &&
          this.YuYueTime !== Number(this.singleAppointmentDuration)
        ) {
          this.$message.error("时间长度不符");
          return;
        }
        let postObj = {
          adminId: this.YuYueItems[0].adminId,
          appointmentDate: this.YuYueItems[0].appointmentDate,
          orderSn: this.YuYueItems[0].orderSn,
          patientSn: this.YuYueItems[0].patientSn,
          scheduleDetailIds: [],
        };

        for (let i = 0; i < this.YuYueItems.length; i++) {
          postObj.scheduleDetailIds.push(this.YuYueItems[i].scheduleDataId);
        }
        console.log("gfdhgfd", postObj);

        const { data } = await this.$api.baseApis.confirmAppointment(postObj);
        if (data == this.YuYueItems[0].orderSn) {
          this.$message.success("预约成功");
          // this.pageInit();
          let _this = this;
          setTimeout(() => {
            _this.YuYueItems = [];
            _this.YuYueTime = 0;
            _this.$emit("child-event-ok");
          }, 1000);
        }
      }
    },

    cancle() {
      this.YuYueItems = [];
      this.YuYueTime = 0;
      this.$emit("child-event");
    },
    async cancleAppiont(orderSn) {
      const { data } = await this.$api.baseApis.cancleAppiont(orderSn);

      if (data == true) {
        this.$message.success("取消预约成功");
        let _this = this;
        setTimeout(() => {
          _this.YuYueItems = [];
          _this.YuYueTime = 0;
          _this.$emit("child-event-ok");
        }, 1000);
      }
    },

    // 取消预约
    cancelAppointment(item) {
      console.log(996633, item);

      this.$confirm("确认取消预约吗", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.cancleAppiont(item.orderSn);
        })
        .catch(() => {});
    },

    // 选择项目改变
    changeProject() {
      for (let item of this.medicalList) {
        if (item.id == this.CheckedProject.id) {
          this.CheckedProject = item;
          this.singleAppointmentDuration = item.singleAppointmentDuration;
        }
      }
      console.log(9991, this.CheckedProject);
    },
  },
};
</script>

<style scoped lang="less">
.YuYueBox {
  position: relative;
  padding-top: 40px;
}
.tab_box {
  height: 554px;
  overflow-y: auto;
}
.my_table {
  border-collapse: collapse;
  border-spacing: 0;
  td,
  th {
    border: 1px solid #d1d1d1;
  }
  .time_line {
    text-align: center;
    width: 100px;
    line-height: 30px;
    font-size: 14px;
    color: #333;
    font-weight: 400;
  }

  .GuaHao_line {
    text-align: center;
    width: 160px;
    line-height: 30px;
    font-size: 14px;
    color: #333;
    font-weight: 400;
    border-bottom: 1px solid #d1d1d1;
    background: #f9f9f9;
  }
  .YiSheng_line {
    text-align: center;
    width: 160px;
    line-height: 50px;
    font-size: 20px;
    color: #333;
    background: #f9f9f9;
  }
  .cell_box {
    width: 100%;
    min-height: 50px;
    box-sizing: border-box;
    // background-color: red;
    padding: 0 6px;
    .cell_box_in {
      width: 100%;
      height: 50px;
      box-sizing: border-box;
      background-color: #eaf1fd;
      border-radius: 3px;
      margin-top: 6px;
      margin-bottom: 6px;
      text-align: center;
      &.active {
        background-color: var(--primary-color);
      }
      .cell_box_in_title {
        line-height: 26px;
        font-size: 16px;
        color: #333;
      }
      .cell_box_in_text {
        line-height: 12px;
        font-size: 12px;
        color: #666;
        padding: 3px 6px;
      }
    }
  }
}

.chinese-time {
  position: absolute;
  top: -4px;
  align-items: center;
  display: flex;
  width: 100%;
  height: 28px;
  margin-bottom: 15px;
  .el-icon-back {
    cursor: pointer;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
  .content {
    text-align: center;
    width: 199px;
    height: 25px;
    line-height: 28px;
  }
  .el-icon-right {
    cursor: pointer;
    margin-right: 10px;
    text-align: center;
    line-height: 28px;
    width: 28px;
    height: 28px;
    font-size: 25px;
  }
}

.hide_input {
  position: relative !important;
  background-color: transparent;
  height: 30px;
}
//修改控件自带的css
.hide_input .el-date-editor {
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0; //设置完全透明
  width: 30px;
  height: 30px;
}

._color_success {
  color: #1f8379 !important;
}
._color_warning {
  color: #fed191 !important;
}
._color_error {
  color: red !important;
}
._color_grey {
  color: #969799 !important;
}
::v-deep(.date_box .el-input--prefix .el-input__inner) {
  opacity: 0;
  width: 0 !important;
}
::v-deep(.date_box .el-input__prefix) {
  opacity: 0;
  width: 0 !important;
}
</style>
<style lang="less">
.date_box .el-picker-panel {
  left: 435px !important;
}

.YiYuYue_text {
  position: absolute;
  top: 10px;
  right: 30px;
}
.two_btns {
  width: 100%;
  text-align: right;
  padding-top: 10px;
}
.text_btn {
  background: #969799;
  color: #fff !important;
  padding: 3px 6px;
  border-radius: 3px;
  font-size: 12px !important;
}

.YuYue_project {
  position: absolute;
  width: 300px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  left: 400px;
  > .item_text {
    width: 62px;
  }
}
</style>
