<template>
  <div class="registration-appointment">
    <table border="1">
      <tr style="height: 79px">
        <th
          style="
            color: #3d3d3d;
            font-size: 18px;
            font-weight: 600;
            border: 1px solid #dddddd;
          "
        >
          医生
        </th>
        <th
          v-for="(doctor, index) in doctors"
          :key="index"
          style="
            color: #333333;
            font-size: 18px;
            font-weight: bold;
            background-color: #f9f9f9;
            border: 1px solid #dddddd;
            text-align: center;
            line-height: 79px;
          "
        >
          <template>
            <div
              style="
                border-bottom: 1px solid #dddddd;
                text-align: center;
                line-height: 30px;
                height: 30px;
              "
            >
              挂号人数:33
            </div>
          </template>
          {{ doctor }}
        </th>
      </tr>
      <!-- 以时间为基础遍历 -->
      <tr v-for="(timeSlot, index) in time_slot" :key="index">
        <!-- 遍历每行的时候，默认先从第一个th开始遍历 -->
        <th class="time-slot">{{ timeSlot }} {{ index }}</th>
        <td
          v-for="(doctorName, onlyId) in doctors"
          :key="onlyId"
          style="
            padding-left: 7px;
            padding-right: 7px;
            border: 1px solid #dddddd;
          "
        >
          <!-- {{ doctorName }} {{ index }} -->
          <template v-if="cellData[`'${doctorName}'-${index}`]">
            <course-panel
              :course-name="cellData[`'${doctorName}'-${index}`]"
              patientSn="2"
            >
              <template #patientStatus>
                <!-- <div class="patientStatusFinish">已完成</div> -->
                <!-- <div class="patientStatusAppointment">待预约</div>
                <div class="patientStatusFaceTreat">面诊中</div>
                <div class="patientStatusPayment">待支付</div> -->
                <div class="patientStatusReport">待报道</div>
              </template>
            </course-panel>
          </template>
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import CoursePanel from "@/components/coursepanel/course-panel.vue";
export default {
  name: "RegistrationAppointment",
  components: {
    CoursePanel,
  },
  props: {
    // 某时间段内预约患者-list
    adminList: {
      type: Array,
      default: [],
    },
    // 患者详情-list
    patientList: {
      type: Array,
      default: [],
    },
  },
  data() {
    return {
      doctors: ["陈明明", "孟子园", "苗若萌", "邹甜"],
      time_slot: ["8:00-8:30", "8:30-9:00", "9:00-9:30", "9:30-10:00"],
      cellData: {
        "'陈明明'-0": "曹翔",
        "'陈明明'-1": "空闲",
        "'陈明明'-2": "左泽远",
        "'陈明明'-3": "周郑源",
        "'孟子园'-0": "",
        "'孟子园'-1": "",
        "'孟子园'-2": "任子祯",
        "'孟子园'-3": "殷佳玉",
        "'苗若萌'-0": "任振宇",
        "'苗若萌'-1": "苏润丽",
        "'苗若萌'-2": "黄天昊",
        "'苗若萌'-3": "空闲",
        "'邹甜'-0": "水翔",
        "'邹甜'-1": "水翔",
        "'邹甜'-2": "魏晨涵",
      },
    };
  },
};
</script>

<style scoped lang="less">
.registration-appointment {
  width: 100%;
  box-sizing: border-box;
  table {
    // border-radius: 5px;
    // border-style: solid;
    // border-width: 2px;
    width: 100%;
    background-color: #fff;
    border-collapse: collapse;
    table-layout: fixed;
    td {
      width: 145px;
      height: 60px;
    }
    .time-slot {
      border: 1px solid #dddddd;
    }
    .patientStatusFinish {
      color: red;
      font-size: 12px;
      line-height: 12px;
      text-align: center;
      color: #666666;
    }
    .patientStatusAppointment {
      color: red;
      font-size: 12px;
      line-height: 12px;
      text-align: center;
      color: #f59a23;
    }
    .patientStatusFaceTreat {
      color: red;
      font-size: 12px;
      line-height: 12px;
      text-align: center;
      color: #00ac93;
    }
    .patientStatusPayment {
      color: red;
      font-size: 12px;
      line-height: 12px;
      text-align: center;
      color: #ef2e2e;
    }
    .patientStatusReport {
      color: red;
      font-size: 12px;
      line-height: 12px;
      text-align: center;
      color: #00ac93;
    }
  }
}
</style>
