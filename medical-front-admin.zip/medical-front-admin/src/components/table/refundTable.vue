<template>
  <div class="com-box">
    <el-table
      ref="RTable"
      class="p-table"
      v-bind="$attrs"
      v-on="$listeners"
      border
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"> </el-table-column>

      <template v-for="(item, index) in columns">
        <el-table-column
          v-if="item.slotName"
          v-bind="item"
          :key="index"
          align="center"
        >
          <template slot-scope="scope">
            <slot
              :name="item.slotName"
              :data="{
                row: scope.row,
                column: scope.column,
                index: scope.$index,
              }"
            ></slot>
          </template>
        </el-table-column>
        <el-table-column
          v-else-if="item.render"
          v-bind="item"
          :key="index"
          align="center"
        >
          <template #default="{ row, column, $index }">
            <render-dom
              :render="item.render"
              :row="row"
              :column="column"
              :columnIndex="index"
              :index="$index"
            ></render-dom>
          </template>
        </el-table-column>
        <el-table-column v-else v-bind="item" :key="index" align="center">
        </el-table-column>
      </template>

      <el-table-column
        fixed="right"
        label="退款时间"
        width="118"
        align="center"
        v-if="activeName == '1'"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.refundTime }}</span>
        </template>
      </el-table-column>

      <el-table-column
        fixed="right"
        label="操作"
        width="118"
        align="center"
        v-if="activeName == '0'"
      >
        <template slot-scope="scope">
          <el-row>
            <el-button
              style="margin: 10px auto"
              @click="dealRefund(scope.row.orderId)"
              type="primary"
              size="mini"
              icon="el-icon-edit-outline"
              >执行退款</el-button
            >
            <br />
            <el-button
              @click="applyRevoke(scope.row.orderId)"
              type="danger"
              plain
              size="mini"
              icon="el-icon-refresh-left"
              >撤销退款</el-button
            >
          </el-row>
        </template>
      </el-table-column>
      <el-table-column
        fixed="right"
        label="处理结果"
        width="118"
        align="center"
        v-if="activeName == '1'"
      >
        <template slot-scope="scope">
          <span
            :class="
              scope.row.refundStatus == 'REFUND'
                ? 'text-success'
                : scope.row.refundStatus == 'CANCEL'
                ? 'text-warning'
                : ''
            "
            >{{
              scope.row.refundStatus == "REFUND"
                ? "已退款"
                : scope.row.refundStatus == "CANCEL"
                ? "已撤销"
                : "其他"
            }}</span
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="p-page"
      layout="prev, pager, next"
      prev-text="上一页"
      next-text="下一页"
      @current-change="currentChange"
      :current-page="page.pageNo || 1"
      :page-size="page.pageSize || 10"
      :total="page.total"
      hide-on-single-page
    >
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: "RTable",

  components: {
    // render函数实现
    renderDom: {
      functional: true,
      props: {
        render: Function,
      },
      render(_, { data, props }) {
        return props.render(_, data.attrs);
      },
    },
  },
  props: {
    columns: {
      type: Array,
      default: () => {
        return [];
      },
    },
    activeName: {
      type: String,
      default: () => {
        return "0";
      },
    },
    page: {
      type: Object,
      default: () => {
        return {};
      },
    },
  },
  methods: {
    currentChange(index) {
      this.$emit("pageCurrent-change", index);
    },
    applyRefund(id, payPrice, orderPrice) {
      this.$parent.dialogFormVApplyRefund = true;
      this.$parent.ApplyRefundForm.orderId = id;

      this.$parent.getSingleInfo(id);

      this.$parent.ApplyRefundForm.refundFee = payPrice;
      this.$parent.ApplyRefundForm.payPrice = payPrice;
      this.$parent.ApplyRefundForm.orderPrice = orderPrice;
    },

    handleSelectionChange(e) {
      let refundIdsArr = [];
      for (let i = 0; i < e.length; i++) {
        refundIdsArr[i] = e[i].orderId;
      }
      this.$parent.batchRefundObj.refundIds = refundIdsArr;
    },

    applyRevoke(id) {
      this.$parent.applyRevoke(id);
    },
    // 单个退款
    dealRefund(id) {
      this.$parent.dealRefund(id);
    },
  },
};
</script>

<style lang="less" scoped>
.p-table.el-table {
  /deep/ th.el-table__cell {
    color: #333;
    background-color: var(--default-color);
  }
}

.el-table {
  /deep/ .sort-caret.descending {
    border-top-color: rgb(127, 127, 127);
  }
  /deep/ .sort-caret.ascending {
    border-bottom-color: rgb(127, 127, 127);
  }
  /deep/ .ascending .sort-caret.ascending {
    border-bottom-color: #409eff;
  }
  /deep/ .descending .sort-caret.descending {
    border-top-color: #409eff;
  }
}

.p-page {
  text-align: right;
  margin-top: 15px;
}

.text-success {
  color: #67c23a;
}
.text-danger {
  color: #f56c6c;
}
.text-warning {
  color: #e6a23c;
}

/**
自定义el-table表格滚动栏样式
*/
.p-table {
  /deep/ .el-table__body-wrapper {
    overflow-x: scroll;
  }
  // ::v-deep .el-table__body-wrapper::-webkit-scrollbar {
  //   width: 10px !important;
  //   /*滚动条宽度*/
  //   height: 20px !important;
  //   /*滚动条高度*/
  // }

  // /*定义滚动条轨道 内阴影+圆角*/
  // ::v-deep .el-table__body-wrapper::-webkit-scrollbar-track {
  //   box-shadow: 0px 1px 3px #ccced2 inset !important;
  //   /*滚动条的背景区域的内阴影*/
  //   border-radius: 10px !important;
  //   /*滚动条的背景区域的圆角*/
  //   background-color: #ccced2 !important;
  //   /*滚动条的背景颜色*/
  // }

  // /*定义滑块 内阴影+圆角*/
  // ::v-deep .el-table__body-wrapper::-webkit-scrollbar-thumb {
  //   box-shadow: 0px 1px 3px #428ab2 inset !important;
  //   /*滚动条的内阴影*/
  //   border-radius: 10px !important;
  //   /*滚动条的圆角*/
  //   background-color: #428ab2 !important;
  //   /*滚动条的背景颜色*/
  // }
}
</style>
