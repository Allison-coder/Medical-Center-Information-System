<template>
  <el-menu
    :default-active="activeIndex"
    router
    active-text-color="#fff"
    background-color="#fff"
    class="my-menu"
  >
    <el-menu-item index="work-panel">
      <span slot="title">
        <i style="font-size: 14px; margin-top: -1px" class="el-icon-date"></i>
        工作面板</span
      >
    </el-menu-item>
    <el-menu-item index="schedule-management">
      <span slot="title">
        <i style="font-size: 14px; margin-top: -1px" class="el-icon-s-grid"></i>
        排班管理</span
      >
    </el-menu-item>
    <el-menu-item index="people-management">
      <span slot="title"
        ><i style="font-size: 14px; margin-top: -1px" class="el-icon-user"></i>
        人员管理</span
      >
    </el-menu-item>
    <el-menu-item index="order-management">
      <span slot="title"
        ><i
          style="font-size: 14px; margin-top: -1px"
          class="el-icon-document-copy"
        ></i>
        订单管理</span
      >
    </el-menu-item>
    <el-menu-item index="patient-management">
      <span slot="title"
        ><i
          style="font-size: 14px; margin-top: -1px"
          class="el-icon-folder-add"
        ></i>
        患者管理</span
      >
    </el-menu-item>
    <el-menu-item index="coupons" v-if="roles.includes('ADMINISTRATOR')">
      <span slot="title"
        ><i style="font-size: 14px; margin-top: -1px" class="el-icon-goods"></i>
        优惠券活动</span
      >
    </el-menu-item>
    <el-menu-item
      index="content-management"
      v-if="roles.includes('ADMINISTRATOR')"
    >
      <span slot="title"
        ><i
          style="font-size: 14px; margin-top: -1px"
          class="el-icon-tickets"
        ></i>
        内容管理</span
      >
    </el-menu-item>
  </el-menu>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "Menu",
  data() {
    return {};
  },
  computed: {
    ...mapState({
      roles: (state) => state.authInfo.roles,
    }),
    activeIndex() {
      // 患者资料高亮"工作面板"
      if (this.$route.name == "patientInformation") {
        return "work-panel";
      }
      // 高亮优惠券活动
      if (this.$route.name == "coupons-edit") {
        return "coupons";
      }
      // 高亮患者任务
      if (this.$route.name == "patient-task") {
        return "patient-management";
      }
      return this.$route.name;
    },
  },
};
</script>

<style lang="less" scoped>
.my-menu {
  padding-top: 5px;
  border-right: none;
  width: 100%;
  opacity: 1;
  background: #ffffff;
  .el-menu-item {
    color: #000 !important;
  }
  .el-menu-item:hover {
    background-color: #fff !important;
    color: var(--primary-color) !important;
  }
  .el-menu-item.is-active {
    color: var(--primary-color) !important;
    background-color: #fceee8 !important;
  }
  .el-menu-item.is-active:hover {
    color: var(--primary-color) !important;
  }
  .el-menu-item {
    width: 200px;
    height: 44px;
    text-align: left;
    line-height: 44px;
    box-sizing: border-box;
    user-select: none;
  }
}
</style>
