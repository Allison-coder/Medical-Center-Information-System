<template>
  <el-dialog
    title="修改密码"
    :visible.sync="show"
    width="30%"
    :before-close="handleClose"
    center
    :close-on-click-modal="false"
  >
    <el-form
      :model="ruleForm"
      ref="ruleForm"
      label-width="130px"
      class="demo-ruleForm"
    >
      <el-form-item label="原密码：">
        <el-input
          v-model="ruleForm.currentPassword"
          clearable
          show-password
          placeholder="请输入原密码"
        ></el-input>
      </el-form-item>
      <el-form-item label="新密码：">
        <el-input
          v-model="ruleForm.password"
          clearable
          show-password
          placeholder="请输入新密码"
        ></el-input>
      </el-form-item>
      <el-form-item label="再次输入新密码：">
        <el-input
          v-model="ruleForm.passwordConfirmation"
          clearable
          show-password
          placeholder="请再次输入新密码"
        ></el-input>
      </el-form-item>
      <div style="margin-left: 130px; color: #e6a23c" v-if="showTips">
        <div>密码强度过弱，请按照以下要求重新输入新密码：</div>
        <div>1.密码长度至少8位；</div>
        <div>2.密码含有数字&字母；</div>
        <div>3.密码至少含有其中任一符号（!@#$%^&*.?+）；</div>
        <div>4.含有字母大小写。</div>
      </div>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="submit">确认修改</el-button>
    </span>
  </el-dialog>
</template>
<script>
import md5 from "md5";
export default {
  props: { show: Boolean },
  data() {
    return {
      ruleForm: {
        currentPassword: "",
        password: "",
        passwordConfirmation: "",
      },
      showTips: false,
    };
  },
  methods: {
    async submit() {
      if (
        !this.ruleForm.currentPassword ||
        !this.ruleForm.password ||
        !this.ruleForm.passwordConfirmation
      ) {
        this.$message.error("请输入密码！");
        return;
      }
      if (this.ruleForm.password !== this.ruleForm.passwordConfirmation) {
        this.$message.error("两次输入的新密码不一致！");
        return;
      }
      let reg =
        /^\S*(?=\S{8,})(?=\S*\d)(?=\S*[A-Z])(?=\S*[a-z])(?=\S*[!@#$%^&*.?+])\S*$/;
      if (!reg.test(this.ruleForm.password)) {
        this.showTips = true;
        this.$message.error("新密码不符合要求！");
      } else {
        let newObj = JSON.parse(JSON.stringify(this.ruleForm));
        newObj.currentPassword = md5(this.ruleForm.currentPassword);

        await this.$api.baseApis.updatePassword(newObj).then((res) => {
          this.handleClose();
          this.$message.success("成功修改密码,请重新登录！");
          this.$store.commit("CLEAR_AUTH_INFO", {});
          this.$router.push("/login");
        });
      }
    },
    handleClose() {
      this.ruleForm.currentPassword = "";
      this.ruleForm.password = "";
      this.ruleForm.passwordConfirmation = "";
      this.$emit("close");
    },
  },
};
</script>
