<template>
  <div class="treat-panel" @click="routerToPatientInformation(patientSn)">
    <div class="treatName">{{ treatName }}</div>
  </div>
</template>

<script>
export default {
  props: {
    treatName: {
      type: String,
      default: "空闲",
    },
    patientSn: {
      type: Number,
      default: 0,
    },
  },
  methods: {
    routerToPatientInformation(patientSn) {
      this.$router.push({
        name: "patientInformation",
        query: {
          patientSn: patientSn,
        },
      });
    },
  },
};
</script>

<style scoped lang="less">
.treat-panel {
  width: 100%;
  height: 60px;
  background: #e7f6f4;
  box-sizing: border-box;
  cursor: move;
  cursor: pointer;
  .treatName {
    font-size: 20px;
    text-align: center;
    line-height: 60px;
  }
}
</style>
