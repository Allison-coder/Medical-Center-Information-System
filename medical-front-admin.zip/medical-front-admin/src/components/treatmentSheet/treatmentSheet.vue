<template>
  <div class="treatment-detail-out">
    <div class="treatment-detail" id="printBox">
      <img class="title_img" src="@/assets/header/logo2.png" alt="" />
      <div class="treatment-title">专用治疗单</div>
      <div class="patient-detail">
        <div class="patient-content">患者姓名：{{ pageData.patientName }}</div>
        <div class="patient-content">
          性别：{{ pageData.gender == 0 ? "女" : "男" }}
        </div>
        <div class="patient-content">
          年龄：{{
            pageData.age
              ? pageData.age === 0 || pageData.age === "null"
                ? "--"
                : pageData.age + "岁"
              : "--"
          }}
        </div>
        <div class="patient-content">手机号：{{ pageData?.phoneNumber }}</div>
        <div class="patient-content">患者ID：{{ pageData.patientSn }}</div>
        <div class="patient-content">治疗单号：{{ pageData.orderSn }}</div>
      </div>
      <div class="medical-detail">
        <span style="margin-right: 100px; color: #323233; font-size: 16px"
          >开单人：{{ pageData.adminName }}</span
        >
        <span style="margin-right: 100px; color: #323233; font-size: 16px"
          >创建时间：{{ pageData.createTime }}</span
        >
        <div style="margin-top: 15px; margin-bottom: 10px; width: 100%">
          <el-table
            :data="pageData.treatmentPlan.items"
            highlight-current-row
            border
          >
            <el-table-column
              type="index"
              label="序号"
              width="50"
              align="center"
            />

            <el-table-column prop="projectType" label="项目名称" align="center">
              <template #default="{ row }">
                {{ row.itemName }}
              </template>
            </el-table-column>
            <el-table-column label="单价" align="center">
              <template #default="{ row }">
                <span v-if="row.projectType == 1">￥</span>
                <span v-if="row.projectType == 1">{{ row.unitPrice }}</span>
                <div
                  v-if="row.projectType == 2"
                  style="width: 100%; min-width: 40px; text-align: center"
                >
                  --
                </div>
              </template>
            </el-table-column>
            <el-table-column label="总次数" align="center">
              <template #default="{ row }">
                <span v-if="row.projectType == 1">
                  {{ row.totalSessions }}
                </span>
                <span v-if="row.projectType == 2"> -- </span>
              </template>
            </el-table-column>
            <el-table-column label="总价" align="center">
              <template #default="{ row }">
                <span v-if="row.projectType == 1">
                  ￥ {{ (row.unitPrice * row.totalSessions).toFixed(2) }}
                </span>
                <span v-if="row.projectType == 2">
                  ￥ {{ row.totalPrice }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="频率" align="center">
              <template #default="{ row }">
                <div v-if="row.projectType == 2">
                  <span v-if="row.frequency"
                    >每日 {{ row.frequencyNum }} 次</span
                  >
                  <span v-else>--</span>
                </div>
                <div v-if="row.projectType == 1">
                  <span>每周 {{ row.frequencyNum }} 次</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              label="描述"
              align="center"
              min-width="150"
              prop="description"
            />
            <el-table-column label="时长" align="center">
              <template #default="{ row }">
                <span v-if="row.projectType == 1">
                  {{ row.durationPerSession + "小时" }}
                </span>
                <span v-if="row.projectType == 2"> -- </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div
          style="
            margin-top: 18px;
            margin-bottom: 5px;
            font-weight: 500;
            font-size: 18px;
            color: #333;
          "
        >
          <span style="font-size: 18px; font-weight: 600">医嘱：</span
          >{{ pageData.treatmentPlan.advice }}
        </div>
        <div
          style="
            text-align: right;
            padding-right: 150px;
            font-weight: 500;
            font-size: 16px;
            margin-top: 20px;
            color: #333;
          "
        >
          <span style="font-size: 16px; font-weight: 600">医生签名：</span>

          <div class="doc_line"></div>
        </div>
      </div>
      <div class="total-payment">
        <div class="payment" :class="payed ? '' : 'payed'">
          <div class="image_box" v-if="qrImg">
            <img :src="qrImg" alt="" />
            <div class="QRcode">付款二维码</div>
          </div>
          <div class="number">
            合计<span style="color: red; font-weight: 600">
              {{ pageData.treatmentPlan.items.length }}
            </span>
            项,
            <span style="color: red; font-weight: 600"
              >￥{{ pageData.orderAmount }}</span
            >
            元
          </div>
        </div>

        <div class="effect">注：处方当日有效</div>
      </div>
    </div>
    <div
      style="
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        margin-top: 40px;
      "
    >
      <el-button size="medium" @click="cancle" icon="el-icon-circle-close"
        >关闭</el-button
      >
      <el-button
        type="primary"
        size="medium"
        @click="toPrint()"
        icon="el-icon-printer"
        >打印</el-button
      >
    </div>
  </div>
</template>

<script>
import html2canvas from "html2canvas";
export default {
  name: "TreatmentSheet",
  props: {
    ZhiLiaoOrderSn: {
      type: String,
      default: "",
    },
  },

  data() {
    return {
      // 处置方案-药物列表
      medicalList: [],
      qrImg: "",
      payed: false,
      pageData: {
        adminName: "",
        age: 0,
        gender: 0,
        idCardNumber: "",
        identityType: 0,
        orderSn: "",
        patientName: "",
        patientSn: "",
        phoneNumber: "",
        treatmentPlan: {
          advice: "",
          createTime: "",
          id: 0,
          items: [
            {
              description: "",
              durationPerSession: 0,
              frequency: "",
              frequencyNum: 0,
              id: 0,
              itemId: 0,
              itemName: "",
              projectType: 0,
              totalSessions: 0,
              unitPrice: 0,
            },
          ],
          orderSn: "",
          patientSn: "",
          planUseStatus: 0,
        },
      },
      mock_pageData: {},
    };
  },
  created() {
    this.getTherapyOrders();
  },
  methods: {
    // 获取治疗单详细
    async getTherapyOrders() {
      const { data } = await this.$api.baseApis.getTherapyOrders(
        this.ZhiLiaoOrderSn
      );
      this.pageData = data;

      // 没支付才请求二维码
      if (data.orderStatus === 0) {
        this.payed = true;
        this.goPayCode(this.ZhiLiaoOrderSn);
      }
    },

    // 获取支付码
    async goPayCode(orderSn) {
      console.log("orderSn", orderSn);
      const { data } = await this.$api.baseApis.WeiXinQrcodePay({
        paymentType: "WEIXIN_QRCODE_PAY",
        orderNum: orderSn,
        subject: "medical_admin",
      });
      if (data.qrImg) {
        this.qrImg = data.qrImg;
      }
    },

    cancle() {
      this.$emit("child-event");
    },
    toPrint() {
      // 定义打印方法
      const dom = document.getElementById("printBox");
      html2canvas(dom, {
        scale: 2,
        width: dom?.offsetWidth,
        height: dom?.offsetHeight,
      }).then((canvas) => {
        const src64 = canvas.toDataURL();
        const contentWidth = canvas.width;
        const contentHeight = canvas.height;

        const imgWidth = 800; // 根据纸张宽度设定
        const imgHeight = (780 / contentWidth) * contentHeight;
        const img = new Image();
        const div = document.createElement("div");
        console.log(imgWidth, imgHeight, contentWidth, contentHeight, "data");
        div.appendChild(img);
        img.setAttribute("src", src64);
        img.setAttribute("width", imgWidth.toString());
        img.setAttribute("height", imgHeight.toString());
        img.setAttribute("id", "imgs");
        div.setAttribute("id", "printImg");
        img.onload = () => {
          var newWindow = window.open("参数医疗", "_blank");
          newWindow.document.write(div.innerHTML);
          newWindow.document.close();
          newWindow.focus();
          newWindow.print();
          newWindow.close();
        };
      });
    },
  },
};
</script>

<style scoped lang="less">
.treatment-detail {
  margin: 0 auto;
  width: 800px;
  background-color: #fff;
  padding: 20px;
  // border: 1px solid #000;
  .title_img {
    display: block;
    width: 300px;
    margin: 20px auto 40px;
  }
  .treatment-title {
    margin-bottom: 10px;
    text-align: center;
    font-size: 38px;
    color: #333333;
    line-height: 60px;
    font-weight: 600;
  }
  .patient-detail {
    display: flex;
    flex-wrap: wrap;
    border-bottom: 2px solid #eee;
    width: 100%;
    padding: 20px 0;
    font-size: 16px;

    .patient-content {
      width: 360px;
      height: 35px;
      line-height: 35px;
      margin-right: 40px;
      font-size: 16px;
      color: #323233;
    }
  }
  .medical-detail {
    // border-bottom: 2px solid #eee;
    padding-top: 30px;
    padding-bottom: 57px;
    position: relative;

    .doc_line {
      position: absolute;
      bottom: 0;
      right: 0;
      height: 2px;
      width: 230px;
      background-color: #dcdee0;
    }
  }
  .total-payment {
    height: 250px;
    position: relative;
    .payment {
      width: 400px;
      position: absolute;
      left: 0;
      top: 48px;
      height: 100px;
      display: flex;
      align-items: center;
      &.payed {
        width: 242px !important;
      }
      .number {
        margin-right: 50px;
        font-size: 18px;
        margin-top: -30px;
      }
      .image_box {
        margin-right: 30px;
        img {
          display: block;
          width: 119px;
          height: 119px;
        }
      }
    }
    .QRcode {
      font-size: 14px;
      width: 119px;
      text-align: center;
      color: #666;
      line-height: 30px;
    }
    .effect {
      font-weight: 500;
      font-size: 15px;
      color: #333;
      position: absolute;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
    }
  }

  .cell * {
    color: #000 !important;
  }
  .cell {
    color: #000 !important;
  }
  ::v-deep(th.el-table__cell.is-leaf) {
    background-color: #e95720;
    color: #fff;
  }
}
</style>
