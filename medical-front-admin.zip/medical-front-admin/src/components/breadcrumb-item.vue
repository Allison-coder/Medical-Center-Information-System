<template>
    <div class="com-box">
        <div class="f-box">
            <div class="flex">
                <i
                    @click="drawer = true"
                    class="el-icon-s-unfold icon-menu"
                ></i>
                <el-breadcrumb>
                    <el-breadcrumb-item class="b-item">{{
                        $route.meta.title
                    }}</el-breadcrumb-item>
                </el-breadcrumb>
            </div>

            <div class="login-out pointer" @click="loginOut">退出登录</div>
        </div>

        <el-drawer
            :visible.sync="drawer"
            :direction="direction"
            :with-header="false"
            size="45%"
            custom-class="m-drawer"
            :before-close="handleClose"
        >
            <div class="back-box">
                <i
                    @click="drawer = false"
                    class="el-icon-back icon-back-menu"
                ></i>
                返回
            </div>
            <Menu></Menu>
        </el-drawer>
    </div>
</template>

<script>
import Menu from '@/components/menu.vue';
export default {
    name: 'BreadcrumbItem',
    components: { Menu },
    data() {
        return {
            drawer: false,
            direction: 'ltr',
        };
    },
    methods: {
        handleClose(done) {
            done();
        },
        async loginOut() {
            this.Toast.loading({
                message: '加载中...',
                forbidClick: true,
                overlay: true,
                loadingType: 'spinner',
                duration: 0,
            });
            await this.$api.baseApis.logout();
            this.Toast.clear();
            this.$store.commit('CLEAR_AUTH_INFO', {});
            this.$router.push('/login');
            this.$message.success('成功退出登录');
        },
    },
};
</script>

<style lang="less" scoped>
.b-item {
    font-size: 18px;
    font-weight: 600;
}

.back-box {
    color: #fff;
}
.com-box,
.back-box {
    display: flex;
    align-items: center;
    color: #000;
}

.icon-menu {
    display: none;
    margin-right: 5px;
    font-size: 30px;
}

.icon-back-menu {
    padding: 13px;
    margin-right: 5px;
    font-size: 30px;
}

.f-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex: 1;
}

.flex {
    display: flex;
    align-items: center;
}

.login-out {
    display: none;
    margin: 0 10px 16px 0;
    color: rgb(217, 0, 27);
}

@media only screen and (max-width: 767px) {
    .b-item {
        padding-bottom: 15px;
    }

    .icon-menu {
        display: block;
        margin-bottom: 15px;
    }

    .login-out {
        display: flex;
    }
}
</style>

<style>
.m-drawer .el-drawer__body {
    background: #fff;
}
</style>
