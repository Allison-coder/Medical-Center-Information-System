import Vue from "vue";
import Fly from "flyio/dist/npm/fly";
import requestConfig from "@/request/config";
import store from "@/store";
import { FlyResponse, FlyErrResponse } from "flyio";

const fly = new Fly();

export default async function (url, params, config, name = "") {
  return new Promise((resolve, reject) => {
    const conf = Object.assign({}, requestConfig, config);
    if (store?.state.authInfo?.token == "") {
      store.commit("CLEAR_AUTH_INFO", {});
      this.$router.push("/login");
      return;
    }
    conf.headers.Authorization = `Bearer ${store.state.authInfo.token}`;
    conf.headers["Content-Type"] = "application/json";
    conf.responseType = "arraybuffer";
    Object.entries(params).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        params[key] = value.join(",");
      }
      if (value == "") {
        delete params[key];
      }
    });
    fly
      .post(url, params, conf)
      .then((response) => {
        const blob = new Blob([response.data], {
          type: response.headers["content-type"],
        });
        //兼容ie
        if (navigator.msSaveBlob) {
          return navigator.msSaveBlob(blob, name);
        }
        let URL = window.URL || window.webkitURL;
        const objectUrl = URL.createObjectURL(blob);
        createTag(objectUrl, name);
        URL.revokeObjectURL(objectUrl);
        resolve();
      })
      .catch((error) => {
        const blob = new Blob([error.response.data], {
          type: error.response.headers["content-type"],
        });
        const fileReader = new FileReader();
        fileReader.readAsText(blob);
        fileReader.onload = (e) => {
          try {
            const resJson = JSON.parse(e.target.result);
            Vue.prototype.$message.error(resJson.message);
            reject(resJson.message);
          } catch (error) {
            // 返回内容未知
            Vue.prototype.$message.error("未知错误");
            reject("未知错误");
          }
        };
        fileReader.onerror = (e) => {
          Vue.prototype.$message.error("错误响应解析失败");
          reject("错误响应解析失败");
        };
      });
  });
}

export async function downloadPic(url, name) {
  const conf = Object.assign({}, requestConfig);
  let data = await getBlob(url, {}, conf);
  // 兼容ie
  if (navigator.msSaveBlob) {
    return navigator.msSaveBlob(data.data, `${name}.jpg`);
  }
  let URL = window.URL || window.webkitURL;
  let objectUrl = URL.createObjectURL(data.data);
  createTag(objectUrl, name);
  URL.revokeObjectURL(objectUrl);
}

export function getBlob(url, data, config) {
  config.responseType = "blob";
  return fly.get(url, data, config);
}

function createTag(objectUrl, name) {
  const a = document.createElement("a");
  a.setAttribute("href", objectUrl);
  a.setAttribute("download", name);
  a.setAttribute("target", "_blank");
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
