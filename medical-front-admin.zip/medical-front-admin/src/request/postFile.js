import requestConfig from './config';
import Fly from 'flyio/dist/npm/fly';
import store from '../store/index';

function postFile(file, url, params = {}) {
    let config = Object.create(requestConfig);
    if (store?.state.authInfo?.token == '') {
        store.commit('CLEAR_AUTH_INFO', {});
        this.$router.push('/login');
        return;
    }
    config.headers = {
        'Content-Type': 'multipart/form-data',
        Authorization: `Bearer ${store.state.authInfo.token}`,
    };
    let formData = new FormData();
    formData.append('file', file);
    if (Object.keys(params).length) {
        Object.keys(params).forEach((key) => {
            formData.append(key, params[key]);
        });
    }
    const fly = new Fly();
    return fly.post(config.baseURL + url, formData, config);
}

export default postFile;
