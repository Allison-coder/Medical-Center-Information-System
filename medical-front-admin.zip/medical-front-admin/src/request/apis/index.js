import request from '../index';
import BASEAPI from './base';
import CONTENTAPI from './content'
export class APIS {
    constructor() {
        this.baseApis = new BASEAPI(request);
        this.contentApis = new CONTENTAPI(request);
    }
}

const api = new APIS();
export default api;
