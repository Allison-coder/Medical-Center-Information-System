export default class BASEAPI {
  constructor(request) {
    this.request = request;
  }
  /**登录 */
  getMerchantInfo(params) {
    return this.request.post("/params/photoApi/getMerchantInfo", params);
  }

  /**登录模块 */
  // 获取验证码图片
  getCaptchaImage(params) {
    return this.request.post("/v1/sys/captcha/getCaptchaImage", params);
  }
  // 点击登录
  loginClick(params) {
    return this.request.post("/v1/auth/login", params);
  }
  // 获取用户信息
  accountInformation(params, config) {
    return this.request.post("/v1/auth/profile", params, config);
  }
  logout(params, config) {
    return this.request.post("/v1/auth/logout", params, config);
  }
  updatePassword(params) {
    return this.request.post("/v1/auth/updatePassword", params);
  }

  /**工作面板模块 */
  // 获取指定日期预约的患者列表
  getPatientSchedule(params) {
    return this.request.get("/panel/manage/getPatientSchedules", params);
  }
  // 获取处置方案的配置信息
  getPlanProjectConfig(params) {
    return this.request.get("/panel/manage/getPlanProjectConfig", params);
  }


  // 根据患者编号获取订单编号集合
  getOrderSnList(patientSn) {
    return this.request.get(
      `/panel/manage/getOrderSnsByPatientSn/${patientSn}`
    );
  }
  // 根据订单号查询主诉和诊断
  getChiefComplaintAndDiagnosis(orderSn) {
    return this.request.get(
      `/panel/manage/getChiefComplaintAndDiagnosis/${orderSn}`
    );
  }

  // 保存诊疗记录的 管理员和医护人员的记录
  saveTreatmentRecordNotes(params) {
    return this.request.post(`/panel/manage/saveTreatmentRecordNotes`, params);
  }

  // 保存患者资料
  savePatientBasicInfo(params) {
    return this.request.post("/panel/manage/savePatientBasicInfo", params);
  }
  // 新增或修改患者信息
  createOrUpdatePatient(params) {
    return this.request.post("/patient/manage/createOrUpdatePatient", params);
  }

  // 保存病历资料
  saveOutpatientMedicalRecord(params) {
    return this.request.post(
      "/panel/manage/saveOutpatientMedicalRecord",
      params
    );
  }
  // 保存面诊记录
  saveInterviewRecords(params) {
    return this.request.post("/panel/manage/saveInterviewRecords", params);
  }

  // 获取诊疗记录的人员记录查看 根据诊疗记录id获取 管理员和医护人员的记录
  getTreatmentRecordNotes(params) {
    return this.request.get("/panel/manage/getTreatmentRecordNotes/" + params);
  }

  // 获取面诊治疗方案配置项
  treatmentPlanConfig() {
    return this.request.get("/patient/manage/treatmentPlanConfig");
  }

  /**排班管理 */
  // 角色人员列表
  getRoleList(params) {
    return this.request.get("/schedule/manage/roleLUserList", params);
  }
  // 批量设置排班
  manageSchedule(params) {
    return this.request.post("/schedule/manage/batchAddSchedule", params);
  }
  // 排班列表
  getScheduleList(params) {
    return this.request.get("/schedule/manage/list", params);
  }

  // 单日期排班
  editSchedule(params) {
    return this.request.post("/schedule/manage/editSchedule", params);
  }

  /**人员管理模块 */
  // 获取人员管理列表
  getPeopleList(params) {
    return this.request.get("/admin/manage/list", params);
  }
  // 新增账号
  addAccount(params) {
    return this.request.post("/admin/manage/add", params);
  }
  // 获取角色
  getRoleLists(params) {
    return this.request.get("/admin/manage/getAllRoles", params);
  }
  // 获取人员信息
  searchAccount(params) {
    return this.request.get(`/admin/manage/getAdminUser/${adminId}`, params);
  }
  // 保存人员信息
  savePeopleInformation(params) {
    return this.request.post("/admin/manage/saveInfo", params);
  }
  // 头像fileKey
  uploadFile(params) {
    return this.request.get("/upload/sign", params);
  }
  // 删除账号
  deleteAccount(adminId) {
    return this.request.post(`/admin/manage/delAdminUser/${adminId}`);
  }
  // 编辑账号
  editAccount(params) {
    return this.request.post("/admin/manage/edit", params);
  }
  // 设置首页是否展示
  isHomeShow(params) {
    return this.request.post("/admin/manage/homeShow", params);
  }
  // 获取首页展示的人员
  getHomeShowList(adminId) {
    return this.request.get(`
    /admin/manage/getHomeShow/${adminId}`);
  }
  // 保存首页展示位置
  saveHomeShow(params) {
    return this.request.post("/admin/manage/saveHomeShow", params);
  }

  /**订单管理模块 */
  // 获取订单信息
  getOrderList(params) {
    return this.request.get("/order/manage/getOrders", params);
  }

  // 获取治疗单详细
  getTherapyOrders(params) {
    return this.request.get(`/panel/manage/getTherapyOrders/${params}`);
  }

  // 修改价格
  updateOrderPrice(params) {
    return this.request.post("/order/manage/modifyPrice", params);
  }
  // 治疗单调价
  modifyZlOrderPrice(params) {
    return this.request.post("/order/manage/modifyZlOrderPrice", params);
  }

  // 退款金额查询
  getRefundAmount(params) {
    return this.request.get("/order/manage/getRefundAmount", params);
  }

  // 申请退款
  applyRefund(params) {
    return this.request.post("/order/manage/refund", params);
  }
  // 取消订单
  cancelOrder(params) {
    return this.request.post("/order/manage/cancelOrder", params);
  }
  // 创建订单
  createOrder(params) {
    return this.request.post("/order/manage/createOrder", params);
  }

  /**患者管理模块 */

  // 通过订单编号取消预约
  cancleAppiont(params) {
    return this.request.get(`/patient/manage/cancleAppiont/${params}`);
  }

  // 患者列表
  getPatientList(params) {
    return this.request.get("/patient/manage/list", params);
  }

  // 患者报道
  reportPatient(params) {
    return this.request.post("/patient/manage/operateMedical", params);
  }

  /**患者资料模块 */
  // 获取患者资料
  getPatientInformation(params) {
    return this.request.get(`/patient/manage/getPatientDetail/${params}`);
  }
  // 获取支付接口
  getMerchantPayWayDetail(params) {
    return this.request.get("/pay/merchantPayWayDetail", {
      ...params,
      _formType: true,
    });
  }
  WeiXinQrcodePay(params) {
    return this.request.post("/paramsPay/pay", {
      ...params,
      _formType: true,
    });
  }
  // 合并治疗订单
  mergePay(params) {
    return this.request.post("/paramsPay/mergePay", {
      ...params,
      // _formType: true,
    });
  }

  // 确认预约
  confirmAppointment(params) {
    return this.request.post("/patient/manage/confirmAppointment", params);
  }

  // 初始化门诊病历配置项
  getClinicCaseConfig() {
    return this.request.get("/patient/manage/clinicCaseConfig");
  }

  /**优惠券模块 */

  // 优惠券活动列表
  getCouponsList(params) {
    return this.request.get("/promotion/manage/list", params);
  }

  // 根据 id删除活动
  delActivity(params) {
    return this.request.get(`/promotion/manage/del/${params}`);
  }

  // 根据 id删除优惠券
  delPromoCouponTemp(params) {
    return this.request.post("/promotion/manage/delPromoCouponTemp", params);
  }

  // 根据 id 查询活动详情信息
  getActivityDetail(params) {
    return this.request.get(`/promotion/manage/details/${params}`);
  }
  // 根据 id 生成活动二维码
  getActivityQRCode(id) {
    return this.request.get(`/promotion/manage/generateQRCode/${id}`);
  }
  // 根据 id 生成活动链接
  getActivityLink(id) {
    return this.request.get(`/promotion/manage/copyLink/${id}`);
  }

  // 活动领取条件
  gettingCondition() {
    return this.request.get("/promotion/manage/gettingCondition");
  }

  //创建优惠券的 获取治疗项目

  getPlanProjectConfigActivity(params) {
    return this.request.get("/planproject/manage/getPlanProjectConfig", params);
  }

  // 创建或修改活动
  createOrUpdateActivity(params) {
    return this.request.post("/promotion/manage/createOrUpdate", params);
  }
  // 导入指定用户表格
  importExcel(params) {
    return this.request.post("/promotion/manage/importExcel", {
      ...params,
      _formData: true,
    });
  }
  //指定用户模板下载
  getTemplate() {
    return this.request.get("/promotion/manage/download/template", {});
  }

  // v1.5患者当前未完成任务列表 patientSn
  getPatientWorkPanel(params) {
    return this.request.get(
      `/patient/manage/getPatientWorkPanel/${params.patientSn}`,
      params
    );
  }

  // V1.5 预约新治疗 可直接预约的项目
  addNewTreatment(params) {
    return this.request.post("/patient/manage/addNewTreatment", params);
  }

  // 处置方案-列表
  getDisposalPlanList(patientSn) {
    return this.request.get(
      `/panel/manage/getDisposalPlanList/${patientSn}`,
      {}
    );
  }
  // 处置方案-创建新方案按钮
  createNewDisposalPlan(patientSn) {
    return this.request.get(
      `/panel/manage/createNewDisposalPlan/${patientSn}`,
      {}
    );
  }
  // 处置方案-保存方案
  saveDisposalPlan(params) {
    return this.request.post(`/panel/manage/saveDisposalPlan`, {
      ...params,
    });
  }
  // 处置方案-开具方案
  openDisposalPlan(id) {
    return this.request.get(`/panel/manage/openDisposalPlan/${id}`, {});
  }
  // 处置方案-取消治疗方案
  cancelDisposalPlan(id) {
    return this.request.get(`/panel/manage/cancelDisposalPlan/${id}`, {});
  }

  // 处置方案-新增方案-添加次数
  addDisposalPlanTimes(id) {
    return this.request.get(`/panel/manage/addDisposalPlanTimes/${id}`, {});
  }
  // 处置方案-新增方案-删除次数
  delDisposalPlanNum(id) {
    return this.request.post(`/panel/manage/delDisposalPlanNum/${id}`, {});
  }

  // 处置方案-新增方案-次数--项目添加
  saveDisposalPlanItem(params) {
    return this.request.post("/panel/manage/saveDisposalPlanItem", {
      ...params,
    });
  }

  // 处置方案-新增方案-次数--项目删除
  delDisposalPlanItem(id) {
    return this.request.post(`/panel/manage/delDisposalPlanItem/${id}`, {});
  }

  // 处置方案-合并治疗订单按钮
  mergeDisposalPlan(id) {
    return this.request.get(`/panel/manage/mergeDisposalPlan/${id}`, {});
  }
  // 处置方案-合并治疗订单确认按钮
  mergeDisposalPlanConfirm(params) {
    return this.request.post(`/panel/manage/mergeDisposalPlanConfirm`, {
      ...params,
    });
  }

  // 获取就诊记录
  getMedicalRecord(id) {
    return this.request.get(`/panel/manage/getMedicalRecord/${id}`, {});
  }
  // 获取治疗师陈述
  getTTherapistStatement(id) {
    return this.request.get(`/panel/manage/getTTherapistStatement/${id}`, {});
  }
  // 更新治疗师陈述
  saveTherapistStatement(params) {
    return this.request.post(`/panel/manage/saveTherapistStatement`, {
      ...params,
    });
  }
  // 面诊记录发布
  releaseOrHideInterviewRecords(params) {
    return this.request.post(`/panel/manage/releaseOrHideInterviewRecords`, {
      ...params,
    });
  }
  // V1.5.1 新开接口 根据患者编号修改姓名和手机号
  updatePatientAccount(params) {
    return this.request.post(`/patient/manage/updatePatientAccount`, {
      ...params,
    });
  }
  // v1.6新开接口 打印治疗单
  printTreatOrder(id) {
    return this.request.get(`/panel/manage/printTreatOrder/${id}`, {});
  }
  // v1.6新开接口 复用项目
  copyDisposalPlanItem(params) {
    return this.request.post(`/panel/manage/copyDisposalPlanItem`, {
      ...params
    });
  }
}


