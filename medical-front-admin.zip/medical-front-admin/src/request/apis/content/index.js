export default class BASEAPI {
  constructor(request) {
    this.request = request;
  }

  getBanners(params) {
    return this.request.get(`/science/manage/getBanners`, params);
  }
  updateBanners(params) {
    return this.request.post(`/science/manage/updateBanners`, params);
  }

  getCategories(params) {
    return this.request.get(`/science/manage/getCategories`, params);
  }
  updateCategories(params) {
    return this.request.post(`/science/manage/updateCategories`, params);
  }

  getRecords(params) {
    return this.request.get(`/science/manage/getRecords`, params);
  }
  createOrUpdateRecord(params) {
    return this.request.post("/science/manage/createOrUpdateRecord", params);
  }

  deleteRecord(id) {
    return this.request.post(`/science/manage/deleteRecord/${id}`, {});
  }
  updateShow(params) {
    return this.request.post(`/science/manage/updateShow`, params);
  }
}
