const config = {
  headers: {
    "Content-Type": "application/x-www-form-urlencoded",
  },
  parseJson: true,
  baseURL: process.env.VUE_APP_API_HOST,
  // baseURL: 'http://172.16.100.30:8301/',
  // baseURL: "http://172.16.100.155:8301",
  timeout: 1000 * 5 * 60, //超时改为5分钟
  withCredentials: false, // 跨域时是否发送cookie
};

export default config;
