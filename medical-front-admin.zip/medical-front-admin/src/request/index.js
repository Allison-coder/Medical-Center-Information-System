import flyIO, { FlyResponse } from "flyio";
import config from "./config";
import cloneDeep from "lodash/cloneDeep";
import Vue from "vue";
import store from "../store/index";
import router from "@/router";
// 使用自定义配置
flyIO.config = config;
flyIO.interceptors.request.use((request) => {
  if (store?.state.authInfo?.token) {
    request.headers.Authorization = `Bearer ${store.state.authInfo.token}`;
    request.headers.token = `${store.state.authInfo.token}`;
  }
  if (!(request.body instanceof FormData)) {
    request.body = cloneDeep(request.body);
    const body = request.body || {};
    Object.entries(body).forEach(([key]) => {
      if (body[key] === undefined || body[key] === null) {
        delete body[key];
      }
    });
    if (request.method.toUpperCase() === "POST") {
      request.headers["Content-Type"] = "application/json";
    }
    if (body._formType) {
      request.headers["Content-Type"] = "application/x-www-form-urlencoded";
      delete body._formType;
    }
    if (body._formData) {
      request.headers["Content-Type"] = "multipart/form-data";
      delete body._formData;
    }
  }
  return request;
});
flyIO.interceptors.response.use(
  (response) => {
    if (response.data.code === 200) {
      return response.data;
    }
    if (response.data.code === 2001401) {
      store.commit("CLEAR_AUTH_INFO");
      router.push("/login");
      Vue.prototype.ElMessage({
        type: "error",
        message: "登录失效，请重新登录！",
      });
      return;
    }
    if (!response.request?.ignoreTost) {
      Vue.prototype.ElMessage({
        type: "error",
        message: response.data.message,
      });
    }
    return Promise.reject(response.data.message);
  },
  (error) => {
    Vue.prototype.ElMessage({
      type: "error",
      message: "网络错误，请稍后重试！",
    });
    return Promise.reject(error);
  }
);

export default flyIO;
