const Version = new Date().getTime()
module.exports = {
  // baseUrl: '/moneyBack',
  publicPath: "/medical-admin",
  outputDir: "dist",
  css: {
    extract: true,
  },
  configureWebpack: {
    output: {
      filename: `js/[name].${Version}.js`,
      chunkFilename: `js/[name].${Version}.js`
    },
  },
  devServer: {
    client: {
      //当出现编译错误或警告时，在浏览器中是否显示全屏覆盖。  示例为只显示错误信息
      overlay: {
        runtimeErrors: false,
      },
    },
  },
};
