package com.params.rest.controller;

import com.params.rest.WithSpringTestBase;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@AutoConfigureMockMvc
public class BaseController extends WithSpringTestBase {
    @Autowired
    protected WebApplicationContext webApplicationContext;

    @Resource
    protected MockMvc mockMvc;

    @Before("")
    public void setUp() throws Exception {
        System.out.println("------------start----------------");
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    public String post(String url, String body) throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
                        .post(url)
                                .header("appid", "cs023b12c900461d25")
//                        .header("token", "73647d113db33a5a284f4f2054c7d554")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
//                .andDo(print())
                .andReturn();
        return mvcResult.getResponse().getContentAsString();
    }

    public String get(String url) throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
                        .get(url)
                        .header("appid", "cs023b12c900461d25")
//                       .header("token", "73647d113db33a5a284f4f2054c7d554")
                        .contentType(MediaType.APPLICATION_JSON))
//                .andDo(print())
                .andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
