package com.params.rest.mq;

import cn.hutool.core.map.MapUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.asymmetric.Sign;
import cn.hutool.crypto.asymmetric.SignAlgorithm;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.StreamUtil;
import com.alipay.api.internal.util.StringUtils;
import com.alipay.api.internal.util.codec.Base64;
import com.google.common.collect.Lists;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class CheckPayStatusMsgReceiverTest {

    private static long nextTimes[] = new long[]{1, 3, 5, 8, 10, 15, 1, 3, 5, 8, 10, 15, 30, 60, 2 * 60, 2 * 60, 2 * 60, 5 * 60, 5 * 60};

    @Test
    void test_name() {
        System.out.println(nextTimes.length);
    }

    @Test
    void testName() {
        JSONObject params = new JSONObject() {{
            put("appId", "dsfsdf");
        }};

        params.put("grantType", "auth_code");
        params.put("authCode", "sdaa");

        Map<String, Object> header = new HashMap() {{
            put("version", "1.0");
            put("charset", "UTF-8");
            put("method", "amap.openapi.oauth.token");
//            put("sign_type", "RSA2");
            put("app_id", "bfndsnfsodj");
        }};
        header.put("biz_content", params);
        System.out.println(header);
//        String paramsStr = MapUtil.sortJoin(params, "&", "=", false);
//        System.out.println(paramsStr);
        String initSign = MapUtil.sortJoin(header, "&", "=", false);
        System.out.println(initSign);

        String signData = getSignData(header);
        System.out.println(signData);

//        try {
//            String sign = rsa256Sign(signData, "asdas", "UTF-8");
//            System.out.println(sign);
//        } catch (AlipayApiException e) {
//            throw new RuntimeException(e);
//        }

        Sign sign = SecureUtil.sign(SignAlgorithm.NONEwithRSA);
        byte[] signed = sign.sign(initSign.getBytes());
        System.out.println(signed);
    }

    public static String getSignData(Map<String, Object> params) {
        List<String> keys = Lists.newArrayList(params.keySet());
        Collections.sort(keys);
        StringBuffer buffer = new StringBuffer();
        Object value;
        for (String key : keys) {
            value = params.get(key);
            if (Objects.isNull(value) || "".equals(value)) {
                continue;
            }
            value = value == null ? "" : value;
            value = value instanceof String ? value : String.valueOf(value);
            buffer.append(key).append("=").append(value).append("&");
        }
        String s = buffer.toString();
        String substring = s.substring(0, s.length() - 1);
//        log.info("参与签名的参数：{}", substring);
        return substring;
    }

    public static String rsa256Sign(String content, String privateKey, String charset) throws AlipayApiException {
        try {
            PrivateKey priKey = getPrivateKeyFromPKCS8("RSA", new ByteArrayInputStream(privateKey.getBytes()));
            java.security.Signature signature = java.security.Signature
                    .getInstance("SHA256WithRSA");
            signature.initSign(priKey);
            if (StringUtils.isEmpty(charset)) {
                signature.update(content.getBytes());
            } else {
                signature.update(content.getBytes(charset));
            }
            byte[] signed = signature.sign();
            return new String(Base64.encodeBase64(signed));
        } catch (Exception e) {
            throw new AlipayApiException("RSAcontent = " + content + "; charset = " + charset, e);
        }
    }

    public static PrivateKey getPrivateKeyFromPKCS8(String algorithm, InputStream ins) throws Exception {
        if (ins == null || StringUtils.isEmpty(algorithm)) {
            return null;
        }
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        byte[] encodedKey = StreamUtil.readText(ins).getBytes();
        encodedKey = Base64.decodeBase64(encodedKey);
        return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(encodedKey));
    }
}