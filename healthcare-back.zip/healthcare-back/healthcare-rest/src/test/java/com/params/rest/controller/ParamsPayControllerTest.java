package com.params.rest.controller;

import com.alibaba.fastjson.JSONObject;
import com.params.service.ParamsPayService;
import com.params.utils.UserSecurityContextHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@ActiveProfiles("local")
class ParamsPayControllerTest extends BaseController {

    @Autowired
    private ParamsPayService paramsPayService;

    @Test
    void testPay() {
        String tradeNum = "240613151033702928247";
        String paymentType = "WEIXIN_APP_PAY";
        Boolean res = paramsPayService.checkPayOrderStatus(tradeNum, paymentType);
        System.out.println(res);
    }

    @BeforeAll
    static void beforeAll() {
        MockedStatic<UserSecurityContextHolder> mock = Mockito.mockStatic(UserSecurityContextHolder.class);
        mock.when(UserSecurityContextHolder::getUserId).thenReturn(5);
        mock.when(UserSecurityContextHolder::getChannelId).thenReturn(1);
    }

    @Test
    void test_should_result_success_while_weixin_app_pay() throws Exception {
        String url = "/paramsPay/pay?orderNum=GH2024051710493567136231&subject=test&paymentType=WEIXIN_APP_PAY";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void test_should_result_success_while_weixin_qrcode_pay() throws Exception {
        String url = "/paramsPay/pay?orderNum=ZL2024052211193282632297&subject=test&paymentType=WEIXIN_QRCODE_PAY";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void test_should_result_success_while_merchantPayWayDetail() throws Exception {
        String url = "/pay/merchantPayWayDetail?source=H5";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }
}