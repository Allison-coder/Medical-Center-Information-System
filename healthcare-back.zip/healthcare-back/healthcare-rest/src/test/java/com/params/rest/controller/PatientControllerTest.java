package com.params.rest.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.params.common.CacheService;
import com.params.entity.User;
import com.params.service.UserService;
import com.params.utils.UserSecurityContextHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;

import javax.annotation.Resource;

@ActiveProfiles("local")
class PatientControllerTest extends BaseController {

    @Resource
    private CacheService cacheService;

    @Resource
    private UserService userService;

    @Test
    void should_result_exception_while_create_patient_with_empty_body() throws Exception {
        String url = "/patient/createPatient";
        String body = "{}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2001400);
    }

    @Test
    void should_result_fail_while_create_patient_with_has_not_idcard_and_isAduit() throws Exception {
        String url = "/patient/createOrUpdatePatient";
        String body = "{\"identityType\":0,\"name\":\"永远18\",\"phoneNumber\":\"13727147258\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2002007);
        Assertions.assertThat(result.getString("message")).isEqualTo("成年人必须上送身份证！");
    }

    @Test
    void should_result_success_while_create_patient_with_isAduit() throws Exception {
        String url = "/patient/createOrUpdatePatient";
        String body = "{\"age\":\"\",\"avatarUrl\":\"\",\"gender\":1,\"idCardNumber\":\"440923199909099999\",\"identityType\":0,\"maritalStatus\":1,\"name\":\"李大龙\",\"occupation\":\"\",\"patientSn\":\"24062810472090677300\",\"phoneNumber\":\"13794578785\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_success_while_update_patient() throws Exception {
        String url = "/patient/createOrUpdatePatient";
        String body = "{\"identityType\":0,\"name\":\"永远18\",\"phoneNumber\":\"13727147258\",\"idCardNumber\":\"441802199912301234\"," +
                "\"occupation\":\"新时代农民工\",\"maritalStatus\":1,\"gender\":1,\"age\":18,\"fileKey\":\"tmp/2024/05/591d3fc7f5dc2f4449ba984d6454f467cf3\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_query_current_userid() throws Exception {
        String url = "/patient/getPatients";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @BeforeAll
    static void beforeAll() {
        MockedStatic<UserSecurityContextHolder> mock = Mockito.mockStatic(UserSecurityContextHolder.class);
        mock.when(UserSecurityContextHolder::getUserId).thenReturn(1);
        mock.when(UserSecurityContextHolder::getChannelId).thenReturn(1);
    }
}