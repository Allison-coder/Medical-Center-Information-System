package com.params.rest.controller;

import com.alibaba.fastjson.JSONObject;
import com.params.utils.UserSecurityContextHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;

/**
 * @DESCRIPTION 查排班表的测试运例
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@ActiveProfiles("liam")
public class ScheduleControllerTest extends BaseController{
    @BeforeAll
    static void beforeAll() {
        MockedStatic<UserSecurityContextHolder> mock = Mockito.mockStatic(UserSecurityContextHolder.class);
        mock.when(UserSecurityContextHolder::getUserId).thenReturn(1);
        mock.when(UserSecurityContextHolder::getChannelId).thenReturn(1);
    }

    @Test
    void getScheduleTime() throws Exception {
        String url = "/schedule/getScheduleTime?date=2024-06-27";
        JSONObject result = JSONObject.parseObject(get(url));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

}
