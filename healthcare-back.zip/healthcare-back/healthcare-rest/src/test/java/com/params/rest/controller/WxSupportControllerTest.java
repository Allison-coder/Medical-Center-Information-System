package com.params.rest.controller;

import com.alibaba.fastjson.JSONObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.params.application.support.wx.MsgReqProcess;
import com.params.application.support.wx.MsgReqProcessFactory;
import com.params.application.support.wx.WxSupportService;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@ActiveProfiles("local")
class WxSupportControllerTest extends BaseController {
    @Autowired
    private WxSupportService wxSupportService;

    @Test
    void test_bind() throws Exception {
        String url = "/wxSupport/access";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
//        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }
    @Test
    void test_processAccess() throws Exception {
        WxReqBO wxReqBO = new WxReqBO();
        WxConfigBO wxConfigBO = new WxConfigBO();
        wxConfigBO.setAppId("wxa7beeb7586e0a3c8");
        wxConfigBO.setSecret("ed4d75ee8c727ce81a540b342d3e7640");
//        wxSupportService.handleSubscribe(wxReqBO, wxConfigBO, null);

//        boolean windows = FileUtil.isWindows();
//        String windowsTmpPath = "C:\\Users\\hjz\\Desktop\\test_data\\test\\";
//        String linuxTmpPath = "/tmp/";
//        String path = linuxTmpPath;
//        if (windows) {
//            path = windowsTmpPath;
//        }
//        if (!FileUtil.exist(path)) {
//            FileUtil.mkdir(path);
//        }
//        String qrCodeData = "6"; // 要转换的字符串
//        String fileName = RandomUtil.randomFileName() + ".png";
////        String filePath = "C:\\Users\\hjz\\Desktop\\test_data\\qrcode.png"; // 保存二维码图片的路径
//        String filePath = path + fileName;
//        int qrCodeHeight = 300; // 二维码高度
//        int qrCodeWidth = 300; // 二维码宽度
//
//        try {
//            generateQRCode(qrCodeData, filePath, qrCodeWidth, qrCodeHeight);
//            System.out.println("QR Code image created successfully!");
//        } catch (WriterException | IllegalArgumentException e) {
//            System.err.println("Could not generate QR Code: " + e.getMessage());
//        }
//        // 删除临时文件
//        if (FileUtil.exist(filePath)) {
//            FileUtil.del(filePath);
//        }
    }

    public static void generateQRCode(String qrCodeData, String filePath, int qrCodeHeight, int qrCodeWidth)
            throws WriterException, IllegalArgumentException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(
                new String(qrCodeData.getBytes(StandardCharsets.UTF_8)),
                BarcodeFormat.QR_CODE, qrCodeWidth, qrCodeHeight);

        Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<>();
        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
        MatrixToImageWriter.writeToPath(bitMatrix, "PNG", Paths.get(filePath));
    }

    @Test
    void test_create_code() throws Exception {
        String url = "/wxSupport/qrCode?appId=wxa7beeb7586e0a3c8&secret=ed4d75ee8c727ce81a540b342d3e7640&params=test";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
//        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Autowired
    private MsgReqProcessFactory msgReqProcessFactory;
    @Test
    void testService() {
        // <CreateTime>1717126731</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[1]]></Content><MsgId>24583344133970455</MsgId></xml>
        WxReqBO wxReqBO = new WxReqBO().setToUserName("gh_d13fa534d8f1").setFromUserName("oqwQ7v4rrYZHAe8toYMBCl8HYbVk")
                .setCreateTime("1717033046").setMsgType("event").setEvent("subscribe")
                .setEventKey("code=152653215")
        ;

//        WxReqBO wxReqBO = new WxReqBO().setToUserName("gh_d13fa534d8f1").setFromUserName("oqwQ7v4rrYZHAe8toYMBCl8HYbVk")
//                .setCreateTime("1717033046").setMsgType("text").setContent("1");

        WxConfigBO wxConfigBO = new WxConfigBO()
                .setAppId("wxa7beeb7586e0a3c8")
                .setSecret("ed4d75ee8c727ce81a540b342d3e7640")
                .setAccessToken("33925ba85971c2c8")
                .setEncodingAESKey("9yBkw8JfhyPgZvEJNydI89ZE1qEnMlDZlB5m1AzSDfd")
                .setOfficialCode("gh_d13fa534d8f1");
        OfficialAccount account = new OfficialAccount();
        account.setStrategy("COUPON");
        account.setResultMsgType("news");
        account.setConfig("{\"url\": \"\", \"title\": \"优惠券二维码\", \"picUrl\": \"\", \"description\": \"到店出示此二维码，即可获得优惠价格！\"}");
        account.setExtConfig("{\n" +
                "\"qrcode\":{\"width\": 500, \"height\": 500},\n" +
                "\"msgType\":\"image\",\n" +
                "\"text\":{\"content\":\"感谢关注\"},\n" +
                "\"image\":{\"mediaId\":\"zIdJDNL1G5D_g8dP3clMdidZQFbZMeCorF2JIrO04C5HPmDzPWv3W0ukG4hIT35G\"}" +
                "}");
        MsgReqProcess msgReqProcess = msgReqProcessFactory.getMsgReqProcess(wxReqBO, account);
        System.out.println("====result: " + msgReqProcess);

        BaseMsg msg = msgReqProcess.handle(wxReqBO, wxConfigBO, account);
        System.out.println(msg);
    }
}