package com.params.rest.controller;

import com.alibaba.fastjson.JSONObject;
import com.params.utils.UserSecurityContextHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("local")
class PortalControllerTest extends BaseController {

    @BeforeAll
    static void beforeAll() {
        MockedStatic<UserSecurityContextHolder> mock = Mockito.mockStatic(UserSecurityContextHolder.class);
        mock.when(UserSecurityContextHolder::getUserId).thenReturn(1);
        mock.when(UserSecurityContextHolder::getChannelId).thenReturn(1);
    }

    //    @Test
    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2, 3})
    void getFamousDoctors(Integer pageNum) throws Exception {
        String url = "/portal/getFamousDoctors?pageSize=1&pageNum=" + pageNum;
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }
}