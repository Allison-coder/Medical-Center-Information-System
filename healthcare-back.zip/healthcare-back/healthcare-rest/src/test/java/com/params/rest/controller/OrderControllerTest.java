package com.params.rest.controller;

import com.alibaba.fastjson.JSONObject;
import com.params.utils.UserSecurityContextHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;

import static com.params.utils.UserSecurityContextHolder.getUserId;

@ActiveProfiles("local")
class OrderControllerTest extends BaseController {

    @Test
    void should_result_2001400_while_create_order_with_empty_body() throws Exception {
        String url = "/order/createOrder";
        String body = "{}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2001400);
        Assertions.assertThat(result.getString("message")).isEqualTo("工作人员ID参数不能为空");
    }

    @Test
    void should_result_ordersn_while_create_order_with_guahao() throws Exception {
        String url = "/order/createOrder";
        String body = "{\"patientSn\":\"202464899454\",\"scheduleDetailId\":2,\"adminId\":4,\"orderType\":\"GH\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_get_unfinished_orders() throws Exception {
        String url = "/order/getUnfinishedOrders";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_get_orders() throws Exception {
        String url = "/order/getOrders";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_cancel_orders_not_exists() throws Exception {
        String url = "/order/cancelOrder";
        String body = "{\"orderSn\":\"111\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2002007);
        Assertions.assertThat(result.getString("message")).contains("不存在此订单");
    }

    @Test
    void should_result_while_cancel_orders() throws Exception {
        String url = "/order/cancelOrder";
        String body = "{\"orderSn\":\"ZL2024052210390368059404\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_get_order_by_orderSn() throws Exception {
        String url = "/order/getOrderByOrderSn?orderSn=ZL2024052211290180949187";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @BeforeAll
    static void beforeAll() {
        MockedStatic<UserSecurityContextHolder> mock = Mockito.mockStatic(UserSecurityContextHolder.class);
        mock.when(UserSecurityContextHolder::getUserId).thenReturn(1);
        mock.when(UserSecurityContextHolder::getChannelId).thenReturn(1);
    }
}