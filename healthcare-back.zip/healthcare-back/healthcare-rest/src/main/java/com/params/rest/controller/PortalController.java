package com.params.rest.controller;

import com.params.application.adminuser.HomeInfoApp;
import com.params.framework.vo.R;
import com.params.pojo.vo.FamousDoctorVO;
import com.params.pojo.vo.ScienceRecordVO;
import com.params.pojo.vo.common.PageVO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.component.config.ConfigProcessDTO;
import com.params.rest.component.config.service.ProcessService;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 * @Create 2024/1/6
 */
@Api(tags = "门户接口")
@RestController
public class PortalController {

    @Qualifier("homepageProcessServiceImpl")
    @Resource
    private ProcessService homepageProcessServiceImpl;

    @Autowired
    private HomeInfoApp homeInfoApp;

    @ApiOperation("获取首页配置")
    @PostMapping("/v1/portal/getHomepage")
    @VerifyLogin(verifyLogin = false)
    public R<Object> getHomepage(HttpServletRequest request) {
        ConfigProcessDTO dto = new ConfigProcessDTO();
        dto.setRequest(request);
        dto.setLoginInfo(UserSecurityContextHolder.getCurrentUser());
        return R.success(homepageProcessServiceImpl.build(dto));
    }

    @ApiOperation("获取名医介绍")
    @GetMapping("/portal/getFamousDoctors")
    @VerifyLogin(verifyLogin = false)
    public R<PageVO<FamousDoctorVO>> getFamousDoctors(@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
                              @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum) {
        PageVO<FamousDoctorVO> famousDoctors = homeInfoApp.getFamousDoctors(UserSecurityContextHolder.getChannelId(), pageNum, pageSize);
        return R.success(famousDoctors);
    }

    @ApiOperation("获取科普知识")
    @GetMapping("/portal/getSciences")
    @VerifyLogin(verifyLogin = false)
    public R<PageVO<ScienceRecordVO>> geSciences(@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
                                                      @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum) {
        PageVO<ScienceRecordVO> scienceRecords = homeInfoApp.getScienceRecords(UserSecurityContextHolder.getChannelId(), pageNum, pageSize);
        return R.success(scienceRecords);
    }
}
