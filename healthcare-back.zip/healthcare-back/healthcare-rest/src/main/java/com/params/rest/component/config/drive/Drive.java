package com.params.rest.component.config.drive;

import com.alibaba.fastjson.JSONObject;
import com.params.rest.pojo.vo.CityVO;

/**
 * <pre>
 * 解析驱动
 *
 * </pre>
 *
 * @version 1.0.0
 */
public interface Drive {

    /**
     * 解析内容
     *
     * @return
     */
    Object parse();

    /**
     * 解析内容
     *
     * @param content
     * @param setting
     * @return
     */
    Object parse(Object content, JSONObject setting);

    void setCity(CityVO city);

    void setDriveFactory(DriveFactory driveFactory);
}
