package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/14
 */
@Getter
@Setter
@ApiModel("找回物流订单 DTO")
public class OrderTraceGetDTO {


    @ApiModelProperty(value = "orderId", example = "1")
    @NotNull(message = "参数不能为空")
    private Long orderId;
}
