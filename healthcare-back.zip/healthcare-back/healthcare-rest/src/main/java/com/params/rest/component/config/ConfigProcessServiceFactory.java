package com.params.rest.component.config;

import cn.hutool.core.thread.GlobalThreadPool;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.CaseFormat;
import com.params.common.CacheService;
import com.params.entity.User;
import com.params.pojo.dto.CityGetCityInfoDTO;
import com.params.pojo.dto.ConfigDTO;
import com.params.rest.component.config.service.ProcessService;
import com.params.service.CityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Slf4j
@Component
public class ConfigProcessServiceFactory {

    @Autowired
    private Map<String, ProcessService> context = new ConcurrentHashMap<>();

    @Qualifier("defaultProcessServiceImpl")
    @Autowired
    private ProcessService defaultProcessService;

    @Autowired
    private CityService cityService;

    @Autowired
    private CacheService cacheService;

    public ProcessService getConfigProcessService(String type) {
        String key = StrUtil.format("{}ProcessServiceImpl", CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, type));
        return context.get(key);
    }

    public Object run(HttpServletRequest request, ConfigDTO dto) {
        CityGetCityInfoDTO infoDTO = new CityGetCityInfoDTO();
        infoDTO.setCityId(dto.getCityId());
        infoDTO.setCityName(dto.getCityName());
        infoDTO.setLongitude(dto.getLongitude());
        infoDTO.setLatitude(dto.getLatitude());
//        CityVO city = cityService.getCityInfo(infoDTO);

//        CmsUser user = cacheService.getUserByToken(UserSecurityContextHolder.getToken());
        User user = null;


        Map<String, Object> result = new HashMap<>();

        if (dto.getCodes().entrySet().size() > 1) {
            List<Future<Map<String, Object>>> futures = new ArrayList<>();

            for (Map.Entry<String, Object> entry : dto.getCodes().entrySet()) {
                if (StrUtil.isBlank(entry.getKey())) continue;

                futures.add(GlobalThreadPool.submit(() -> {
                    JSONObject config = new JSONObject();
                    if (null != entry.getValue()) {
                        if (entry.getValue() instanceof JSONObject) {
                            config = (JSONObject) entry.getValue();
                        } else {
                            config = JSON.parseObject(JSON.toJSONString(entry.getValue()));
                        }
                    }

                    ConfigProcessDTO configProcessDTO = new ConfigProcessDTO();
                    configProcessDTO.setRequest(request);
                    configProcessDTO.setCity(null);
                    configProcessDTO.setUser(user);
                    configProcessDTO.setCode(entry.getKey());
                    configProcessDTO.setConfig(config);
                    return doConfigProcess(configProcessDTO);
                }));
            }

            for (Future<Map<String, Object>> future : futures) {
                try {
                    if (null == future.get()) continue;
                    result.putAll(future.get());
                } catch (InterruptedException | ExecutionException e) {
                    log.warn("[{}.run] 异常", this.getClass().getSimpleName(), e);
                }
            }
        } else {
            try {
                for (Map.Entry<String, Object> entry : dto.getCodes().entrySet()) {
                    JSONObject config = new JSONObject();
                    if (null != entry.getValue()) {
                        if (entry.getValue() instanceof JSONObject) {
                            config = (JSONObject) entry.getValue();
                        } else {
                            config = JSON.parseObject(JSON.toJSONString(entry.getValue()));
                        }
                    }

                    ConfigProcessDTO configProcessDTO = new ConfigProcessDTO();
                    configProcessDTO.setRequest(request);
                    configProcessDTO.setCity(null);
                    configProcessDTO.setUser(user);
                    configProcessDTO.setCode(entry.getKey());
                    configProcessDTO.setConfig(config);
                    result.putAll(doConfigProcess(configProcessDTO));
                }
            } catch (Exception e) {
                log.warn("[{}.run]  异常", this.getClass().getSimpleName(), e);
            }
        }

        return result;
    }

    private Map<String, Object> doConfigProcess(ConfigProcessDTO dto) {
        // 设置语言请求头
        String language = dto.getRequest().getHeader("accept-yuyan");
        if (!StrUtil.isEmpty(language) && language.contains("US")) {
            LocaleContextHolder.setLocale(Locale.US);
        } else {
            LocaleContextHolder.setLocale(Locale.SIMPLIFIED_CHINESE);
        }
        ProcessService processService = getConfigProcessService(dto.getCode());
        if (null == processService) processService = defaultProcessService;
        Map<String, Object> tmp = new HashMap<>();
        tmp.put(dto.getCode(), processService.build(dto));
        return tmp;
    }
}
