package com.params.rest.component.config.drive;

import com.alibaba.fastjson.JSONObject;
import com.params.entity.User;
import com.params.rest.pojo.vo.CityVO;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Getter
@Setter
public class DriveDTO implements Serializable {

    private static final long serialVersionUID = 341812148586538367L;

    private CityVO city;
    private User user;
    private Object content;
    private JSONObject setting;
}
