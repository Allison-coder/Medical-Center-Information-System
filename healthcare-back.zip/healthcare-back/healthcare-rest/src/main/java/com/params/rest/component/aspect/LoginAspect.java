package com.params.rest.component.aspect;

import cn.hutool.core.lang.UUID;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.servlet.ServletUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.params.ErrorCodeEnum;
import com.params.common.CacheService;
import com.params.constant.ValidateUtil;
import com.params.constant.errorcode.UserErrorCodeConstants;
import com.params.entity.Clinic;
import com.params.framework.constant.DeletedStatusEnum;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.LoginInfoBO;
import com.params.service.ClinicService;
import com.params.utils.CurrentServletUtils;
import com.params.utils.UserSecurityContext;
import com.params.utils.UserSecurityContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;

;

@Aspect
@Component
@Order(1)
@Slf4j
public class LoginAspect {


    @Autowired
    private CacheService cacheService;

    @Autowired
    private ClinicService clinicService;


    @Pointcut("execution(public * com.params..controller..*(..))")
    public void loginPointCut() {

    }

    @Before("loginPointCut()")
    public void doBefore(JoinPoint point) {
        MethodSignature signature = (MethodSignature) point.getSignature();
        String methodName = signature.getMethod().getName();
        String className = point.getTarget().getClass().getSimpleName();
        Object[] args = point.getArgs();
        log.debug("Entering in Method: " + className + "." + methodName);
        log.debug("Arguments: " + Arrays.toString(args));

        HttpServletRequest request = CurrentServletUtils.getRequest();
        VerifyLogin verifyToken = getVerifyTokenInstance(point);
        String token = request.getHeader("token");
        String appId = request.getHeader("appId");
        String vid = request.getHeader("vid");
        vid = StrUtil.isBlank(vid) ? UUID.randomUUID().toString(true) : vid;
        // 设置语言请求头
        String language = request.getHeader("accept-yuyan");
        if (StrUtil.isNotBlank(language) && language.contains("US")) {
            LocaleContextHolder.setLocale(Locale.US);
        } else {
            LocaleContextHolder.setLocale(Locale.SIMPLIFIED_CHINESE);
        }

        R.setVid(vid);
        UserSecurityContext userSecurityContext = new UserSecurityContext();
        userSecurityContext.setVid(vid);
        userSecurityContext.setIp(ServletUtil.getClientIP(request));
        userSecurityContext.setAppId(appId);
        userSecurityContext.setToken(token);

        if (Objects.nonNull(verifyToken) && !verifyToken.verifyParam()) {
            UserSecurityContextHolder.setContext(userSecurityContext);
            return;
        }

        // 补充渠道信息，有条件的补充渠道信息，
        ValidateUtil.isTrue(StringUtils.isEmpty(appId), ErrorCodeEnum.UNKNOWN_MERCHANT, "渠道号不能为空!");
        Clinic clinic = clinicService.getOne(new QueryWrapper<Clinic>().eq("app_id", appId).eq("deleted", DeletedStatusEnum.DELETED_NO.getValue()));
        ValidateUtil.isTrue(Objects.isNull(clinic), ErrorCodeEnum.UNKNOWN_MERCHANT, "无效渠道号：" + appId);
        userSecurityContext.setChannelId(clinic.getId());

        if (Objects.nonNull(verifyToken) && !verifyToken.verifyLogin()) {
            userSecurityContext.setUserId(null);
            UserSecurityContextHolder.setContext(userSecurityContext);
            return;
        }
        verifyLoginUser(request);
        // 设置到
        LoginInfoBO loginInfo = cacheService.getUserByToken(token);
        userSecurityContext.setUserId(loginInfo.getUserId());
        userSecurityContext.setAppId(appId);
        userSecurityContext.setMemberId(loginInfo.getMemberId());
        UserSecurityContextHolder.setContext(userSecurityContext);
    }


    private boolean verifyLoginUser(HttpServletRequest request) {
        String token = request.getHeader("token");
        String userId = request.getHeader("userId");
        if (StrUtil.isBlank(token) || StrUtil.isBlank(userId)) {
            throw new ServiceException(UserErrorCodeConstants.USER_NOT_AUTH);
        }
        LoginInfoBO loginInfo = cacheService.getUserByToken(token);
        if (Objects.isNull(loginInfo)) {
            throw new ServiceException(UserErrorCodeConstants.INVALID_LOGIN_TOKEN_AUTH);
        }
        if (!loginInfo.getUserId().equals(Integer.valueOf(userId))) {
            throw new ServiceException(UserErrorCodeConstants.INVALID_LOGIN_AUTH);
        }
        return true;
    }


    @Around("loginPointCut()")
    public Object arround(ProceedingJoinPoint point) throws Throwable {
        return point.proceed();
    }

    @AfterReturning(pointcut = "loginPointCut()", returning = "result")
    public void logAfter(Object result) {
        if (result instanceof R) {
            log.debug("Response data: " + ((R<?>) result).getData());
        }
    }

    private VerifyLogin getVerifyTokenInstance(JoinPoint point) {
        MethodSignature signature = (MethodSignature) point.getSignature();
        //从切面中获取当前方法
        Method method = signature.getMethod();
        //得到了方,提取出他的注解
        return method.getAnnotation(VerifyLogin.class);
    }

}
