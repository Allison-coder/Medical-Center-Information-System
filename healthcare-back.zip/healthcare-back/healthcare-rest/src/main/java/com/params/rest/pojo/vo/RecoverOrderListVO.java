package com.params.rest.pojo.vo;

import com.params.pojo.vo.OrderItemVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/7
 */
@Getter
@Setter
@ApiModel("找回订单列表 VO")
public class RecoverOrderListVO implements Serializable {

    private static final long serialVersionUID = -6377415932797082358L;
    @ApiModelProperty(value = "key", example = "1")
    private String key;

    @ApiModelProperty(value = "订单商品信息", example = "[]")
    private List<OrderItemVO> items;

    @ApiModelProperty(value = "实际支付价格", example = "1.1")
    private BigDecimal payPrice;

    @ApiModelProperty(value = "支付时间", example = "2022-12-08 00:00:00")
    private Date payTime;

    @ApiModelProperty(value = "下单时间", example = "2022-12-08 00:00:00")
    private Date createTime;

    @ApiModelProperty(value = "订单状态 0 - 等待支付 1 - 支付成功 2 - 退款中 3 - 退款成功 9 - 关闭", example = "0")
    private Integer orderStatus;

    @ApiModelProperty(value = "订单状态 ", example = "待支付")
    private String orderStatusStr;

    @ApiModelProperty(value = "物流状态 0 - 无需物流，1 - 等待发货 2 - 暂停发货 3 - 发货 9 - 已关闭", example = "0")
    private Integer logisticsStatus;

    @ApiModelProperty(value = "物流状态", example = "0")
    private String logisticsStatusStr;

    /**
     * 是否预订(0:否 1:是)
     */
    @ApiModelProperty(value = "是否预订(0:否 1:是)", example = "0")
    private Integer placeOrderFlag;

}
