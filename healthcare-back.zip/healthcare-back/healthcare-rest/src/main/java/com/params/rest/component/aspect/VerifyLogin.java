package com.params.rest.component.aspect;


import java.lang.annotation.*;

@Target({ElementType.PARAMETER, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface VerifyLogin {

    /** true 或者没有该注解 统一验证token false不验证*/
    boolean verifyLogin() default true;


    boolean verifyParam() default true;

    String message() default "";

}
