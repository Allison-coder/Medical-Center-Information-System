package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @DESCRIPTION
 * @AUTHOR LIAM
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class GetCouponListDTO implements Serializable {

    @ApiModelProperty(value = "页大小，默认10", example = "10")
    @Min(1)
    @Max(100)
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码，默认1", example = "1")
    @Min(0)
    private Integer pageNum = 1;


    @ApiModelProperty(value = "登录时返回的 token", required = true)
    private String  token;
}
