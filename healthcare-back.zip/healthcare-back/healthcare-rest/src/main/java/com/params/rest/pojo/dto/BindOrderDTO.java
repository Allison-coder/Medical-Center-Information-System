package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/7
 */
@Getter
@Setter
@ApiModel("绑定订单 VO")
public class BindOrderDTO implements Serializable {

    private static final long serialVersionUID = 7444087993815055820L;

    @ApiModelProperty(value = "key", example = "1")
    @NotNull(message = "参数不能为空")
    private List<String> key;

}
