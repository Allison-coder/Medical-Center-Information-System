package com.params.rest.component.security;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
public interface ContentSecurityClient {
    ContentSecurityBO contentSecurityV2(String checkContent);

}
