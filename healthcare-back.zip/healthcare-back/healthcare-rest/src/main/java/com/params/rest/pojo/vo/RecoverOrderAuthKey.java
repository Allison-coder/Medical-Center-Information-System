package com.params.rest.pojo.vo;

import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/14
 */
@Getter
@Setter
@ApiModel("找回订单列表 VO")
public class RecoverOrderAuthKey {

    private Long orderId;
    private Long userId;
    private Long memberId;
    private String token;
    private String mobile;
    private Long expiresTime;

}
