package com.params.rest.component.config.service;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.params.cachekey.LuckyConfigCacheKey;
import com.params.component.redis.ParamsRedis;
import com.params.pojo.constant.ConfigCodeEnum;
import com.params.pojo.dto.ParamsConfigDTO;
import com.params.rest.component.config.AbstractProcessService;
import com.params.rest.component.config.ConfigProcessDTO;
import com.params.rest.component.config.PageFactory;
import com.params.service.ParamsConfigService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <pre>
 * 普通配置获取方式
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Service
public class HomepageProcessServiceImpl extends AbstractProcessService {

    @Resource
    private ParamsRedis paramsRedis;

    @Resource
    private ParamsConfigService paramsConfigService;

    @Resource
    private PageFactory pageFactory;

    @Override
    public Object build(ConfigProcessDTO dto) {
        String language = "ZH";
        JSONObject setting = null;
        if (null != dto.getConfig()) {
            if (dto.getConfig() instanceof JSONObject) {
                setting = (JSONObject) dto.getConfig();
            } else {
                setting = JSON.parseObject(JSON.toJSONString(dto.getConfig()));
            }
        }
        String extentConfigCode = "DEFAULT";

        String cacheKey = LuckyConfigCacheKey.HOMEPAGE_BUILD_CACHE_KEY.getKey(ConfigCodeEnum.HOMEPAGE.getCode(), -1, language, extentConfigCode, -1);
        Object result = paramsRedis.get(cacheKey);
        if (null == result) {
            ParamsConfigDTO configDTO = new ParamsConfigDTO();
            configDTO.setCityId(dto.getCity() != null ? dto.getCity().getCityId() : -1);
            configDTO.setChannelId(-1);
            configDTO.setConfigCode(ConfigCodeEnum.HOMEPAGE.getCode());
            configDTO.setNeedParent(true);
            configDTO.setExtentConfigCode(extentConfigCode);
            configDTO.setLanguage(language);
            String configInfo = paramsConfigService.getOneConfig(configDTO);
            if (StrUtil.isBlank(configInfo)) {
                configDTO.setExtentConfigCode("OTHER");
                configInfo = paramsConfigService.getOneConfig(configDTO);
            }
            if (StrUtil.isBlank(configInfo)) return new Object();

            result = pageFactory.parse(dto.getCity(), configInfo, setting);
            paramsRedis.setEx(cacheKey, result, LuckyConfigCacheKey.HOMEPAGE_BUILD_CACHE_KEY.getExpire());
        }
        JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(result));
        jsonObject.put("currentTime", DateUtil.date().getTime());
        return jsonObject;
    }
}
