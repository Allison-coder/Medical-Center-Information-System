package com.params.rest.controller;

import com.params.entity.PromotionAccessEventLog;
import com.params.framework.vo.R;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.pojo.dto.AddEventLogDTO;
import com.params.service.PromotionAccessEventLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @DESCRIPTION 落地页访问及领取日志
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@RestController
@RequestMapping("/accessEventLog")
@Api(tags = "落地页埋点接口")
public class PromotionAccessEventLogController {

    @Autowired
    private PromotionAccessEventLogService promotionAccessEventLogService;


    @ApiOperation("落地页访问和领取接钮点击事件")
    @PostMapping("/addEventLog")
    @VerifyLogin(verifyParam = false,verifyLogin = false)
    public R addEventLog(@RequestBody AddEventLogDTO params) {
        PromotionAccessEventLog accessEventLog = new PromotionAccessEventLog();
        BeanUtils.copyProperties(params, accessEventLog);
        promotionAccessEventLogService.save(accessEventLog);
        return R.success(null);
    }

}
