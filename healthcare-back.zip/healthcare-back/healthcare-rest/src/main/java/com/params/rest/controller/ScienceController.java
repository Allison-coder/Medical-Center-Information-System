package com.params.rest.controller;

import com.params.domain.science.ScienceDomainService;
import com.params.framework.vo.R;
import com.params.pojo.dto.ScienceRecordQueryDTO;
import com.params.pojo.req.ScienceRecordQueryReq;
import com.params.pojo.vo.ScienceBannerVO;
import com.params.pojo.vo.ScienceCategoryVO;
import com.params.pojo.vo.ScienceInfoVO;
import com.params.pojo.vo.ScienceRecordVO;
import com.params.pojo.vo.common.PageVO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Api(tags = "科普内容")
@RestController
@RequestMapping("/science")
@Validated
@Slf4j
public class ScienceController {

    private ScienceDomainService scienceDomainService;

    public ScienceController(ScienceDomainService scienceDomainService) {
        this.scienceDomainService = scienceDomainService;
    }

    // 获取banner + 分类 + 默认分类的科普知识
    @GetMapping("/getScienceInfo")
    @ApiOperation("获取科普页面信息")
    @VerifyLogin(verifyLogin = false)
    public R<ScienceInfoVO> getScienceInfo() {
        ScienceInfoVO result = new ScienceInfoVO();
        Integer channelId = UserSecurityContextHolder.getChannelId();
        // 查询 banner
        List<ScienceBannerVO> banners = scienceDomainService.getBanners(channelId);
        result.setBanners(banners);
        // 查询 类别
        List<ScienceCategoryVO> categories = scienceDomainService.getCategories(channelId);
        result.setCategories(categories);
        // 查询 第一个类别的科普信息
        if (Objects.nonNull(categories) && categories.size() >= 1) {
            Optional<ScienceCategoryVO> first = categories.stream().findFirst();
            ScienceCategoryVO scienceCategoryVO = first.get();
            List<ScienceRecordVO> scienceRecords = scienceDomainService.getRecordsByCategoryId(scienceCategoryVO.getId(), channelId);
            result.setScienceRecords(scienceRecords);
        }
        return R.success(result);
    }

    @GetMapping("/getRecords")
    @ApiOperation("根据类别获取科普知识列表")
    @VerifyLogin(verifyLogin = false)
    public R<PageVO<ScienceRecordVO>> getRecords(ScienceRecordQueryReq req) {
        ScienceRecordQueryDTO dto = ScienceRecordQueryDTO.builder()
                .categoryId(req.getCategoryId())
                .pageSize(req.getPageSize())
                .pageNum(req.getPageNum())
                .channelId(UserSecurityContextHolder.getChannelId())
                .build();
        PageVO<ScienceRecordVO> records = scienceDomainService.getRecords(dto);
        return R.success(records);
    }
}
