package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NonNull;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @DESCRIPTION 推广的登录
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PromotionLoginDTO implements Serializable {

    @ApiModelProperty(value = "账号", example = "admin",required = true)
    @NotNull(message = "账号不为空")
    private String username;

    @ApiModelProperty(value = "密码", example = "123456",required = true)
    @NotNull(message = "密码不为空")
    private String password;
}
