package com.params.rest.controller;

import com.params.ErrorCodeEnum;
import com.params.constant.PaymentTypeEnum;
import com.params.constant.SourceTypeEnum;
import com.params.constant.ValidateUtil;
import com.params.entity.MerchantPaymentInfo;
import com.params.framework.vo.R;
import com.params.pojo.dto.PaymentTypeResp;
import com.params.pojo.req.MergePayReq;
import com.params.pojo.vo.PayReq;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.service.MerchantPaymentInfoService;
import com.params.service.ParamsPayService;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
public class ParamsPayController {

    @Autowired
    private ParamsPayService paramsPayService;

    @Autowired
    private MerchantPaymentInfoService merchantPaymentInfoService;

    /**
     * 统一支付下单接口
     */
    @RequestMapping("paramsPay/pay")
    public R pay(@Validated PayReq payReq, HttpServletRequest request) {
        return paramsPayService.pay(payReq, request, UserSecurityContextHolder.getChannelId());
    }

    /**
     * 微信支付
     */
    @PostMapping("weiXinPayApi/weiXinPay")
    public R weiXinPay(@Validated String orderNum, HttpServletRequest request) {
        PayReq payReq = new PayReq();
        payReq.setOrderNum(orderNum);
        payReq.setPaymentType("WEIXIN_APP_PAY");
        payReq.setSubject("诊疗服务费用");
        return pay(payReq, request);
    }

    /**
     * 小程序的合并支付  TODO V1.5.1 mock 数据
     */

    @ApiOperation("V1.5.1 新开接口 合并支付的立即支付按钮")
    @PostMapping("weiXinMergePayApi/weiXinMergePay")
    // @VerifyLogin(verifyParam = false,verifyLogin = false)
    public R weiXinMergePay(@Validated MergePayReq req, HttpServletRequest request) {

        Integer clinicId = UserSecurityContextHolder.getChannelId();
        req.setChannelId(clinicId);
        // req.setChannelId(1);
        req.setSubject("诊疗费用合并支付");
        req.setNeedUser(true);
        return paramsPayService.mergePay(req, request);

        // PayReq payReq = new PayReq();
        // // payReq.setOrderNum(orderNum);
        // payReq.setPaymentType("WEIXIN_APP_PAY");
        // payReq.setSubject("诊疗服务费用");
        //
        // JSONObject resp = new JSONObject();
        // resp.put("timeStamp", "1724221443420");
        // resp.put("package", "prepay_id=wx211424033148800dcb1794ac230ec40001");
        // resp.put("paySign", "DD01347F197ED0BA7D0AF3583575D1506D4CD9DF2F21A620C2FFFF2A77E61C20");
        // resp.put("appId", "wx8fd123f864f19f96");
        // resp.put("signType", "HMACSHA256");
        // resp.put("nonceStr", "58mzsyv8e4ugkv1m5sz329qahcc0ei4s");
        // resp.put("orderSn", "HB202401021424033148800dcb1794ac230ec40001");
        // return R.success(resp);
        // return pay(payReq, request);
    }


    /**
     * 支付宝小程序支付回调
     */
    @VerifyLogin(verifyParam = false)
    @RequestMapping("aliPay/aliPayNotice")
    public void aliPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.ALI_H5_PAY.name());
    }

    /**
     * 支付宝支付回调
     */
    @VerifyLogin(verifyParam = false)
    @RequestMapping("aliPay/aliAppPayNotice")
    public void aliAppPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.ALI_APP_PAY.name());
    }

    /**
     * 支付宝扫码支付回调
     */
    @VerifyLogin(verifyParam = false)
    @RequestMapping("aliPay/qrCodePayNotice")
    public void aliQrCodePayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.ALI_QRCODE_PAY.name());
    }

    /**
     * 微信支付回调
     */
    @VerifyLogin(verifyParam = false)
    @RequestMapping("weiXinPayApi/weiXinPayNotice")
    public void weiXinPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.WEIXIN_JS_PAY.name());
    }

    /**
     * 微信扫码回调
     *
     * @param request
     * @param response
     */
    @VerifyLogin(verifyParam = false)
    @RequestMapping("weiXinPayApi/qrPayNotice")
    public void weiXinQrPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.WEIXIN_QRCODE_PAY.name());
    }

    @VerifyLogin(verifyLogin = false)
    @GetMapping("pay/merchantPayWayDetail")
    public R merchantPayWayDetail(@NotNull String source) {
        ValidateUtil.isTrue(!SourceTypeEnum.exists(source), ErrorCodeEnum.SYSTEM_ERR);
        List<MerchantPaymentInfo> infos = merchantPaymentInfoService.getMerchantPaymentInfos(UserSecurityContextHolder.getChannelId(), source);
        ValidateUtil.isTrue(infos == null || infos.size() == 0, ErrorCodeEnum.SYSTEM_ERR);
        List<PaymentTypeResp> paymentTypeResps = new ArrayList<>();
        for (MerchantPaymentInfo info : infos) {
            PaymentTypeResp r = new PaymentTypeResp();
            r.setName(info.getNickName());
            r.setPaymentType(info.getPaymentType());
            r.setIconUrl(info.getIconUrl());
            r.setSource(source);
            r.setPaymentUrl(info.getPaymentUrl());
            paymentTypeResps.add(r);
        }
        return R.success(paymentTypeResps);
    }


}
