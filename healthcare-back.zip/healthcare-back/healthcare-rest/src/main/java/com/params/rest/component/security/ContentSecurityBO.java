package com.params.rest.component.security;

import com.alibaba.fastjson.JSONObject;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@Setter
public class ContentSecurityBO implements Serializable {

    private static final long serialVersionUID = -2654192004112975439L;
    private Boolean result;
    private Boolean abnormal;

    private List<ContentSecurityTaskBO> tasks;
    private String checkContent;
    private JSONObject responseBody;
    private Long useTime;
}
