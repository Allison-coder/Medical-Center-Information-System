package com.params.rest.config.rabbit;

import com.params.constant.rabbitmq.CheckPayStatusConstant;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * 检查支付消息
 */
@Configuration
public class RabbitCheckPayStatusConfig {


    /**
     * 定义队列
     *
     * @return
     */
    @Bean
    public Queue checkPayQueue() {
        return QueueBuilder
                .durable(CheckPayStatusConstant.QUEUE)
                .withArgument("x-max-priority", 255)
                .build()
                ;
    }

    /**
     * 配置默认的交换机
     *
     * @return
     */
    @Bean
    public CustomExchange checkPayExchange() {
        Map<String, Object> args = new HashMap<>();
        args.put("x-delayed-type", "direct");
        //参数二为类型：必须是x-delayed-message
        return new CustomExchange(CheckPayStatusConstant.EXCHANGE,
                "x-delayed-message",
                true,
                false,
                args
        );
    }

    /**
     * 绑定队列到交换器
     *
     * @param queue
     * @param customExchange
     * @return
     */
    @Bean
    public Binding checkPayBinding(@Qualifier("checkPayQueue") Queue queue,
                                     @Qualifier("checkPayExchange") CustomExchange customExchange) {
        return BindingBuilder
                .bind(queue)
                .to(customExchange)
                .with(CheckPayStatusConstant.QUEUE)
                .noargs();
    }


}
