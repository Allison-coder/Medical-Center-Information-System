package com.params.rest.component.config.drive;

import cn.hutool.core.util.ReUtil;
import com.params.rest.component.config.constant.DriveEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Component
public class DriveFactory {
    @Autowired
    private Map<String, Drive> driveMap = new ConcurrentHashMap<>();

    public Drive getDrive(DriveEnum driveEnum) {
        return driveMap.get(driveEnum.getDrive());
    }

    public Object parseDrive(DriveEnum driveEnum, DriveDTO dto) {
        Drive drive = driveMap.get(driveEnum.getDrive());
        if (null == drive) return null;
        drive.setCity(dto.getCity());
        drive.setDriveFactory(this);
        return drive.parse(dto.getContent(), dto.getSetting());
    }

    public Object parseDrive(DriveDTO dto) {
        String tmp = dto.getContent().toString();

        for (DriveEnum driveEnum : DriveEnum.values()) {
            if (ReUtil.isMatch(driveEnum.getPattern(), tmp)) {
                Drive drive = getDrive(driveEnum);
                if (null == drive) break;
                drive.setCity(dto.getCity());
                drive.setDriveFactory(this);
                return drive.parse(dto.getContent(), dto.getSetting());
            }
        }

        return dto.getContent();
    }
}
