package com.params.rest.component.config.drive;

import cn.hutool.core.util.ReUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.params.rest.pojo.vo.CityVO;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
public abstract class AbstractDrive implements Drive {

    private DriveFactory driveFactory;
    private CityVO city;

    public CityVO getCity() {
        return city;
    }

    @Override
    public void setCity(CityVO city) {
        this.city = city;
    }

    public DriveFactory getDriveFactory() {
        return driveFactory;
    }

    @Override
    public void setDriveFactory(DriveFactory driveFactory) {
        this.driveFactory = driveFactory;
    }

    @Override
    public Object parse() {
        return null;
    }

    protected JSONObject parseContent(String regex, Object content) {
        String str = String.valueOf(content);
        String params = ReUtil.get(regex, str, 1);
        return JSON.parseObject(params.replace("\\\"", "\""));
    }
}
