package com.params.rest.component.config.constant;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface ModuleConstants {
    String VAN_TABS = "van-tabs";
    String ARTICLE_CATEGORY = "article-category";
    String EXAM_REMINDER = "exam-reminder";
    String BANNER = "banner";
    String TEXT = "text";
}
