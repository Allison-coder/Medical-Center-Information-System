package com.params.rest.component.config;

import cn.hutool.core.util.CharUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.params.rest.component.config.constant.ModuleConstants;
import com.params.rest.component.config.drive.DriveDTO;
import com.params.rest.component.config.drive.DriveFactory;
import com.params.rest.pojo.vo.CityVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;

/**
 * <pre>
 * 页面解析
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Component
public class PageFactory {

    @Autowired
    private DriveFactory driveFactory;

    public Object parse(CityVO city, String config) {
        return parse(city, config, new JSONObject());
    }

    public Object parse(CityVO city, String config, JSONObject params) {
        JSONObject jsonObject = JSON.parseObject(config);
        if (null == params) params = new JSONObject();

        List<String> version = StrUtil.split(jsonObject.getString("version"), CharUtil.DOT);

        // 版本号没有或者小于2直接返回
        if (null == version || version.size() == 0
                || Integer.valueOf(1).compareTo(Integer.valueOf(version.get(0))) > 0) {
            return jsonObject;
        }
        if (StrUtil.isBlank(jsonObject.getString("modules"))) {
            return jsonObject;
        }

        JSONArray modules = jsonObject.getJSONArray("modules");
        for (Iterator<Object> iterator = modules.iterator(); iterator.hasNext(); ) {
            JSONObject next = (JSONObject) iterator.next();
            String module = next.getString("module");
            JSONObject setting = params;
            if (StrUtil.isNotBlank(next.getString("setting"))) {
                setting.putAll(next.getJSONObject("setting"));
            }
            JSONObject data = next.getJSONObject("data");
            if (StrUtil.isBlank(module)) continue;
            JSONArray items = next.getJSONArray("items");
            JSONObject item = next.getJSONObject("item");


            switch (module.toLowerCase()) {
                case ModuleConstants.BANNER:
                    if (null == items || items.size() == 0) continue;

                    for (Iterator<Object> ite = items.iterator(); ite.hasNext(); ) {
                        JSONObject nt = (JSONObject) ite.next();
                        if (StrUtil.isBlank(nt.getString("link"))) {
                            continue;
                        }
                        nt.put("link", parseLink(city, nt.getString("link"), setting));
                    }
                    break;
                case ModuleConstants.TEXT:
                default:
                    continue;
            }
        }

        return jsonObject;
    }

    private Object parseLink(CityVO city, String linkStr, JSONObject setting) {
        try {
            JSONObject link = JSON.parseObject(linkStr);
            if (link.size() == 0) return new Object();
            JSONObject options = link.getJSONObject("options");
            if (null == options) options = new JSONObject();
            JSONObject query = options.getJSONObject("query");
            if (null == query) query = new JSONObject();
            options.put("query", query);
            link.put("options", options);
            return link;
        } catch (Exception e) {
            return parseDrive(city, linkStr, setting);
        }

    }

    public Object parseDrive(CityVO city, Object content, JSONObject setting) {
        DriveDTO driveDTO = new DriveDTO();
        driveDTO.setCity(city);
        driveDTO.setContent(content);
        driveDTO.setSetting(setting);
        return driveFactory.parseDrive(driveDTO);

    }
}
