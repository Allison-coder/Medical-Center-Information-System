package com.params.rest.utils;

import cn.hutool.http.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.lionsoul.ip2region.*;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Objects;

/**
 * Created by dzl on 2019/11/12
 **/
@Slf4j
public class IPUtils {

    private static DbSearcher searcher;

    public static String getCityInfo(String ip) {
        long l = System.currentTimeMillis();
        if (!StringUtils.hasLength(ip)) {
            return null;
        }
        try {
            String regionInfo = getRegionInfo(ip);
            if (Objects.nonNull(regionInfo)) {
                String[] region = regionInfo.split("\\|");
                long time = System.currentTimeMillis() - l;
                if (time > 500) {
                    log.warn("根据ID定位城市消耗的时间：{}, ip:{}", time, ip);
                }
                return "0".equals(region[3]) ? null: region[3].substring(region[3].indexOf("省") != -1 ? region[3].indexOf("省") + 1 : 0, region[3].indexOf("市") != -1 ? region[3].indexOf("市") + 1 : region[3].length());
            }
        } catch (Exception e) {
        }
        return null;
    }

    public static DbSearcher getDbSearch() throws DbMakerConfigException, IOException {
        if (Objects.nonNull(searcher)) {
            return searcher;
        }
//        String dbPath = IPUtil.class.getResource("/ip2region.db").getPath();
        InputStream resourceAsStream = IPUtils.class.getClassLoader().getResourceAsStream("ip2region.db");
//        byte[] bytes = IOUtils.toByteArray(resourceAsStream);
        /*String dbPath = "/home/params/params-8080/ip2region.db";
        log.info("dbPath-{}", dbPath);
        File file = new File(dbPath);
        if (Objects.isNull(file) || file.exists() == false) {
            return null;
        }*/
        String dbPath = inputStreamToFile(resourceAsStream);
        log.info("dbPath-{}", dbPath);
        DbConfig config = new DbConfig();
        searcher = new DbSearcher(config, dbPath);
        return searcher;
    }

    private static String inputStreamToFile(InputStream resourceAsStream) throws IOException {
        String dbPath = "/home/params/params-8080/ip2region.db";
        File file = new File(dbPath);
        if (!file.exists()) {
//            log.info("文件不存在，创建中");
            FileUtils.copyInputStreamToFile(resourceAsStream, file);
        }
        return dbPath;

    }


    /**
     * 通过本地文件查询城市
     */
    public static String getRegionInfo(String ip) {
        try {
            //查询算法
            int algorithm = DbSearcher.BTREE_ALGORITHM; //B-tree
            //DbSearcher.BINARY_ALGORITHM //Binary
            //DbSearcher.MEMORY_ALGORITYM //Memory

            Method method = null;
            switch (algorithm) {
                case DbSearcher.BTREE_ALGORITHM:
                    method = getDbSearch().getClass().getMethod("btreeSearch", String.class);
                    break;
                case DbSearcher.BINARY_ALGORITHM:
                    method = getDbSearch().getClass().getMethod("binarySearch", String.class);
                    break;
                case DbSearcher.MEMORY_ALGORITYM:
                    method = getDbSearch().getClass().getMethod("memorySearch", String.class);
                    break;
            }
            DataBlock dataBlock = null;
            if (Util.isIpAddress(ip) == false) {
                return null;
            }
            dataBlock = (DataBlock) method.invoke(getDbSearch(), ip);
            return dataBlock.getRegion();
        } catch (Exception e) {
//            log.warn("定位异常-", e);
        }
        return null;
    }

    /**
     * 通过pconline 接口查询城市
     */
    public static String getCityByPcon(String ip) {
        String cityName = new String();
        try {
            String url = new StringBuilder().append("http://whois.pconline.com.cn/jsAlert.jsp?ip=").append(ip).toString();
            String result = HttpUtil.get(url)
                    .replace("alert('", "")
                    .replace("');", "")
                    .replace("\r", "")
                    .replace("\n", "");
            if (result.indexOf("市") != -1) {
                String[] area = result.split(" ");
                cityName = area[0].substring(area[0].indexOf("省") != -1 ? area[0].indexOf("省") + 1 : 0, result.indexOf("市") + 1);
            }
        } catch (Exception e) {
        }
        return cityName;
    }
}
