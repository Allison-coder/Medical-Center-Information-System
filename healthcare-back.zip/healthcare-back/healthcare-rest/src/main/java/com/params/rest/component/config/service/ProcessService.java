package com.params.rest.component.config.service;


import com.params.rest.component.config.ConfigProcessDTO;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
public interface ProcessService {

    Object build(ConfigProcessDTO dto);

}
