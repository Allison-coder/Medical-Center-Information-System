package com.params.rest.component.config;

import com.alibaba.fastjson.JSONObject;
import com.params.entity.User;
import com.params.pojo.bo.LoginInfoBO;
import com.params.rest.pojo.vo.CityVO;
import lombok.Getter;
import lombok.Setter;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Getter
@Setter
public class ConfigProcessDTO implements Serializable {
    private static final long serialVersionUID = 4391144871377748386L;
    private HttpServletRequest request;
    private CityVO city;
    private User user;
    private LoginInfoBO loginInfo;
    private String code;
    private JSONObject config;
}
