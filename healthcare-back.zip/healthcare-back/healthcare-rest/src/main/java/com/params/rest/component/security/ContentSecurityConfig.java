package com.params.rest.component.security;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@Setter
public class ContentSecurityConfig implements Serializable {

    private static final long serialVersionUID = 3328003446124691914L;

    private Boolean scan;
    private Boolean textScan;
    private List<String> allowSuggestion;
    private List<String> scenes;
    private List<String> nodes;
    private List<String> labels;
    private String riskLabels;
    private String textRiskLabels;
    private Boolean newScan;
    private List<String> newApis;

}
