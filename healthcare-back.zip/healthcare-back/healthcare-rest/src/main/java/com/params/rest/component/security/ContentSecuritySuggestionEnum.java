package com.params.rest.component.security;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@AllArgsConstructor
public enum ContentSecuritySuggestionEnum {

    PASS("pass", "结果正常，无需进行其余操作"),
    REVIEW("review", "结果不确定，需要进行人工审核。"),
    BLOCK("block", "结果违规，建议直接删除或者限制公开。"),
    ;

    private final String code;
    private final String msg;
}
