package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/14
 */
@Getter
@Setter
@ApiModel("找回订单 DTO")
public class RecoverOrderDTO {

    private String mobile;
    private String code;
    private String codeText;
    private String codeToken;
}
