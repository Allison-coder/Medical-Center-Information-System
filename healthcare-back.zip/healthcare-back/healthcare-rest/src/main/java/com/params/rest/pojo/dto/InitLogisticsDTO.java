package com.params.rest.pojo.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class InitLogisticsDTO implements Serializable {
    private static final long serialVersionUID = -8714036979777656130L;

    private String pwd;
    private List<Integer> orders;
}
