package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @DESCRIPTION 订单与优惠券绑定
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class BindOrderAndCouponDTO {

    @ApiModelProperty(value = "是否使用优惠券 false-不使用 true-使用",required = true)
    private Boolean isUseCoupon;

    @ApiModelProperty(value = "优惠券码 面诊单的参数")
    private String couponCode;

    @ApiModelProperty(value = "订单编码",required = true)
    private String orderSn;

    @ApiModelProperty(value = "项目id  治疗单才有")
    private Integer projectId;

}
