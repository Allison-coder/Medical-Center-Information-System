package com.params.rest.component.security;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ContentSecurityTaskDTO implements Serializable {
    private static final long serialVersionUID = 8365549681009271575L;

    private String dataId;
    private String url;
    private Date time;
}
