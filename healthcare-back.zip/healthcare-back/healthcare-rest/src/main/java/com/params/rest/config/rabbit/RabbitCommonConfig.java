package com.params.rest.config.rabbit;

import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.support.DefaultMessagePropertiesConverter;
import org.springframework.amqp.rabbit.support.MessagePropertiesConverter;
import org.springframework.boot.autoconfigure.amqp.SimpleRabbitListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <pre>
 * RabbitMQ 公共配置
 *
 * </pre>
 *
 * 
 * @version 1.0.0
 */
@Configuration
public class RabbitCommonConfig {


    @Bean(name = "messagePropertiesConverter")
    public MessagePropertiesConverter getMessagePropertiesConverter() {
        return new DefaultMessagePropertiesConverter();
    }

    @Bean(name = "consumerBatchContainerFactory")
    public SimpleRabbitListenerContainerFactory consumerBatchContainerFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConcurrentConsumers(3); //设置线程数
        factory.setMaxConcurrentConsumers(10); //最大线程数
        configurer.configure(factory, connectionFactory);
        // // <X> 额外添加批量消费的属性
        factory.setPrefetchCount(2);
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        // factory.setReceiveTimeout(30 * 1000L);
        // factory.setDeBatchingEnabled(true);
        return factory;
    }

    @Bean(name = "consumerSingleContainerFactory")
    public SimpleRabbitListenerContainerFactory consumerSingleContainerFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConcurrentConsumers(5); //设置线程数
        factory.setMaxConcurrentConsumers(30); //最大线程数
        configurer.configure(factory, connectionFactory);
        // // <X> 额外添加批量消费的属性
        factory.setPrefetchCount(1);
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        // factory.setReceiveTimeout(30 * 1000L);
        // factory.setDeBatchingEnabled(true);
        return factory;
    }
}
