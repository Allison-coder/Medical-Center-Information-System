package com.params.rest.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.servlet.ServletUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.params.ErrorCodeEnum;
import com.params.cachekey.UserCacheKey;
import com.params.common.CacheService;
import com.params.component.redis.ParamsRedis;
import com.params.constant.SourceTypeEnum;
import com.params.constant.ValidateUtil;
import com.params.constant.errorcode.SystemErrorCodeConstants;
import com.params.constant.errorcode.UserErrorCodeConstants;
import com.params.domain.patient.PatientDomainService;
import com.params.entity.Member;
import com.params.entity.MerchantPaymentInfo;
import com.params.entity.Patient;
import com.params.entity.User;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.LoginInfoBO;
import com.params.pojo.dto.DecryptUserInfoDTO;
import com.params.pojo.dto.LoginDTO;
import com.params.pojo.dto.MobileLoginDTO;
import com.params.pojo.dto.VerifyCodeDTO;
import com.params.pojo.vo.UserInfoVO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.utils.IPUtils;
import com.params.service.MemberService;
import com.params.service.MerchantPaymentInfoService;
import com.params.service.UserService;
import com.params.service.impl.AliUtil;
import com.params.service.impl.WxUtil;
import com.params.utils.PhoneFormatCheckUtils;
import com.params.utils.RSA;
import com.params.utils.StringUtil;
import com.params.utils.UserSecurityContextHolder;
import com.params.utils.WxMaCryptUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

;

/**
 * <pre>
 * 考试
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Slf4j
@RestController
@Api(tags = "用户")
public class UserController {

    @Resource
    private UserService cmsUserService;

    @Resource
    private ParamsRedis paramsRedis;

    @Resource
    private MemberService cmsMemberService;

    @Resource
    private DefaultKaptcha defaultKaptcha;

    @Resource
    private WxUtil wxUtil;

    @Autowired
    private AliUtil aliUtil;

    @Autowired
    private MerchantPaymentInfoService merchantPaymentInfoService;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private PatientDomainService patientDomainService;


    @ApiOperation("用户统一登录")
    @PostMapping("/v1/user/login")
    @VerifyLogin(verifyLogin = false)
    public R<UserInfoVO> login(@RequestBody LoginDTO req, HttpServletRequest request) {
        String clientIP = ServletUtil.getClientIP(request, null);
        String cityInfo = IPUtils.getCityInfo(clientIP);
        req.setClientIP(clientIP);
        req.setRegion(cityInfo);
        UserInfoVO userInfoVO = cmsMemberService.toLogin(req, UserSecurityContextHolder.getChannelId());
        return R.success(userInfoVO);
    }


    @VerifyLogin(verifyLogin = false)
    @ApiOperation("发送验证码")
    @PostMapping("/v1/user/sendVerifyCode")
    public R sendVerifyCode(HttpServletRequest request, @RequestBody VerifyCodeDTO dto) {
        if (!StringUtils.hasLength(dto.getMobile()) || !StringUtils.hasLength(dto.getType())) {
            return R.error(SystemErrorCodeConstants.PARAMS_DEFECT);
        }

        if (!PhoneFormatCheckUtils.isPhoneLegal(dto.getMobile())) {
            return R.error(UserErrorCodeConstants.PHONE_ERROR);
        }
        // 安全检测
        String ip = ServletUtil.getClientIP(request, null);
        JSONObject codeResult = checkSafety(dto.getMobile(), dto.getType(), ip);
        // 发mq
        String code = sendVerifyCode(dto.getType(), dto.getMobile(), ip);
        log.info("手机：{},发送验证码:{}", dto.getMobile(), code);
        return R.success(codeResult);
    }


    @VerifyLogin(verifyLogin = false)
    @PostMapping("/v1/user/mobileLoginByVCode")
    public R mobileLoginByVCode(@RequestBody MobileLoginDTO dto,HttpServletRequest request) {
        ValidateUtil.isTrue(!StringUtil.validMobile(dto.getMobile()), ErrorCodeEnum.USER_MOBILE_ERR);
        ValidateUtil.isTrue(StringUtils.isEmpty(dto.getVerifyCode()), ErrorCodeEnum.ILLEGAL_PARAM);
        LoginDTO loginReq = new LoginDTO().setCode(dto.getVerifyCode()).setMobile(dto.getMobile()).setSourceType(SourceTypeEnum.H5.name());
        loginReq.setCodeToken(dto.getCodeToken());
        loginReq.setCodeText(dto.getCodeText());
        String clientIP = ServletUtil.getClientIP(request, null);
        loginReq.setClientIP(clientIP);
        return R.success(cmsMemberService.toLogin(loginReq, UserSecurityContextHolder.getChannelId()));
    }


    private JSONObject checkSafety(String mobile, String type, String ip) {
        JSONObject kaptcha = null;
        // 检测IP是否频繁发送
        String ipKey = UserCacheKey.SEND_VERIFY_CODE_IP.getKey(mobile);
        int ipKeyCount = Objects.isNull(paramsRedis.get(ipKey)) ? 0 : Integer.parseInt(paramsRedis.get(ipKey).toString());
        if (ipKeyCount > 20) {
            log.info("此IP：{}发送验证码达到了上限：{},电话：{}，发送", ip, ipKeyCount, mobile);
            throw new ServiceException(UserErrorCodeConstants.ACCOUNT_GET_MSG_OVER);
        }
        //再检查是否间隔过短
        String TimeKey = UserCacheKey.SEND_VERIFY_CODE_TIME.getKey(mobile);
        Long lastTime = Objects.isNull(paramsRedis.get(TimeKey)) ? null : Long.parseLong(paramsRedis.get(TimeKey).toString());
        // 如果当次不是第一次获取验证码，则需要图形验证码
        if (Objects.nonNull(lastTime)) {
            kaptcha = getKaptcha();
        }
        if (!Objects.isNull(lastTime) && System.currentTimeMillis() - lastTime <= 60 * 1000) {
            log.info("此号码：{}发送验证码频繁，上一次发送时间：{}", mobile, lastTime);
            throw new ServiceException(UserErrorCodeConstants.USER_VERIFY_CODE_SEND_FREQUENTLY);
        }
        // 再检查是否硬破解
        String key = UserCacheKey.ABNORMAL_VERIFY_CODE_KEY.getKey(mobile).replace("#type", type);
        int count = Objects.isNull(paramsRedis.get(key)) ? 0 : Integer.parseInt(paramsRedis.get(key).toString());
        kaptcha = getKaptcha();
//        if (count > 0) {
//            // 输错一次，则需要图形验证码
//        }
        if (count >= 20) {
            log.info("用户：{}已经连续输入错了验证码次数：{}", mobile, count);
            throw new ServiceException(UserErrorCodeConstants.USER_VERIFY_CODE_SEND_FREQUENTLY);
        }

        String ipCountKey = UserCacheKey.SEND_VERIFY_CODE_IP_COUNT.getKey(ip);
        Object o = paramsRedis.get(ipCountKey);
        int iPSendCount = Objects.isNull(o) ? 0 : Integer.parseInt(o.toString());
        if (iPSendCount > 100) {
            log.info("此IP：{}发送验证码达到了上限：{},电话：{}，发送", ip, ipKeyCount, mobile);
            throw new ServiceException(UserErrorCodeConstants.ACCOUNT_IP_GET_MSG_OVER);
        }
        return kaptcha;
    }


    @VerifyLogin(verifyLogin = false)
    @GetMapping("/v1/user/getKaptcha")
    public R getKaptchaImg() {
        return R.success(getKaptcha());
    }


    public JSONObject getKaptcha() {
        String text = defaultKaptcha.createText();
        log.info("kaptchaText:{}", text);
        BufferedImage bi = defaultKaptcha.createImage(text);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            ImageIO.write(bi, "jpeg", outputStream);
        } catch (IOException e) {
        }
        String base64Image = "data:image/jpeg;base64," + RSA.encryptBASE64(outputStream.toByteArray());
        JSONObject result = new JSONObject();
        result.put("image", base64Image);
        result.put("kaptchaToken", putKaptchaText(text));
        return result;
    }

    public String putKaptchaText(String text) {
        String token = UUID.randomUUID().toString();
        String kaptchaKey = UserCacheKey.KAPTCHA_CODE_KEY.getKey(token);
        paramsRedis.setEx(kaptchaKey, text, (long) (60 * 5));
        return token;
    }


    public String sendVerifyCode(String type, String mobile, String ip) {
        String key = StrUtil.format(UserCacheKey.BASE_VERIFY_CODE_CACHE_KEY.getKey().replace("#type", type), mobile);
        String code = String.valueOf(RandomUtil.randomInt(100001, 999999));
        List<String> whileListMobile = new ArrayList<>();
        whileListMobile.add("18888888888");
        if (whileListMobile.contains(mobile)) {
            code = mobile.substring(mobile.length() - 6);
        } else {
//            smsCommonSender.send(SmsTypeEnum.KY_SMS_BIND_PHONE.name(), UserSecurityContextHolder.getChannelId(), mobile, code);
            saveCheckKey(mobile, ip);
        }
        paramsRedis.setEx(key, code, (long) 60 * 5);
        return code;
    }


    private void saveCheckKey(String mobile, String ip) {
        // 记录发送验证码的IP次数
        String ipKey = UserCacheKey.SEND_VERIFY_CODE_IP.getKey(mobile);
        int ipKeyCount = Objects.isNull(paramsRedis.get(ipKey)) ? 0 : Integer.parseInt(paramsRedis.get(ipKey).toString());
        long l = DateUtil.betweenMs(new Date(), getEndTime());
        paramsRedis.setEx(ipKey, ipKeyCount + 1, l / 1000);
        // 记录用户发送的情况,发送时间 todo
        String TimeKey = UserCacheKey.SEND_VERIFY_CODE_TIME.getKey(mobile);
        paramsRedis.setEx(TimeKey, System.currentTimeMillis(), l / 1000);

        String ipCountKey = UserCacheKey.SEND_VERIFY_CODE_IP_COUNT.getKey(ip);
        final Object o = paramsRedis.get(ipCountKey);
        int iPSendCount = Objects.isNull(o) ? 0 : Integer.parseInt(o.toString());
        paramsRedis.setEx(ipCountKey, iPSendCount + 1, l / 1000);
    }

    private static Date getEndTime() {
        Calendar todayEnd = Calendar.getInstance();
        todayEnd.set(Calendar.HOUR_OF_DAY, 23);
        todayEnd.set(Calendar.MINUTE, 59);
        todayEnd.set(Calendar.SECOND, 59);
        todayEnd.set(Calendar.MILLISECOND, 999);
        return todayEnd.getTime();
    }

    @PostMapping("/v1/user/decryptAliAppMobile")
    public R decryptAliAppMobile(@RequestBody DecryptUserInfoDTO dto) {
        String resultInfo = aliUtil.getAliAppMobile(dto.getEncryptedData(), dto.getSource(), dto.getIsPlugins(), dto.getHostAppId(), UserSecurityContextHolder.getChannelId());
        JSONObject jsonObject = JSONObject.parseObject(resultInfo);
        if ("Success".equalsIgnoreCase(jsonObject.getString("msg"))) {
            User user = cmsUserService.getById(UserSecurityContextHolder.getUserId());
            user.setMobile(jsonObject.getString("mobile"));
            user.setModifyTime(new Date());
            cmsUserService.updateById(user);

            Member member = cmsMemberService.getById(user.getMemberId());
            member.setMobile(jsonObject.getString("mobile"));
            member.setModifyTime(new Date());
            cmsMemberService.updateById(member);

            JSONObject result = new JSONObject();
            result.put("msg", jsonObject.getString("msg"));
            result.put("mobile", member.getMobile());
            return R.success(result);
        } else {
            return R.error(UserErrorCodeConstants.USER_GET_USER_ERR.getCode(), jsonObject.getString("msg"));
        }

    }

    @PostMapping("/v1/user/getAliPayAuthAppId")
    @VerifyLogin(verifyLogin = false)
    public R getAliPayAuthAppId() {
        MerchantPaymentInfo paymentInfo = merchantPaymentInfoService.getAliPayAuthConfig(UserSecurityContextHolder.getChannelId());
        String appId = paymentInfo == null ? "" : paymentInfo.getAppid();
        JSONObject result = new JSONObject();
        result.put("appId", appId);
        return R.success(result);
    }

    @GetMapping("/v1/user/checkToken")
    @VerifyLogin(verifyLogin = false)
    public R checkToken(HttpServletRequest request) {
        String token = request.getHeader("token");
        if (StrUtil.isBlank(token)) {
            return R.success(false);
        }
        LoginInfoBO loginInfo = cacheService.getUserByToken(token);
        if (Objects.isNull(loginInfo)) {
            return R.success(false);
        }
        return R.success(true);

    }

    @PostMapping("/v1/user/decryptWxUserInfo")
    public R decryptWxUserInfo(String encryptedData, String iv, String code, String source) {
        ValidateUtil.isTrue(StringUtils.isEmpty(encryptedData) || StringUtils.isEmpty(iv), ErrorCodeEnum.SYSTEM_PARAMS_ERR);
        ValidateUtil.isTrue(com.aliyuncs.utils.StringUtils.isEmpty(code) || com.aliyuncs.utils.StringUtils.isEmpty(source), ErrorCodeEnum.SYSTEM_PARAMS_ERR);
        ValidateUtil.isTrue(!SourceTypeEnum.exists(source), ErrorCodeEnum.INVALID_LOGIN_SOURCE);
        Integer merchantId = UserSecurityContextHolder.getChannelId();
        MerchantPaymentInfo info = merchantPaymentInfoService.selectMerchantPaymentInfoByMerchantIdAndCh(merchantId, source);
        ValidateUtil.isTrue(info == null, ErrorCodeEnum.SYSTEM_ERR);
        JSONObject re = WxUtil.getWechatNativeOpenId(info.getAppid(), info.getSecret(), code);
        String uInfo = null;
        try {
            uInfo = WxMaCryptUtils.decrypt(re.getString("session_key"), encryptedData, iv);
            log.info("decryptWxUserInfo uInfo :{}", uInfo);
            JSONObject uJO = JSONObject.parseObject(uInfo);
            if (StringUtil.validMobile(uJO.getString("purePhoneNumber"))) {
                User user = cmsUserService.getById(UserSecurityContextHolder.getUserId());
                user.setMobile(uJO.getString("purePhoneNumber"));
                cmsUserService.updateById(user);
                Member member = cmsMemberService.selectById(user.getMemberId());
                member.setMobile(user.getMobile());
                cmsMemberService.updateById(member);
                // 根据电话号码查出所有患者
                List<Patient> patientList = patientDomainService.getPatientByMobile(user.getMobile());
                if (CollectionUtils.isNotEmpty(patientList)) {
                    patientList.forEach(patient -> patient.setUserId(user.getId()));
                    // 修改所有 患者的 user_id
                    patientDomainService.updatePatientList(patientList);
                }
            }
            return R.success(uJO);
        } catch (Exception e) {
            log.error("获取用户详情信息失败,uId:{},exception:{},userInfo：{},{}", UserSecurityContextHolder.getUserId(), e, uInfo, re.toJSONString());
            throw new ServiceException(ErrorCodeEnum.SYSTEM_GET_USER_ERR.msg());
        }
    }
}
