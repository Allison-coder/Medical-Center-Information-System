package com.params.rest.controller;

import com.params.application.order.OrderApp;
import com.params.application.schedule.ScheduleApp;
import com.params.domain.order.OrderDomainService;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.baseparam.PageBaseParam;
import com.params.pojo.bo.ConfirmAppointmentBO;
import com.params.pojo.dto.ReserveQueryDTO;
import com.params.pojo.req.ConfirmAppointmentReq;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.RecentReserveVO;
import com.params.pojo.vo.ReserveListNewVO;
import com.params.pojo.vo.ReserveListVO;
import com.params.pojo.vo.ScheduleDateVO;
import com.params.pojo.vo.common.PageVO;
import com.params.rest.pojo.dto.ReserveDTO;
import com.params.rest.pojo.dto.ScheduleDTO;
import com.params.service.OrdersService;
import com.params.service.PatientService;
import com.params.utils.DateUtil;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Calendar;
import java.util.Date;

/**
 * @DESCRIPTION 医生排班
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "预约挂号")
@RestController
@RequestMapping("/schedule")
public class ScheduleController {


    @Autowired
    private ScheduleApp scheduleApp;

    @Autowired
    private OrderApp orderApp;

    @Autowired
    private OrderDomainService orderDomainService;

    @Autowired
    private OrdersService ordersService;  // TODO V1.5

    @Autowired
    private PatientService patientService;

    @ApiOperation("获取医生列表和排班时间")
    @GetMapping("/getScheduleTime")
    // @VerifyLogin(verifyLogin = false, verifyParam = false)
    public R<PageVO<ScheduleDateVO>> getScheduleTime(ScheduleDTO params) {

        // 判断 params.getDate() 是否在当天之前
        if (StringUtils.isBlank(params.getDate())) {
            throw new ServiceException("请选择日期");
        }

        // 创建或获取一个Date实例
        Date currentDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DATE, -1);
        Date yesterday = calendar.getTime();

        if (DateUtil.formatStrToDate(params.getDate(), DateUtil.FORMAT_TYPE_3).before(yesterday)) {
            throw new ServiceException("不允许预约历史日期");
        }
        PageVO<ScheduleDateVO> vos = scheduleApp.getScheduleTime(params.getPageNum(), params.getPageSize(), params.getDate(), params.getIsHeal());
        return R.success(vos);
    }


    @ApiOperation("我的预约列表")
    @GetMapping("/getReserveList")
    public R<PageVO<ReserveListVO>> getReserveList(ReserveDTO params) {
        ReserveQueryDTO reserveQueryDTO = new ReserveQueryDTO().setPageNum(params.getPageNum()).setPageSize(params.getPageSize()).setUserId(UserSecurityContextHolder.getUserId()).setChannelId(UserSecurityContextHolder.getChannelId());
        PageVO<ReserveListVO> pageVO = scheduleApp.getReserveList(reserveQueryDTO);
        return R.success(pageVO);
    }


    @Deprecated
    @ApiOperation("近期预约")
    @GetMapping("/getRecentReserve/{patientSn}")
    public R<RecentReserveVO> getRecentReserve(@ApiParam(name = "patientSn", value = "患者编号", required = true) @PathVariable String patientSn) {
        RecentReserveVO vo = scheduleApp.getRecentReserve(patientSn);
        return R.success(vo);
    }

    // region V1.5 变更接口 ------------------ TODO V1.5
    @ApiOperation("V1.5 变更接口 通过订单编号取消预约")
    @GetMapping("/cancleAppiont/{orderSn}")
    public R<Boolean> cancleAppiont(@ApiParam(name = "orderSn", value = "订单编号", required = true) @PathVariable String orderSn) {
        Boolean su = scheduleApp.cancleAppiont(orderSn);
        return R.success(su);
    }

    // endregion

    // region V1.5 新开接口 ------------------ TODO V1.5

    // 我的预约列表NEW
    @ApiOperation("V1.5 新开接口 我的预约列表")
    @GetMapping("/getReserveListNew")
    // @VerifyLogin(verifyLogin = false, verifyParam = false)
    public R<PageVO<ReserveListNewVO>> getReserveListNew(PageBaseParam params) {
        ReserveQueryDTO reserveQueryDTO = new ReserveQueryDTO().setPageNum(params.getPageNum()).setPageSize(params.getPageSize()).setUserId(UserSecurityContextHolder.getUserId()).setChannelId(UserSecurityContextHolder.getChannelId());
        // ReserveQueryDTO reserveQueryDTO = new ReserveQueryDTO().setPageNum(params.getPageNum()).setPageSize(params.getPageSize()).setUserId(42).setChannelId(1);
        PageVO<ReserveListNewVO> pageVO = scheduleApp.getNewReserveList(reserveQueryDTO);
        return R.success(pageVO);
    }

    // 预约详情
    @ApiOperation("V1.5 新开接口 预约详情")
    @GetMapping("/getReserveDetail/{orderSn}")
    public R<OrderVO> getReserveDetail(@ApiParam(name = "orderSn", value = "订单编号", required = true) @PathVariable String orderSn) {
        return R.success(OrderVO.builder().build());
    }


    // 治疗方案的预约
    @ApiOperation("V1.5 新开接口 治疗方案的预约")
    @PostMapping("/addNewTreatPlan")
    public R<String> addNewTreatPlan(@RequestBody ConfirmAppointmentReq params) {
        ConfirmAppointmentBO bo = new ConfirmAppointmentBO()
                .setAdminId(params.getAdminId())
                .setAppointmentDate(params.getAppointmentDate())
                .setOrderSn(params.getOrderSn())
                .setScheduleDetailIds(params.getScheduleDetailIds())
                .setSource(params.getSource())
                .setPatientSn(params.getPatientSn());
        return R.success(orderDomainService.confirmAppointment(bo));
    }
    // endregion


}
