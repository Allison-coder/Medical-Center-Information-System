package com.params.rest.component.security;

import lombok.*;

import java.io.Serializable;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ContentSecurityTaskBO implements Serializable {

    private static final long serialVersionUID = -2058570996823325536L;

    private Boolean result;
    private String dataId;
    private String url;
    private String scene;
    private String label;
    private String suggestion;
    private String rate;
}
