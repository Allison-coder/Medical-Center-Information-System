package com.params.rest.component.config.drive;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.params.pojo.dto.ParamsConfigDTO;
import com.params.rest.pojo.vo.CityVO;
import com.params.service.ParamsConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * <pre>
 * 普通配置获取
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Slf4j
@Component
public class BuildConfigDrive extends AbstractDrive {

    @Resource
    private ParamsConfigService paramsConfigService;

    @Override
    public Object parse() {
        return parse(null, null);
    }

    @Override
    public Object parse(Object content, JSONObject setting) {
        JSONObject c = super.parseContent("^^#driveConfig\\((.*)\\)$", content);
        if (c.size() == 0) return null;
        if (StrUtil.isBlank(c.getString("code"))) return null;

        CityVO city = super.getCity();

        // 热门配置
        String config = paramsConfigService.getOneConfig(ParamsConfigDTO.builder()
                .configCode(c.getString("code"))
                .channelId(-1)
                .cityId((null != c.getInteger("cityId")) ? c.getInteger("cityId") : city.getCityId())
                .isNeedParent((null != c.getBoolean("isNeedParent")) ? c.getBoolean("isNeedParent") : true)
                .build());
        if (StrUtil.isBlank(config)) return null;
        return JSON.toJSONString(config);
    }

}
