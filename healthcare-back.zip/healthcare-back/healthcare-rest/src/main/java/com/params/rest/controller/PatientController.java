package com.params.rest.controller;

import com.params.application.patient.PatientApp;
import com.params.domain.patient.PatientDomainService;
import com.params.entity.Patient;
import com.params.framework.vo.R;
import com.params.pojo.dto.GetUserCouponsToGHOrderDTO;
import com.params.pojo.req.GetUserCouponsToGHOrderReq;
import com.params.pojo.vo.PatientUserInfoVO;
import com.params.pojo.vo.UserCouponsVO;
import com.params.rest.pojo.dto.GetUserCouponsToOrderDTO;
import com.params.rest.pojo.dto.PatientBaseInfoDTO;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@Api(tags = "患者接口")
@Validated
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientDomainService patientDomainService;

    @Autowired
    private PatientApp patientApp;

    @ApiOperation("新增或修改患者信息")
    @PostMapping("/createOrUpdatePatient")
    public R<Boolean> createOrUpdatePatient(@RequestBody @Validated PatientBaseInfoDTO dto) {
        Patient patient = Patient.builder()
                .avatarUrl(dto.getFileKey())
                .patientSn(dto.getPatientSn())
                .identityType(dto.getIdentityType())
                .name(dto.getName())
                .idCardNumber(dto.getIdCardNumber())
                .phoneNumber(dto.getPhoneNumber())
                .age(dto.getAge())
                .gender(dto.getGender())
                .occupation(dto.getOccupation())
                .maritalStatus(dto.getMaritalStatus())
                .userId(UserSecurityContextHolder.getUserId())
                .clinicId(UserSecurityContextHolder.getChannelId())
                .build();
        boolean save = patientDomainService.createOrUpdatePatient(patient);
        return R.success(save);
    }

    @ApiOperation("查询当前用户患者信息")
    @GetMapping("/getPatients")
    public R<List<PatientUserInfoVO>> getPatients() {
        List<PatientUserInfoVO> patientByCurrentUser = patientApp.getPatientByCurrentUser(UserSecurityContextHolder.getUserId(), UserSecurityContextHolder.getChannelId());
        return R.success(patientByCurrentUser);
    }


    // 当前用户已领取的优惠券
    @ApiOperation("当前用户已领取的优惠券")
    @GetMapping("/getUserCoupons/{status}")
    public R<List<UserCouponsVO>> getUserCoupons(@PathVariable @ApiParam(name = "status",value = "使用状态 0-全部 1-待使用 2-已使用 3-已失效 ",required = true) String status) {
        List<UserCouponsVO> list= patientApp.getUserCoupons(UserSecurityContextHolder.getUserId(),status);
        return R.success(list);
    }



    // 优惠券详情
    @ApiOperation("优惠券详情")
    @GetMapping("/getUserCouponDetail/{couponCode}")
    public R<UserCouponsVO> getUserCouponDetail(@PathVariable @ApiParam(name = "couponCode",value = "优惠券码",required = true) String couponCode) {
        List<UserCouponsVO> list= patientApp.getUserCoupons(UserSecurityContextHolder.getUserId(),"0");
        if (ObjectUtils.isNotEmpty(list)){
            return R.success(list.stream().filter(item->item.getCouponCode().equals(couponCode)).findFirst().orElse(null));
        }
        return R.success(null);
    }

    // 当前用户可用的优惠券
    @ApiOperation("当前用户可用优惠券")
    @GetMapping("/getUserCouponsToOrder")
    public R<List<UserCouponsVO>> getUserCouponsToOrder(GetUserCouponsToOrderDTO params) {
        List<UserCouponsVO> list= patientApp.getUserCouponsToOrder(params.getOrderSn(),params.getId(),UserSecurityContextHolder.getUserId());
        return R.success(list);
    }

    // 当前用户可用于订单的优惠券 TODO V1.5
    @ApiOperation("当前用户可用于挂号订单的优惠券")
    @GetMapping("/getUserCouponsToGHOrder")
    public R<List<UserCouponsVO>> getUserCouponsToGHOrder(GetUserCouponsToGHOrderReq params) {
        GetUserCouponsToGHOrderDTO dto = new GetUserCouponsToGHOrderDTO();
        dto.setUserId(UserSecurityContextHolder.getUserId());
        dto.setOrderType(params.getOrderType());
        dto.setSourceAmount(params.getSourceAmount());
        dto.setProjectId(params.getProjectId());
        List<UserCouponsVO> list= patientApp.getUserCouponsToGHOrder(dto);
        return R.success(list);
    }

}
