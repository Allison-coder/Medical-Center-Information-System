package com.params.rest.controller;

import com.params.application.order.OrderApp;
import com.params.application.patient.PatientApp;
import com.params.domain.order.OrderDomainService;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.BindOrderAndCouponBO;
import com.params.pojo.bo.GetMergeOrderListBO;
import com.params.pojo.bo.OrderCreateBO;
import com.params.pojo.dto.AddNewTreatmentDTO;
import com.params.pojo.dto.CreateOrderDTO;
import com.params.pojo.dto.QueryOrderDTO;
import com.params.pojo.req.AddNewTreatmentReq;
import com.params.pojo.req.GetMergeOrderListReq;
import com.params.pojo.vo.InterviewRecordsVO;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.PatientUserInfoVO;
import com.params.pojo.vo.TreatmentOrderVO;
import com.params.pojo.vo.common.PageVO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.pojo.dto.BindOrderAndCouponDTO;
import com.params.rest.pojo.dto.CancelOrderDTO;
import com.params.rest.pojo.dto.OrderDTO;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@RestController
@Api(tags = "订单接口")
@Validated
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderDomainService orderService;

    @Autowired
    private OrderApp orderApp;

    @Autowired
    private PatientApp patientApp;


    @ApiOperation("创建订单")
    @PostMapping("/createOrder")
    public R<String> createOrder(@RequestBody @Validated CreateOrderDTO dto) {
        OrderCreateBO bo = OrderCreateBO.builder().patientSn(dto.getPatientSn())
                .scheduleDetailId(dto.getScheduleDetailId())
                .adminId(dto.getAdminId())
                .orderType(dto.getOrderType())
                .parentOrderSn(dto.getParentOrderSn())
                .userId(UserSecurityContextHolder.getUserId())
                .channelId(UserSecurityContextHolder.getChannelId())
                .isUseCoupon(dto.getIsUseCoupon())
                .couponCode(dto.getCouponCode())
                .build();
        String orderSn = orderService.createOrder(bo);
        return R.success(orderSn);
    }

    @ApiOperation("获取未完成的订单信息")
    @GetMapping("/getUnfinishedOrders")
    public R<List<OrderVO>> getUnfinishedOrders() {
        Integer userId = UserSecurityContextHolder.getUserId();
        Integer channelId = UserSecurityContextHolder.getChannelId();
        List<OrderVO> unfinishedOrders = orderApp.getUnfinishedOrders(userId, channelId);
        return R.success(unfinishedOrders);
    }

    @ApiOperation("获取订单信息")
    @GetMapping("/getOrders")
    public R<PageVO<OrderVO>> getOrders(OrderDTO req) {
        QueryOrderDTO dto = QueryOrderDTO.builder()
                .orderTypes(Arrays.asList(req.getType()).stream().filter(Objects::nonNull).collect(Collectors.toList()))
                .orderStatusList(Arrays.asList(req.getStatus()).stream().filter(Objects::nonNull).collect(Collectors.toList()))
                .pageNum(req.getPageNum())
                .pageSize(req.getPageSize())
                .channelId(UserSecurityContextHolder.getChannelId())
                // .channelId(1)
                .build();
        // 根据 userId 查出患者
        List<PatientUserInfoVO> patientByCurrentUser = patientApp.getPatientByCurrentUser(UserSecurityContextHolder.getUserId(), UserSecurityContextHolder.getChannelId());
        // List<PatientUserInfoVO> patientByCurrentUser = patientApp.getPatientByCurrentUser(33, 1);
        if (CollectionUtils.isNotEmpty(patientByCurrentUser)) {
            dto.setPatientSns(patientByCurrentUser.stream().map(PatientUserInfoVO::getPatientSn).collect(Collectors.toList()));
            PageVO<OrderVO> result = orderApp.getOrders(dto);
            return R.success(result);
        }
        PageVO<OrderVO> result = new PageVO<OrderVO>();
        result.setCurrentPage(req.getPageNum());
        result.setPageSize(req.getPageSize());
        return R.success(result);
    }

    @ApiOperation("根据订单号获取订单信息")
    @GetMapping("/getOrderByOrderSn")
    public R<OrderVO> getOrderByOrderSn(@RequestParam(value = "orderSn") @NotNull @NotEmpty(message = "订单号不能为空！") String orderSn) {
        OrderVO orderVO = orderApp.getOrderByOrderSn(orderSn, UserSecurityContextHolder.getChannelId());
        return R.success(orderVO);
    }

    @ApiOperation("取消订单")
    @PostMapping("/cancelOrder")
    public R cancelOrder(@RequestBody @Validated CancelOrderDTO dto) {
        return R.success(orderService.cancelOrder(dto.getOrderSn(), UserSecurityContextHolder.getChannelId()));
    }

    @ApiOperation("绑定优惠券和订单")
    @PostMapping("/bindOrderAndCoupon")
    public R<Boolean> bindOrderAndCoupon(@RequestBody BindOrderAndCouponDTO dto) {

        BindOrderAndCouponBO bo = new BindOrderAndCouponBO();
        bo.setIsUseCoupon(dto.getIsUseCoupon());
        bo.setCouponCode(dto.getCouponCode());
        bo.setOrderSn(dto.getOrderSn());
        bo.setProjectId(dto.getProjectId());
        return R.success(orderService.bindOrderAndCoupon(bo,UserSecurityContextHolder.getChannelId()));
    }

    // 0元订单支付
    @ApiOperation("0元订单支付")
    @PostMapping("/zeroOrderAndPay/{orderSn}")
    public R<Boolean> zeroOrderAndPay(@PathVariable String orderSn) {
        // 直接改状态
        Boolean suc = orderService.zeroOrderAndPay(orderSn);
        return R.success(suc);
    }


    // region V1.5 新开接口 ------------------ TODO V1.5

    @ApiOperation("V1.5 新增接口 创建项目订单")
    @PostMapping("/createOrderToProject")
    public R<String> createOrderToProject(@RequestBody @Validated AddNewTreatmentReq params) {

        AddNewTreatmentDTO dto = new AddNewTreatmentDTO();
        BeanUtils.copyProperties(params, dto);
        return R.success(orderApp.addNewTreatment(dto));
    }


    // 面诊记录的详情
    @ApiOperation("V1.5 新开接口 面诊记录的详情")
    @GetMapping("/getFaceDiagnoseDetail/{orderSn}")
    public R<InterviewRecordsVO> getFaceDiagnoseDetail(@PathVariable String orderSn) {
        return R.success(orderApp.getInterviewRecordsByOrderSn(orderSn,"WEIXIN_APP"));
    }

    // 通过方案编号查看订单
    @ApiOperation("V1.5 新开接口 通过方案编号查看订单")
    @GetMapping("/getOrderByProjectSn/{planSn}")
    @VerifyLogin(verifyLogin = false,verifyParam = false)
    public R<List<TreatmentOrderVO>> getOrderByProjectSn(@PathVariable String planSn) {
        return R.success(orderApp.getOrderByProjectSn(planSn));
    }

    // endregion


    // region V1.5.1 新开接口 ------------------ TODO V1.5.1

    // 获取合并支付的订单列表
    @ApiOperation("V1.5.1 新开接口 获取合并支付的订单列表")
    @GetMapping("/getMergeOrderList")
    public R<List<OrderVO>> getMergeOrderList(GetMergeOrderListReq req)  {
        if (ObjectUtils.isEmpty(req.getOrderSns())){
            throw new ServiceException("订单号不能为空");
        }
        // private Integer channelId;
        GetMergeOrderListBO bo = new GetMergeOrderListBO();
        bo.setOrderSns(req.getOrderSns());
        bo.setChannelId(UserSecurityContextHolder.getChannelId());
        List<OrderVO> voList = orderApp.getMergeOrderList(bo);
        return R.success(voList);
    }

    // endregion
}
