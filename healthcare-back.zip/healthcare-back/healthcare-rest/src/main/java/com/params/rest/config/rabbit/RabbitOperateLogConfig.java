package com.params.rest.config.rabbit;

import com.params.constant.rabbitmq.OperateLogQueueConstant;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <pre>
 * 操作日志队列
 * </pre>
 *
 * 
 * @version 1.0.0
 */
@Configuration
public class RabbitOperateLogConfig {

    /**
     * 定义队列
     *
     * @return
     */
    @Bean
    public Queue operateLogQueue() {
        return QueueBuilder
                .durable(OperateLogQueueConstant.QUEUE_OPERATE_LOG) // durable: 是否持久化
                .withArgument("x-max-priority", 255)
                .build()
                ;
    }

    /**
     * 配置默认的交换机
     *
     * @return
     */
    @Bean
    public DirectExchange operateLogExchange() {
        return new DirectExchange(OperateLogQueueConstant.EXCHANGE_OPERATE_LOG_COMMON, true, false);
    }

    /**
     * 绑定队列到交换器
     *
     * @param queue
     * @param directExchange
     *
     * @return
     */
    @Bean
    public Binding operateLogBinding(@Qualifier("operateLogQueue") Queue queue, @Qualifier("operateLogExchange") DirectExchange directExchange) {
        return BindingBuilder
                .bind(queue)
                .to(directExchange)
                .with(OperateLogQueueConstant.QUEUE_OPERATE_LOG);
    }

}
