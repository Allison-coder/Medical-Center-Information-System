package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Data
@ApiModel("订单查询 DTO")
public class OrderDTO {

    @ApiModelProperty(value = "订单类型，1：挂号单，2：治疗单", example = "1")
    @Min(1)
    @Max(2)
    private Integer type;

    @ApiModelProperty(value = "订单状态,0：待支付 1：已支付 2：已取消 3：退款中 4：已退款", example = "1")
    @Min(0)
    @Max(4)
    private Integer status;

    @ApiModelProperty(value = "页大小，默认10", example = "10")
    @Min(1)
    @Max(100)
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码，默认1", example = "1")
    @Min(1)
    private Integer pageNum = 1;
}
