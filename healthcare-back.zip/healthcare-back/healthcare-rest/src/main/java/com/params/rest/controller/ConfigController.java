package com.params.rest.controller;

import cn.hutool.core.collection.CollUtil;
import com.params.framework.vo.R;
import com.params.pojo.dto.ConfigDTO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.component.config.ConfigProcessServiceFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import static com.params.framework.constant.GlobalErrorCodeConstant.VALIDATION_REQUEST_PARAM_ERROR;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 * @Create 2024/1/5
 */
@Api(tags = "配置接口")
@RestController
public class ConfigController {

    @Resource
    private ConfigProcessServiceFactory configProcessServiceFactory;

    @ApiOperation("获取配置")
    @PostMapping("/v1/config/getConfig")
    @VerifyLogin(verifyLogin = false)
    public R<Object> getConfig(HttpServletRequest request, @RequestBody ConfigDTO dto) {
        if (CollUtil.isEmpty(dto.getCodes())) return R.success(null);
        if (dto.getCodes().size() > 5) {
            return R.error(VALIDATION_REQUEST_PARAM_ERROR.getCode(), "最多同时处理5个配置");
        }
        return R.success(configProcessServiceFactory.run(request, dto));
    }
}
