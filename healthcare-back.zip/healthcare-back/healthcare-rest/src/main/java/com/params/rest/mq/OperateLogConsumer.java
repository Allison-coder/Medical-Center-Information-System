package com.params.rest.mq;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.params.constant.rabbitmq.OperateLogQueueConstant;
import com.params.pojo.dto.OperateLogDTO;
import com.params.rabbitmq.OperateLogSender;
import com.params.service.OperateLogService;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * <pre>
 * 操作日志消费者
 * </pre>
 *
 * 
 * @version 1.0.0
 */
@Slf4j
@Component
@RabbitListener(queues = OperateLogQueueConstant.QUEUE_OPERATE_LOG, containerFactory = "consumerBatchContainerFactory")
public class OperateLogConsumer {

    @Autowired
    private OperateLogSender operateLogSender;

    @Autowired
    private OperateLogService operateLogService;

    @RabbitHandler
    public void process(@Payload String body, Message message, Channel channel) throws IOException {
        MessageProperties messageProperties = message.getMessageProperties();
        OperateLogDTO operateLogDTO = null;
        try {
            if (StrUtil.isBlank(body)) return;
            operateLogDTO = JSON.parseObject(body, OperateLogDTO.class);
            operateLogService.doOperateLog(operateLogDTO);
        } catch (Exception e) {
            if (null == operateLogDTO || operateLogDTO.getRetryCount() >= 10) {
                log.error("OperateLogReceiver.process 异常 重试次数大于等于10 threadId:{} body:{}", Thread.currentThread().getId(), body, e);
                return;
            }
            log.warn("OperateLogReceiver.process 消费异常 threadId:{} body:{}", Thread.currentThread().getId(), body, e);
            operateLogDTO.setRetryCount(operateLogDTO.getRetryCount() + 1);
            operateLogSender.send(operateLogDTO, messageProperties);
        } finally {
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
        }
    }

}
