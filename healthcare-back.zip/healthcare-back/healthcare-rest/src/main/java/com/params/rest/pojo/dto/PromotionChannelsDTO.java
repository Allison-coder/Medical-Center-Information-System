package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @DESCRIPTION 创建推广渠道的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@ApiModel("创建渠道的参数")
public class PromotionChannelsDTO implements Serializable {

    @ApiModelProperty(value = "渠道名称",required = true)
    @NotNull(message="渠道名称不能为空")
    private String channelName;

    @ApiModelProperty(value = "优惠券类型  0-免费券 1- 8折券",required = true)
    @NotNull(message="优惠券类型")
    private Integer couponType;

    @ApiModelProperty(value = "大标题",required = true)
    @NotNull(message="大标题不能为空")
    private String bigTitle;

    @ApiModelProperty(value = "小标题",required = true)
    @NotNull(message="小标题不能为空")
    private String smallTitle;

    @ApiModelProperty(value = "自动回复文本",required = true)
    @NotNull(message="自动回复文本不能为空")
    private String autoAckContent;

}
