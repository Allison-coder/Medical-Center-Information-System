package com.params.rest.config;

import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.asymmetric.RSA;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "system.rsa")
public class RsaProperties {
    private String publicKey;
    private String privateKey;

    public RSA getRsa() {
        return SecureUtil.rsa(privateKey, publicKey);
    }
}
