package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 获取活动详情的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class GetPromotionDetailDTO implements Serializable {

    @ApiModelProperty(value = "渠道code ")
    private String channelCode;

    @ApiModelProperty(value = "用户 id ")
    private Integer userId;


}
