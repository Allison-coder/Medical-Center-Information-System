package com.params.rest.mq;

import com.alibaba.fastjson.JSONObject;
import com.params.constant.CustomException;
import com.params.constant.rabbitmq.CheckPayStatusConstant;
import com.params.pojo.vo.CheckPayOrderStatusVO;
import com.params.rabbitmq.CheckPayStatusMsgSender;
import com.params.service.ParamsPayService;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * 检测订单队列消费者者
 */
@Component
@Slf4j
public class CheckPayStatusMsgReceiver {


    @Autowired
    private ParamsPayService paramsPayService;

    @Autowired
    private CheckPayStatusMsgSender checkPayStatusMsgSender;

    private static long nextTimes[] = new long[]{1, 3, 5, 8, 10, 15, 1, 3, 5, 8, 10, 15, 30, 60, 2 * 60, 2 * 60, 2 * 60, 5 * 60, 5 * 60};

    @RabbitListener(queues = CheckPayStatusConstant.QUEUE)
    public void process(String content, Message message, Channel channel) throws IOException {
        CheckPayOrderStatusVO checkPayOrderStatusVO = null;
        try {
            log.info("查询支付队列开始消费：{}", content);
            checkPayOrderStatusVO = JSONObject.parseObject(content, CheckPayOrderStatusVO.class);
            if (checkPayOrderStatusVO.getReTryCount() >= nextTimes.length) {
                log.warn("{}:查询次数也达到最大值，不再进行系统查询，请管理人员确认,消息：{}", checkPayOrderStatusVO.getPaymentType(), content);
                // 通知&存库
                channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
                return;
            }
            Boolean checkResult = paramsPayService.checkPayOrderStatus(checkPayOrderStatusVO.getTradeNum(), checkPayOrderStatusVO.getPaymentType());
            log.info("当次查询支付结果：{}, 内容：{}", checkResult, content);
            if (checkResult == null){
                channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
                return;
            }
            if (!checkResult) {
                checkPayOrderStatusVO.setReTryIntervalsTime(nextTimes[checkPayOrderStatusVO.getReTryCount()] * 1000);
                checkPayOrderStatusVO.setReTryCount(checkPayOrderStatusVO.getReTryCount() + 1);
                checkPayStatusMsgSender.send(checkPayOrderStatusVO);
            }
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
        } catch (CustomException ignored) {
            // 确认消费
            log.warn("支付方式：{}， 抛出用户自定义异常:{}", checkPayOrderStatusVO.getPaymentType(), ignored.getMessage());
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
        } catch (Exception e) {
            log.warn("消息：{}，重试计划处理失败:{}", content, e);
            channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
        }
    }


}
