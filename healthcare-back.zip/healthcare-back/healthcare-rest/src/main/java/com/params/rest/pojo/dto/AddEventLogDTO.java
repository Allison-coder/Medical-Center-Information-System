package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 埋点日志表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-25
 */
@Data
@ApiModel("添加埋点日志的 DTO")
public class AddEventLogDTO implements Serializable {


    /**
     * 事件类型
     */
    @ApiModelProperty(value = "事件类型 'INTO_LANDING_PAGE'-落地页 ,'CLICK_GETCOUPON_BUTTUN'-领取按钮,'REHABILITATION_GUIDE_PAGE'-康复指页")
    private String eventType;

    /**
     * 活动渠道 code
     */
    @ApiModelProperty(value = "活动渠道 code ")
    private String channelCode;

    /**
     * 客户端的 openId
     */
    @ApiModelProperty(value = "客户端的 openId ")
    private String openId;

    /**
     * 设备品牌
     */
    @ApiModelProperty(value = "设备品牌  wx.getSystemInfoAsync 可以获取")
    private String systemInfoBrand;

    /**
     * 设备型号
     */
    @ApiModelProperty(value = "设备型号  wx.getSystemInfoAsync 可以获取")
    private String systemInfoModel;

    /**
     * 设备的唯一标识符
     */
    @ApiModelProperty(value = "设备的唯一标识符  如果wx.getSystemInfoAsync或是其他方法都获取不到就不传 ")
    private String deviceId;

    /**
     * 页面的唯一标识符
     */
    @ApiModelProperty(value = "哪个页面上传的数据就传哪个页面的路径 ")
    private String pagePath;

    /**
     * 按钮的操作
     */
    @ApiModelProperty(value = "按钮标识 传中文 ",example = "立即领取")
    private String buttonFlag;

    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID ")
    private Integer userId;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码 ")
    private String mobile;
    /**
     * 设备系统类型
     */
    @ApiModelProperty(value = "设备系统类型")
    private String system;


}
