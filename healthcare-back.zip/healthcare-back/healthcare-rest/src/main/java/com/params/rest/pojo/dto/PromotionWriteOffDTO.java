package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @DESCRIPTION 推广的核销
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PromotionWriteOffDTO implements Serializable {

    @ApiModelProperty(value = "登录时返回的 token",required = true)
    @NotNull(message = "token不为空")
    private String  token;

    @ApiModelProperty(value = "优惠券码",required = true)
    @NotNull(message = "优惠券码不为空")
    private String couponCode;
}
