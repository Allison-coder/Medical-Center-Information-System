package com.params.rest.component.security;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@AllArgsConstructor
public enum ContentSecurityScenesEnum {

    PORN("porn", "图片智能鉴黄"),
    TERRORISM("terrorism", "图片暴恐涉政"),
    AD("ad", "图文违规"),
    QRCODE("qrcode", "图片二维码"),
    LIVE("live", "图片不良场景"),
    LOGO("logo", "图片logo"),
    ;

    private final String code;
    private final String msg;
}
