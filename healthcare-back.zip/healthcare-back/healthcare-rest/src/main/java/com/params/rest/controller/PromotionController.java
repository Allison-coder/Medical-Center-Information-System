package com.params.rest.controller;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.application.promotion.PromotionApp;
import com.params.domain.promotion.PromotionDomainService;
import com.params.entity.Coupon;
import com.params.entity.ParamsConfig;
import com.params.framework.vo.R;
import com.params.pojo.bo.PromotionChannelsBO;
import com.params.pojo.vo.CheckWriteOffVO;
import com.params.pojo.vo.LandingPageVO;
import com.params.pojo.vo.PromotionDetailsVO;
import com.params.pojo.vo.PromotionLoginVO;
import com.params.pojo.vo.ReceiveStatusVO;
import com.params.pojo.vo.WriteOffCouponVO;
import com.params.pojo.vo.common.PageVO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.pojo.dto.GetCouponListDTO;
import com.params.rest.pojo.dto.PromotionChannelsDTO;
import com.params.rest.pojo.dto.PromotionLoginDTO;
import com.params.rest.pojo.dto.PromotionWriteOffDTO;
import com.params.service.ParamsConfigService;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @DESCRIPTION 推广
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "优惠券活动")
@RestController
@RequestMapping("/promotion")
public class PromotionController {

    @Autowired
    private PromotionDomainService promotionDomainService;

    @Autowired
    private ParamsConfigService paramsConfigService;


    @Autowired
    private PromotionApp promotionApp;


    @PostMapping("/login")
    @ApiOperation("登录")
    @VerifyLogin(verifyParam = false)
    public R<PromotionLoginVO> login(@RequestBody @Validated PromotionLoginDTO params) {
        String login = promotionDomainService.login(params.getUsername(), params.getPassword());
        PromotionLoginVO promotionLoginVO = new PromotionLoginVO();
        promotionLoginVO.setToken(login);
        return R.success(promotionLoginVO);
    }

    @PostMapping("/createPromotionChannels")
    @ApiOperation("创建推广渠道")
    @VerifyLogin(verifyParam = false)
    public R<String> createPromotionChannels(@RequestBody @Validated PromotionChannelsDTO params) {

        PromotionChannelsBO bo = new PromotionChannelsBO();
        bo.setChannelName(params.getChannelName());
        bo.setCouponType(params.getCouponType());
        bo.setBigTitle(params.getBigTitle());
        bo.setSmallTitle(params.getSmallTitle());
        bo.setAutoAckContent(params.getAutoAckContent());
        String code = promotionDomainService.createPromotionChannels(bo);
        return R.success(code);
    }


    @ApiOperation("核销")
    @PostMapping("/writeOff")
    @VerifyLogin(verifyParam = false)
    public R<CheckWriteOffVO> writeOff(@RequestBody @Validated PromotionWriteOffDTO params) {
        return R.success(promotionDomainService.writeOff(params.getToken(), params.getCouponCode()));
    }

    @ApiOperation("优惠券是否已核销")
    @PostMapping("/checkWriteOff")
    @VerifyLogin(verifyParam = false)
    public R<CheckWriteOffVO> checkWriteOff(@RequestBody @Validated PromotionWriteOffDTO params) {
        return R.success(promotionDomainService.checkWriteOff(params.getToken(), params.getCouponCode()));
    }


    @ApiOperation("根据优惠券查找详情")
    @GetMapping("/getCoupon/{couponCode}")
    @VerifyLogin(verifyParam = false)
    public R<WriteOffCouponVO> getCoupon(@PathVariable String couponCode) {
        WriteOffCouponVO writeOffCoupon = promotionDomainService.getCoupon(couponCode);
        return R.success(writeOffCoupon);
    }

    @ApiOperation("获取已核销的优惠券")
    @GetMapping("/getWriteOffCouponList")
    @VerifyLogin(verifyParam = false)
    public R<PageVO<WriteOffCouponVO>> getWriteOffCouponList(GetCouponListDTO params) {
        Page<Coupon> page = new Page<>();
        page.setSize(params.getPageSize());
        page.setCurrent(params.getPageNum());
        PageVO<WriteOffCouponVO> writeOffCouponList = promotionDomainService.getWriteOffCouponList(page, params.getToken());
        return R.success(writeOffCouponList);
    }

    // --------------------------------------------- 新

    // 活动落地页配置
    @ApiOperation("活动落地页配置")
    @GetMapping("/getLandingPage")
    @VerifyLogin(verifyLogin = false,verifyParam = false)
    public R<LandingPageVO> getLandingPageConfig() {
        LandingPageVO vo = new LandingPageVO();
        String config = paramsConfigService.getOne(new LambdaQueryWrapper<ParamsConfig>().eq(ParamsConfig::getConfigCode, "LANDING_PAGE").last("limit 1")).getConfigInfo();
        vo = JSON.parseObject(config, LandingPageVO.class);
        return R.success(vo);
    }


    @ApiOperation("根据渠道code获取详情")
    @GetMapping("/getPromotionDetail/{channelCode}")
    @VerifyLogin(verifyLogin = false,verifyParam = false)
    // public R<PromotionDetailsVO> getPromotionDetail(GetPromotionDetailDTO params) {
    public R<PromotionDetailsVO> getPromotionDetail(@PathVariable String channelCode) {
        PromotionDetailsVO vo = promotionApp.getPromotionChannelByCode(channelCode);
        return R.success(vo);
    }


    @ApiOperation("根据渠道code获取用户领取状态")
    @GetMapping("/getReceiveStatus/{channelCode}")
    public R<ReceiveStatusVO> getReceiveStatus(@PathVariable String channelCode) {
        ReceiveStatusVO vo = promotionApp.getReceiveStatus(channelCode,UserSecurityContextHolder.getUserId());
        return R.success(vo);
    }


    // 领取活动优惠券
    @ApiOperation("领取活动优惠券")
    @GetMapping("/receiveCoupons/{channelCode}")
    public R<Boolean> receiveCoupons(@PathVariable String channelCode) {
        Boolean receSuc= promotionDomainService.receiveCoupons(channelCode, UserSecurityContextHolder.getUserId());
        return R.success(receSuc);
    }


}
