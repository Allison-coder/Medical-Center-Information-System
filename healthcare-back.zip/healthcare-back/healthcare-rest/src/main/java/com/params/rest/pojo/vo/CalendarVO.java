package com.params.rest.pojo.vo;

import lombok.Data;

import java.util.List;

@Data
public class CalendarVO {
    private List<String> week;
    private List<DateInfoVO> date1;
    private List<DateInfoVO> date2;

}
