package com.params.rest.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.thread.GlobalThreadPool;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.servlet.ServletUtil;
import cn.hutool.json.JSONTokener;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.params.framework.vo.R;
import com.params.pojo.dto.OperateLogDTO;
import com.params.rabbitmq.OperateLogSender;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.service.OperateLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
@Api(tags = "API接口")
public class ApiController {

    @Resource
    private OperateLogSender operateLogSender;

    @Resource
    private OperateLogService operateLogService;

    /**
     * 上传日志
     */
    @ApiOperation("上传日志")
    @PostMapping("/v1/uploadOperateLog")
    @VerifyLogin(verifyParam = false)
    public R<Boolean> uploadOperateLog(HttpServletRequest request, @RequestBody String jsonArrData) {
        GlobalThreadPool.execute(() -> {
            try {
                String body = jsonArrData;
               if (StrUtil.isBlank(body)) {
                   String reqStr = JSON.toJSONString(ServletUtil.getParamMap(request));
                   JSONObject jsonObject = JSONObject.parseObject(reqStr);
                   body = jsonObject.getString("jsonArrData");
               } else {
                   JSONObject jsonObject = JSONObject.parseObject(body);
                   body = jsonObject.getString("jsonArrData");
               }

                OperateLogDTO operateLogDTO = new OperateLogDTO();
                operateLogDTO.setBody(body);
                operateLogDTO.setIp(ServletUtil.getClientIP(request));
                operateLogDTO.setTime(cn.hutool.core.date.DateUtil.date());
                operateLogSender.send(operateLogDTO);
            } catch (Exception e) {
                log.warn("埋点日志格式异常 {}", jsonArrData, e);
                doUploadOperateLog(request, jsonArrData);
            }
        });
        return R.success(true);
    }

    private void doUploadOperateLog(HttpServletRequest request, String jsonArrData) {
        try {
            if (StrUtil.isEmpty(jsonArrData)) {
                String reqStr = JSON.toJSONString(ServletUtil.getHeaderMap(request));
                JSONObject jsonObject = JSONObject.parseObject(reqStr);
                jsonArrData = jsonObject.getString("jsonArrData");
            }
            Object obj = new JSONTokener(jsonArrData, null).nextValue();
            if (obj instanceof cn.hutool.json.JSONObject) {                 // Json 格式
                JSONObject jsonObject = JSONObject.parseObject(jsonArrData);
                if (StrUtil.isBlank(jsonObject.getString("ip")))
                    jsonObject.put("ip", ServletUtil.getClientIP(request));
                jsonObject.put("time", DateUtil.format(DateUtil.date(), "yyyy-MM-dd HH:mm:ss SSS"));
                operateLogService.saveSysLog(jsonObject);
            } else if (obj instanceof cn.hutool.json.JSONArray) {
                JSONArray jsonArray = JSONArray.parseArray(jsonArrData);    //JsonArray 格式
                if (jsonArray != null) {
                    for (int i = 0; i < jsonArray.size(); i++) {
                        JSONObject jsonObject = JSONObject.parseObject(jsonArray.get(i).toString());
                        if (StrUtil.isBlank(jsonObject.getString("ip")))
                            jsonObject.put("ip", ServletUtil.getClientIP(request));
                        jsonObject.put("time", DateUtil.format(DateUtil.date(), "yyyy-MM-dd HH:mm:ss SSS"));
                        operateLogService.saveSysLog(jsonObject);
                    }
                }
            } else {                                                        // 其他类型
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("value", jsonArrData);
                if (StrUtil.isBlank(jsonObject.getString("ip")))
                    jsonObject.put("ip", ServletUtil.getClientIP(request));
                jsonObject.put("time", DateUtil.format(DateUtil.date(), "yyyy-MM-dd HH:mm:ss SSS"));
                operateLogService.saveSysLog(jsonObject);
            }
        } catch (Exception e) {
            log.warn("埋点日志格式异常", e);
        }
    }
}
