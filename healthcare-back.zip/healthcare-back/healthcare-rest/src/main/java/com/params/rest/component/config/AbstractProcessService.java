package com.params.rest.component.config;

import com.params.pojo.dto.ParamsConfigDTO;
import com.params.rest.component.config.service.ProcessService;
import com.params.rest.pojo.vo.CityVO;
import com.params.service.ParamsConfigService;

import javax.annotation.Resource;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
public abstract class AbstractProcessService implements ProcessService {

    @Resource
    private ParamsConfigService paramsConfigService;

    protected String getConfig(String code, CityVO cityVO) {
        return getConfig(code, cityVO, true);
    }

    protected String getConfig(String code, CityVO cityVO, Boolean isNeedParent) {
        ParamsConfigDTO configDTO = new ParamsConfigDTO();
        configDTO.setCityId(cityVO != null ? cityVO.getCityId() : -1);
        configDTO.setChannelId(-1);
        configDTO.setConfigCode(code);
        configDTO.setNeedParent(isNeedParent);
        return paramsConfigService.getOneConfig(configDTO);
    }

}
