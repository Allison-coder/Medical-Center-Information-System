package com.params.rest.pojo.vo;

import lombok.Data;

import java.time.LocalDate;

@Data
public class DateInfoVO {
    private String date;
    private String textDate;
    private String textMonth;

    // 构造函数
    public DateInfoVO(LocalDate date) {
        this.date = date.toString();
        this.textDate = String.valueOf(date.getDayOfMonth());
        this.textMonth = date.getMonthValue() + "月";
    }
}
