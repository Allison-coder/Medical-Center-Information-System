package com.params.rest.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @DESCRIPTION 获取用户订单可用优惠券
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class GetUserCouponsToOrderDTO {

    @ApiModelProperty(value = "治疗方案的子项 id", required = true)
    private Integer id;
    @ApiModelProperty(value = "订单号", required = true)
    private String orderSn;

}
