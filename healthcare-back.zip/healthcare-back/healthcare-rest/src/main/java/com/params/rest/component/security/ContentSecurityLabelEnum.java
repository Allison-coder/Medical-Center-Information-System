package com.params.rest.component.security;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Getter
@AllArgsConstructor
public enum ContentSecurityLabelEnum {

    NORMAL("normal", "正常"),
    ;

    private final String code;
    private final String msg;
}
