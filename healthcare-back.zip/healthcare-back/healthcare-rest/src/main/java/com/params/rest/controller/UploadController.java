package com.params.rest.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.UUID;
import cn.hutool.core.util.StrUtil;
import com.params.component.oss.service.OssService;
import com.params.framework.vo.R;
import com.params.utils.UserSecurityContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@RestController
@Slf4j
public class UploadController {

    @Autowired
    private OssService ossService;

    @GetMapping("/upload/sign")
    public R sign(String contentType) throws UnsupportedEncodingException {
        String resultKey = StrUtil.format("tmp/{}/{}{}", DateUtil.format(DateUtil.date(), "yyyy/MM"),
                UserSecurityContextHolder.getChannelId(), UUID.randomUUID().toString(true));
        return R.success(ossService.sign(resultKey, contentType));
    }
}
