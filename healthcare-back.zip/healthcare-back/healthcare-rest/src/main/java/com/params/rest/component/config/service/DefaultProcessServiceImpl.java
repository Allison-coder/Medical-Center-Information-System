package com.params.rest.component.config.service;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.params.rest.component.config.AbstractProcessService;
import com.params.rest.component.config.ConfigProcessDTO;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * 普通配置获取方式
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Service
public class DefaultProcessServiceImpl extends AbstractProcessService {

    @Override
    public Object build(ConfigProcessDTO dto) {
        String configInfo = super.getConfig(dto.getCode(), dto.getCity());
        if (StrUtil.isBlank(configInfo)) return null;
        return JSON.parseObject(configInfo);
    }
}
