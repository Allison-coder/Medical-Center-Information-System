package com.params.rest.component.security;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.UUID;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipaySecurityRiskContentAnalyzeRequest;
import com.alipay.api.request.AlipaySecurityRiskContentResultGetRequest;
import com.alipay.api.response.AlipaySecurityRiskContentAnalyzeResponse;
import com.alipay.api.response.AlipaySecurityRiskContentResultGetResponse;
import com.params.service.impl.ProxyDefaultAlipayClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *
 * Created by jc on 2022/1/10.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Slf4j
@Component
public class ContentSecurityClientImpl implements ContentSecurityClient {

    private final static String TEXT_RISK_LABELS = "politics,porn,illegal,terrorism";

    @Override
    public ContentSecurityBO contentSecurityV2(String checkContent) {
        long startTime = System.currentTimeMillis();

        ContentSecurityBO result = new ContentSecurityBO();
        result.setResult(true);
        result.setAbnormal(false);
        result.setCheckContent(checkContent);
        try {
            String riskLabels = TEXT_RISK_LABELS;

            Map<String, Object> bizContent = new HashMap<>();
            bizContent.put("app_name", "证件照拍摄_text");
            bizContent.put("app_scene", "cs_open_service_text");
            bizContent.put("publish_date", DateUtil.formatDateTime(DateUtil.date()));
            bizContent.put("account_id", "2019032163622086");
            bizContent.put("account_type", "");
            bizContent.put("app_main_scene", "");
            bizContent.put("app_main_scene_id", UUID.randomUUID().toString(true));
            bizContent.put("check_labels", riskLabels);
            bizContent.put("app_scene_data_id", UUID.randomUUID().toString(true));
            bizContent.put("text", checkContent);

            AlipayClient alipayClient = ProxyDefaultAlipayClient.getAliClient("https://openapi.alipay.com/gateway.do", "2019032163622086", "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC6a1MTlzDRLMIba5K9QN8eB/reXetrgzr8ejSV8UJYcEx/0F1bAlDZNfERPywXQYlytdyVUVxFcDwNgqhoExBHPkTC/pIdSukrf7wf0kOj3r7NYx6Lip60lcqqywlYas682T5Kdmv4MITbELWtzhO3f3diTxfEHIGdrON/xROYJQaxqP4HRVPbNbmAOCKH/TzfTS3IXSu/v4ao00P/S3k1iRYB1JY0KTK6F8knHD0A4an0FJP4ESurVtki0EpYkDXpu+h8CGZ4pws7m0mvOI9EjpWHcYxdNnvRwxO1VrodXKQiJy89K80r2A2qWtGhDUg7mzg78yMasVOM7yI6oiZ1AgMBAAECggEAC4JAuL7mxqMqwKKdho2QuLvpYv0NYa/SXm/0+yTP4cHdFy739HxqHV7VKSlrQWxMXgaYPaeuOKM7MeJVH0e+A4f2mss4nhJX3tWd+aDziBRiVy+9XQQL1D5DKtQqGYlOhh4rWFGDTOlB6nxXmwlT8kouRqV3ZCYWYnOf/+1czlGvqytxQunt/5cRWyGOh4aN2AKZZlHX/KnAmfnN3Ypi6mzeI+vNrhtB+ZrX/SO7v+Arkh0B0hk80T5+6DUvMSfqmrNtBIP9gKW8u3waOxKYJDCCxlqNUfKBZqKPxUTfebHSYABjXNZFgefYVXeLRdkjoFs2bELSG5ezze+IbYdTgQKBgQD4kjA8l6YUpegIm3je6l8PAigmfeEZuif1iq7vtvxR40+sVUDtCHXorcSx2+4FDk47kiCQsG6+FOj6SiXUIYzsAY722PDOqSrn7W4ufldC0aqx2xCilgqnM8dZE+mQ2PJC0RJr/WfX5DG1xjdGnmXCTHDJ6UhZzhTvrDouWMcgpQKBgQC//Z0sWAJmd6wIk5L+tPXJuzPfHj3q4zA58hQkPKaxlU6CjbQU3bCABzYC68iL/30RWrQcpTXr2UnLsY7JVVA+OcuFsrhNvdEWszuM4VuXL+ghf8A41j227vls8VypzQB1MgeEBpcjtelFNMFsjTHerIzVXRd3BN8+cYQVWXS1kQKBgQCCuFZ3twSXPTyOMjzZdgWxnd/Bhld3sSdMgLdIx0FgSxteNKNlRBrF14RmSJOewwwvVcSccrx6aAKxhYbpTQ+QGa22cRYKiHpQ59MWzkhTknGjAOJ5rlBB6AAA/3DIRN76dnqqoeQXbCEcR/ZPxAMdsBdsh6sN10u5UyhxsSxfJQKBgElFDZ2lvMzEMRhY0Yl5IDArzGEDFpg0uevzUfJ+XxN4qqyyTZ6E+F3z4o38091x1JYx6njgKBLpKvucuKRndac5wU015pZssYYbQsfCHYU2WD2oloBaatUMoI4OEtIOlXUkca/WIAoV23944bR+siCL83dd/p2Cc3xOMB1BtYOxAoGAGJ4iPoFttW9PLmIvOI85+iMJaZDE49nHLLKDB8k6AbB4i0Wd0LesMxwtNbmBSkNQ0Oal0jLRS1pz7chBDfusaVFr/ZsnejUwFbM9Ojrq625LjIWBtKIifywGWL2JHuxjIZP1iy2rQDWRP5DawhZ3PtVE+oSXRtx+Sfq5jwuayAA=", "json", "GBK", "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5gESNahyxAdrBfcyS4Rm8Bvb1r8uFHg1FfTrrc4eKE665PQE9FuhME6pyXv8ltXb+xSBkj8UUDJRFsy7yiGBM/p7DckSIODFouiQG7m5V0G28OtgXfHFyX8r9328hI9kva+26Xnn6i44kNbAFYx94wupkEQcabDsGE9YlN1NS8AXTQ48E98cqJjNUATy18zzetDtJpWrw+wdg01XsJSDRk54KVzWCXGE1HSYuoRyoI6sD/OtUpGi0lrudBweAlTRXM3y6XunRF/JrqQlN7ENKEcG/t9E68a0NpqjGk5Sm1wUy7qkrz5sZRDM105JVlJ+l0GSLir/K5MzLHGyBi6yLQIDAQAB", "RSA2");
            AlipaySecurityRiskContentAnalyzeRequest request = new AlipaySecurityRiskContentAnalyzeRequest();
            request.setBizContent(JSON.toJSONString(bizContent));
            AlipaySecurityRiskContentAnalyzeResponse response = alipayClient.execute(request);
            result.setResponseBody(JSON.parseObject(response.getBody()));

            log.info("[{}.contentSecurityV2]请求结果 task:{} responseCode:{} responseContent:{}", this.getClass().getSimpleName(), JSON.toJSONString(bizContent), response.getCode(), response.getBody());

            if (!response.isSuccess()) {
                log.error("[{}.contentSecurityV2]请求异常 task:{} responseCode:{} responseContent:{}", this.getClass().getSimpleName(), JSON.toJSONString(bizContent), response.getCode(), response.getBody());
                result.setResult(true);
                result.setUseTime(System.currentTimeMillis() - startTime);
                return result;
            }

            String resultAction = response.getResultAction();
            if ("need".equalsIgnoreCase(response.getNeedQuery()) && StrUtil.isNotBlank(response.getAppSceneDataId())) {
                int i = 0;
                while (true) {
                    if (i > 5) {
                        break;
                    }

                    if (i == 1) {
                        Thread.sleep(500);
                    } else {
                        Thread.sleep(1000);
                    }
                    AlipaySecurityRiskContentResultGetResponse response2;
                    Map<String, String> bizContent2 = new HashMap<>();
                    bizContent2.put("app_scene", "cs_open_service_text");
                    bizContent2.put("app_scene_data_id", response.getAppSceneDataId());
                    bizContent2.put("event_id", response.getEventId());
                    AlipaySecurityRiskContentResultGetRequest request2 = new AlipaySecurityRiskContentResultGetRequest();
                    request2.setBizContent(JSON.toJSONString(bizContent2));
                    response2 = alipayClient.execute(request2);

                    resultAction = response2.getResultAction();
                    result.setResponseBody(JSON.parseObject(response2.getBody()));

                    if ("CC".equalsIgnoreCase(response2.getResultAction())) {
                        i++;
                        continue;
                    }
                }
            }

            if ("REJECTED".equalsIgnoreCase(resultAction)) {
                result.setResult(false);
            }

            result.setUseTime(System.currentTimeMillis() - startTime);
            return result;
        } catch (Exception e) {
            log.warn("[{}.contentSecurityV2] 内容检测异常", this.getClass().getSimpleName(), e);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("error", e.getMessage());
            result.setAbnormal(true);
            result.setResponseBody(jsonObject);
            result.setUseTime(System.currentTimeMillis() - startTime);
            return result;
        } finally {
            log.debug("[{}.contentSecurityV2] 内容安全检测耗时 useTime:{}", System.currentTimeMillis(), System.currentTimeMillis() - startTime);
        }
    }
}
