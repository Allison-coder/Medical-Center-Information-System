package com.params.rest.component.config.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * 
 * @version 1.0.0
 */
@Getter
@AllArgsConstructor
public enum DriveEnum {

    // 考试驱动
    EXAM_DRIVE("#driveExam\\(.*\\)", "examDrive"),
    // 热门考试
    HOT_EXAM_DRIVE("#driveHotExam", "hotExamDrive"),
    // 获取配置
    BUILD_CONFIG_DRIVE("#driveBuildConfig\\(.*\\)", "buildConfigDrive"),
    // 考试
    BUILD_HOT_EXAM_DRIVE("#driveBuildHotExam\\(.*\\)", "buildHotExamDrive"),
    // 考试文章
    BUILD_ARTICLE_LIST_DRIVE("#driveBuildArticleList\\(.*\\)", "buildArticleListDrive"),
    ;

    private final String pattern;
    private final String drive;

}
