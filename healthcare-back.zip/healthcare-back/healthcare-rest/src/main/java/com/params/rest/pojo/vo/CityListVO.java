package com.params.rest.pojo.vo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by dzl on 2018/11/29
 **/
@Getter
@Setter
public class CityListVO implements Serializable {
    private static final long serialVersionUID = -549714614813506939L;
    private Long cityId;
    private Long cityTempId;
    private String code;
    private Integer hotable;
    private String name;
    private Long parentId;
    private String type;
    private BigDecimal longitude;
    private BigDecimal latitude;
    private String pinyin;
    private String fullFight;
}
