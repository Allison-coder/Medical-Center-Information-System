package com.params.rest.controller;

import com.params.application.patient.PatientApp;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.framework.vo.R;
import com.params.pojo.req.GetPlanFollowUpReq;
import com.params.pojo.vo.BaseTreatmentPlanVO;
import com.params.pojo.vo.PlanFollowUpVO;
import com.params.pojo.vo.PlanProjectConfigVO;
import com.params.pojo.vo.UserTreatmentPlanVO;
import com.params.pojo.vo.common.PageVO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.rest.pojo.dto.TreatmentPlanDTO;
import com.params.utils.UserSecurityContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @DESCRIPTION 治疗方案
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Api(tags = "治疗方案")
@RestController
@RequestMapping("/treatmentPlan")
public class TreatmentPlanController {

    @Autowired
    private PatientApp patientApp;


    @Autowired
    private TreatmentPlanDomainService treatmentPlanDomainService;


    @ApiOperation("获取治疗方案列表")
    @GetMapping("/getTreatmentPlan")
    // @VerifyLogin(verifyLogin = false,verifyParam = false)
    public R<PageVO<UserTreatmentPlanVO>> getTreatmentPlan(TreatmentPlanDTO params) {
        PageVO<UserTreatmentPlanVO> pageVO = patientApp.getTreatmentPlan(UserSecurityContextHolder.getUserId(), params.getPageNum(), params.getPageSize());
        return R.success(pageVO);
    }


    // region V1.5 新开接口 ------------------ TODO V1.5


    // 方案的配置接口
    @ApiOperation("V1.5 新开接口 方案为空时的项目接口")
    @GetMapping("/getTreatmentPlanConfig")
    public R<List<PlanProjectConfigVO>> getTreatmentPlanConfig() {
        List<PlanProjectConfigVO> vos = treatmentPlanDomainService.getPlanProjectConfig(null);
        return R.success(vos);
    }

    // 方案的配置接口
    @ApiOperation("V1.5 新开接口 方案为空时的项目接口")
    @GetMapping("/getTreatmentPlanConfigV15")
    @VerifyLogin(verifyLogin = false, verifyParam = false)
    public R<List<PlanProjectConfigVO>> getTreatmentPlanConfigv15() {
        List<PlanProjectConfigVO> vos = treatmentPlanDomainService.getPlanProjectConfig(1);
        if (ObjectUtils.isNotEmpty(vos)) {
            // 创建一个新的列表，并只添加需要保留的元素
            List<PlanProjectConfigVO> filteredConfigs = new ArrayList<>();
            for (PlanProjectConfigVO config : vos) {
                if (!config.getProjectName().equals("药物")
                        && !config.getProjectName().equals("急性扭伤拉伤处理")
                        && !config.getProjectName().equals("白贴固定")) {
                    filteredConfigs.add(config);
                }
            }
            return R.success(filteredConfigs);
        }
        return R.success(vos);
    }

    // 方案跟进列表
    @ApiOperation("V1.5 新开接口 方案跟进列表")
    @GetMapping("/getPlanFollowUp")
    public R<PageVO<PlanFollowUpVO>> getPlanFollowUp(GetPlanFollowUpReq params) {
        PageVO<PlanFollowUpVO> pageVO = new PageVO<>();
        pageVO = patientApp.getPlanFollowUp(params.getPageNum(), params.getPageSize(), UserSecurityContextHolder.getUserId());
        return R.success(pageVO);
    }


    // 方案详情
    @ApiOperation("V1.5 新开接口 方案详情")
    @GetMapping("/getPlanFollowUpDetail/{planSn}")
    public R<BaseTreatmentPlanVO> getPlanFollowUpDetail(@PathVariable @ApiParam(name = "planSn", value = "方案编号", required = true) String planSn) {
        BaseTreatmentPlanVO planDetail = patientApp.getDisposalPlanDetail(planSn);
        return R.success(planDetail);
    }

    //  获取所有方案
    @GetMapping("/getAllPlan")
    @ApiOperation("V1.5 新开接口 获取所有方案")
    public R<List<BaseTreatmentPlanVO>> getAllPlan() {
        Integer userId = UserSecurityContextHolder.getUserId();
        Integer channelId = UserSecurityContextHolder.getChannelId();
        List<BaseTreatmentPlanVO> voList = patientApp.getAllPlan(userId, channelId);
        return R.success(voList);
    }
    // endregion


}
