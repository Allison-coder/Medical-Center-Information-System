package com.params.rest.controller;

import com.params.framework.vo.R;
import com.params.pojo.bo.CityListBO;
import com.params.rest.component.aspect.VerifyLogin;
import com.params.service.CityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/7
 */
@Api(tags = "城市")
@RestController
public class CityController {
    @Resource
    private CityService cityService;


    @ApiOperation("城市列表")
    @PostMapping("/v1/city/getList")
    @VerifyLogin(verifyLogin = false)
    public R<List<CityListBO>> getList() {
        List<CityListBO> cityListBOS = cityService.getCityList();
        return R.success(cityListBOS);
    }
}
