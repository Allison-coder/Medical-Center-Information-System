package com.params.rest.pojo.vo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Created by dzl on 2018/11/12
 **/
@Getter
@Setter
public class CityVO implements Serializable {
    private static final long serialVersionUID = 1905126456943653978L;
    private Integer cityId;
    private Integer provinceId;
    private String name;
    private String districtCode;
    private String isDefault;
}
