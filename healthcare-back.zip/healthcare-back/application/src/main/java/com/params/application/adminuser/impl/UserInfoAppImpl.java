package com.params.application.adminuser.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.application.adminuser.HomeInfoApp;
import com.params.constant.RoleTypeEnum;
import com.params.constant.ValidateUtil;
import com.params.convert.PageConvert;
import com.params.domain.adminuser.AdminUserDomainService;
import com.params.domain.science.ScienceDomainService;
import com.params.entity.AdminRole;
import com.params.entity.AdminUserInfo;
import com.params.pojo.dto.ScienceRecordQueryDTO;
import com.params.pojo.vo.FamousDoctorVO;
import com.params.pojo.vo.ScienceRecordVO;
import com.params.pojo.vo.common.PageVO;
import com.params.service.AdminUserInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
@Slf4j
public class UserInfoAppImpl implements HomeInfoApp {
    @Resource
    private AdminUserInfoService adminUserInfoService;

    @Autowired
    private ScienceDomainService scienceDomainService;

    @Autowired
    private AdminUserDomainService adminUserDomainService;


    @Override
    public PageVO<FamousDoctorVO> getFamousDoctors(Integer channelId, Integer pageNum, Integer pageSize) {
        ValidateUtil.isTrue(Objects.isNull(channelId), "渠道id不能为空");
        ValidateUtil.isTrue(Objects.isNull(pageNum), "页码不能为空");
        ValidateUtil.isTrue(Objects.isNull(pageSize), "页大小不能为空");
        Page<AdminUserInfo> page = new Page<>(pageNum, pageSize);
        Page<AdminUserInfo> pageInfo = adminUserInfoService.getFamousDoctors(page, channelId);
        System.out.println(pageInfo);
        List<FamousDoctorVO> famousDoctorVOS = convertFamousDoctorVOS(pageInfo.getRecords());
        PageVO<FamousDoctorVO> result = PageConvert.INSTANCE.convertPage(pageInfo);
        result.setList(famousDoctorVOS);
        return result;
    }

    @Override
    public PageVO<ScienceRecordVO> getScienceRecords(Integer channelId, Integer pageNum, Integer pageSize) {
        ValidateUtil.isTrue(Objects.isNull(channelId), "渠道id不能为空");
        ValidateUtil.isTrue(Objects.isNull(pageNum), "页码不能为空");
        ValidateUtil.isTrue(Objects.isNull(pageSize), "页大小不能为空");
        ScienceRecordQueryDTO dto = ScienceRecordQueryDTO.builder()
                .showStatus(1)
                .pageSize(pageSize)
                .pageNum(pageNum)
                .channelId(channelId)
                .build();
        PageVO<ScienceRecordVO> records = scienceDomainService.getRecords(dto);
        return records;
    }

    private List<FamousDoctorVO> convertFamousDoctorVOS(List<AdminUserInfo> infos) {
        List<FamousDoctorVO> result = new ArrayList<>();
        for (AdminUserInfo info : infos) {
            FamousDoctorVO famousDoctorVO = convertFamousDoctorVO(info);
            result.add(famousDoctorVO);
        }
        return result;
    }

    private FamousDoctorVO convertFamousDoctorVO(AdminUserInfo info) {
        // 查出角色
        AdminRole role = adminUserDomainService.getRoleByadminId(info.getAdminId());
        RoleTypeEnum anEnum = RoleTypeEnum.getEnum(role.getId());
        return FamousDoctorVO.builder()
                .adminId(info.getAdminId())
                .roleCode(anEnum.code())
                .name(info.getRealName())
                .introduction(info.getIntroduction())
                .url(info.getAvatarUrl())
                .build();
    }
}
