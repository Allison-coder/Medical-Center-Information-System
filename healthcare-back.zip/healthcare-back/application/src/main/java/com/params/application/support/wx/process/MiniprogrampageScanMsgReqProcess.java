package com.params.application.support.wx.process;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component("miniprogrampageEventScanMsgReqProcess")
@Slf4j
public class MiniprogrampageScanMsgReqProcess extends MiniprogrampageSubscribeMsgReqProcess {
}
