package com.params.application.support.wx;

import cn.hutool.core.util.StrUtil;
import com.google.common.base.CaseFormat;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxReqBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class MsgReqProcessFactory {

    @Autowired
    private Map<String, MsgReqProcess> context = new ConcurrentHashMap<>();

    @Autowired
    private MsgReqProcess defaultResultMsgReqProcess;

    public MsgReqProcess getMsgReqProcess(WxReqBO req, OfficialAccount account) {
        // 路由规则，strategy + msgtype + event 定位
        /** default + msgtype + event + ResultMsgReqProcess,如果都没有，则使用【defaultResultMsgReqProcess】
         * strategy，= default，则定位到【defaultResultMsgReqProcess】则使用默认的MsgReqProcess
         * 如果为 coupon，则定位到
         */
        String strategy = getStr(account.getStrategy());
        String msgType = getStr(req.getMsgType());
        String event = getStr(req.getEvent());
        String key = StrUtil.format("{}{}{}MsgReqProcess", CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, strategy),
                CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, msgType),
                CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, event));
        log.info("key : " + key);
        MsgReqProcess msgReqProcess = context.get(key);
        return Objects.isNull(msgReqProcess) ? defaultResultMsgReqProcess : msgReqProcess;
    }

    private String getStr(String s) {
        return StrUtil.isEmpty(s) ? "" : s;
    }
}
