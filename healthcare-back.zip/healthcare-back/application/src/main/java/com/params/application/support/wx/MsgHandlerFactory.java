package com.params.application.support.wx;

import cn.hutool.core.util.StrUtil;
import com.google.common.base.CaseFormat;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxReqBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class MsgHandlerFactory {

    @Autowired
    private Map<String, ResultMsgHandler> context = new ConcurrentHashMap<>();

    @Autowired
    private ResultMsgHandler defaultTextMsgHandler;

    public ResultMsgHandler getMsgHandler(WxReqBO req, OfficialAccount account) {
        String strategy = getStr(account.getStrategy());
        String msgType = getStr(account.getResultMsgType());
        String key = StrUtil.format("{}{}MsgHandler", CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, strategy),
                CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, msgType));
        log.info("====result msg key : " + key);
        ResultMsgHandler msgHandler = context.get(key);
        return Objects.isNull(msgHandler) ? defaultTextMsgHandler : msgHandler;
    }

    private String getStr(String s) {
        return StrUtil.isEmpty(s) ? "" : s;
    }
}
