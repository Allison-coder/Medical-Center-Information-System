package com.params.application.support.wx.process;

import com.params.application.support.wx.MsgHandlerFactory;
import com.params.application.support.wx.MsgReqProcess;
import com.params.application.support.wx.ResultMsgHandler;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("defaultResultMsgReqProcess")
@Slf4j
public class DefaultResultMsgReqProcess implements MsgReqProcess {

    @Autowired
    private MsgHandlerFactory msgHandlerFactory;

    @Override
    public BaseMsg handle(WxReqBO reqBO, WxConfigBO wxConfigBO, OfficialAccount account) {
        /**
         * 默认处理器，根据配置内容返回对应的msg信息
         * 此处不区分事件、消息类型，仅根据配置返回类型处理返回结果
         * 即新增的config配置
         */
        ResultMsgHandler resultMsgHandler = msgHandlerFactory.getMsgHandler(reqBO, account);
        return resultMsgHandler.handle(reqBO, account);
    }
}
