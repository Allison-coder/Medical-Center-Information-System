package com.params.application.patient.impl;

import com.params.constant.CouponTypeEnums;
import com.params.pojo.vo.UserCouponsVO;
import com.params.utils.DateUtil;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Date;

public class CouponComparator implements Comparator<UserCouponsVO> {

    @Override
    public int compare(UserCouponsVO c1, UserCouponsVO c2) {
        // 先比较 coupon_type
        int priority1 = getPriority(c1.getCouponType());
        int priority2 = getPriority(c2.getCouponType());
        int typeComparison = Integer.compare(priority1, priority2);
        if (typeComparison != 0) {
            return typeComparison;
        }

        // coupon_type 相同时，比较 coupon_par_value 和 discount
        BigDecimal value1 = c1.getCouponParValue() != null ? new BigDecimal(c1.getCouponParValue()) : BigDecimal.ZERO;
        BigDecimal value2 = c2.getCouponParValue() != null ? new BigDecimal(c2.getCouponParValue()) : BigDecimal.ZERO;
        int valueComparison = value2.compareTo(value1);
        if (valueComparison != 0) {
            return valueComparison;
        }

        String discount1 = c1.getDiscount() != null ? c1.getDiscount() : "";
        String discount2 = c2.getDiscount() != null ? c2.getDiscount() : "";
        int discountComparison = discount2.compareTo(discount1);
        if (discountComparison != 0) {
            return discountComparison;
        }

        // 在 coupon_par_value 和 discount 相同的情况下，比较 expire_date
        Date date1 = DateUtil.formatStrToDate(c1.getExpireDate(),DateUtil.FORMAT_TYPE_3);
        Date date2 = DateUtil.formatStrToDate(c2.getExpireDate(),DateUtil.FORMAT_TYPE_3);
        if (date1 == null && date2 == null) {
            return 0;
        } else if (date1 == null) {
            return 1;
        } else if (date2 == null) {
            return -1;
        } else {
            return date2.compareTo(date1);
        }
    }



    private int getPriority(Integer couponType) {
        if (couponType == CouponTypeEnums.EXCHANGE_COUPON.getValue()) {
            return 1;
        } else if (couponType == CouponTypeEnums.CASH_COUPON.getValue()) {
            return 2;
        } else if (couponType == CouponTypeEnums.DISCOUNT_COUPON.getValue()) {
            return 3;
        } else {
            return 4; // 其他类型的优先级，
        }
    }
}
