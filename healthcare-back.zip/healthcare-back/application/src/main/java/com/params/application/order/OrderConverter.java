package com.params.application.order;

import com.params.entity.Orders;
import com.params.pojo.vo.OrderVO;

import java.util.List;

public interface OrderConverter {

    OrderVO convertOrder(Orders orders);

    List<OrderVO> convertOrderFormat(List<Orders> orders, Integer channelId,Boolean isList);
}
