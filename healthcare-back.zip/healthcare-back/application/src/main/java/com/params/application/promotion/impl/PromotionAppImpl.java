package com.params.application.promotion.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.params.application.promotion.PromotionApp;
import com.params.constant.ForeverStatusEnum;
import com.params.convert.PageConvert;
import com.params.domain.coupon.CouponDomainService;
import com.params.domain.promotion.PromotionDomainService;
import com.params.entity.Coupon;
import com.params.entity.CouponTemplatePromotionBind;
import com.params.entity.PromotionChannels;
import com.params.framework.constant.DeletedStatusEnum;
import com.params.pojo.vo.ActivityCouponDetailsVO;
import com.params.pojo.vo.PromotionDetailsVO;
import com.params.pojo.vo.PromotionPageVO;
import com.params.pojo.vo.ReceiveStatusVO;
import com.params.pojo.vo.common.PageVO;
import com.params.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Component
@Slf4j
public class PromotionAppImpl implements PromotionApp {


    @Autowired
    private PromotionDomainService promotionDomainService;

    @Autowired
    private CouponDomainService couponDomainService;

    /**
     * 优惠活动列表
     *
     * @param page
     * @param channelName
     * @param activityName
     * @return
     */
    @Override
    public PageVO<PromotionPageVO> promotionList(Page<PromotionChannels> page, String channelName, String activityName) {

        LambdaQueryWrapper<PromotionChannels> wrapper = new LambdaQueryWrapper<>();
        if (StringUtils.isNotBlank(channelName)) {
            wrapper.like(PromotionChannels::getChannelName, channelName);
        }
        if (StringUtils.isNotBlank(activityName)) {
            wrapper.like(PromotionChannels::getActivityName, activityName);
        }
        wrapper.eq(PromotionChannels::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
        wrapper.orderByDesc(PromotionChannels::getCreateTime);

        Page<PromotionChannels> promotionChannelsPage = promotionDomainService.getPromotionChannelsPage(page, wrapper);

        List<PromotionChannels> list = promotionChannelsPage.getRecords();

        if (CollectionUtils.isEmpty(list)) {
            PageVO<PromotionPageVO> pageVO = PageConvert.INSTANCE.convertPage(promotionChannelsPage);
            return pageVO;
        }

        // 查出活动和优惠券的关系
        List<Integer> ids = list.stream().map(pc -> pc.getId()).collect(Collectors.toList());
        List<CouponTemplatePromotionBind> couponList = promotionDomainService.getPromotionChannelsCouponList(ids);

        Map<Integer, List<CouponTemplatePromotionBind>> couponMap = couponList.stream()
                .collect(Collectors.groupingBy(CouponTemplatePromotionBind::getPromotionChannelsId));

        List<PromotionPageVO> voList = list.stream().map(pc -> {
            PromotionPageVO pageVO = new PromotionPageVO();
            pageVO.setId(pc.getId());
            pageVO.setCreateOperator(pc.getOperator());
            pageVO.setCreateTime(DateUtil.formatDateToString(pc.getCreateTime(), DateUtil.FORMAT_TYPE_1));
            // 优惠券张数
            List<CouponTemplatePromotionBind> binds = couponMap.get(pc.getId());
            pageVO.setCouponSheetNum(CollectionUtils.isEmpty(binds) ? 0 : binds.size());

            pageVO.setExpireDateTime(DateUtil.formatDateToString(pc.getExpireDateTime(), DateUtil.FORMAT_TYPE_1));
            if (ObjectUtils.isNotEmpty(pc.getForeverStatus()) && pc.getForeverStatus() == 1) {
                pageVO.setExpireDateTime("永久有效");
            }
            pageVO.setStatus(1);
            if (ObjectUtils.isNotEmpty(pc.getForeverStatus()) && pc.getForeverStatus().equals(ForeverStatusEnum.CAN_BE_EXPIRE.getValue()) &&ObjectUtils.isNotEmpty(pc.getExpireDateTime()) && new Date().after(pc.getExpireDateTime())) {
                pageVO.setStatus(2);
            }
            pageVO.setActivityName(pc.getActivityName());
            pageVO.setChannelName(pc.getChannelName());
            pageVO.setCreateOperator(pc.getOperator());
            return pageVO;
        }).collect(Collectors.toList());

        PageVO<PromotionPageVO> vo = PageConvert.INSTANCE.convertPage(promotionChannelsPage);
        vo.setList(voList);
        return vo;
    }

    /**
     * 根据id查出优惠券详情
     *
     * @param id
     * @return
     */
    @Override
    public PromotionDetailsVO getPromotionChannelById(Integer id) {
        PromotionChannels promotionChannels = promotionDomainService.getChannelInfoById(id);
        if (promotionChannels == null) {
            return null;
        }
        List<Integer> ids = Arrays.asList(promotionChannels.getId());
        List<CouponTemplatePromotionBind> couponList = promotionDomainService.getPromotionChannelsCouponList(ids);
        Map<Integer, List<CouponTemplatePromotionBind>> couponMap = couponList.stream()
                .collect(Collectors.groupingBy(CouponTemplatePromotionBind::getPromotionChannelsId));


        PromotionDetailsVO vo = convertPromotionChannel(promotionChannels);

        //指定用户   TODO 魔法值
        if (vo.getGettingCondition().equals(2)) {
            // 查出用户
            List<String> phoneNums = promotionDomainService.getPromotionSpecifyUserBind(promotionChannels.getChannelCode());
            vo.setPhoneNumbers(phoneNums);
        }


        List<CouponTemplatePromotionBind> binds = couponMap.get(promotionChannels.getId());
        if (CollectionUtils.isEmpty(binds)) {
            vo.setActivityCouponDetails(Lists.newArrayList());
        } else {
            List<ActivityCouponDetailsVO> activityCouponList = binds.stream().map(bind -> {
                ActivityCouponDetailsVO couponDetailsVO = new ActivityCouponDetailsVO();
                couponDetailsVO.setId(bind.getId());
                couponDetailsVO.setCouponType(bind.getCouponType());
                couponDetailsVO.setCouponTypeName(bind.getCouponTypeName());
                couponDetailsVO.setCouponName(bind.getName());
                couponDetailsVO.setCouponParValue(ObjectUtils.isEmpty(bind.getCouponParValue()) ? "0" : bind.getCouponParValue().toString());
                couponDetailsVO.setDiscount(bind.getDiscount());
                couponDetailsVO.setExchangeOrder(bind.getExchangeOrder());
                couponDetailsVO.setThresholdNo(bind.getThresholdNo());
                couponDetailsVO.setOrderUseAmount(bind.getOrderUseAmount());
                couponDetailsVO.setForeverStatus(bind.getForeverStatus());
                couponDetailsVO.setExpireDate(DateUtil.formatDateToString(bind.getExpireDate(), DateUtil.FORMAT_TYPE_3));
                couponDetailsVO.setInstructions(bind.getInstructions());

                if (StringUtils.isNotBlank(bind.getTreatmentProjectIds())) {
                    couponDetailsVO.setProjectId(
                            Arrays.stream(bind.getTreatmentProjectIds()
                                            .replace('，', ',')
                                            .split(","))
                                    .map(Integer::parseInt)
                                    .collect(Collectors.toList())
                    );
                }


                if (StringUtils.isNotBlank(bind.getAvailableProject())) {
                    couponDetailsVO.setAvailableProject(
                            Arrays.stream(bind.getAvailableProject()
                                            .replace('，', ',')
                                            .split(","))
                                    .map(Integer::parseInt)
                                    .collect(Collectors.toList())
                    );
                }
                return couponDetailsVO;
            }).collect(Collectors.toList());
            vo.setActivityCouponDetails(activityCouponList);
        }
        return vo;
    }

    /**
     * 根据渠道code查出渠道活动详情
     *
     * @param channelCode
     * @return
     */
    @Override
    public PromotionDetailsVO getPromotionChannelByCode(String channelCode) {
        PromotionChannels channels = promotionDomainService.getChannelInfoByChannelCode(channelCode);
        if (ObjectUtils.isNotEmpty(channels)) {
            return convertPromotionChannel(channels);
        }
        return null;
    }

    /**
     * 根据渠道code获取用户领取状态
     *
     * @param channelCode
     * @param userId
     * @return
     */
    @Override
    public ReceiveStatusVO getReceiveStatus(String channelCode, Integer userId) {
        List<Coupon> userCoupons = couponDomainService.getUserCoupons(userId);
        if (CollectionUtils.isNotEmpty(userCoupons)) {
            userCoupons = userCoupons.stream().filter(coupon -> coupon.getChannelCode().equals(channelCode)).collect(Collectors.toList());
        }
        ReceiveStatusVO statusVO = new ReceiveStatusVO();
        statusVO.setStatus(CollectionUtils.isNotEmpty(userCoupons) ? 3 : 4);
        return statusVO;
    }


    private PromotionDetailsVO convertPromotionChannel(PromotionChannels promotionChannels) {
        PromotionDetailsVO vo = new PromotionDetailsVO();
        vo.setId(promotionChannels.getId());
        vo.setActivityName(promotionChannels.getActivityName());
        vo.setChannelName(promotionChannels.getChannelName());
        vo.setExpireDate(DateUtil.formatDateToString(promotionChannels.getExpireDateTime(), DateUtil.FORMAT_TYPE_3));
        vo.setExpireTime(DateUtil.formatDateToString(promotionChannels.getExpireDateTime(), DateUtil.FORMAT_TYPE_5));
        vo.setForeverStatus(promotionChannels.getForeverStatus());
        vo.setGettingCondition(promotionChannels.getGettingCondition());
        vo.setShareContent(promotionChannels.getShareContent());
        vo.setTotalValue(ObjectUtils.isEmpty(promotionChannels.getTotalValue()) ? "0" : promotionChannels.getTotalValue().toString());
        vo.setStatus(1);
        if (ObjectUtils.isNotEmpty(promotionChannels.getForeverStatus()) && promotionChannels.getForeverStatus().equals(ForeverStatusEnum.CAN_BE_EXPIRE.getValue()) && new Date().after(promotionChannels.getExpireDateTime())) {
            vo.setStatus(2);
        }
        return vo;
    }
}
