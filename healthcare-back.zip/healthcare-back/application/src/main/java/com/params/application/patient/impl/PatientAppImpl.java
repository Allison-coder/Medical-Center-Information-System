package com.params.application.patient.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.application.patient.PatientApp;
import com.params.constant.CouponTypeEnums;
import com.params.constant.CouponTypeUseStatusEnums;
import com.params.constant.ForeverStatusEnum;
import com.params.constant.MedicalRecordStatusEnum;
import com.params.constant.OrderBusinessStatusEnum;
import com.params.constant.OrderStatusEnum;
import com.params.constant.OrderTypeEnum;
import com.params.constant.PlanItemProjectTypeEnum;
import com.params.constant.TreatPlanBaseSpeedStatusEnum;
import com.params.constant.TreatPlanIssuedStatusEnum;
import com.params.constant.ValidateUtil;
import com.params.constant.WriteOffStatusEnum;
import com.params.convert.PageConvert;
import com.params.domain.coupon.CouponDomainService;
import com.params.domain.patient.PatientDomainService;
import com.params.domain.tasklog.TaskLogDomainService;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.entity.AdminUserInfo;
import com.params.entity.Coupon;
import com.params.entity.MedicalRecords;
import com.params.entity.Orders;
import com.params.entity.Patient;
import com.params.entity.ScheduleDetail;
import com.params.entity.TaskLog;
import com.params.entity.TreatmentPlan;
import com.params.entity.TreatmentPlanBase;
import com.params.entity.TreatmentPlanItem;
import com.params.entity.User;
import com.params.framework.constant.DeletedStatusEnum;
import com.params.pojo.dto.GetUserCouponsToGHOrderDTO;
import com.params.pojo.vo.BaseTreatmentPlanVO;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.PatientAdminVO;
import com.params.pojo.vo.PatientAgeUserInfoVO;
import com.params.pojo.vo.PatientUserInfoVO;
import com.params.pojo.vo.PlanFollowUpVO;
import com.params.pojo.vo.PlanProjectConfigVO;
import com.params.pojo.vo.TherapyOrdersNewVO;
import com.params.pojo.vo.TreatmentItemVO;
import com.params.pojo.vo.TreatmentPlanListVO;
import com.params.pojo.vo.TreatmentPlanVO;
import com.params.pojo.vo.UserCouponsVO;
import com.params.pojo.vo.UserTreatmentPlanVO;
import com.params.pojo.vo.common.PageVO;
import com.params.service.AdminUserInfoService;
import com.params.service.MedicalRecordsService;
import com.params.service.OrdersService;
import com.params.service.PatientService;
import com.params.service.ScheduleDetailService;
import com.params.service.TreatmentPlanBaseService;
import com.params.service.TreatmentPlanItemService;
import com.params.service.TreatmentPlanService;
import com.params.service.UserService;
import com.params.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Component
@Slf4j
public class PatientAppImpl implements PatientApp {
    @Autowired
    private PatientService patientService;

    @Autowired
    private PatientDomainService patientDomainService;

    @Autowired
    private OrdersService ordersService;

    @Autowired
    private MedicalRecordsService medicalRecordsService;

    @Autowired
    private TreatmentPlanBaseService treatmentPlanBaseService;

    @Autowired
    private TreatmentPlanService treatmentPlanService;

    @Autowired
    private TreatmentPlanItemService treatmentPlanItemService;


    @Autowired
    private TaskLogDomainService taskLogDomainService;


    @Autowired
    private AdminUserInfoService adminUserInfoService;

    @Autowired
    private CouponDomainService couponDomainService;


    @Autowired
    private TreatmentPlanDomainService planProjectDomainService;

    @Autowired
    private ScheduleDetailService scheduleDetailService;

    @Autowired
    private UserService userService;


    @Override
    public List<String> getPatientSnsByName(String name, Integer channelId) {
        ValidateUtil.isTrue(Objects.isNull(channelId), "渠道id不能为空！");
        log.info("根据名称：{} 模糊查询患者号", name);
        List<String> result = new ArrayList<>();
        List<Patient> list = patientService.getPatientsByName(name, channelId);
        if (list != null && list.size() > 0) {
            result = list.stream().map(Patient::getPatientSn).collect(Collectors.toList());
        }
        return result;
    }

    @Override
    public List<PatientUserInfoVO> getPatientByCurrentUser(Integer userId, Integer channelId) {
        ValidateUtil.isTrue(Objects.isNull(userId), "用户id不能为空！");
        ValidateUtil.isTrue(Objects.isNull(channelId), "渠道id不能为空！");
        // 查出user
        User user = userService.getById(userId);
        List<Patient> list = patientService.getPatientsByUserIdOrMobile(userId, user.getMobile(), channelId);
        // 把user_id set 给它，再修改
        if (CollectionUtils.isNotEmpty(list)) {
            list.forEach(c -> c.setUserId(userId));
        }
        patientService.updateBatchById(list);
        return convertPatientUserInfoVOs(list);
    }

    /**
     * 获取患者的治疗方案列表
     *
     * @param userId
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public PageVO<UserTreatmentPlanVO> getTreatmentPlan(Integer userId, Integer pageNum, Integer pageSize) {
        log.info("获取预约列表:{}", userId);
        Page<Orders> page = new Page<Orders>().setCurrent(pageNum).setSize(pageSize);
        // 先转换一次，空值时返回
        PageVO<UserTreatmentPlanVO> pageVO = PageConvert.INSTANCE.convertPage(page);

        List<Patient> patients = patientService.list(new LambdaQueryWrapper<Patient>()
                .eq(Patient::getUserId, userId)
                .eq(Patient::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));

        if (CollectionUtils.isEmpty(patients)) {
            return pageVO;
        }
        List<String> patientSns = patients.stream().map(Patient::getPatientSn).collect(Collectors.toList());
        // 查出所有治疗订单
        ordersService.page(page, new LambdaQueryWrapper<Orders>()
                .in(Orders::getPatientSn, patientSns)
                .eq(Orders::getOrderType, OrderTypeEnum.THERAPY.getCode())
                .eq(Orders::getOrderStatus, OrderStatusEnum.IS_PAY.getCode())
                .orderByDesc(Orders::getCreateTime)
        );

        List<Orders> ordersList = page.getRecords();

        if (CollectionUtils.isEmpty(ordersList)) {
            return pageVO;
        }
        List<String> orderSns = ordersList.stream().map(Orders::getOrderSn).collect(Collectors.toList());

        // 处置方案
        List<TreatmentPlanItem> treatmentPlanItemList = treatmentPlanItemService.list(new LambdaQueryWrapper<TreatmentPlanItem>()
                .in(TreatmentPlanItem::getZlOrderSn, orderSns)
                .eq(TreatmentPlanItem::getProjectType, PlanItemProjectTypeEnum.THERAPY.getCode())
                .eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue())
        );
        Map<String, TreatmentPlanItem> treatmentPlanItemMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(treatmentPlanItemList)) {
            treatmentPlanItemMap = treatmentPlanItemList.stream().collect(Collectors.toMap(TreatmentPlanItem::getZlOrderSn, o -> o, (o, n) -> o));
        }

        // 诊疗记录
        // List<MedicalRecords> medicalRecordsList = medicalRecordsService.getPatientLastMedicalRecords(patientSns);
        List<MedicalRecords> medicalRecordsList = medicalRecordsService.getLastMedicalRecordsByOrderSns(orderSns);
        Map<String, MedicalRecords> medicalRecordsMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(medicalRecordsList)) {
            medicalRecordsMap = medicalRecordsList.stream().collect(Collectors.toMap(MedicalRecords::getOrderSn, o -> o, (o, n) -> o));

        }


        // 开具治疗单的人员
        List<Integer> adminIds = ordersList.stream().map(Orders::getCreateAdminId).collect(Collectors.toList());
        List<AdminUserInfo> adminUserInfos = adminUserInfoService.list(new LambdaQueryWrapper<AdminUserInfo>().in(AdminUserInfo::getAdminId, adminIds));

        Map<Integer, AdminUserInfo> adminUserInfoMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(adminUserInfos)) {
            adminUserInfoMap = adminUserInfos.stream().collect(Collectors.toMap(AdminUserInfo::getAdminId, o -> o, (o, n) -> o));
        }

        // 任务 数据应该是要去看治疗单的任务状态，而不是患者当前的任务状态
        List<TaskLog> taskLogs = taskLogDomainService.getOrderLastTaskLogByOrderSns(orderSns);
        Map<String, TaskLog> taskLogsMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(taskLogs)) {
            taskLogsMap = taskLogs.stream().collect(Collectors.toMap(TaskLog::getOrderSn, o -> o, (o, n) -> o));
        }

        Map<String, MedicalRecords> finalMedicalRecordsMap = medicalRecordsMap;
        Map<String, TreatmentPlanItem> finalTreatmentPlanItemMap = treatmentPlanItemMap;

        Map<Integer, AdminUserInfo> finalAdminUserInfoMap = adminUserInfoMap;
        Map<String, TaskLog> finalTaskLogsMap = taskLogsMap;
        List<UserTreatmentPlanVO> planVOS = ordersList.stream().map(order -> {
            UserTreatmentPlanVO planVO = new UserTreatmentPlanVO();
            // 如果在诊疗记录里面有，取诊疗记录里面的次数
            MedicalRecords medicalRecords = finalMedicalRecordsMap.get(order.getOrderSn());
            if (medicalRecords != null) {
                planVO.setProgress(medicalRecords.getProgress());
                planVO.setTotalSessions(medicalRecords.getTotalSessions());
                planVO.setRemainsSessions(planVO.getTotalSessions() - planVO.getProgress());
                if (!medicalRecords.getStatus().equals(MedicalRecordStatusEnum.FINISH.getCode())) {
                    planVO.setRemainsSessions(planVO.getRemainsSessions() + 1);
                }
            } else {
                // 如果在诊疗记录里面没有，证明是新建的治疗单，取处置方案里面的次数
                TreatmentPlanItem planItem = finalTreatmentPlanItemMap.get(order.getOrderSn());
                // 这里实际可不判断，但防止脏数据，就判断一下
                if (planItem != null) {
                    planVO.setTotalSessions(planItem.getTotalSessions());
                    planVO.setRemainsSessions(planItem.getTotalSessions());
                }
            }
            TaskLog taskLog = finalTaskLogsMap.get(order.getOrderSn());
            // 当前任务状态
            if (taskLog != null) {
                planVO.setTaskStatus(taskLog.getTaskStatus());
            }
            AdminUserInfo userInfo = finalAdminUserInfoMap.get(order.getCreateAdminId());

            planVO.setCreateTime(DateUtil.formatDateToString(order.getCreateTime(), DateUtil.FORMAT_TYPE_1));
            planVO.setCreateName(userInfo == null ? null : userInfo.getRealName());
            planVO.setOrderSn(order.getOrderSn());
            return planVO;
        }).collect(Collectors.toList());
        // 重新转换一次，有总页数等
        pageVO = PageConvert.INSTANCE.convertPage(page);
        pageVO.setList(planVOS);
        return pageVO;
    }

    /**
     * 当前用户已领取的优惠券
     *
     * @param userId
     * @param status 1-待使用 2-已使用 3-已失效
     * @return
     */
    @Override
    public List<UserCouponsVO> getUserCoupons(Integer userId, String status) {

        List<PlanProjectConfigVO> vos = planProjectDomainService.getPlanProjectConfig(null);
        Map<Integer, PlanProjectConfigVO> projectConfigVOMap = vos.stream()
                .collect(Collectors.toMap(PlanProjectConfigVO::getId, pro -> pro));

        List<Coupon> couponList = couponDomainService.getUserCoupons(userId);
        if (CollectionUtils.isNotEmpty(couponList)) {
            List<String> orderSns = couponList.stream().map(c -> c.getOrderSn()).collect(Collectors.toList());
            Map<String, Orders> ordersMap = new HashMap<>();
            if (CollectionUtils.isNotEmpty(orderSns)) {
                List<Orders> ordersList = ordersService.list(new LambdaQueryWrapper<Orders>().in(Orders::getOrderSn, orderSns));
                if (CollectionUtils.isNotEmpty(ordersList)) {
                    ordersMap = ordersList.stream()
                            .collect(Collectors.toMap(Orders::getOrderSn, order -> order));
                }
            }
            Map<String, Orders> finalOrdersMap = ordersMap;

            List<UserCouponsVO> collect = couponList.stream().map(coupon -> convertUserCouponsVO(coupon, finalOrdersMap, projectConfigVOMap)).collect(Collectors.toList());
            if (Integer.valueOf(status) != 0) {
                collect = collect.stream().filter(c -> c.getUseStatus().equals(Integer.valueOf(status))).collect(Collectors.toList());
            }

            Collections.sort(collect, new CouponComparator());

            return collect;
        }
        return Collections.emptyList();
    }

    /**
     * 获取用户订单可用的优惠券
     *
     * @param orderSn
     * @param id
     * @param userId
     * @return
     */
    @Override
    public List<UserCouponsVO> getUserCouponsToOrder(String orderSn, Integer id, Integer userId) {
        List<UserCouponsVO> userCoupons = getUserCoupons(userId, "1");
        if (CollectionUtils.isEmpty(userCoupons)) {
            return Collections.emptyList();
        }
        // 订单
        Orders order = ordersService.getOne(new LambdaQueryWrapper<Orders>().eq(Orders::getOrderSn, orderSn).last("limit 1"));

        List<UserCouponsVO> userCouponsVOS = userCoupons.stream().filter(coupon -> {

            CouponTypeEnums couponTypeEnums = CouponTypeEnums.fromValue(coupon.getCouponType());

            switch (couponTypeEnums) {
                case CASH_COUPON:
                    // 有门槛
                    if (coupon.getThresholdNo() == 1) {
                        if (order.getSourceAmount().compareTo(new BigDecimal(coupon.getOrderUseAmount())) < 0) {
                            return false;
                        }
                    }

                    List<Integer> integerList = coupon.getAvailableProject();

                    // 判断优惠券的可用类型是否符合条件
                    if (!integerList.contains(order.getOrderType())) {
                        return false;
                    }
                    // getTreatmentProjectIds
                    // 如果在，并且有治疗项
                    if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode()) && integerList.contains(order.getOrderType()) && CollectionUtils.isNotEmpty(coupon.getProjectDetails())) {
                        List<Integer> collect = coupon.getProjectDetails().stream().map(c -> c.getId()).collect(Collectors.toList());
                        if (CollectionUtils.isNotEmpty(collect) && !collect.contains(0)) {
                            // 查出是否符合指定项目
                            TreatmentPlanItem planItem = treatmentPlanItemService.getById(id);
                            if (planItem == null) {
                                return false;
                            }
                            if (!collect.contains(planItem.getItemId())) {
                                return false;
                            }
                        }
                    }
                    break;
                case EXCHANGE_COUPON:
                    // 兑换
                    if (ObjectUtils.isNotEmpty(coupon.getExchangeOrder()) && !coupon.getExchangeOrder().equals(order.getOrderType())) {
                        return false;
                    }

                    // 如果是治疗单，且 不是支持所有项目
                    if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode()) && coupon.getExchangeOrder().equals(order.getOrderType()) && CollectionUtils.isNotEmpty(coupon.getProjectDetails())) {
                        List<Integer> collect = coupon.getProjectDetails().stream().map(c -> c.getId()).collect(Collectors.toList());
                        if (CollectionUtils.isNotEmpty(collect) && !collect.contains(0)) {
                            // 查出是否符合指定项目
                            TreatmentPlanItem planItem = treatmentPlanItemService.getById(id);
                            if (planItem == null) {
                                return false;
                            }
                            if (!collect.contains(planItem.getItemId())) {
                                return false;
                            }
                        }
                    }
                    break;
                case DISCOUNT_COUPON:
                    // 有门槛
                    if (coupon.getThresholdNo() == 1) {
                        if (order.getSourceAmount().compareTo(new BigDecimal(coupon.getOrderUseAmount())) < 0) {
                            return false;
                        }
                    }

                    List<Integer> integerListDiscount = coupon.getAvailableProject();

                    // 判断优惠券的可用类型是否符合条件
                    if (!integerListDiscount.contains(order.getOrderType())) {
                        return false;
                    }

                    // 如果在，并且有治疗项
                    if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode()) && integerListDiscount.contains(order.getOrderType()) && CollectionUtils.isNotEmpty(coupon.getProjectDetails())) {
                        List<Integer> collect = coupon.getProjectDetails().stream().map(c -> c.getId()).collect(Collectors.toList());
                        if (CollectionUtils.isNotEmpty(collect) && !collect.contains(0)) {
                            // 查出是否符合指定项目
                            TreatmentPlanItem planItem = treatmentPlanItemService.getById(id);
                            if (planItem == null) {
                                return false;
                            }
                            if (!collect.contains(planItem.getItemId())) {
                                return false;
                            }
                        }
                    }
                    break;
            }

            return true;

        }).collect(Collectors.toList());

        // 根据过期时间排个序
        Collections.sort(userCouponsVOS, new Comparator<UserCouponsVO>() {
            @Override
            public int compare(UserCouponsVO o1, UserCouponsVO o2) {
                // 如果foreverStatus都为0，则比较expireDate
                if (o1.getForeverStatus() == 0 && o2.getForeverStatus() == 0) {
                    LocalDate date1 = LocalDate.parse(o1.getExpireDate(), DateTimeFormatter.ofPattern(DateUtil.FORMAT_TYPE_3));
                    LocalDate date2 = LocalDate.parse(o2.getExpireDate(), DateTimeFormatter.ofPattern(DateUtil.FORMAT_TYPE_3));
                    return date1.compareTo(date2);
                }
                // 如果o1的foreverStatus为0而o2的foreverStatus不为0，o1排在前面
                if (o1.getForeverStatus() == 0) {
                    return -1;
                }
                // 如果o2的foreverStatus为0而o1的foreverStatus不为0，o2排在前面
                if (o2.getForeverStatus() == 0) {
                    return 1;
                }
                // 如果都不为0，则不需要改变顺序
                return 0;
            }
        });
        return userCouponsVOS;

    }

    /**
     * 获取用户挂号单可用的优惠券
     *
     * @param dto
     * @return
     */
    @Override
    public List<UserCouponsVO> getUserCouponsToGHOrder(GetUserCouponsToGHOrderDTO dto) {

        List<UserCouponsVO> userCoupons = getUserCoupons(dto.getUserId(), "1");
        if (CollectionUtils.isEmpty(userCoupons)) {
            return Collections.emptyList();
        }

        BigDecimal sourceAmount = dto.getSourceAmount();
        // Integer orderType = dto.getOrderType();
        // 持号单
        Integer orderType = OrderTypeEnum.getEnumCode(dto.getOrderType());
        //
        List<UserCouponsVO> userCouponsVOS = userCoupons.stream().filter(coupon -> {

            CouponTypeEnums couponTypeEnums = CouponTypeEnums.fromValue(coupon.getCouponType());

            switch (couponTypeEnums) {
                case CASH_COUPON:
                    // 有门槛
                    if (coupon.getThresholdNo() == 1) {
                        if (sourceAmount.compareTo(new BigDecimal(coupon.getOrderUseAmount())) < 0) {
                            return false;
                        }
                    }

                    List<Integer> integerList = coupon.getAvailableProject();

                    // 判断优惠券的可用类型是否符合条件
                    if (!integerList.contains(orderType)) {
                        return false;
                    }

                    // 如果是治疗单
                    if (orderType.equals(OrderTypeEnum.THERAPY.getCode()) && ObjectUtils.isNotEmpty(coupon.getProjectDetails())) {
                        // 可使用的详情列表
                        List<PlanProjectConfigVO> projectDetails = coupon.getProjectDetails();
                        if (CollectionUtils.isNotEmpty(projectDetails)) {
                            List<Integer> treatmentProjectIdsList = projectDetails.stream().map(c -> c.getId()).collect(Collectors.toList());
                            if (ObjectUtils.isNotEmpty(treatmentProjectIdsList)) {
                                if (treatmentProjectIdsList.get(0) == 0) {
                                    return true;
                                }
                                // 查出是否符合指定项目
                                if (!treatmentProjectIdsList.contains(dto.getProjectId())) {
                                    return false;
                                }
                            }

                        }

                    }


                    break;
                case EXCHANGE_COUPON:
                    // 兑换
                    if (ObjectUtils.isNotEmpty(coupon.getExchangeOrder()) && !coupon.getExchangeOrder().equals(orderType)) {
                        return false;
                    }
                    // 如果是治疗单，且 不是支持所有项目
                    if (orderType.equals(OrderTypeEnum.THERAPY.getCode()) && coupon.getExchangeOrder().equals(orderType) && ObjectUtils.isNotEmpty(coupon.getProjectDetails())) {

                        // 可使用的详情列表
                        List<PlanProjectConfigVO> projectDetails = coupon.getProjectDetails();
                        if (CollectionUtils.isNotEmpty(projectDetails)) {
                            List<Integer> treatmentProjectIdsList = projectDetails.stream().map(c -> c.getId()).collect(Collectors.toList());

                            if (ObjectUtils.isNotEmpty(treatmentProjectIdsList)) {
                                if (treatmentProjectIdsList.get(0) == 0) {
                                    return true;
                                }
                                // 查出是否符合指定项目
                                if (!treatmentProjectIdsList.contains(dto.getProjectId())) {
                                    return false;
                                }
                            }

                        }
                    }

                    break;
                case DISCOUNT_COUPON:
                    // 有门槛
                    if (coupon.getThresholdNo() == 1) {
                        if (sourceAmount.compareTo(new BigDecimal(coupon.getOrderUseAmount())) < 0) {
                            return false;
                        }
                    }
                    List<Integer> integerListDiscount = coupon.getAvailableProject();
                    // 判断优惠券的可用类型是否符合条件
                    if (!integerListDiscount.contains(orderType)) {
                        return false;
                    }

                    // 如果是治疗单，且 不是支持所有项目
                    if (orderType.equals(OrderTypeEnum.THERAPY.getCode()) && ObjectUtils.isNotEmpty(coupon.getProjectDetails())) {

                        // 可使用的详情列表
                        List<PlanProjectConfigVO> projectDetails = coupon.getProjectDetails();
                        if (CollectionUtils.isNotEmpty(projectDetails)) {
                            List<Integer> treatmentProjectIdsList = projectDetails.stream().map(c -> c.getId()).collect(Collectors.toList());
                            if (ObjectUtils.isNotEmpty(treatmentProjectIdsList)) {
                                if (treatmentProjectIdsList.get(0) == 0) {
                                    return true;
                                }
                                // 查出是否符合指定项目
                                if (!treatmentProjectIdsList.contains(dto.getProjectId())) {
                                    return false;
                                }
                            }

                        }
                    }
                    break;
            }
            return true;

        }).collect(Collectors.toList());

        // 根据过期时间排个序
        Collections.sort(userCouponsVOS, new Comparator<UserCouponsVO>() {
            @Override
            public int compare(UserCouponsVO o1, UserCouponsVO o2) {
                // 如果foreverStatus都为0，则比较expireDate
                if (o1.getForeverStatus() == 0 && o2.getForeverStatus() == 0) {
                    LocalDate date1 = LocalDate.parse(o1.getExpireDate(), DateTimeFormatter.ofPattern(DateUtil.FORMAT_TYPE_3));
                    LocalDate date2 = LocalDate.parse(o2.getExpireDate(), DateTimeFormatter.ofPattern(DateUtil.FORMAT_TYPE_3));
                    return date1.compareTo(date2);
                }
                // 如果o1的foreverStatus为0而o2的foreverStatus不为0，o1排在前面
                if (o1.getForeverStatus() == 0) {
                    return -1;
                }
                // 如果o2的foreverStatus为0而o1的foreverStatus不为0，o2排在前面
                if (o2.getForeverStatus() == 0) {
                    return 1;
                }
                // 如果都不为0，则不需要改变顺序
                return 0;
            }
        });
        return userCouponsVOS;
    }

    /**
     * 根据患者编号获取患者的所有处置方案
     * @param patientSn
     * @param clinicId
     * @param speedStatus  进度状态
     * @return
     */
    // @Override
    // public List<BaseTreatmentPlanVO> getDisposalPlanList(String patientSn, Integer clinicId,Integer speedStatus,Boolean isPlanIssued) {
    //     // 总表
    //     LambdaQueryWrapper<TreatmentPlanBase> baseWrapper = new LambdaQueryWrapper<>();
    //     baseWrapper.eq(TreatmentPlanBase::getPatientSn, patientSn);
    //     if (ObjectUtils.isNotEmpty(speedStatus)) {
    //         baseWrapper.eq(TreatmentPlanBase::getSpeedStatus, speedStatus);
    //     }
    //     if (ObjectUtils.isNotEmpty(isPlanIssued)) {
    //         baseWrapper.eq(TreatmentPlanBase::getIsPlanIssued, isPlanIssued);
    //     }
    //     baseWrapper.eq(TreatmentPlanBase::getPatientSn, patientSn);
    //     baseWrapper.eq(TreatmentPlanBase::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
    //     baseWrapper.orderByDesc(TreatmentPlanBase::getCreateTime);
    //     List<TreatmentPlanBase> bases = treatmentPlanBaseService.list(baseWrapper);
    //     if (CollectionUtils.isEmpty(bases)) {
    //         return Collections.emptyList();
    //     }
    //     // 查出患者信息
    //     PatientAdminVO patientDetail = patientDomainService.getPatientDetail(patientSn);
    //     // 子表
    //     List<String> planSns = bases.stream().map(TreatmentPlanBase::getPlanSn).collect(Collectors.toList());
    //     LambdaQueryWrapper<TreatmentPlan> planWrapper = new LambdaQueryWrapper<>();
    //     planWrapper.in(TreatmentPlan::getPlanSn, planSns);
    //     planWrapper.eq(TreatmentPlan::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
    //     List<TreatmentPlan> planList = treatmentPlanService.list(planWrapper);
    //     Map<String, List<TreatmentPlan>> planMap = CollectionUtils.isEmpty(planList) ? Collections.emptyMap() : planList.stream().collect(Collectors.groupingBy(TreatmentPlan::getPlanSn));
    //
    //
    //     // 项目表
    //     List<TreatmentPlanItem> itemList = new ArrayList<>();
    //     if (CollectionUtils.isNotEmpty(planList)) {
    //         List<Integer> planIds = planList.stream().map(TreatmentPlan::getId).collect(Collectors.toList());
    //         LambdaQueryWrapper<TreatmentPlanItem> itemWrapper = new LambdaQueryWrapper<>();
    //         itemWrapper.in(TreatmentPlanItem::getPlanId, planIds);
    //         itemWrapper.eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
    //         itemList = treatmentPlanItemService.list(itemWrapper);
    //     }
    //     Map<Integer, List<TreatmentPlanItem>> planItemMap = CollectionUtils.isEmpty(itemList) ? Collections.emptyMap() : itemList.stream().collect(Collectors.groupingBy(TreatmentPlanItem::getPlanId));
    //
    //     // 组装 vo
    //     List<BaseTreatmentPlanVO> voList = bases.stream().map(base -> {
    //         BaseTreatmentPlanVO vo = new BaseTreatmentPlanVO();
    //         vo.setId(base.getId());
    //         vo.setPlanSn(base.getPlanSn());
    //         vo.setPatientSn(base.getPatientSn());
    //         vo.setPatientName(patientDetail.getPatientName());
    //         vo.setCreateTime(DateUtil.formatDateToString(base.getCreateTime(), DateUtil.FORMAT_TYPE_1));
    //         vo.setAdvice(ObjectUtils.isEmpty(base.getAdvice()) ? "" : base.getAdvice());
    //         vo.setSpeedStatus(base.getSpeedStatus());
    //         // 配置次数方案
    //         List<TreatmentPlan> plans = planMap.get(base.getPlanSn());
    //         if (CollectionUtils.isNotEmpty(plans)) {
    //             List<TreatmentPlanVO> planVOS = plans.stream().map(plan -> {
    //                 TreatmentPlanVO planVO = new TreatmentPlanVO();
    //                 planVO.setId(plan.getId());
    //                 planVO.setPatientSn(plan.getPatientSn());
    //                 planVO.setOrderSn(plan.getZlOrderSn());
    //                 planVO.setRecommendedTime(DateUtil.formatDateToString(plan.getRecommendedTime(), DateUtil.FORMAT_TYPE_3));
    //                 planVO.setNoRecommended(ObjectUtils.isNotEmpty(planVO.getNoRecommended()));
    //                 planVO.setMechanization(plan.getMechanization());
    //                 planVO.setExpectedOutcomes(plan.getExpectedOutcomes());
    //                 // 配置项目
    //                 List<TreatmentPlanItem> items = planItemMap.get(plan.getId());
    //                 if (CollectionUtils.isNotEmpty(items)) {
    //                     List<TreatmentItemVO> itemVOS = items.stream().map(item -> {
    //                         TreatmentItemVO itemVO = TreatmentItemVO.builder().build();
    //                         itemVO.setId(item.getId());
    //                         itemVO.setItemId(item.getItemId());
    //                         itemVO.setProjectType(item.getProjectType());
    //                         itemVO.setItemName(item.getItemName());
    //                         itemVO.setUnitPrice(item.getUnitPrice());
    //                         itemVO.setPriceHour(item.getUnitPrice());
    //                         itemVO.setTotalPrice(item.getTotalPrice());
    //                         itemVO.setPreferentialPrice(item.getPreferentialPrice());
    //                         itemVO.setSourceAmount(item.getSourceAmount());
    //                         itemVO.setTotalSessions(item.getTotalSessions());
    //                         itemVO.setFrequency(item.getFrequency());
    //                         itemVO.setFrequencyNum(item.getFrequencyNum());
    //                         itemVO.setDurationPerSession(item.getDurationPerSession());
    //                         itemVO.setDescription(item.getDescription());
    //                         itemVO.setExpectedDuration(item.getExpectedDuration());
    //                         itemVO.setSingleAppointmentDuration(ObjectUtils.isNotEmpty(item.getDurationPerSession()) ? item.getDurationPerSession().toString() : "");
    //                         // itemVO.setCouponsVO(new UserCouponsVO());
    //                         return itemVO;
    //                     }).collect(Collectors.toList());
    //                     planVO.setItems(itemVOS);
    //                 }
    //                 planVO.setPlanUseStatus(0);
    //                 planVO.setSortNum(plan.getSortNum());
    //                 return planVO;
    //             }).collect(Collectors.toList());
    //             vo.setPlanItems(planVOS);
    //         }
    //         // TODO 是否开具了方案单
    //         vo.setIsPlanIssued(base.getIsPlanIssued());
    //         return vo;
    //     }).collect(Collectors.toList());
    //
    //
    //     return voList;
    // }

    /**
     * 根据患者编号获取患者的所有处置方案
     *
     * @param patientSn
     * @param clinicId
     * @param speedStatus 进度状态
     * @return
     */
    @Override
    public List<BaseTreatmentPlanVO> getDisposalPlanList(String patientSn, Integer clinicId, Integer speedStatus, Boolean isPlanIssued) {
        // 查询总表
        List<TreatmentPlanBase> bases = getTreatmentPlanBases(patientSn, null, speedStatus, isPlanIssued);
        if (CollectionUtils.isEmpty(bases)) {
            return Collections.emptyList();
        }

        // 查出患者信息
        PatientAdminVO patientDetail = patientDomainService.getPatientDetail(patientSn);

        // 查询子表和项目表
        List<String> planSns = bases.stream().map(TreatmentPlanBase::getPlanSn).collect(Collectors.toList());
        Map<String, List<TreatmentPlan>> planMap = getTreatmentPlans(planSns);
        Map<Integer, List<TreatmentPlanItem>> planItemMap = getTreatmentPlanItems(planMap.values().stream().flatMap(List::stream).map(TreatmentPlan::getId).collect(Collectors.toList()));

        // 组装 voList
        return bases.stream().map(base -> {
            BaseTreatmentPlanVO vo = new BaseTreatmentPlanVO();
            vo.setId(base.getId());
            vo.setPlanSn(base.getPlanSn());
            vo.setPatientSn(base.getPatientSn());
            vo.setPatientName(patientDetail.getPatientName());
            vo.setCreateTime(DateUtil.formatDateToString(base.getCreateTime(), DateUtil.FORMAT_TYPE_1));
            vo.setAdvice(ObjectUtils.isEmpty(base.getAdvice()) ? "" : base.getAdvice());
            vo.setSpeedStatus(base.getSpeedStatus());
            vo.setPlanItems(assembleTreatmentPlanVOs(planMap.get(base.getPlanSn()), planItemMap));
            vo.setIsPlanIssued(base.getIsPlanIssued());
            vo.setStatus(0); // 未开具方案单
            if (base.getIsPlanIssued()) {
                vo.setStatus(base.getSpeedStatus());
            }
            return vo;
        }).collect(Collectors.toList());
    }


    /**
     * 根据方案编号获取处置方案详情
     *
     * @param planSn
     * @return
     */
    // @Override
    // public BaseTreatmentPlanVO getDisposalPlanDetail(String planSn) {
    //
    //     BaseTreatmentPlanVO vo = new BaseTreatmentPlanVO();
    //     // 总表
    //     LambdaQueryWrapper<TreatmentPlanBase> baseWrapper = new LambdaQueryWrapper<>();
    //     baseWrapper.eq(TreatmentPlanBase::getPlanSn, planSn);
    //     baseWrapper.eq(TreatmentPlanBase::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
    //     TreatmentPlanBase base = treatmentPlanBaseService.getOne(baseWrapper);
    //     if (ObjectUtils.isEmpty(base)) {
    //         return vo;
    //     }
    //
    //     // 查出患者信息
    //     PatientAdminVO patientDetail = patientDomainService.getPatientDetail(base.getPatientSn());
    //     // 子表
    //     LambdaQueryWrapper<TreatmentPlan> planWrapper = new LambdaQueryWrapper<>();
    //     planWrapper.eq(TreatmentPlan::getPlanSn, base.getPlanSn());
    //     planWrapper.eq(TreatmentPlan::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
    //     List<TreatmentPlan> planList = treatmentPlanService.list(planWrapper);
    //     Map<String, List<TreatmentPlan>> planMap = CollectionUtils.isEmpty(planList) ? Collections.emptyMap() : planList.stream().collect(Collectors.groupingBy(TreatmentPlan::getPlanSn));
    //
    //     // 项目表
    //     List<TreatmentPlanItem> itemList = new ArrayList<>();
    //     if (CollectionUtils.isNotEmpty(planList)) {
    //         List<Integer> planIds = planList.stream().map(TreatmentPlan::getId).collect(Collectors.toList());
    //         LambdaQueryWrapper<TreatmentPlanItem> itemWrapper = new LambdaQueryWrapper<>();
    //         itemWrapper.in(TreatmentPlanItem::getPlanId, planIds);
    //         itemWrapper.eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
    //         itemList = treatmentPlanItemService.list(itemWrapper);
    //     }
    //     Map<Integer, List<TreatmentPlanItem>> planItemMap = CollectionUtils.isEmpty(itemList) ? Collections.emptyMap() : itemList.stream().collect(Collectors.groupingBy(TreatmentPlanItem::getPlanId));
    //
    //     // 组装 vo
    //     vo.setId(base.getId());
    //     vo.setPlanSn(base.getPlanSn());
    //     vo.setPatientSn(base.getPatientSn());
    //     vo.setPatientName(patientDetail.getPatientName());
    //     vo.setCreateTime(DateUtil.formatDateToString(base.getCreateTime(), DateUtil.FORMAT_TYPE_1));
    //     vo.setAdvice(base.getAdvice());
    //     // 配置次数方案
    //     List<TreatmentPlan> plans = planMap.get(base.getPlanSn());
    //     if (CollectionUtils.isNotEmpty(plans)) {
    //         List<TreatmentPlanVO> planVOS = plans.stream().map(plan -> {
    //             TreatmentPlanVO planVO = new TreatmentPlanVO();
    //             planVO.setId(plan.getId());
    //             planVO.setPatientSn(plan.getPatientSn());
    //             planVO.setOrderSn(plan.getZlOrderSn());
    //             planVO.setRecommendedTime(DateUtil.formatDateToString(plan.getRecommendedTime(), DateUtil.FORMAT_TYPE_3));
    //             planVO.setNoRecommended(ObjectUtils.isNotEmpty(planVO.getNoRecommended()));
    //             // planVO.setCreateTime("");
    //             // 配置项目
    //             List<TreatmentPlanItem> items = planItemMap.get(plan.getId());
    //             if (CollectionUtils.isNotEmpty(items)) {
    //                 List<TreatmentItemVO> itemVOS = items.stream().map(item -> {
    //                     TreatmentItemVO itemVO = TreatmentItemVO.builder().build();
    //                     itemVO.setId(item.getId());
    //                     itemVO.setItemId(item.getItemId());
    //                     itemVO.setProjectType(item.getProjectType());
    //                     itemVO.setItemName(item.getItemName());
    //                     itemVO.setUnitPrice(item.getUnitPrice());
    //                     itemVO.setTotalPrice(item.getTotalPrice());
    //                     itemVO.setPreferentialPrice(item.getPreferentialPrice());
    //                     itemVO.setSourceAmount(item.getSourceAmount());
    //                     itemVO.setTotalSessions(item.getTotalSessions());
    //                     itemVO.setFrequency(item.getFrequency());
    //                     itemVO.setFrequencyNum(item.getFrequencyNum());
    //                     itemVO.setDurationPerSession(item.getDurationPerSession());
    //                     itemVO.setDescription(item.getDescription());
    //                     return itemVO;
    //                 }).collect(Collectors.toList());
    //                 planVO.setItems(itemVOS);
    //             }
    //             planVO.setPlanUseStatus(0);
    //             planVO.setSortNum(plan.getSortNum());
    //             return planVO;
    //         }).collect(Collectors.toList());
    //         vo.setPlanItems(planVOS);
    //     }
    //     // TODO 是否开具了方案单
    //     vo.setIsPlanIssued(base.getIsPlanIssued());
    //     return vo;
    // }


    /**
     * 根据方案编号获取处置方案详情
     *
     * @param planSn
     * @return
     */
    @Override
    public BaseTreatmentPlanVO getDisposalPlanDetail(String planSn) {
        BaseTreatmentPlanVO vo = new BaseTreatmentPlanVO();
        // 查询总表
        List<TreatmentPlanBase> bases = getTreatmentPlanBases(null, planSn, null, null);
        if (CollectionUtils.isEmpty(bases)) {
            return vo;
        }
        TreatmentPlanBase base = bases.get(0);

        // 查出患者信息
        PatientAdminVO patientDetail = patientDomainService.getPatientDetail(base.getPatientSn());

        // 查询子表和项目表
        List<String> planSns = Collections.singletonList(planSn);
        Map<String, List<TreatmentPlan>> planMap = getTreatmentPlans(planSns);
        Map<Integer, List<TreatmentPlanItem>> planItemMap = getTreatmentPlanItems(planMap.values().stream().flatMap(List::stream).map(TreatmentPlan::getId).collect(Collectors.toList()));

        // 组装 vo
        vo.setId(base.getId());
        vo.setPlanSn(base.getPlanSn());
        vo.setPatientSn(base.getPatientSn());
        vo.setPatientName(patientDetail.getPatientName());
        vo.setCreateTime(DateUtil.formatDateToString(base.getCreateTime(), DateUtil.FORMAT_TYPE_1));
        vo.setAdvice(base.getAdvice());
        vo.setPlanItems(assembleTreatmentPlanVOs(planMap.get(base.getPlanSn()), planItemMap));
        vo.setIsPlanIssued(base.getIsPlanIssued());
        AtomicInteger atomicInt = new AtomicInteger(0);
        List<TreatmentPlanVO> plans = vo.getPlanItems();
        if (ObjectUtils.isNotEmpty(plans)) {
            List<String> orderSns = plans.stream().map(TreatmentPlanVO::getOrderSn).collect(Collectors.toList());
            // 查出订单
            List<Orders> ordersList = ordersService.list(new LambdaQueryWrapper<Orders>().in(Orders::getOrderSn, orderSns));
            if (ObjectUtils.isNotEmpty(ordersList)) {
                // 转成 map
                Map<String, Orders> ordersMap = ordersList.stream().collect(Collectors.toMap(Orders::getOrderSn, c -> c));
                plans.forEach(c -> {
                    Orders order = ordersMap.get(c.getOrderSn());
                    if (ObjectUtils.isNotEmpty(order)) {
                        c.setPlanStatus(order.getOrderStatus() == 0 ? order.getBusinessStatus() : order.getOrderStatus());
                        c.setOrderStatus(order.getOrderStatus());
                        c.setBusinessStatus(order.getBusinessStatus());
                        // 如果是完成状态
                        // 不是取消，不是退款，然后是完成，才是完成
                        if (!order.getOrderStatus().equals(OrderStatusEnum.REFUND.getCode()) && !order.getOrderStatus().equals(OrderStatusEnum.CANCEL.getCode()) && order.getBusinessStatus().equals(OrderBusinessStatusEnum.FINISH.getCode())) {
                            atomicInt.incrementAndGet();
                        }
                        // 查出订单的治疗师陈述
                        MedicalRecords records = medicalRecordsService.getOne(new LambdaQueryWrapper<MedicalRecords>().eq(MedicalRecords::getOrderSn, order.getOrderSn()).last("limit 1"));
                        c.setStatementContent(ObjectUtils.isNotEmpty(records) ? records.getStatementContent() : "");
                    }
                });
            }
        }
        vo.setTotalSessions(ObjectUtils.isNotEmpty(vo.getPlanItems()) ? vo.getPlanItems().size() : 0);
        TreatPlanBaseSpeedStatusEnum statusEnum = TreatPlanBaseSpeedStatusEnum.fromCode(base.getSpeedStatus());
        StringBuilder sb = new StringBuilder();
        sb.append(statusEnum.getValue());
        sb.append("(已完成");
        sb.append(atomicInt.get());
        sb.append("次,");
        sb.append("剩余");
        sb.append(vo.getTotalSessions() - atomicInt.get());
        sb.append("次）");
        vo.setSpeedStatusDoc(sb.toString());
        return vo;
    }


    /**
     * 客户端方案跟进的列表
     *
     * @param pageNum
     * @param pageSize
     * @param userId
     * @return
     */
    @Override
    public PageVO<PlanFollowUpVO> getPlanFollowUp(Integer pageNum, Integer pageSize, Integer userId) {

        PageVO<PlanFollowUpVO> pageVO = new PageVO<>();

        // 查出患者
        List<Patient> patientList = patientDomainService.getPatientByUserId(userId);

        if (CollectionUtils.isEmpty(patientList)) {
            return pageVO;
        }

        Map<String, Patient> patientMap = patientList.stream().collect(Collectors.toMap(Patient::getPatientSn, patient -> patient));

        List<String> patientSn = patientList.stream().map(Patient::getPatientSn).collect(Collectors.toList());

        // Page<AdminUserInfo> userInfoPage, List<Integer> doctorIds
        pageVO.setPageSize(pageSize);
        pageVO.setCurrentPage(pageNum);

        Page iPage = new Page<PlanFollowUpVO>();
        iPage.setSize(pageSize);
        iPage.setCurrent(pageNum);

        Page<PlanFollowUpVO> page = patientService.cusPageGetPlanFollowUp(iPage, patientSn);
        List<PlanFollowUpVO> voList = page.getRecords();
        if (CollectionUtils.isNotEmpty(voList)) {
            // 查出患者
            voList.forEach(vo -> {
                Patient patient = patientMap.get(vo.getPatientSn());
                if (ObjectUtils.isNotEmpty(patient)) {
                    vo.setPatientName(ObjectUtils.isNotEmpty(patient) ? patient.getName() : "");
                }

                String planSn = vo.getPlanSn();
                if (ObjectUtils.isNotEmpty(planSn)) {
                    TreatmentPlanBase base = treatmentPlanBaseService.getOne(new LambdaQueryWrapper<TreatmentPlanBase>().eq(TreatmentPlanBase::getPlanSn, planSn).eq(TreatmentPlanBase::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                    if (ObjectUtils.isNotEmpty(base)) {
                        vo.setSpeedStatus(base.getSpeedStatus());
                        List<TreatmentPlan> plans = treatmentPlanService.list(new LambdaQueryWrapper<TreatmentPlan>().eq(TreatmentPlan::getPlanSn, planSn).eq(TreatmentPlan::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));

                        AtomicInteger atomicInt = new AtomicInteger(0);
                        if (CollectionUtils.isNotEmpty(plans)) {
                            // 总数
                            vo.setTotalSessions(plans.size());
                            List<String> orderSns = plans.stream().map(TreatmentPlan::getZlOrderSn).collect(Collectors.toList());
                            // 查出订单
                            List<Orders> ordersList = ordersService.list(new LambdaQueryWrapper<Orders>().in(Orders::getOrderSn, orderSns));
                            if (ObjectUtils.isNotEmpty(ordersList)) {
                                // 转成 map
                                Map<String, Orders> ordersMap = ordersList.stream().collect(Collectors.toMap(Orders::getOrderSn, c -> c));
                                plans.forEach(c -> {
                                    Orders order = ordersMap.get(c.getZlOrderSn());
                                    if (ObjectUtils.isNotEmpty(order)) {
                                        // 如果是完成状态
                                        if (!order.getOrderStatus().equals(OrderStatusEnum.REFUND.getCode()) && !order.getOrderStatus().equals(OrderStatusEnum.CANCEL.getCode()) && order.getBusinessStatus().equals(OrderBusinessStatusEnum.FINISH.getCode())) {
                                            atomicInt.incrementAndGet();
                                        }
                                    }
                                });
                            }
                            vo.setFinishSessions(atomicInt.get());
                            vo.setRemainsSessions(vo.getTotalSessions() - atomicInt.get());

                        }
                    }

                }


                // 查预约时间
                String orderSn = vo.getOrderSn();
                if (ObjectUtils.isNotEmpty(orderSn)) {
                    Orders order = ordersService.getOne(new LambdaQueryWrapper<Orders>().eq(Orders::getOrderSn, orderSn).eq(Orders::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                    if (ObjectUtils.isNotEmpty(order) && vo.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode())) {
                        Integer scheduleDetailId = order.getScheduleDetailId();
                        if (ObjectUtils.isNotEmpty(scheduleDetailId)) {
                            ScheduleDetail scheduleDetail = scheduleDetailService.getOne(new LambdaQueryWrapper<ScheduleDetail>().eq(ScheduleDetail::getId, scheduleDetailId).eq(ScheduleDetail::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                            String dateStr = ObjectUtils.isNotEmpty(scheduleDetail) ? DateUtil.formatDateToString(scheduleDetail.getScheduleDate(), DateUtil.FORMAT_TYPE_3) : "";
                            String startStr = ObjectUtils.isNotEmpty(scheduleDetail) ? DateUtil.formatDateToString(scheduleDetail.getStartTime(), DateUtil.FORMAT_TYPE_5) : "";
                            String endStr = ObjectUtils.isNotEmpty(scheduleDetail) ? DateUtil.formatDateToString(scheduleDetail.getEndTime(), DateUtil.FORMAT_TYPE_5) : "";
                            vo.setScheduleTime(dateStr + " " + startStr + "-" + endStr);
                            // 查出预约的医生
                            AdminUserInfo adminUser = adminUserInfoService.getOne(new LambdaQueryWrapper<AdminUserInfo>().eq(AdminUserInfo::getAdminId, scheduleDetail.getAdminId()).last("limit 1"));
                            vo.setAdminName(ObjectUtils.isNotEmpty(adminUser) ? adminUser.getRealName() : "");

                        }
                    }
                }

            });
        }

        pageVO.setTotal(page.getTotal());
        pageVO.setList(voList);
        pageVO.setCurrentPage(pageNum);
        pageVO.setPageSize(pageSize);

        return pageVO;
    }

    /**
     * 查出账号下的所有处置方案  TODO V1.5 优化
     *
     * @param userId
     * @return
     */
    @Override
    public List<BaseTreatmentPlanVO> getAllPlan(Integer userId, Integer channelId) {

        // 查出患者
        List<Patient> patientList = patientDomainService.getPatientByUserId(userId);

        if (CollectionUtils.isEmpty(patientList)) {
            return null;
        }
        List<String> patientSnList = patientList.stream().map(Patient::getPatientSn).collect(Collectors.toList());
        List<BaseTreatmentPlanVO> voList = new ArrayList<>();
        for (String s : patientSnList) {
            List<BaseTreatmentPlanVO> disposalPlanList = getDisposalPlanList(s, channelId, TreatPlanBaseSpeedStatusEnum.DOING.getCode(), TreatPlanIssuedStatusEnum.ISSUED.getCode());
            if (CollectionUtils.isNotEmpty(disposalPlanList)) {
                for (BaseTreatmentPlanVO planVO : disposalPlanList) {
                    List<TreatmentPlanVO> plans = planVO.getPlanItems();
                    if (ObjectUtils.isNotEmpty(plans)) {
                        List<String> orderSns = plans.stream().map(TreatmentPlanVO::getOrderSn).collect(Collectors.toList());
                        // 查出订单
                        List<Orders> ordersList = ordersService.list(new LambdaQueryWrapper<Orders>().in(Orders::getOrderSn, orderSns));
                        // 转成 map
                        Map<String, Orders> ordersMap = ordersList.stream().collect(Collectors.toMap(Orders::getOrderSn, c -> c));
                        plans.forEach(c -> {
                            Orders orders = ordersMap.get(c.getOrderSn());
                            if (ObjectUtils.isNotEmpty(orders)) {
                                c.setOrderStatus(orders.getOrderStatus());
                                c.setBusinessStatus(orders.getBusinessStatus());
                            }
                        });
                    }
                }
                voList.addAll(disposalPlanList);
            }
        }

        return voList;
    }

    /**
     * 根据方案id 和订单合并的支付单
     *
     * @param id
     * @param orderSns
     * @return
     */
    @Override
    public TherapyOrdersNewVO mergeDisposalPlanConfirm(String id, List<String> orderSns) {

        TherapyOrdersNewVO vo = new TherapyOrdersNewVO();
        TreatmentPlanBase base = treatmentPlanBaseService.getById(id);
        // 查出患者
        PatientAdminVO detail = patientDomainService.getPatientDetail(base.getPatientSn());
        vo.setPatientSn(base.getPatientSn());
        vo.setPlanSn(base.getPlanSn());
        vo.setPatientName(detail.getPatientName());
        vo.setGender(detail.getGender());
        vo.setAdvice(ObjectUtils.isEmpty(base.getAdvice()) ? "" : base.getAdvice());
        vo.setAge(detail.getAge());

        List<Orders> ordersList = ordersService.list(new LambdaQueryWrapper<Orders>().in(Orders::getOrderSn, orderSns));

        // 转成 map
        Map<String, Orders> ordersMap = ordersList.stream().collect(Collectors.toMap(Orders::getOrderSn, c -> c));

        // 订单对应的项目
        List<TreatmentPlan> treatmentPlanList = treatmentPlanService.list(new LambdaQueryWrapper<TreatmentPlan>().in(TreatmentPlan::getZlOrderSn, orderSns));
        List<String> stringList = treatmentPlanList.stream().map(c -> c.getZlOrderSn()).collect(Collectors.toList());

        // 查出项目的子项
        List<TreatmentPlanItem> itemList = treatmentPlanItemService.list(new LambdaQueryWrapper<TreatmentPlanItem>().in(TreatmentPlanItem::getZlOrderSn, stringList));

        // 转成 map
        Map<Integer, List<TreatmentPlanItem>> itemMap = itemList.stream().collect(Collectors.groupingBy(TreatmentPlanItem::getPlanId));

        List<TreatmentPlanListVO> itemVoList = treatmentPlanList.stream().map(c -> {
            TreatmentPlanListVO itemVo = new TreatmentPlanListVO();
            itemVo.setOrderSn(c.getZlOrderSn());
            Orders orders = ordersMap.get(c.getZlOrderSn());
            // itemVo.setPlanStatus(orders.getOrderStatus());
            itemVo.setOrderStatus(orders.getOrderStatus());
            List<TreatmentPlanItem> items = itemMap.get(c.getId());
            // 算出 items 里的总价格
            BigDecimal totalPrice = items.stream().map(TreatmentPlanItem::getTotalPrice).reduce(BigDecimal.ZERO, BigDecimal::add);

            List<String> names = items.stream().map(it -> it.getItemName()).collect(Collectors.toList());
            // 用逗号分隔
            itemVo.setProjectNames(String.join("、", names));
            itemVo.setTotalPrice(totalPrice);
            itemVo.setSortNum(c.getSortNum());
            return itemVo;
        }).collect(Collectors.toList());
        vo.setOrderAmount(BigDecimal.ZERO.toString());
        if (CollectionUtils.isNotEmpty(itemVoList)) {
            BigDecimal totalPrice = itemVoList.stream().map(TreatmentPlanListVO::getTotalPrice).reduce(BigDecimal.ZERO, BigDecimal::add);
            vo.setOrderAmount(totalPrice.toString());
        }
        vo.setTreatmentPlan(itemVoList);
        return vo;
    }

    private UserCouponsVO convertUserCouponsVO(Coupon coupon, Map<String, Orders> ordersMap, Map<Integer, PlanProjectConfigVO> projectConfigVOMap) {
        UserCouponsVO couponsVO = new UserCouponsVO();
        couponsVO.setCouponCode(coupon.getCouponCode());
        couponsVO.setCouponType(coupon.getCouponType());
        couponsVO.setCouponTypeName(coupon.getCouponTypeName());
        couponsVO.setCouponName(coupon.getTemplateName());
        couponsVO.setCouponParValue(ObjectUtils.isEmpty(coupon.getCouponParValue()) ? "0" : coupon.getCouponParValue().toString());
        couponsVO.setDiscount(coupon.getDiscount());
        couponsVO.setExchangeOrder(coupon.getExchangeOrder());
        couponsVO.setThresholdNo(coupon.getThresholdNo());
        couponsVO.setOrderUseAmount(ObjectUtils.isEmpty(coupon.getOrderUseAmount()) ? "0" : coupon.getOrderUseAmount().toString());
        couponsVO.setForeverStatus(coupon.getForeverStatus());


        List<Integer> integerList = new ArrayList<>();
        if (StringUtils.isNotBlank(coupon.getAvailableProject())) {
            integerList = Arrays.stream(coupon.getAvailableProject().split(","))
                    .map(Integer::valueOf)
                    .collect(Collectors.toList());
        }
        couponsVO.setAvailableProject(integerList);

        // 设置治疗项目
        List<PlanProjectConfigVO> projectConfigVOS = new ArrayList<>();
        if (StringUtils.isNotBlank(coupon.getTreatmentProjectIds())) {
            List<Integer> projectIds = Arrays.stream(coupon.getTreatmentProjectIds().split(","))
                    .map(Integer::valueOf)
                    .collect(Collectors.toList());
            if (projectIds.size() == 1 && projectIds.get(0) == 0) {
                PlanProjectConfigVO projectConfigVO = new PlanProjectConfigVO();
                projectConfigVO.setId(0);
                projectConfigVO.setProjectName("全部项目");
                projectConfigVO.setProjectType(0);
                projectConfigVOS.add(projectConfigVO);
            } else {
                projectIds.forEach(pro -> {
                    if (ObjectUtils.isNotEmpty(projectConfigVOMap.get(pro))) {
                        projectConfigVOS.add(projectConfigVOMap.get(pro));
                    }
                });
            }
        }
        couponsVO.setProjectDetails(projectConfigVOS);


        String dateToString = DateUtil.formatDateToString(coupon.getExpireDate(), DateUtil.FORMAT_TYPE_3);
        String expireDateTime = dateToString + " " + "23:59:59";
        Date date = DateUtil.formatStrToDate(expireDateTime, DateUtil.FORMAT_TYPE_1);

        // 有订单，已使用
        if (StringUtils.isNotBlank(coupon.getOrderSn()) || coupon.getStatus().equals(WriteOffStatusEnum.WRITE_OFF.getCode())) {
            couponsVO.setUseStatus(CouponTypeUseStatusEnums.IS_USE.getValue());
        } else if (coupon.getForeverStatus().equals(ForeverStatusEnum.IS_FOEREVER.getValue())) {
            // 没有订单，又是永久有效的，待使用
            couponsVO.setUseStatus(CouponTypeUseStatusEnums.WAIT_FOR_USE.getValue());
        } else if (ObjectUtils.isNotEmpty(date) && date.before(new Date())) {
            // 已失效
            couponsVO.setUseStatus(CouponTypeUseStatusEnums.IS_EXPIRE.getValue());
        } else {
            couponsVO.setUseStatus(CouponTypeUseStatusEnums.WAIT_FOR_USE.getValue());
        }

        couponsVO.setExpireDate(DateUtil.formatDateToString(coupon.getExpireDate(), DateUtil.FORMAT_TYPE_3));
        couponsVO.setInstructions(coupon.getInstructions());
        Orders orders = ordersMap.get(coupon.getOrderSn());
        if (ObjectUtils.isNotEmpty(orders)) {
            OrderVO orderVO = OrderVO.builder().build();
            BeanUtils.copyProperties(orders, orderVO);
            couponsVO.setOrderVO(orderVO);
        }
        return couponsVO;
    }

    private List<PatientUserInfoVO> convertPatientUserInfoVOs(List<Patient> patients) {
        List<PatientUserInfoVO> result = new ArrayList<>();
        if (patients != null && patients.size() > 0) {
            for (Patient patient : patients) {
                PatientUserInfoVO patientUserInfoVO = convertPatientUserInfoVO(patient);
                result.add(patientUserInfoVO);
            }
        }
        return result;
    }

    private PatientUserInfoVO convertPatientUserInfoVO(Patient patient) {
        Integer age = patient.getAge();
        if (Objects.isNull(age)) {
            PatientUserInfoVO patientUserInfoVO = new PatientUserInfoVO();
            patientUserInfoVO.setAvatarUrl(patient.getAvatarUrl());
            patientUserInfoVO.setPatientSn(patient.getPatientSn());
            patientUserInfoVO.setIdentityType(patient.getIdentityType());
            patientUserInfoVO.setName(patient.getName());
            patientUserInfoVO.setIdCardNumber(patient.getIdCardNumber());
            patientUserInfoVO.setPhoneNumber(patient.getPhoneNumber());
            patientUserInfoVO.setGender(patient.getGender());
            patientUserInfoVO.setOccupation(patient.getOccupation());
            patientUserInfoVO.setMaritalStatus(patient.getMaritalStatus());
            return patientUserInfoVO;
        }
        PatientAgeUserInfoVO userInfoVO = new PatientAgeUserInfoVO();
        userInfoVO.setAvatarUrl(patient.getAvatarUrl());
        userInfoVO.setPatientSn(patient.getPatientSn());
        userInfoVO.setIdentityType(patient.getIdentityType());
        userInfoVO.setName(patient.getName());
        userInfoVO.setIdCardNumber(patient.getIdCardNumber());
        userInfoVO.setPhoneNumber(patient.getPhoneNumber());
        userInfoVO.setGender(patient.getGender());
        userInfoVO.setOccupation(patient.getOccupation());
        userInfoVO.setMaritalStatus(patient.getMaritalStatus());
        userInfoVO.setAge(patient.getAge());
        return userInfoVO;
    }


    // V1.5
    // 提取公共部分 - 查询 TreatmentPlanBase 列表
    private List<TreatmentPlanBase> getTreatmentPlanBases(String patientSn, String planSn, Integer speedStatus, Boolean isPlanIssued) {
        LambdaQueryWrapper<TreatmentPlanBase> baseWrapper = new LambdaQueryWrapper<>();
        if (ObjectUtils.isNotEmpty(patientSn)) {
            baseWrapper.eq(TreatmentPlanBase::getPatientSn, patientSn);
        }
        if (ObjectUtils.isNotEmpty(planSn)) {
            baseWrapper.eq(TreatmentPlanBase::getPlanSn, planSn);
        }
        if (ObjectUtils.isNotEmpty(speedStatus)) {
            baseWrapper.eq(TreatmentPlanBase::getSpeedStatus, speedStatus);
        }
        if (ObjectUtils.isNotEmpty(isPlanIssued)) {
            baseWrapper.eq(TreatmentPlanBase::getIsPlanIssued, isPlanIssued);
        }
        baseWrapper.eq(TreatmentPlanBase::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
        baseWrapper.orderByDesc(TreatmentPlanBase::getCreateTime);
        return treatmentPlanBaseService.list(baseWrapper);
    }

    // 提取公共部分 - 查询 TreatmentPlan 列表
    private Map<String, List<TreatmentPlan>> getTreatmentPlans(List<String> planSns) {
        if (CollectionUtils.isEmpty(planSns)) {
            return Collections.emptyMap();
        }
        LambdaQueryWrapper<TreatmentPlan> planWrapper = new LambdaQueryWrapper<>();
        planWrapper.in(TreatmentPlan::getPlanSn, planSns);
        planWrapper.eq(TreatmentPlan::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
        List<TreatmentPlan> planList = treatmentPlanService.list(planWrapper);
        return CollectionUtils.isEmpty(planList) ? Collections.emptyMap() : planList.stream().collect(Collectors.groupingBy(TreatmentPlan::getPlanSn));
    }

    // 提取公共部分 - 查询 TreatmentPlanItem 列表
    private Map<Integer, List<TreatmentPlanItem>> getTreatmentPlanItems(List<Integer> planIds) {
        if (CollectionUtils.isEmpty(planIds)) {
            return Collections.emptyMap();
        }
        LambdaQueryWrapper<TreatmentPlanItem> itemWrapper = new LambdaQueryWrapper<>();
        itemWrapper.in(TreatmentPlanItem::getPlanId, planIds);
        itemWrapper.eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue());
        List<TreatmentPlanItem> itemList = treatmentPlanItemService.list(itemWrapper);
        return CollectionUtils.isEmpty(itemList) ? Collections.emptyMap() : itemList.stream().collect(Collectors.groupingBy(TreatmentPlanItem::getPlanId));
    }

    // 提取公共部分 - 组装 TreatmentPlanVO 列表
    private List<TreatmentPlanVO> assembleTreatmentPlanVOs(List<TreatmentPlan> plans, Map<Integer, List<TreatmentPlanItem>> planItemMap) {
        if (CollectionUtils.isEmpty(plans)) {
            return Collections.emptyList();
        }
        return plans.stream().map(plan -> {
            TreatmentPlanVO planVO = new TreatmentPlanVO();
            planVO.setId(plan.getId());
            planVO.setPatientSn(plan.getPatientSn());
            planVO.setOrderSn(plan.getZlOrderSn());
            planVO.setRecommendedTime(DateUtil.formatDateToString(plan.getRecommendedTime(), DateUtil.FORMAT_TYPE_3));
            planVO.setNoRecommended(ObjectUtils.isEmpty(planVO.getRecommendedTime()));
            planVO.setMechanization(plan.getMechanization());
            planVO.setExpectedOutcomes(plan.getExpectedOutcomes());
            planVO.setSortNum(plan.getSortNum());

            String zlOrderSn = plan.getZlOrderSn();
            if (ObjectUtils.isNotEmpty(zlOrderSn)) {
                Orders order = ordersService.getOne(new LambdaQueryWrapper<Orders>().eq(Orders::getOrderSn, zlOrderSn));
                Integer scheduleDetailId = ObjectUtils.isNotEmpty(order) ? order.getScheduleDetailId() : null;
                if (ObjectUtils.isNotEmpty(scheduleDetailId)) {
                    ScheduleDetail scheduleDetail = scheduleDetailService.getById(scheduleDetailId);
                    String dateStr = DateUtil.formatDateToString(scheduleDetail.getScheduleDate(), DateUtil.FORMAT_TYPE_3);
                    String startTime = DateUtil.formatDateToString(scheduleDetail.getStartTime(), DateUtil.FORMAT_TYPE_5);
                    planVO.setScheduleDateTime(dateStr + " " + startTime);
                    Integer adminId = scheduleDetail.getAdminId();
                    AdminUserInfo adminUserInfo = adminUserInfoService.getOne(new LambdaQueryWrapper<AdminUserInfo>().eq(AdminUserInfo::getAdminId, adminId));
                    planVO.setAdminName(ObjectUtils.isNotEmpty(adminUserInfo) ? adminUserInfo.getRealName() : "");
                }

            }
            List<TreatmentPlanItem> items = planItemMap.get(plan.getId());
            if (CollectionUtils.isNotEmpty(items)) {
                List<TreatmentItemVO> itemVOS = items.stream().map(item -> {
                    TreatmentItemVO itemVO = TreatmentItemVO.builder().build();
                    itemVO.setId(item.getId());
                    itemVO.setItemId(item.getItemId());
                    itemVO.setPlanId(item.getPlanId());
                    itemVO.setProjectType(item.getProjectType());
                    itemVO.setItemName(item.getItemName());
                    itemVO.setUnitPrice(ObjectUtils.isNotEmpty(item.getUnitPrice()) ? item.getUnitPrice().toString() : "");
                    itemVO.setPriceHour(ObjectUtils.isNotEmpty(item.getUnitPrice()) ? item.getUnitPrice().toString() : "");
                    itemVO.setTotalPrice(item.getTotalPrice());
                    itemVO.setPreferentialPrice(ObjectUtils.isNotEmpty(item.getPreferentialPrice()) ? item.getPreferentialPrice().toString() : "");
                    itemVO.setSourceAmount(item.getSourceAmount());
                    itemVO.setTotalSessions(item.getTotalSessions());
                    itemVO.setFrequency(item.getFrequency());
                    itemVO.setFrequencyNum(item.getFrequencyNum());
                    itemVO.setDurationPerSession(item.getDurationPerSession());
                    itemVO.setDescription(item.getDescription());
                    itemVO.setExpectedDuration(item.getExpectedDuration());
                    itemVO.setSingleAppointmentDuration(ObjectUtils.isNotEmpty(item.getDurationPerSession()) ? item.getDurationPerSession().toString() : "");
                    return itemVO;
                }).collect(Collectors.toList());
                planVO.setItems(itemVOS);
            }
            return planVO;
        }).collect(Collectors.toList());
    }
}
