package com.params.application.support.wx.impl;

import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.alibaba.fastjson.JSONObject;
import com.params.application.support.wx.MsgReqProcess;
import com.params.application.support.wx.MsgReqProcessFactory;
import com.params.application.support.wx.WxSupportService;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.entity.OfficialAccount;
import com.params.framework.exception.ServiceException;
import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;
import com.params.service.OfficialAccountService;
import com.params.utils.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

@Component
@Slf4j
public class WxSupportServiceImpl implements WxSupportService {

    @Autowired
    private MsgReqProcessFactory msgReqProcessFactory;

    @Autowired
    private OfficialAccountService officialAccountService;

    @Override
    public void bind(HttpServletRequest request, HttpServletResponse response, WxConfigBO wxConfig) {
        if (isLegal(wxConfig.getAccessToken(), request)) {
            try {
                response.getWriter().write(request.getParameter("echostr"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void processAccess(HttpServletRequest request, HttpServletResponse response, WxConfigBO wxConfig, WxReqBO req) {
        try {
            if (!isLegal(wxConfig.getAccessToken(), request)) {
                log.info("微信公众号接入失败，签名验证失败,param:{}", request.getParameterMap());
                response.getWriter().write("");
                return;
            }
            // 查询配置
            String msgType = req.getMsgType().toUpperCase();
            String event = req.getEvent();
            String code = msgType;
            if (StrUtil.isNotEmpty(event)) {
                code = msgType + "_" + event.toUpperCase();
            }
            OfficialAccount account = officialAccountService.getOfficialByCode(req.getToUserName(), code);
            if (Objects.isNull(account)) {
                log.info("表【official_account】不存在配置：{}，{}", req.getToUserName(), code);
                response.getWriter().write("");
                return;
            }
            MsgReqProcess msgReqProcess = msgReqProcessFactory.getMsgReqProcess(req, account);
            BaseMsg msg = msgReqProcess.handle(req, wxConfig, account);
            String result = wxResult(msg, req);
            log.debug("process result={}", result);
            if (!Objects.isNull(result)) {
                response.setContentType("text/html; charset=utf-8");
                response.getWriter().write(result);
            } else {
                response.getWriter().write("success");
            }
        } catch (Exception e) {
            log.warn("公众号接入异常：" + e);
            throw new ServiceException("公众号接入异常");
        }
    }


    private String wxResult(BaseMsg msg, WxReqBO req) {
        if (Objects.isNull(msg)) {
            return "";
        }
        msg.setFromUserName(req.getToUserName());
        msg.setToUserName(req.getFromUserName());
        msg.setCreateTime(System.currentTimeMillis());
        return msg.toXml();
    }

    @Override
    public WxConfigBO getWxConfigInfo(String officialCode) {
        OfficialAccount account = officialAccountService.getOfficialByCode(officialCode, "CONFIG");
        if (Objects.isNull(account)) {
            log.info("开发者微信号：{} 未配置公众号信息！", officialCode);
            throw new ServiceException("未配置公众号信息！");
        }
        JSONObject jsonObject = JSONObject.parseObject(account.getConfig());
        WxConfigBO wxConfigBO = new WxConfigBO().setAppId(account.getAppid())
                .setSecret(jsonObject.getString("appSecret"))
                .setAccessToken(jsonObject.getString("token"))
                .setEncodingAESKey(jsonObject.getString("encodingAESKey"))
                .setOfficialCode(officialCode);
        return wxConfigBO;
    }

    private boolean isLegal(String token, HttpServletRequest request) {
        String signature = request.getParameter("signature");
        String timestamp = request.getParameter("timestamp");
        String nonce = request.getParameter("nonce");
        if (StringUtil.hasBlank(signature, timestamp, nonce)) {
            return false;
        }
        String[] arr = new String[]{token, timestamp, nonce};
        Arrays.sort(arr);
        StringBuilder content = new StringBuilder();
        for (String anArr : arr) {
            content.append(anArr);
        }
        return signature.equals(SecureUtil.sha1(content.toString()));
    }

}
