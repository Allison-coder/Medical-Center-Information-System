package com.params.application.order;

import com.params.pojo.bo.GetMergeOrderListBO;
import com.params.pojo.dto.AddNewTreatmentDTO;
import com.params.pojo.dto.PatientTasksDTO;
import com.params.pojo.dto.QueryOrderDTO;
import com.params.pojo.vo.InterviewRecordsVO;
import com.params.pojo.vo.MergePayOrderVO;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.PatientTaskVO;
import com.params.pojo.vo.TreatmentOrderVO;
import com.params.pojo.vo.common.PageVO;

import java.util.List;

public interface OrderApp {

    PageVO<OrderVO> getOrders(QueryOrderDTO dto);

    List<OrderVO> getUnfinishedOrders(Integer userId, Integer channelId);

    OrderVO getOrderByOrderSn(String orderSn, Integer channelId);

    /**
     * 查治疗师的订单
     * @param dto
     * @return
     */
    PageVO<OrderVO> getZlOrders(QueryOrderDTO dto);

    /**
     * 根据订单号查询面诊记录
     * @param orderSn
     * @return
     */
    InterviewRecordsVO getInterviewRecordsByOrderSn(String orderSn,String source);

    /**
     * 根据患者编号查找用户任务列表
     * @param dto
     * @return
     */
    PageVO<PatientTaskVO> getPatientTaskOrders(PatientTasksDTO dto);

    /**
     * 添加新的治疗（项目）
     * @param dto
     * @return
     */
    String addNewTreatment(AddNewTreatmentDTO dto);

    /**
     * 根据方案编号查找订单
     * @param planSn
     * @return
     */
    List<TreatmentOrderVO> getOrderByProjectSn(String planSn);

    /**
     * 根据处置方案 id 查出订单
     * @param id
     * @return
     */
    List<MergePayOrderVO> mergeDisposalPlan(Integer id);

    /**
     * 合并支付订单列表
     * @param bo
     * @return
     */
    List<OrderVO> getMergeOrderList(GetMergeOrderListBO bo);
}
