package com.params.application.support.wx.process;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.params.application.support.wx.MsgReqProcess;
import com.params.constant.SourceTypeEnum;
import com.params.domain.promotion.PromotionDomainService;
import com.params.domain.wx.callback.WxDomainService;
import com.params.domain.wx.user.UserInfoDomainService;
import com.params.entity.Coupon;
import com.params.entity.OfficialAccount;
import com.params.entity.OfficialUserBind;
import com.params.entity.PromotionChannels;
import com.params.pojo.bo.wx.Article;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.pojo.bo.wx.NewsMsg;
import com.params.pojo.bo.wx.WeiXinUserInfoBO;
import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;
import com.params.rabbitmq.sender.WeiXinTextMsgSender;
import com.params.service.OfficialUserBindService;
import com.params.service.impl.WxUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/**
 * 优惠券的关注事件适配器
 */
@Component("couponEventSubscribeMsgReqProcess")
@Slf4j
public class CouponSubscribeMsgReqProcess implements MsgReqProcess {
    @Autowired
    private PromotionDomainService promotionDomainService;

    @Autowired
    private WxDomainService wxDomainService;

    @Autowired
    private MsgReqProcess defaultResultMsgReqProcess;

    @Autowired
    private UserInfoDomainService userInfoDomainService;

    @Autowired
    private OfficialUserBindService officialUserBindService;

    @Autowired
    private WeiXinTextMsgSender msgSender;

    @Override
    public BaseMsg handle(WxReqBO reqBO, WxConfigBO wxConfigBO, OfficialAccount account) {
        // 获取参数
        log.info("【医疗中心优惠券关注事件处理】");
        String fromUserName = reqBO.getFromUserName();
        log.info("用户：" + fromUserName);
        // 登记关注公众号的用户
        WeiXinUserInfoBO wxUserInfo = userInfoDomainService.getWxUserInfo(fromUserName, wxConfigBO.getAppId(), wxConfigBO.getSecret());
        subscribeOfficialAccount(reqBO, wxUserInfo);

        String eventKey = reqBO.getEventKey();
        log.info("===eventKey: " + eventKey);
        if (Objects.isNull(eventKey)) {
            return handleDefaultMsg(fromUserName, account);
        }
        Map<String, String> paramsMap = wxDomainService.convertQrEventKeyToMap(eventKey);
        String code = paramsMap.get("code");
        // 业务逻辑，通过 code 获取优惠券id
        if (Objects.isNull(code)) {
            return handleDefaultMsg(fromUserName, account);
        }
        // 判断用户是否已有优惠券
        String couponCode = promotionDomainService.getCouponCodeByUserName(code, fromUserName);
        log.info("===优惠券码: " + couponCode);
        // 优惠券code
        String qrCodeData = couponCode;
        if (Objects.isNull(couponCode)) {
            Coupon coupon = promotionDomainService.createCodeAfterFollow(code, fromUserName);
            qrCodeData = coupon.getCouponCode();
            log.info("用户暂无优惠券，创建优惠券：" + qrCodeData);
        }
        // 创建临时文件
        String filePath = wxDomainService.getQrCodeTempFile();
        log.info("===临时路径: " + filePath);
        JSONObject extConfig = JSONObject.parseObject(account.getExtConfig());
        JSONObject qrcode = extConfig.getJSONObject("qrcode");
        int qrCodeHeight = qrcode.getInteger("height"); // 二维码高度
        int qrCodeWidth = qrcode.getInteger("width"); // 二维码宽度
        wxDomainService.generateQRCode(qrCodeData, filePath, qrCodeWidth, qrCodeHeight);
        // 生成了二维码，将二维码图片上传给到微信，并将url返回
        // 根据优惠券id生成图片，并上传到微信，将微信返回的url作为响应
        String accessToken = WxUtil.getWxAppAccessToken(wxConfigBO.getAppId(), wxConfigBO.getSecret());
        String url = WxUtil.uploadFileByUrl(accessToken, filePath);
        log.info("回复图片url内容：{}", url);
        // 删除临时文件
        if (FileUtil.exist(filePath)) {
            FileUtil.del(filePath);
        }
        Article article = JSONObject.parseObject(account.getConfig(), Article.class);
        NewsMsg newsMsg = new NewsMsg();
        newsMsg.add(article);
        article.setUrl(url);
        // 调整从推广渠道获取配置
        PromotionChannels channelCodeInfo = promotionDomainService.getChannelInfoByChannelCode(code);
        String contextConfig = channelCodeInfo.getContextConfig();
        JSONObject jsonObject = JSONObject.parseObject(contextConfig);
        if (Objects.nonNull(jsonObject)) {
            String title = jsonObject.getString("bigTitle");
            if (StrUtil.isNotEmpty(title)) {
                article.setTitle(title);
            }
            String description = jsonObject.getString("smallTitle");
            if (StrUtil.isNotEmpty(description)) {
                article.setDescription(description);
            }
        }
        // 入队，后续发送文案消息  fromUserName
        String autoAckContent = jsonObject.getString("autoAckContent");
        if (StrUtil.isNotEmpty(autoAckContent)) {
            JSONObject config = JSONObject.parseObject(account.getConfig());
            msgSender.send(fromUserName, "text", autoAckContent, config.getLong("dissipate"));
        }
        return newsMsg;
    }

    private BaseMsg handleDefaultMsg(String fromUserName, OfficialAccount account) {
        log.info("不存在额外参数，非推广二维码扫码！");
        // 取配置返回
        JSONObject extConfig = JSONObject.parseObject(account.getExtConfig());
        String type = extConfig.getString("msgType");
        log.info("默认返回类型：" + type);
        OfficialAccount config = new OfficialAccount();
        config.setStrategy("DEFAULT");
        config.setResultMsgType(type);
        config.setConfig(extConfig.getString(type));
        BaseMsg msg = defaultResultMsgReqProcess.handle(null, null, config);
        // send
        JSONArray customerMsg = extConfig.getJSONArray("customerMsg");
        Iterator<Object> iterator = customerMsg.iterator();
        while (iterator.hasNext()) {
            JSONObject next = (JSONObject) iterator.next();
//            System.out.println(next);
//            System.out.println(next.getString("msgType"));
//            System.out.println(next.getString("media_id"));
            String mediaId = next.getString("media_id");
            Long dissipate = next.getLong("dissipate");
            if (StrUtil.isEmpty(mediaId)) {
                // TODO 如果没有mediaId,则将图片上传到素材获取 mediaId，有则直接使用
            }
            msgSender.send(fromUserName, next.getString("msgType"), mediaId, dissipate);
        }
        return msg;
    }

    private void subscribeOfficialAccount(WxReqBO reqBO, WeiXinUserInfoBO wxUserInfo) {
        try {
            OfficialUserBind bind = new OfficialUserBind();
            bind.setOfficialCode(reqBO.getToUserName());
            bind.setUniqueCode(reqBO.getFromUserName());
            bind.setType(SourceTypeEnum.WEIXIN.name());
            bind.setCreateTime(new Date());
            bind.setModifyTime(new Date());
            if (Objects.nonNull(wxUserInfo)) {
                bind.setUnionid(wxUserInfo.getUnionid());
            }
            officialUserBindService.save(bind);
        } catch (Exception e) {
//            log.error("[{}.subscribeOfficialAccount] insert_fail", this.getClass().getSimpleName(), e);
        }
    }
}
