package com.params.application.patient;

import com.params.pojo.dto.GetUserCouponsToGHOrderDTO;
import com.params.pojo.vo.BaseTreatmentPlanVO;
import com.params.pojo.vo.PatientUserInfoVO;
import com.params.pojo.vo.PlanFollowUpVO;
import com.params.pojo.vo.TherapyOrdersNewVO;
import com.params.pojo.vo.UserCouponsVO;
import com.params.pojo.vo.UserTreatmentPlanVO;
import com.params.pojo.vo.common.PageVO;

import java.util.List;

public interface PatientApp {

    /**
     * 根据名称模糊查询得到患者号列表
     * @param name
     * @return
     */
    List<String> getPatientSnsByName(String name, Integer channelId);

    /**
     * 根据用户、渠道获取患者信息
     * @param userId
     * @param channelId
     * @return
     */
    List<PatientUserInfoVO> getPatientByCurrentUser(Integer userId, Integer channelId);


    /**
     * 获取患者的治疗方案列表
     * @param userId
     * @param pageNum
     * @param pageSize
     * @return
     */
    PageVO<UserTreatmentPlanVO> getTreatmentPlan(Integer userId, Integer pageNum, Integer pageSize);


    /**
     * 当前用户已领取的优惠券
     * @param userId
     * @param status 1-待使用 2-已使用 3-已失效
     * @return
     */
    List<UserCouponsVO> getUserCoupons(Integer userId, String status);

    /**
     * 获取用户订单可用的优惠券
     * @param orderSn
     * @param id
     * @param userId
     * @return
     */
    List<UserCouponsVO> getUserCouponsToOrder(String orderSn,  Integer id,Integer userId);

    /**
     * 获取用户挂号单可用的优惠券
     * @param dto
     * @return
     */
    List<UserCouponsVO> getUserCouponsToGHOrder(GetUserCouponsToGHOrderDTO dto);

    /**
     * 根据患者编号获取患者的所有处置方案
     * @param patientSn
     * @param clinicId
     * @param speedStatus
     * @param isPlanIssued
     * @return
     */
    List<BaseTreatmentPlanVO> getDisposalPlanList(String patientSn, Integer clinicId,Integer speedStatus,Boolean isPlanIssued);

    /**
     * 根据方案编号获取处置方案详情
     * @param planSn
     * @return
     */
    BaseTreatmentPlanVO getDisposalPlanDetail(String planSn);

    /**
     * 客户端方案跟进的列表
     * @param pageNum
     * @param pageSize
     * @param userId
     * @return
     */
    PageVO<PlanFollowUpVO> getPlanFollowUp(Integer pageNum, Integer pageSize, Integer userId);

    /**
     * 查出账号下的所有处置方案
     * @param userId
     * @return
     */
    List<BaseTreatmentPlanVO> getAllPlan(Integer userId,Integer channelId);


    /**
     * 根据方案id 和订单合并的支付单
     * @param id
     * @param orderSns
     * @return
     */
    TherapyOrdersNewVO mergeDisposalPlanConfirm(String id, List<String> orderSns);
}
