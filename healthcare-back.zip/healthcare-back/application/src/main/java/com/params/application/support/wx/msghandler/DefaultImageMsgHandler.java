package com.params.application.support.wx.msghandler;

import com.alibaba.fastjson.JSONObject;
import com.params.application.support.wx.ResultMsgHandler;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.pojo.bo.wx.ImageMsg;
import com.params.pojo.bo.wx.WxReqBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component("defaultImageMsgHandler")
@Slf4j
public class DefaultImageMsgHandler implements ResultMsgHandler {
    @Override
    public BaseMsg handle(WxReqBO reqBO, OfficialAccount account) {
        ImageMsg msg = new ImageMsg();
        JSONObject jsonObject = JSONObject.parseObject(account.getConfig());
        String content = jsonObject.getString("mediaId");
        msg.setMediaId(Objects.isNull(content) ? "" : content);
        return msg;
    }
}
