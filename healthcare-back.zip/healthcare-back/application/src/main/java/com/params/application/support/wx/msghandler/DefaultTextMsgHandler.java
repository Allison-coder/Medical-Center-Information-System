package com.params.application.support.wx.msghandler;

import com.alibaba.fastjson.JSONObject;
import com.params.application.support.wx.ResultMsgHandler;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.pojo.bo.wx.TextMsg;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxReqBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component("defaultTextMsgHandler")
@Slf4j
public class DefaultTextMsgHandler implements ResultMsgHandler {
    @Override
    public BaseMsg handle(WxReqBO reqBO, OfficialAccount account) {
        TextMsg msg = new TextMsg();
        JSONObject jsonObject = JSONObject.parseObject(account.getConfig());
        String content = jsonObject.getString("content");
        msg.setContent(Objects.isNull(content) ? "" : content);
        return msg;
    }
}
