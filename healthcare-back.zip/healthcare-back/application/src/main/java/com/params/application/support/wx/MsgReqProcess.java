package com.params.application.support.wx;

import com.params.pojo.bo.wx.BaseMsg;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;

public interface MsgReqProcess {

    BaseMsg handle(WxReqBO reqBO, WxConfigBO wxConfigBO, OfficialAccount account);
}
