package com.params.application.workpanel;

import com.params.pojo.vo.MedicalRecordPatientVO;

import java.util.List;

/**
 * @DESCRIPTION 工作面板的 app 层
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public interface WorkPanelApp {

    /**
     * 根据串者编号查出就诊记录
     * @param patientSn
     * @return
     */
    List<MedicalRecordPatientVO> getMedicalRecord(String patientSn, Integer clinicId);


    // 根据



}
