package com.params.application.adminuser;

import com.params.pojo.vo.FamousDoctorVO;
import com.params.pojo.vo.ScienceRecordVO;
import com.params.pojo.vo.common.PageVO;

public interface HomeInfoApp {

    PageVO<FamousDoctorVO> getFamousDoctors(Integer channelId, Integer pageNum, Integer pageSize);

    PageVO<ScienceRecordVO> getScienceRecords(Integer channelId, Integer pageNum, Integer pageSize);
}
