package com.params.application.schedule;

import com.params.pojo.dto.ReserveQueryDTO;
import com.params.pojo.vo.RecentReserveVO;
import com.params.pojo.vo.ReserveListNewVO;
import com.params.pojo.vo.ReserveListVO;
import com.params.pojo.vo.ScheduleDateVO;
import com.params.pojo.vo.common.PageVO;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public interface ScheduleApp {

    // @ApiModelProperty(value = "页大小，默认10", example = "10")
    // @Min(1)
    // @Max(100)
    // private Integer pageSize = 10;
    //
    // @ApiModelProperty(value = "页码，默认1", example = "1")
    // @Min(0)
    // private Integer pageNum = 1;

    /**
     * 获取医生排班时间
     * @param date
     * @return
     */
    PageVO<ScheduleDateVO> getScheduleTime(Integer pageNum, Integer pageSize, String date,Boolean isHeal);


    /**
     * 预约列表
     * @return
     */
    PageVO<ReserveListVO> getReserveList(ReserveQueryDTO reserveQueryDTO);

    /**
     * 我的近期预约
     * @param patientSn
     * @return
     */
    RecentReserveVO getRecentReserve(String patientSn);

    /**
     * 取消预约
     * @param orderSn
     * @return
     */
    Boolean cancleAppiont(String orderSn);

    /**
     * 新的获取预约列表
     * @param reserveQueryDTO
     * @return
     */
    PageVO<ReserveListNewVO> getNewReserveList(ReserveQueryDTO reserveQueryDTO);
}
