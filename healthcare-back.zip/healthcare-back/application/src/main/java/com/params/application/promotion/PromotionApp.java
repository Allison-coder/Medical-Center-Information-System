package com.params.application.promotion;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.entity.PromotionChannels;
import com.params.pojo.vo.PromotionDetailsVO;
import com.params.pojo.vo.PromotionPageVO;
import com.params.pojo.vo.ReceiveStatusVO;
import com.params.pojo.vo.common.PageVO;

/**
 * @DESCRIPTION 优惠活动的app层
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public interface PromotionApp {

    /**
     * 优惠活动列表
     * @param page
     * @param channelName
     * @param activityName
     * @return
     */
    PageVO<PromotionPageVO>  promotionList(Page<PromotionChannels> page, String channelName, String activityName);


    /**
     * 根据id查出优惠券详情
     * @param id
     * @return
     */
    PromotionDetailsVO getPromotionChannelById(Integer id);

    /**
     * 根据渠道code查出渠道活动详情
     * @param channelCode
     * @return
     */
    PromotionDetailsVO getPromotionChannelByCode(String channelCode);

    /**
     * 根据渠道code获取用户领取状态
     * @param channelCode
     * @param userId
     * @return
     */
    ReceiveStatusVO getReceiveStatus(String channelCode, Integer userId);
}
