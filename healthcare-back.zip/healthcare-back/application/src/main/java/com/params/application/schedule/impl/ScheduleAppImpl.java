package com.params.application.schedule.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.application.schedule.ScheduleApp;
import com.params.constant.MedicalRecordStatusEnum;
import com.params.constant.OrderBusinessStatusEnum;
import com.params.constant.OrderStatusEnum;
import com.params.constant.OrderTypeEnum;
import com.params.constant.OrserScheduleTypeEnum;
import com.params.constant.PlanItemProjectTypeEnum;
import com.params.constant.RoleCodeEnum;
import com.params.constant.ScheduleStatusEnum;
import com.params.convert.PageConvert;
import com.params.domain.schedule.ScheduleDomainService;
import com.params.domain.tasklog.TaskLogDomainService;
import com.params.entity.AdminRole;
import com.params.entity.AdminRoleBind;
import com.params.entity.AdminUserInfo;
import com.params.entity.MedicalRecords;
import com.params.entity.Orders;
import com.params.entity.Patient;
import com.params.entity.Schedule;
import com.params.entity.ScheduleDetail;
import com.params.entity.ScheduleDetailPatientBind;
import com.params.entity.TreatmentPlan;
import com.params.entity.TreatmentPlanBase;
import com.params.entity.TreatmentPlanItem;
import com.params.framework.constant.DeletedStatusEnum;
import com.params.framework.exception.ServiceException;
import com.params.pojo.dto.ReserveQueryDTO;
import com.params.pojo.vo.RecentReserveVO;
import com.params.pojo.vo.ReserveListNewVO;
import com.params.pojo.vo.ReserveListVO;
import com.params.pojo.vo.ScheduleDateVO;
import com.params.pojo.vo.ScheduleDetailTimeVo;
import com.params.pojo.vo.common.PageVO;
import com.params.service.AdminRoleBindService;
import com.params.service.AdminRoleService;
import com.params.service.AdminUserInfoService;
import com.params.service.MedicalRecordsService;
import com.params.service.OrdersService;
import com.params.service.PatientService;
import com.params.service.ScheduleDetailPatientBindService;
import com.params.service.ScheduleDetailService;
import com.params.service.ScheduleService;
import com.params.service.TreatmentPlanBaseService;
import com.params.service.TreatmentPlanItemService;
import com.params.service.TreatmentPlanService;
import com.params.utils.DateUtil;
import com.params.utils.UserSecurityContextHolder;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @DESCRIPTION
 * @AUTHOR LIAM
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Component
public class ScheduleAppImpl implements ScheduleApp {

    private static final Logger log = LoggerFactory.getLogger(ScheduleAppImpl.class);
    @Autowired
    private PatientService patientService;

    @Autowired
    private MedicalRecordsService medicalRecordsService;

    @Autowired
    private AdminUserInfoService adminUserInfoService;

    @Autowired
    private AdminRoleService adminRoleService;
    @Autowired
    private AdminRoleBindService adminRoleBindService;

    @Autowired
    private ScheduleDetailService scheduleDetailService;

    @Autowired
    private ScheduleDetailPatientBindService scheduleDetailPatientBindService;

    @Autowired
    private OrdersService ordersService;

    @Autowired
    private TreatmentPlanItemService treatmentPlanItemService;

    @Autowired
    private TreatmentPlanService treatmentPlanService;
    @Autowired
    private TreatmentPlanBaseService treatmentPlanBaseService;


    @Autowired
    private ScheduleDomainService scheduleDomainService;

    @Autowired
    private ScheduleService scheduleService;

    @Autowired
    private TaskLogDomainService taskLogDomainService;

    /**
     * 获取医生排班时间
     *
     * @param date
     * @return
     */
    @Override
    public PageVO<ScheduleDateVO> getScheduleTime(Integer pageNum, Integer pageSize, String date, Boolean isHeal) {

        LambdaQueryWrapper<AdminRole> roleWrapper = new LambdaQueryWrapper<AdminRole>().eq(AdminRole::getClinicId, UserSecurityContextHolder.getChannelId()).last("limit 1");
        if (isHeal) {
            roleWrapper.eq(AdminRole::getCode, RoleCodeEnum.HEAL.getKey());
        } else {
            roleWrapper.eq(AdminRole::getCode, RoleCodeEnum.DOCTOR.getKey());
        }

        // 查出对应职业的角色
        AdminRole role = adminRoleService.getOne(roleWrapper);
        // AdminRole role = adminRoleService.getOne(new LambdaQueryWrapper<AdminRole>().eq(AdminRole::getCode, RoleCodeEnum.DOCTOR.getKey()).eq(AdminRole::getClinicId, 1).last("limit 1"));
        List<AdminRoleBind> adminRoleBinds = adminRoleBindService.list(new LambdaQueryWrapper<AdminRoleBind>().eq(AdminRoleBind::getRoleId, role.getId()));
        // 所有医生 id
        List<Integer> doctorIds = adminRoleBinds.stream().map(AdminRoleBind::getAdminId).collect(Collectors.toList());

        // 分页
        Page<AdminUserInfo> userInfoPage = new Page<>(pageNum, pageSize);
        PageVO<ScheduleDateVO> result = PageConvert.INSTANCE.convertPage(userInfoPage);

        // 这里的连表是为了 分页的数据能一致
        userInfoPage = adminUserInfoService.cusPage(userInfoPage, doctorIds, date);
        List<AdminUserInfo> adminUserInfos = userInfoPage.getRecords();
        if (CollectionUtils.isEmpty(adminUserInfos)) {
            return result;
        }

        // 医生的排班信息
        List<Integer> adminIds = adminUserInfos.stream().map(AdminUserInfo::getAdminId).collect(Collectors.toList());
        List<Schedule> scheduleList = scheduleService.list(new LambdaQueryWrapper<Schedule>()
                .eq(Schedule::getScheduleDate, date)
                .in(Schedule::getAdminId, adminIds)
                .eq(Schedule::getDeleted, DeletedStatusEnum.DELETED_NO.getValue())
                .eq(Schedule::getScheduleStatus, ScheduleStatusEnum.WORK.getCode()));
        if (CollectionUtils.isEmpty(scheduleList)) {
            return result;
        }


        LambdaQueryWrapper<ScheduleDetail> queryWrapper = new LambdaQueryWrapper<ScheduleDetail>()
                .in(ScheduleDetail::getAdminId, adminIds)
                .eq(ScheduleDetail::getScheduleDate, date)
                .eq(ScheduleDetail::getDeleted, DeletedStatusEnum.DELETED_NO.getValue())
                .in(ScheduleDetail::getScheduleId, scheduleList.stream().map(Schedule::getId).collect(Collectors.toList()));

        if (!DateUtil.formatStrToDate(date, DateUtil.FORMAT_TYPE_3).after(new Date())) {
            queryWrapper.gt(ScheduleDetail::getEndTime, DateUtil.currentTimeString(DateUtil.FORMAT_TYPE_5));
        }
        List<ScheduleDetail> scheduleDetailList = scheduleDetailService.list(queryWrapper);
        if (CollectionUtils.isEmpty(scheduleDetailList)) {
            return result;
        }
        // 将 ScheduleDetail 按照 adminId 分组
        Map<Integer, List<ScheduleDetail>> scheduleDetailMap = scheduleDetailList.stream() // 过滤掉没有绑定关系的用户
                .collect(Collectors.groupingBy(ScheduleDetail::getAdminId));

        // 排班的预约
        List<Integer> scheduleDetailIds = scheduleDetailList.stream().map(ScheduleDetail::getId).collect(Collectors.toList());
        List<ScheduleDetailPatientBind> bindList = scheduleDetailPatientBindService.list(new LambdaQueryWrapper<ScheduleDetailPatientBind>()
                .in(ScheduleDetailPatientBind::getScheduleDetailId, scheduleDetailIds)
                .eq(ScheduleDetailPatientBind::getDeleted, DeletedStatusEnum.DELETED_NO.getValue())
        );

        Map<Integer, List<ScheduleDetailPatientBind>> bindListMap = new HashMap<>();

        if (CollectionUtils.isNotEmpty(bindList)) {
            // detailId 来分组
            bindListMap = bindList.stream() // 过滤掉没有绑定关系的用户
                    .collect(Collectors.groupingBy(ScheduleDetailPatientBind::getScheduleDetailId));
        }
        // 需要返回的 VO 对象
        List<ScheduleDateVO> voList_back = new ArrayList<>();

        Map<Integer, List<ScheduleDetailPatientBind>> finalBindListMap = bindListMap;
        adminUserInfos.forEach(doc -> {
            ScheduleDateVO scheduleDateVO = new ScheduleDateVO();
            // 基础信息 scheduleDateVO.setScheduleId(0);
            scheduleDateVO.setAdminId(doc.getAdminId());
            scheduleDateVO.setRealName(doc.getRealName());
            scheduleDateVO.setIntroduction(doc.getIntroduction());
            scheduleDateVO.setAvatarUrl(doc.getAvatarUrl());
            // 组装排班
            List<ScheduleDetailTimeVo> detailTimeList = new ArrayList<>();
            List<ScheduleDetail> details = scheduleDetailMap.get(doc.getAdminId());
            if (CollectionUtils.isNotEmpty(details)) {
                details.forEach(detail -> {
                    ScheduleDetailTimeVo detailTimeVo = new ScheduleDetailTimeVo();
                    detailTimeVo.setScheduleDetailId(detail.getId());
                    detailTimeVo.setStartTime(DateUtil.formatDateToString(detail.getStartTime(), DateUtil.FORMAT_TYPE_5));
                    detailTimeVo.setEndTime(DateUtil.formatDateToString(detail.getEndTime(), DateUtil.FORMAT_TYPE_5));
                    detailTimeVo.setRegistrationAmount(doc.getRegistrationAmount());
                    // 当次排班是否满诊
                    detailTimeVo.setIsFullTimeNum(CollectionUtils.isEmpty(finalBindListMap.get(detail.getId())) ? false : finalBindListMap.get(detail.getId()).size() >= doc.getRegistrationCount() ? true : false);
                    detailTimeList.add(detailTimeVo);
                });
                if (CollectionUtils.isNotEmpty(detailTimeList)) {
                    detailTimeList.sort(Comparator.comparing(ScheduleDetailTimeVo::getStartTime));
                }
                scheduleDateVO.setDetailTimeList(detailTimeList);
                // 当天 是否满诊  如果班次里有 false 的 当天没有满诊
                List<ScheduleDetailTimeVo> collect = detailTimeList.stream().filter(c -> !c.getIsFullTimeNum()).collect(Collectors.toList());
                // 根据 开始时间排个序

                scheduleDateVO.setIsFullDateNum(CollectionUtils.isEmpty(collect) ? true : false);
                voList_back.add(scheduleDateVO);
            }
        });

        result = PageConvert.INSTANCE.convertPage(userInfoPage);

        result.setList(voList_back);
        return result;
    }

    /**
     * 预约列表
     *
     * @return
     */
    @Deprecated
    @Override
    public PageVO<ReserveListVO> getReserveList(ReserveQueryDTO params) {

        log.info("获取预约列表:{}", params.getUserId());

        Page<ReserveListVO> page = new Page<ReserveListVO>().setCurrent(params.getPageNum()).setSize(params.getPageSize());
        PageVO<ReserveListVO> pageVO = PageConvert.INSTANCE.convertPage(page);

        // 查出患者编号
        List<Patient> patients = patientService.list(new LambdaQueryWrapper<Patient>()
                .eq(Patient::getUserId, params.getUserId())
                .eq(Patient::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));
        if (CollectionUtils.isEmpty(patients)) {
            return pageVO;
        }
        List<String> patientSns = patients.stream().map(Patient::getPatientSn).collect(Collectors.toList());
        params.setPatientSnList(patientSns);
        List<ReserveListVO> voList = medicalRecordsService.getReserveList(page, params);
        if (CollectionUtils.isEmpty(voList)) {
            return pageVO;
        }

        List<String> orderSns = voList.stream().map(ReserveListVO::getOrderSn).collect(Collectors.toList());

        // 查处置方案
        List<TreatmentPlanItem> treatmentPlanItemList = treatmentPlanItemService.list(new LambdaQueryWrapper<TreatmentPlanItem>()
                .in(TreatmentPlanItem::getZlOrderSn, orderSns)
                .eq(TreatmentPlanItem::getProjectType, PlanItemProjectTypeEnum.THERAPY.getCode())
                .eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue())
        );

        Map<String, TreatmentPlanItem> treatmentPlanItemMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(treatmentPlanItemList)) {
            treatmentPlanItemMap = treatmentPlanItemList.stream().collect(Collectors.toMap(TreatmentPlanItem::getZlOrderSn, o -> o, (o, n) -> o));
        }

        // 排班
        List<Integer> scheduleDetailIds = voList.stream().map(ReserveListVO::getScheduleDetailId).collect(Collectors.toList());
        List<ScheduleDetail> detailList = scheduleDetailService.list(new LambdaQueryWrapper<ScheduleDetail>().in(ScheduleDetail::getId, scheduleDetailIds));
        Map<Integer, ScheduleDetail> scheduleDetailMap = detailList.stream().collect(Collectors.toMap(ScheduleDetail::getId, o -> o, (o, n) -> o));
        // 人员
        List<Integer> adminIds = detailList.stream().map(ScheduleDetail::getAdminId).collect(Collectors.toList());
        adminIds.addAll(voList.stream().map(ReserveListVO::getAdminId).collect(Collectors.toList()));
        List<AdminUserInfo> adminUserInfos = adminUserInfoService.list(new LambdaQueryWrapper<AdminUserInfo>().in(AdminUserInfo::getAdminId, adminIds));
        Map<Integer, AdminUserInfo> adminUserInfoMap = adminUserInfos.stream().collect(Collectors.toMap(AdminUserInfo::getAdminId, o -> o, (o, n) -> o));

        // 被全字段
        Map<String, TreatmentPlanItem> finalTreatmentPlanItemMap = treatmentPlanItemMap;
        voList.forEach(c -> {
            ScheduleDetail scheduleDetail = null;
            if (c.getScheduleDetailId() != null) {
                scheduleDetail = scheduleDetailMap.get(c.getScheduleDetailId());
            }
            // 治疗单 并且 c.getRemainsSessions() == null && c.getProgress() == null 代表没有过诊疗记录，用处置方案里面的
            if (c.getParentOrderSn() != null && c.getRemainsSessions() == null && c.getProgress() == null) {
                TreatmentPlanItem treatmentPlanItem = finalTreatmentPlanItemMap.get(c.getOrderSn());
                c.setTotalSessions(treatmentPlanItem.getTotalSessions());
                c.setProgress(1);
            }
            if (scheduleDetail != null) {
                AdminUserInfo userInfo = adminUserInfoMap.get(scheduleDetail.getAdminId());
                c.setRealName(userInfo == null ? null : userInfo.getRealName());
                c.setScheduleDate(scheduleDetail.getScheduleDate());
                c.setStartTime(scheduleDetail.getStartTime());
                c.setEndTime(scheduleDetail.getEndTime());
            }
            if (c.getTotalSessions() != null && c.getProgress() != null) {
                c.setRemainsSessions(c.getTotalSessions() - c.getProgress());
                System.err.println("剩余次数：" + c.getRemainsSessions());
            }

            if (c.getStatus() != null && !c.getStatus().equals(MedicalRecordStatusEnum.FINISH.getCode()) && c.getRemainsSessions() != null) {
                c.setRemainsSessions(c.getRemainsSessions() + 1);
            }
        });
        pageVO = PageConvert.INSTANCE.convertPage(page);
        pageVO.setList(voList);
        return pageVO;
    }

    /**
     * 我的近期预约
     *
     * @param patientSn
     * @return
     */
    @Deprecated
    @Override
    public RecentReserveVO getRecentReserve(String patientSn) {
        RecentReserveVO reserveVO = new RecentReserveVO();

        List<String> patientSns = Arrays.asList(patientSn);
        // 查出最新订单
        List<Orders> patientLastOrders = ordersService.getPatientLastOrders(patientSns);

        if (CollectionUtils.isEmpty(patientLastOrders)) {
            return null;
        }
        // 有订单
        Orders order = patientLastOrders.get(0);
        log.info("查到的order:{}", JSONObject.toJSONString(order));
        if (!order.getOrderStatus().equals(OrderStatusEnum.IS_PAY.getCode()) || (!order.getBusinessStatus().equals(OrderBusinessStatusEnum.WAIT_CHECK_IN.getCode()))) {
            return null;
        }
        // 时间
        ScheduleDetail scheduleDetail = scheduleDetailService.getOne(new LambdaQueryWrapper<ScheduleDetail>().eq(ScheduleDetail::getId, order.getScheduleDetailId()));
        // 医生
        AdminUserInfo adminUserInfo = adminUserInfoService.getOne(new LambdaQueryWrapper<AdminUserInfo>()
                .eq(AdminUserInfo::getAdminId, scheduleDetail.getAdminId()));
        if (scheduleDetail != null) {
            reserveVO.setRealName(adminUserInfo == null ? null : adminUserInfo.getRealName());
            reserveVO.setScheduleDate(scheduleDetail == null ? null : scheduleDetail.getScheduleDate());
            reserveVO.setStartTime(scheduleDetail == null ? null : scheduleDetail.getStartTime());
            reserveVO.setEndTime(scheduleDetail == null ? null : scheduleDetail.getEndTime());
        }
        reserveVO.setOrderType(order.getOrderType());
        return reserveVO;
    }

    /**
     * 取消预约
     *
     * @param orderSn
     * @return
     */
    @Override
    @Transactional
    public Boolean cancleAppiont(String orderSn) {
        // 查出是什么订单，挂号单，操作订单 现在只有治疗单
        Orders orderOne = ordersService.getOne(new LambdaQueryWrapper<Orders>()
                .eq(Orders::getOrderSn, orderSn)
                .eq(Orders::getOrderType, OrderTypeEnum.THERAPY.getCode())
                .eq(Orders::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));

        if (orderOne == null) {
            throw new ServiceException("订单不存在");
        }

        if (orderOne.getBusinessStatus().equals(OrderBusinessStatusEnum.THERAPY.getCode())) {
            throw new ServiceException("开始治疗后不可取消");
        }

        // 修改订单状态
        ordersService.update(new LambdaUpdateWrapper<Orders>()
                .eq(Orders::getId, orderOne.getId())
                .set(Orders::getBusinessStatus, OrderBusinessStatusEnum.WAIT_BOOK.getCode())
                .set(Orders::getScheduleDetailId, null)
        );

        // 查出排班 id
        Integer scheduleDetailId = orderOne.getScheduleDetailId();
        // 释放排班
        Boolean b = scheduleDomainService.cancleAppiont(scheduleDetailId);
        // 将状态改成已待预约，而不是软删除
        // 查有没有待报到的
        MedicalRecords medicalRecords = medicalRecordsService.getOne(new LambdaQueryWrapper<MedicalRecords>().eq(MedicalRecords::getOrderSn, orderSn).in(MedicalRecords::getStatus,
                Arrays.asList(MedicalRecordStatusEnum.WAIT_CHECK_IN.getCode(), MedicalRecordStatusEnum.WAITING_FOR_CALL.getCode())
        ));
        if (ObjectUtils.isNotEmpty(medicalRecords)) {
            // 改成待预约
            medicalRecords.setStatus(MedicalRecordStatusEnum.WAIT_BOOK.getCode());
            medicalRecords.setModifyTime(new Date());
            medicalRecordsService.updateById(medicalRecords);
        }
        // 任务日志表
        taskLogDomainService.addTaskLogFByOrderSn(orderOne.getOrderSn());
        return true;
    }

    /**
     * 新的获取预约列表
     *
     * @param params
     * @return
     */
    @Override
    public PageVO<ReserveListNewVO> getNewReserveList(ReserveQueryDTO params) {

        Page<Orders> page = new Page<Orders>().setCurrent(params.getPageNum()).setSize(params.getPageSize());
        PageVO<ReserveListNewVO> pageVO = PageConvert.INSTANCE.convertPage(page);

        // 查出患者编号
        List<Patient> patients = patientService.list(new LambdaQueryWrapper<Patient>()
                .eq(Patient::getUserId, params.getUserId())
                .eq(Patient::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));
        if (CollectionUtils.isEmpty(patients)) {
            return pageVO;
        }
        Map<String, Patient> patientMap = patients.stream()
                .collect(Collectors.toMap(Patient::getPatientSn, patient -> patient));

        // 查出订单
        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<Orders>();
        wrapper.ne(Orders::getOrderStatus, OrderStatusEnum.CANCEL.getCode());
        wrapper.ne(Orders::getOrderStatus, OrderStatusEnum.REFUND.getCode());
        wrapper.in(Orders::getPatientSn, patients.stream().map(Patient::getPatientSn).collect(Collectors.toList()));
        wrapper.isNotNull(Orders::getScheduleDetailId);
        // ordersService.page(page, wrapper);
        ordersService.cusPageGetOrdersJoinSchedule(page, wrapper);
        List<Orders> ordersList = page.getRecords();

        if (CollectionUtils.isEmpty(ordersList)) {
            return pageVO;
        }

        // 排班
        List<Integer> scheduleDetailIds = ordersList.stream().map(Orders::getScheduleDetailId).collect(Collectors.toList());
        List<ScheduleDetail> detailList = scheduleDetailService.list(new LambdaQueryWrapper<ScheduleDetail>().in(ScheduleDetail::getId, scheduleDetailIds));
        Map<Integer, ScheduleDetail> scheduleDetailMap = detailList.stream().collect(Collectors.toMap(ScheduleDetail::getId, o -> o, (o, n) -> o));


        // 人员
        List<Integer> adminIds = detailList.stream().map(ScheduleDetail::getAdminId).collect(Collectors.toList());
        List<AdminUserInfo> adminUserInfos = adminUserInfoService.list(new LambdaQueryWrapper<AdminUserInfo>().in(AdminUserInfo::getAdminId, adminIds));
        Map<Integer, AdminUserInfo> adminUserInfoMap = adminUserInfos.stream().collect(Collectors.toMap(AdminUserInfo::getAdminId, o -> o, (o, n) -> o));


        List<ReserveListNewVO> voList = ordersList.stream().map(order -> {
            ReserveListNewVO vo = new ReserveListNewVO();
            Patient patient = patientMap.get(order.getPatientSn());
            vo.setPatientName(ObjectUtils.isNotEmpty(patient) ? patient.getName() : null);
            AdminUserInfo userInfo = adminUserInfoMap.get(order.getAdminId());
            vo.setRealName(ObjectUtils.isNotEmpty(userInfo) ? userInfo.getRealName() : null);
            vo.setOrderType(order.getOrderType());
            vo.setScheduleType(ObjectUtils.isNotEmpty(order.getScheduleType()) ? order.getScheduleType().toString() : null);
            vo.setOrderSn(order.getOrderSn());
            vo.setScheduleDate(ObjectUtils.isNotEmpty(scheduleDetailMap.get(order.getScheduleDetailId())) ? DateUtil.formatDateToString(scheduleDetailMap.get(order.getScheduleDetailId()).getScheduleDate(), DateUtil.FORMAT_TYPE_3) : null);
            vo.setStartTime(ObjectUtils.isNotEmpty(scheduleDetailMap.get(order.getScheduleDetailId())) ? DateUtil.formatDateToString(scheduleDetailMap.get(order.getScheduleDetailId()).getStartTime(), DateUtil.FORMAT_TYPE_5) : null);
            vo.setEndTime(ObjectUtils.isNotEmpty(scheduleDetailMap.get(order.getScheduleDetailId())) ? DateUtil.formatDateToString(scheduleDetailMap.get(order.getScheduleDetailId()).getEndTime(), DateUtil.FORMAT_TYPE_5) : null);
            vo.setStatus(order.getOrderStatus() > 0 ? order.getBusinessStatus() : order.getOrderStatus());
            if (order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode())) {
                vo.setScheduleName("医生面诊");
            } else if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode())) {
                if (ObjectUtils.isNotEmpty(order.getScheduleType()) && order.getScheduleType().equals(OrserScheduleTypeEnum.PLAN.getCode())) {
                    //
                    TreatmentPlan treatmentPlan = treatmentPlanService.getOne(new LambdaQueryWrapper<TreatmentPlan>().eq(TreatmentPlan::getZlOrderSn, order.getOrderSn()).eq(TreatmentPlan::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                    if (ObjectUtils.isNotEmpty(treatmentPlan)) {
                        TreatmentPlanBase base = treatmentPlanBaseService.getOne(new LambdaQueryWrapper<TreatmentPlanBase>().eq(TreatmentPlanBase::getPlanSn, treatmentPlan.getPlanSn()).eq(TreatmentPlanBase::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                        vo.setScheduleName("治疗方案 " + base.getPlanSn() + " 第" + treatmentPlan.getSortNum() + "次");
                    }
                }
                if (ObjectUtils.isNotEmpty(order.getScheduleType()) && order.getScheduleType().equals(OrserScheduleTypeEnum.PROJECT.getCode())) {
                    TreatmentPlanItem treatmentPlanItem = treatmentPlanItemService.getOne(new LambdaQueryWrapper<TreatmentPlanItem>().eq(TreatmentPlanItem::getZlOrderSn, order.getOrderSn()).eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                    vo.setScheduleName(ObjectUtils.isNotEmpty(treatmentPlanItem) ? treatmentPlanItem.getItemName() : "");
                }
            }

            return vo;
        }).collect(Collectors.toList());


        // 根据 开始时间排个序
        // voList.sort(Comparator.comparing(ReserveListNewVO::getScheduleDate).reversed());
        pageVO = PageConvert.INSTANCE.convertPage(page);
        pageVO.setList(voList);

        return pageVO;
    }
}
