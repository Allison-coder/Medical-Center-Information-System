package com.params.application.order.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.params.application.order.OrderConverter;
import com.params.application.patient.PatientApp;
import com.params.constant.MedicalRecordStatusEnum;
import com.params.constant.OrderStatusEnum;
import com.params.constant.OrderTypeEnum;
import com.params.constant.OrserScheduleTypeEnum;
import com.params.domain.coupon.CouponDomainService;
import com.params.domain.order.OrderDomainService;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.entity.AdminUserInfo;
import com.params.entity.Coupon;
import com.params.entity.MedicalRecords;
import com.params.entity.Orders;
import com.params.entity.Patient;
import com.params.entity.ScheduleDetail;
import com.params.entity.TreatmentPlan;
import com.params.entity.TreatmentPlanBase;
import com.params.entity.TreatmentPlanItem;
import com.params.framework.constant.DeletedStatusEnum;
import com.params.pojo.bo.BindOrderAndCouponBO;
import com.params.pojo.dto.GetUserCouponsToGHOrderDTO;
import com.params.pojo.vo.AppointmentVO;
import com.params.pojo.vo.MedicalRecordStrageVO;
import com.params.pojo.vo.MedicalRecordVO;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.PatientBaseInfoVO;
import com.params.pojo.vo.PayInformationVO;
import com.params.pojo.vo.PlanProjectConfigVO;
import com.params.pojo.vo.RefundInformationVO;
import com.params.pojo.vo.TreatmentItemVO;
import com.params.pojo.vo.TreatmentVO;
import com.params.pojo.vo.UserCouponsVO;
import com.params.pojo.vo.WorkerVO;
import com.params.service.AdminUserInfoService;
import com.params.service.MedicalRecordsService;
import com.params.service.OrdersService;
import com.params.service.PatientService;
import com.params.service.ScheduleDetailService;
import com.params.service.TreatmentPlanBaseService;
import com.params.service.TreatmentPlanItemService;
import com.params.service.TreatmentPlanService;
import com.params.utils.DateUtil;
import com.params.utils.UserSecurityContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class OrderConverterImpl implements OrderConverter {

    @Autowired
    private AdminUserInfoService adminUserInfoService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private ScheduleDetailService scheduleDetailService;

    @Autowired
    private TreatmentPlanService treatmentPlanService;

    @Autowired
    private TreatmentPlanItemService treatmentPlanItemService;

    @Autowired
    private MedicalRecordsService medicalRecordsService;

    @Autowired
    private CouponDomainService couponDomainService;

    @Autowired
    private TreatmentPlanDomainService planProjectDomainService;

    @Autowired
    private PatientApp patientApp;

    @Autowired
    private OrderDomainService orderDomainService;


    @Autowired
    private OrdersService ordersService;

    @Autowired
    private TreatmentPlanBaseService treatmentPlanBaseService;


    @Override
    public OrderVO convertOrder(Orders orders) {
        return null;
    }

    @Override
    public List<OrderVO> convertOrderFormat(List<Orders> orders, Integer channelId, Boolean isList) {
        List<OrderVO> result = new ArrayList<>();
        if (orders == null || orders.size() <= 0) {
            return result;
        }
        List<String> orderSnsList = orders.stream().map(Orders::getOrderSn).collect(Collectors.toList());
        Map<String, List<Coupon>> couponMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(orderSnsList)) {
            // 取有绑定的优惠券
            List<Coupon> userCouponsByOrderSns = couponDomainService.getUserCouponsByOrderSns(orderSnsList);
            if (CollectionUtils.isNotEmpty(userCouponsByOrderSns)) {
                couponMap = userCouponsByOrderSns.stream().collect(Collectors.groupingBy(Coupon::getOrderSn));
            }
        }

        // 工作人员
        List<Integer> doctorAdminIds = orders.stream().map(Orders::getAdminId).distinct().collect(Collectors.toList());
        orders.stream().map(o -> {
            if (o.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode())) {
                return o.getAdminId();
            } else {
                return o.getCreateAdminId();
            }
        }).distinct().collect(Collectors.toList());


        List<Integer> creatZlAdminIds = orders.stream().map(Orders::getCreateAdminId).distinct().collect(Collectors.toList());
        doctorAdminIds.addAll(creatZlAdminIds);
        System.out.println("工作人员：" + doctorAdminIds);
        List<AdminUserInfo> doctors = adminUserInfoService.getInfoByAdminIdsInclueDeleted(doctorAdminIds, channelId);
        System.out.println("工作人员：" + doctors);
        Map<Integer, AdminUserInfo> doctorMap = doctors.stream().collect(Collectors.toMap(AdminUserInfo::getAdminId, o -> o, (o, n) -> o));
        // 患者列表
        List<String> patientSns = orders.stream().map(Orders::getPatientSn).distinct().collect(Collectors.toList());
        System.out.println("患者列表：" + patientSns);
        List<Patient> patients = patientService.getPatientsByPatientSns(patientSns, channelId);
        System.out.println("患者列表：" + patients);
        Map<String, Patient> patientMap = patients.stream().collect(Collectors.toMap(Patient::getPatientSn, o -> o, (o, n) -> o));
        // 排班时间，治疗单可能缺少排班时间（未预约的情况下）
        Set<Integer> scheduleDetailIds = orders.stream().map(Orders::getScheduleDetailId).filter(x -> Objects.nonNull(x)).collect(Collectors.toSet());
        System.out.println("排班时间：" + scheduleDetailIds);
        Map<Integer, ScheduleDetail> scheduleDetailMap = new HashMap<>();
        if (Objects.nonNull(scheduleDetailIds) && scheduleDetailIds.size() > 0) {
            List<ScheduleDetail> scheduleDetails = scheduleDetailService.getScheduleDetailByIds(scheduleDetailIds, channelId);
            scheduleDetailMap = scheduleDetails.stream().collect(Collectors.toMap(ScheduleDetail::getId, o -> o, (o, n) -> o));
        }
        /**
         * 原：查询处置方案，需要考虑治疗单的情况，治疗单的处置方案需要通过父级订单号获取
         * 后：2024-06-17 处置和治疗单 1v1 表里添加了治疗单字段，不需要再查父级订单号
         */
        // Set<String> parentOrderSns = orders.stream().filter(x -> StrUtil.isNotBlank(x.getParentOrderSn())).map(Orders::getParentOrderSn).collect(Collectors.toSet());
        Set<String> orderSns = orders.stream().map(Orders::getOrderSn).collect(Collectors.toSet());
        // orderSns.addAll(parentOrderSns);
        System.out.println("订单号：" + orderSns);
        List<TreatmentPlan> treatmentPlans = treatmentPlanService.getTreatmentPlansByOrderSns(orderSns, channelId);
        // 方案id，方案信息 key 改成了 zlOrderSn
        Map<String, TreatmentPlan> treatmentPlanMap = treatmentPlans.stream().collect(Collectors.toMap(TreatmentPlan::getZlOrderSn, o -> o, (o, n) -> o));
        // 通过方案id，查询项目id，获取具体项目
        List<Integer> treatmentPlanIds = treatmentPlans.stream().map(TreatmentPlan::getId).distinct().collect(Collectors.toList());
        System.out.println("方案id：" + treatmentPlanIds);
        Map<Integer, ArrayList<TreatmentPlanItem>> TreatmentPlanItemMap = new HashMap<>();
        if (treatmentPlanIds != null && treatmentPlanIds.size() > 0) {
            List<TreatmentPlanItem> treatmentPlanItems = treatmentPlanItemService.getItemsByPlanIds(treatmentPlanIds, channelId);
            TreatmentPlanItemMap = treatmentPlanItems.stream().collect(Collectors.toMap(TreatmentPlanItem::getPlanId, e -> {
                ArrayList<TreatmentPlanItem> res = new ArrayList<>();
                res.add(e);
                return res;
            }, (o, n) -> {
                o.addAll(n);
                return o;
            }));
        }

        // 诊疗记录的进度情况，通过订单号查询诊疗记录 orderSns
        List<MedicalRecords> medicalRecords = medicalRecordsService.getRecordsByOrderSns(orderSns, channelId);
        Map<String, ArrayList<MedicalRecords>> medicalRecordMap = medicalRecords.stream().collect(Collectors.toMap(MedicalRecords::getOrderSn, e -> {
            ArrayList<MedicalRecords> res = new ArrayList<>();
            res.add(e);
            return res;
        }, (o, n) -> {
            o.addAll(n);
            return o;
        }));


        // 取出所有项目
        List<PlanProjectConfigVO> vos = planProjectDomainService.getPlanProjectConfig(null);
        Map<Integer, PlanProjectConfigVO> projectConfigVOMap = vos.stream()
                .collect(Collectors.toMap(PlanProjectConfigVO::getId, pro -> pro));


        for (Orders order : orders) {
            OrderVO orderVO = getInitOrderVO(order);
            orderVO.setAdvice(order.getAdvice());

            // 付款信息
            PayInformationVO payInformation = new PayInformationVO();
            payInformation.setOrderAmount(order.getOrderAmount());
            payInformation.setPayTime(order.getPayTime());
            payInformation.setSourceAmount(order.getSourceAmount());
            orderVO.setPayInformationVO(payInformation);

            // 退款信息
            RefundInformationVO refundInformation = new RefundInformationVO();
            refundInformation.setRefundFee(order.getRefundFee());
            refundInformation.setRefundTime(order.getRefundTime());
            orderVO.setRefundInformationVO(refundInformation);

            List<Coupon> couponList = couponMap.get(order.getOrderSn());
            List<UserCouponsVO> couponDetils = new ArrayList<>();
            // 客户端的挂号单和管理后台用的；治疗单客户端返回的数据在治疗方案里
            if (CollectionUtils.isNotEmpty(couponList)) {
                couponDetils = couponList.stream().map(coupon -> {
                    UserCouponsVO couponsVO = new UserCouponsVO();
                    couponsVO.setCouponCode(coupon.getCouponCode());
                    couponsVO.setCouponType(coupon.getCouponType());
                    couponsVO.setCouponTypeName(coupon.getCouponTypeName());
                    couponsVO.setCouponName(coupon.getTemplateName());
                    couponsVO.setCouponParValue(ObjectUtils.isEmpty(coupon.getCouponParValue()) ? "0" : coupon.getCouponParValue().toString());
                    couponsVO.setDiscount(coupon.getDiscount());
                    couponsVO.setExchangeOrder(coupon.getExchangeOrder());
                    couponsVO.setThresholdNo(coupon.getThresholdNo());
                    couponsVO.setOrderUseAmount(ObjectUtils.isEmpty(coupon.getOrderUseAmount()) ? "0" : coupon.getOrderUseAmount().toString());
                    couponsVO.setForeverStatus(coupon.getForeverStatus());
                    List<Integer> integerList = new ArrayList<>();
                    if (StringUtils.isNotBlank(coupon.getAvailableProject())) {
                        integerList = Arrays.stream(coupon.getAvailableProject().split(","))
                                .map(Integer::valueOf)
                                .collect(Collectors.toList());
                    }
                    couponsVO.setAvailableProject(integerList);
                    couponsVO.setUseStatus(2);
                    couponsVO.setExpireDate(DateUtil.formatDateToString(coupon.getExpireDate(), DateUtil.FORMAT_TYPE_1));
                    couponsVO.setInstructions(coupon.getInstructions());
                    return couponsVO;
                }).collect(Collectors.toList());
            } else {

                // 如果没有优惠券，并且没有改过价的 ，则自动绑定可用优惠券
                if (!isList && order.getOrderAmount().compareTo(order.getSourceAmount()) == 0) {
                    GetUserCouponsToGHOrderDTO dto = new GetUserCouponsToGHOrderDTO();
                    dto.setOrderType(OrderTypeEnum.DIAGNOSIS.getType());
                    dto.setSourceAmount(order.getSourceAmount());
                    dto.setUserId(UserSecurityContextHolder.getUserId());
                    List<UserCouponsVO> userCouponsToGHOrder = patientApp.getUserCouponsToGHOrder(dto);
                    if (CollectionUtils.isNotEmpty(userCouponsToGHOrder)) {
                        // 取出第一个
                        UserCouponsVO couponsVO = userCouponsToGHOrder.get(0);
                        couponDetils.add(couponsVO);
                        // 并绑定给订单
                        BindOrderAndCouponBO bo = new BindOrderAndCouponBO();
                        bo.setIsUseCoupon(true);
                        bo.setCouponCode(couponsVO.getCouponCode());
                        bo.setOrderSn(order.getOrderSn());
                        if (order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode()) || order.getOrderStatus().equals(OrderStatusEnum.WAITING_PAY.getCode())) {
                            try {
                                orderDomainService.bindOrderAndCoupon(bo, UserSecurityContextHolder.getChannelId());
                            } catch (Exception e) {
                                log.info("绑定优惠券异常，订单号：{}，优惠券code：{}", order.getOrderSn(), couponsVO.getCouponCode());
                            }
                        }
                    }
                }
            }

            // 补充优惠券信息
            orderVO.setCouponDetailList(couponDetils);


            // 不可调价
            orderVO.setCanAdjustAmount(false);
            // 不可以使用优惠券
            orderVO.setCanUseCoupon(false);

            // 设置是否可以退款
            if (CollectionUtils.isNotEmpty(couponDetils)) {
                if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode())) {
                    // 使用了优惠券，不可退款
                    orderVO.setIsUseCoupon(true);
                }
                // 使用了优惠券，不可以调价，但可以继续使用优惠券
                orderVO.setCanUseCoupon(true);
            } else {
                // 没有用优惠券
                // 那么可以使用优惠券
                orderVO.setCanAdjustAmount(true);
                // 且原价和支付价相等，代表没有调价过,可以调价也可以使用优惠券
                if (order.getOrderAmount().compareTo(order.getSourceAmount()) == 0) {
                    orderVO.setCanUseCoupon(true);
                }
            }

            // 如果创单时，就已经是0钱，那么不可使用优惠券和调价
            if (order.getSourceAmount().compareTo(BigDecimal.ZERO) == 0) {
                // 不可调价
                orderVO.setCanAdjustAmount(false);
                // 不可以使用优惠券
                orderVO.setCanUseCoupon(false);
            }


            if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode()) && ObjectUtils.isNotEmpty(order.getScheduleType()) && order.getScheduleType().equals(OrserScheduleTypeEnum.PLAN.getCode())) {
                // 治疗单 并具是方案单的   由项目控制
                orderVO.setCanAdjustAmount(true);
                // 不可以使用优惠券
                orderVO.setCanUseCoupon(true);
            }


            // 补充患者信息
            String patientSn = order.getPatientSn();
            Patient patient = patientMap.get(patientSn);
            if (patient != null) {
                orderVO.setPatientBaseInfoVO(convertPatientVO(patient));
            }

            // 补充账号信息
            // 如果是治疗单，取 create_admin_id
            orderVO.setWorkerVO(convertWorkerVO(order.getOrderType() == OrderTypeEnum.THERAPY.getCode() ? doctorMap.get(order.getCreateAdminId()) : doctorMap.get(order.getAdminId())));

            // 补充预约信息,治疗单不会有预约信息，不在此处存储，且治疗单关注的是诊疗进度
            Integer scheduleDetailId = order.getScheduleDetailId();
            if (scheduleDetailId != null) {
                orderVO.setAppointmentVO(convertAppointmentVO(scheduleDetailMap.get(order.getScheduleDetailId())));
            }
            TreatmentPlan treatmentPlan = treatmentPlanMap.get(order.getOrderSn());
            /**
             * 原：处置方案,挂号单使用订单号；治疗单使用父级订单号
             * 后：2024-06-17 处置和治疗单 1v1 表里添加了治疗单字段，不需要再查父级订单号
             */
            // if (Integer.valueOf(2).equals(order.getOrderType())) {
            //     treatmentPlan = treatmentPlanMap.get(order.getParentOrderSn());
            // }
            if (treatmentPlan != null) {
                // 防止 NEP 异常
                if (CollectionUtils.isEmpty(couponList)) {
                    couponList = new ArrayList<>();
                }
                // 设置治疗方案
                orderVO.setTreatmentVO(convertTreatmentVO(treatmentPlan, TreatmentPlanItemMap.get(treatmentPlan.getId()), couponList, projectConfigVOMap, order, isList));

                // TODO 如果订单是治疗单，那么这里需要设置治疗项目
                // orderVO.setVisitProject(order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode()) ? OrderTaskTypeEnum.DOCTOR_DIAGNOSIS.getValue() : treatmentPlan.getPlanSn());

                if (order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode())) {
                    orderVO.setVisitProject("医生面诊");
                } else if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode())) {
                    if (ObjectUtils.isNotEmpty(order.getScheduleType()) && order.getScheduleType().equals(OrserScheduleTypeEnum.PLAN.getCode())) {
                        if (ObjectUtils.isNotEmpty(treatmentPlan)) {
                            orderVO.setSortNum(treatmentPlan.getSortNum());
                            TreatmentPlanBase base = treatmentPlanBaseService.getOne(new LambdaQueryWrapper<TreatmentPlanBase>().eq(TreatmentPlanBase::getPlanSn, treatmentPlan.getPlanSn()).eq(TreatmentPlanBase::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                            orderVO.setVisitProject("治疗方案 " + base.getPlanSn() + " 第" + treatmentPlan.getSortNum() + "次");
                            orderVO.setAdvice(base.getAdvice());
                            orderVO.setPlanSn(base.getPlanSn());
                        }
                    }
                    if (ObjectUtils.isNotEmpty(order.getScheduleType()) && order.getScheduleType().equals(OrserScheduleTypeEnum.PROJECT.getCode())) {
                        TreatmentPlanItem treatmentPlanItem = treatmentPlanItemService.getOne(new LambdaQueryWrapper<TreatmentPlanItem>().eq(TreatmentPlanItem::getZlOrderSn, order.getOrderSn()).eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()).last("limit 1"));
                        orderVO.setVisitProject(ObjectUtils.isNotEmpty(treatmentPlanItem) ? treatmentPlanItem.getItemName() : "");
                    }
                }
            }
            // 诊疗记录
            orderVO.setMedicalRecordStrageVO(convertMedicalRecordStrageVO(medicalRecordMap.get(order.getOrderSn())));


            if (!isList) {
                Orders newOrder = ordersService.getById(order.getId());
                // 重新设一下价格， 恶心的优惠券默认
                orderVO.setOrderAmount(newOrder.getOrderAmount());
            }
            result.add(orderVO);
        }
        return result;
    }

    private OrderVO getInitOrderVO(Orders order) {
        OrderVO build = OrderVO.builder()
                .id(order.getId())
                .orderSn(order.getOrderSn())
                .orderType(order.getOrderType())
                .orderAmount(order.getOrderAmount())
                .sourceAmount(order.getSourceAmount())
                .orderStatus(order.getOrderStatus())
                .businessStatus(order.getBusinessStatus())
                .createTime(order.getCreateTime())
                .scheduleType(ObjectUtils.isNotEmpty(order.getScheduleType()) ? order.getScheduleType().toString() : null)
                .clinicId(order.getClinicId())
                .build();
        return build;
    }

    private PatientBaseInfoVO convertPatientVO(Patient patient) {
        return PatientBaseInfoVO.builder()
                .patientSn(patient.getPatientSn())
                .name(patient.getName())
                .phoneNumber(patient.getPhoneNumber())
                .build();
    }

    private WorkerVO convertWorkerVO(AdminUserInfo userInfo) {
        if (userInfo == null) {
            return null;
        }
        return WorkerVO.builder()
                .adminId(userInfo.getAdminId())
                .name(userInfo.getRealName())
                .url(userInfo.getAvatarUrl())
                .build();
    }

    private AppointmentVO convertAppointmentVO(ScheduleDetail scheduleDetail) {
        if (scheduleDetail == null) {
            return null;
        }
        Integer adminId = scheduleDetail.getAdminId();
        AdminUserInfo userInfo = adminUserInfoService.getOne(new LambdaQueryWrapper<AdminUserInfo>().eq(AdminUserInfo::getAdminId, adminId));

        return AppointmentVO.builder()
                .scheduleDate(DateUtil.formatDateToString(scheduleDetail.getScheduleDate(), DateUtil.FORMAT_TYPE_3))
                .startTime(DateUtil.formatDateToString(scheduleDetail.getStartTime(), DateUtil.FORMAT_TYPE_5))
                .endTime(DateUtil.formatDateToString(scheduleDetail.getEndTime(), DateUtil.FORMAT_TYPE_5))
                .week(DateUtil.convertWeekName2(scheduleDetail.getScheduleDate()))
                .name(ObjectUtils.isNotEmpty(userInfo) ? userInfo.getRealName() : null)
                .build();
    }

    private TreatmentVO convertTreatmentVO(TreatmentPlan plan, List<TreatmentPlanItem> items, List<Coupon> couponList, Map<Integer, PlanProjectConfigVO> projectConfigVOMap, Orders order, Boolean isList) {
        if (plan == null) {
            return null;
        }
        // 子项
        List<TreatmentItemVO> itemVOS = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(items)) {

            for (TreatmentPlanItem item : items) {

                Coupon coupon = couponList.stream()
                        .filter(c -> ObjectUtils.isNotEmpty(c.getOrderUseProjectId()) && c.getOrderUseProjectId().equals(item.getId()))
                        .findFirst().orElse(null);

                TreatmentItemVO treatmentItemVO = convertTreatmentItemVO(item, coupon, projectConfigVOMap, order, isList);
                itemVOS.add(treatmentItemVO);
            }
            TreatmentVO build = TreatmentVO.builder()
                    .id(plan.getId())
                    .advice(plan.getAdvice())
                    .treatmentItemVOS(itemVOS)
                    .build();
            return build;
        }
        return null;
    }

    private TreatmentItemVO convertTreatmentItemVO(TreatmentPlanItem item, Coupon coupon, Map<Integer, PlanProjectConfigVO> projectConfigVOMap, Orders order, Boolean isList) {
        if (item == null) {
            return null;
        }

        TreatmentItemVO build = TreatmentItemVO.builder()
                .id(item.getId())
                .itemId(item.getItemId())
                .projectType(item.getProjectType())
                .itemName(item.getItemName())
                .priceHour(ObjectUtils.isNotEmpty(item.getUnitPrice()) ? item.getUnitPrice().toString() : "")
                .unitPrice(ObjectUtils.isNotEmpty(item.getUnitPrice()) ? item.getUnitPrice().toString() : "")
                .totalPrice(item.getTotalPrice())
                .totalSessions(item.getTotalSessions())
                .sourceAmount(item.getSourceAmount())
                .frequency(item.getFrequency())
                .frequencyNum(item.getFrequencyNum())
                .durationPerSession(item.getDurationPerSession())
                .description(item.getDescription())
                .build();


        build.setCanAdjustAmount(true);
        build.setCanUseCoupon(true);

        if (ObjectUtils.isNotEmpty(item.getPreferentialPrice())) {
            build.setPriceHour(ObjectUtils.isNotEmpty(item.getPreferentialPrice()) ? item.getPreferentialPrice().toString() : "");
            build.setUnitPrice(ObjectUtils.isNotEmpty(item.getPreferentialPrice()) ? item.getPreferentialPrice().toString() : "");

        }

        UserCouponsVO couponsVO = null;
        if (coupon != null) {
            couponsVO = new UserCouponsVO();
            couponsVO.setExpireDate(DateUtil.formatDateToString(coupon.getExpireDate(), DateUtil.FORMAT_TYPE_1));
            couponsVO.setCouponCode(coupon.getCouponCode());
            couponsVO.setCouponType(coupon.getCouponType());
            couponsVO.setCouponTypeName(coupon.getCouponTypeName());
            couponsVO.setCouponName(coupon.getTemplateName());
            couponsVO.setCouponParValue(ObjectUtils.isEmpty(coupon.getCouponParValue()) ? "0" : coupon.getCouponParValue().toString());
            couponsVO.setDiscount(coupon.getDiscount());
            couponsVO.setExchangeOrder(coupon.getExchangeOrder());
            couponsVO.setThresholdNo(coupon.getThresholdNo());
            couponsVO.setOrderUseAmount(ObjectUtils.isEmpty(coupon.getOrderUseAmount()) ? "0" : coupon.getOrderUseAmount().toString());
            couponsVO.setForeverStatus(coupon.getForeverStatus());
            List<Integer> integerList = new ArrayList<>();
            if (StringUtils.isNotBlank(coupon.getAvailableProject())) {
                integerList = Arrays.stream(coupon.getAvailableProject().split(","))
                        .map(Integer::valueOf)
                        .collect(Collectors.toList());
            }
            couponsVO.setAvailableProject(integerList);

            List<PlanProjectConfigVO> projectConfigVOS = new ArrayList<>();
            if (StringUtils.isNotBlank(coupon.getTreatmentProjectIds())) {
                List<Integer> projectIds = Arrays.stream(coupon.getTreatmentProjectIds().split(","))
                        .map(Integer::valueOf)
                        .collect(Collectors.toList());
                if (projectIds.size() == 1 && projectIds.get(0) == 0) {
                    PlanProjectConfigVO projectConfigVO = new PlanProjectConfigVO();
                    projectConfigVO.setId(0);
                    projectConfigVO.setProjectName("全部项目");
                    projectConfigVO.setProjectType(0);
                    projectConfigVOS.add(projectConfigVO);
                } else {
                    projectConfigVOS = projectIds.stream().map(pro -> projectConfigVOMap.get(pro)).collect(Collectors.toList());
                }
            }
            couponsVO.setProjectDetails(projectConfigVOS);
            couponsVO.setUseStatus(2);
            couponsVO.setInstructions(coupon.getInstructions());

            // 用了优惠券的，不可改价
            build.setCanAdjustAmount(false);

        } else {
            // 如果是空的 并且没有调过价
            if (order.getOrderAmount().compareTo(order.getSourceAmount()) == 0 && !isList && item.getSourceAmount().compareTo(BigDecimal.ZERO) != 0 && order.getOrderStatus().equals(OrderStatusEnum.WAITING_PAY.getCode())) {

                List<UserCouponsVO> userCouponsToOrder = patientApp.getUserCouponsToOrder(item.getZlOrderSn(), item.getId(), UserSecurityContextHolder.getUserId());
                if (CollectionUtils.isNotEmpty(userCouponsToOrder)) {
                    // 取第一个
                    couponsVO = userCouponsToOrder.get(0);
                    // 绑定
                    BindOrderAndCouponBO bo = new BindOrderAndCouponBO();
                    bo.setIsUseCoupon(true);
                    bo.setCouponCode(couponsVO.getCouponCode());
                    bo.setOrderSn(order.getOrderSn());
                    bo.setProjectId(item.getId());
                    try {
                        orderDomainService.bindOrderAndCoupon(bo, UserSecurityContextHolder.getChannelId());
                    } catch (Exception e) {
                        couponsVO = null;
                        log.info("绑定优惠券失败:{}", e.getMessage());
                    }
                }
            }
        }

        // 如果是0元 不可调价，不可调优惠券
        if (item.getSourceAmount().compareTo(BigDecimal.ZERO) == 0) {
            build.setCanAdjustAmount(false);
            build.setCanUseCoupon(false);
        }

        if (item.getTotalPrice().compareTo(item.getSourceAmount()) != 0) {
            build.setCanUseCoupon(false);
        }

        build.setCouponsVO(couponsVO);
        return build;
    }

    private MedicalRecordStrageVO convertMedicalRecordStrageVO(List<MedicalRecords> records) {
        if (records == null || records.size() <= 0) {
            return null;
        }
        Integer totalSessions = records.get(0).getTotalSessions();
        long count = records.stream().filter(x -> MedicalRecordStatusEnum.FINISH.getCode().equals(x.getStatus())).count();

        List<MedicalRecords> medicalRecords = records.stream().sorted(Comparator.comparingInt(MedicalRecords::getProgress)).collect(Collectors.toList());
        List<MedicalRecordVO> recordVOS = new ArrayList<>();
        for (MedicalRecords record : medicalRecords) {
            MedicalRecordVO medicalRecordVO = convertMedicalRecordVO(record);
            recordVOS.add(medicalRecordVO);
        }
        return MedicalRecordStrageVO.builder()
                .total(totalSessions)
                .completed(Integer.valueOf(String.valueOf(count)))
                .MedicalRecordVOS(recordVOS)
                .build();
    }

    private MedicalRecordVO convertMedicalRecordVO(MedicalRecords record) {
        return MedicalRecordVO.builder()
                .id(record.getId())
                .patientSn(record.getPatientSn())
                .orderSn(record.getOrderSn())
                .scheduleDetailId(record.getScheduleDetailId())
                .completionTime(record.getCompletionTime())
                .adminId(record.getAdminId())
                .medicalType(record.getMedicalType())
                .progress(record.getProgress())
                .totalSessions(record.getTotalSessions())
                .status(record.getStatus())
                .adminNotes(record.getAdminNotes())
                .medicalStaffNotes(record.getMedicalStaffNotes())
                .createTime(record.getCreateTime())
                .build();
    }
}
