package com.params.application.order.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.ErrorCodeEnum;
import com.params.application.order.OrderApp;
import com.params.application.order.OrderConverter;
import com.params.constant.OrderBusinessStatusEnum;
import com.params.constant.OrderStatusEnum;
import com.params.constant.OrderTaskTypeEnum;
import com.params.constant.OrderTypeEnum;
import com.params.constant.ValidateUtil;
import com.params.convert.PageConvert;
import com.params.domain.adminuser.AdminUserDomainService;
import com.params.domain.order.OrderDomainService;
import com.params.domain.patient.PatientDomainService;
import com.params.domain.schedule.ScheduleDomainService;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.entity.AdminUserInfo;
import com.params.entity.Orders;
import com.params.entity.OrdersInterviewRecords;
import com.params.entity.Patient;
import com.params.entity.ScheduleDetail;
import com.params.entity.ScheduleDetailPatientBind;
import com.params.entity.TreatmentPlan;
import com.params.entity.TreatmentPlanItem;
import com.params.framework.constant.DeletedStatusEnum;
import com.params.framework.exception.ServiceException;
import com.params.pojo.bo.ConfirmAppointmentBO;
import com.params.pojo.bo.GetMergeOrderListBO;
import com.params.pojo.bo.PageOrdersConditionBO;
import com.params.pojo.dto.AddNewTreatmentDTO;
import com.params.pojo.dto.PatientTasksDTO;
import com.params.pojo.dto.QueryOrderDTO;
import com.params.pojo.vo.AdminUserVO;
import com.params.pojo.vo.AppointmentVO;
import com.params.pojo.vo.InterviewRecordsVO;
import com.params.pojo.vo.MergePayOrderVO;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.PatientAdminVO;
import com.params.pojo.vo.PatientBaseInfoVO;
import com.params.pojo.vo.PatientTaskVO;
import com.params.pojo.vo.TreatmentOrderVO;
import com.params.pojo.vo.common.PageVO;
import com.params.service.AdminUserInfoService;
import com.params.service.OrdersService;
import com.params.service.ScheduleDetailPatientBindService;
import com.params.service.ScheduleDetailService;
import com.params.service.TreatmentPlanItemService;
import com.params.service.TreatmentPlanService;
import com.params.utils.DateUtil;
import com.params.utils.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@Slf4j
public class OrderAppImpl implements OrderApp {

    @Autowired
    private OrderConverter orderConverter;

    @Autowired
    private OrdersService ordersService;


    @Autowired
    private PatientDomainService patientDomainService;

    @Autowired
    private ScheduleDomainService scheduleDomainService;

    @Autowired
    private OrderDomainService orderDomainService;

    @Autowired
    private AdminUserDomainService adminUserDomainService;

    @Autowired
    private TreatmentPlanDomainService treatmentPlanDomainService;

    @Autowired
    private ScheduleDetailService scheduleDetailService;

    @Autowired
    private ScheduleDetailPatientBindService scheduleDetailPatientBindService;

    @Autowired
    private AdminUserInfoService adminUserInfoService;

    @Autowired
    private TreatmentPlanService treatmentPlanService;
    @Autowired
    private TreatmentPlanItemService treatmentPlanItemService;


    @Override
    public PageVO<OrderVO> getOrders(QueryOrderDTO dto) {
        // 根据条件查询订单：支付状态、排序字段、订单号、患者姓名(获取患者id，可以是列表)
        ValidateUtil.isTrue(Objects.isNull(dto.getChannelId()), "诊所id不能为空");
        // 查询订单，根据返回订单类型，转换不同的VO
        Page<Orders> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        IPage<Orders> list = ordersService.getOrders(page, dto);
        List<OrderVO> orderVOS = orderConverter.convertOrderFormat(list.getRecords(), dto.getChannelId(), true);
        PageVO<OrderVO> result = PageConvert.INSTANCE.convertPage(list);
        result.setList(orderVOS);
        return result;
    }

    @Override
    public List<OrderVO> getUnfinishedOrders(Integer userId, Integer channelId) {
        ValidateUtil.isTrue(Objects.isNull(userId), "用户id不能为空");
        ValidateUtil.isTrue(Objects.isNull(channelId), "诊所id不能为空");
        // 查询订单，根据返回订单类型，转换不同的VO
        List<OrderVO> orderVOS = new ArrayList<>();
        // TODO 根据userId 查出患者 现在只有一个 后续多患者时，外层的接口要改
        List<Patient> patientList = patientDomainService.getPatientByUserId(userId);
        if (CollectionUtils.isNotEmpty(patientList)) {
            Patient patient = patientList.get(0);
            List<Orders> list = ordersService.unFinishOrdersForPatient(patient.getPatientSn());
            orderVOS = orderConverter.convertOrderFormat(list, channelId, true);
        }
        return orderVOS;
    }

    @Override
    public OrderVO getOrderByOrderSn(String orderSn, Integer channelId) {
        Orders order = ordersService.getOrderByOrderSn(orderSn, channelId);
        ValidateUtil.isTrue(Objects.isNull(order), ErrorCodeEnum.ORDER_IS_NOT_FIND_ERR);

        List<OrderVO> orderVOS = orderConverter.convertOrderFormat(Arrays.asList(order), channelId, false);
        if (orderVOS != null && orderVOS.size() > 0) {
            return orderVOS.get(0);
        }
        return null;
    }

    /**
     * 查治疗师的订单
     *
     * @param dto
     * @return
     */
    @Override
    public PageVO<OrderVO> getZlOrders(QueryOrderDTO dto) {
        // 根据条件查询订单：支付状态、排序字段、订单号、患者姓名(获取患者id，可以是列表)
        ValidateUtil.isTrue(Objects.isNull(dto.getChannelId()), "诊所id不能为空");
        // 查询订单，根据返回订单类型，转换不同的VO
        Page<Orders> page = new Page<>(dto.getPageNum(), dto.getPageSize());

        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<Orders>();

        /**
         * 诊疗表
         * 如果诊疗表没有，代表还没有预约过该治疗师
         */

        /**
         * 取出治疗师
         *
         */

        // 治疗师id
        Integer adminId = dto.getAdminId();

        // 查出预约表
        List<ScheduleDetailPatientBind> bindList = scheduleDetailPatientBindService.list(new LambdaQueryWrapper<ScheduleDetailPatientBind>().eq(ScheduleDetailPatientBind::getAdminId, adminId));
        if (CollectionUtils.isEmpty(bindList)) {
            return PageConvert.INSTANCE.convertPage(page);
        }

        // 有预约过的患者
        List<String> patientSns = bindList.stream().map(c -> c.getPatientSn()).collect(Collectors.toList());

        // 订单
        List<String> orderSns = bindList.stream().map(o -> o.getOrderSn()).collect(Collectors.toList());

        wrapper.orderByDesc(Orders::getCreateTime);
        wrapper.in(Orders::getOrderSn, orderSns).eq(Orders::getOrderType, OrderTypeEnum.THERAPY.getCode());
        wrapper.in(Orders::getPatientSn, patientSns);


        if (!StringUtil.isEmpty(dto.getOrderSn())) {
            wrapper.like(Orders::getOrderSn, dto.getOrderSn());
        }

        if (CollectionUtils.isNotEmpty(dto.getPatientSns())) {
            wrapper.in(Orders::getPatientSn, dto.getPatientSns());
        }
        if (CollectionUtils.isNotEmpty(dto.getOrderStatusList())) {
            wrapper.in(Orders::getOrderStatus, dto.getOrderStatusList());
        }

        Page<Orders> list = ordersService.page(page, wrapper);
        List<OrderVO> orderVOS = orderConverter.convertOrderFormat(list.getRecords(), dto.getChannelId(), true);
        PageVO<OrderVO> result = PageConvert.INSTANCE.convertPage(list);
        result.setList(orderVOS);
        return result;
    }

    /**
     * 根据订单号查询面诊记录
     *
     * @param orderSn
     * @return
     */
    @Override
    public InterviewRecordsVO getInterviewRecordsByOrderSn(String orderSn, String source) {

        InterviewRecordsVO interviewRecordsVO = new InterviewRecordsVO();
        interviewRecordsVO.setInterviewRecordsId(null);
        interviewRecordsVO.setDiagnosisTime("");
        interviewRecordsVO.setOrderSn("");
        interviewRecordsVO.setAdminName("");
        interviewRecordsVO.setPatientName("");
        interviewRecordsVO.setPatientSn("");
        interviewRecordsVO.setChiefComplaint("");
        interviewRecordsVO.setDiagnosis("");
        interviewRecordsVO.setForecast("");
        interviewRecordsVO.setExpectedOutcomes("");
        interviewRecordsVO.setAdvice("");
        interviewRecordsVO.setReleaseStatus(0);


        // 查出订单
        Orders orders = ordersService.getOne(new LambdaQueryWrapper<Orders>().eq(Orders::getOrderSn, orderSn));

        List<ScheduleDetail> detailList = scheduleDomainService.selectScheduleDetails(Arrays.asList(orders.getScheduleDetailId()));
        if (CollectionUtils.isNotEmpty(detailList)) {
            ScheduleDetail scheduleDetail = detailList.get(0);
            StringBuilder sb = new StringBuilder();
            sb.append(DateUtil.formatDateToString(scheduleDetail.getScheduleDate(), DateUtil.FORMAT_TYPE_3));
            sb.append(" ");
            sb.append(DateUtil.formatDateToString(scheduleDetail.getStartTime(), DateUtil.FORMAT_TYPE_5));
            sb.append("-");
            sb.append(DateUtil.formatDateToString(scheduleDetail.getEndTime(), DateUtil.FORMAT_TYPE_5));

            interviewRecordsVO.setDiagnosisTime(sb.toString());
        }

        PatientAdminVO patientDetail = patientDomainService.getPatientDetail(orders.getPatientSn());

        if (ObjectUtils.isNotEmpty(patientDetail)) {
            interviewRecordsVO.setPatientName(patientDetail.getPatientName());
            interviewRecordsVO.setPatientSn(orders.getPatientSn());
        }
        AdminUserInfo adminUser = adminUserInfoService.getOne(new LambdaQueryWrapper<AdminUserInfo>().eq(AdminUserInfo::getAdminId, orders.getAdminId()).last("limit 1"));
        interviewRecordsVO.setAdminName(adminUser == null ? "" : adminUser.getRealName());
        interviewRecordsVO.setOrderSn(orderSn);


        // 查出面诊记录
        OrdersInterviewRecords interviewRecords = orderDomainService.selectInterviewRecordsByOrderSn(orderSn);
        // 没有发布的不给看
        if (ObjectUtils.isEmpty(interviewRecords)) {
            //
            return interviewRecordsVO;
        }
        if (source.equals("WEIXIN_APP") && interviewRecords.getReleaseStatus().equals(0)) {
            return null;
        }
        interviewRecordsVO.setChiefComplaint(StringUtils.isNotBlank(interviewRecords.getChiefComplaint()) ? interviewRecords.getChiefComplaint() : "");
        interviewRecordsVO.setDiagnosis(StringUtils.isNotBlank(interviewRecords.getDiagnosis()) ? interviewRecords.getDiagnosis() : "");
        interviewRecordsVO.setForecast(StringUtils.isNotBlank(interviewRecords.getForecast()) ? interviewRecords.getForecast() : "");
        // interviewRecordsVO.setTreatmentPlan(StringUtils.isNotBlank(interviewRecords.getTreatmentPlan()) ? JSON.parseObject(interviewRecords.getTreatmentPlan()) : JSON.parse(patientParamsConfig("ORDER_TREATMENT_PLAN")));
        interviewRecordsVO.setExpectedOutcomes(StringUtils.isNotBlank(interviewRecords.getExpectedOutcomes()) ? interviewRecords.getExpectedOutcomes() : "");
        interviewRecordsVO.setAdvice(StringUtils.isNotBlank(interviewRecords.getAdvice()) ? interviewRecords.getAdvice() : "");
        interviewRecordsVO.setInterviewRecordsId(interviewRecords.getId());
        interviewRecordsVO.setReleaseStatus(interviewRecords.getReleaseStatus());
        return interviewRecordsVO;
    }

    /**
     * 根据患者编号查找用户任务列表
     *
     * @param dto
     * @return
     */
    @Override
    public PageVO<PatientTaskVO> getPatientTaskOrders(PatientTasksDTO dto) {

        // 查出订单信息了
        Page<Orders> ordersPage = new Page<Orders>();
        ordersPage.setCurrent(dto.getPageNum());
        ordersPage.setSize(dto.getPageSize());
        PageOrdersConditionBO bo = PageOrdersConditionBO.builder().patientSn(dto.getPatientSn()).build();
        bo.setTaskStatus(dto.getTaskStatus());

        orderDomainService.getPageOrdersByCondition(ordersPage, bo);
        List<Orders> ordersList = ordersPage.getRecords();

        if (CollectionUtils.isEmpty(ordersList)) {
            return PageConvert.INSTANCE.convertPage(ordersPage);
        }


        // 预约详情
        List<ScheduleDetail> details = scheduleDomainService.selectScheduleDetails(ordersList.stream().map(c -> c.getScheduleDetailId()).collect(Collectors.toList()));

        // 转成 map
        Map<Integer, ScheduleDetail> detailMap = details.stream()
                .collect(Collectors.toMap(ScheduleDetail::getId, detail -> detail));

        // 组状 vo
        List<PatientTaskVO> voList = ordersList.stream().map(order -> {
            PatientTaskVO taskVo = new PatientTaskVO();
            // 根据订单类型和新字段赋值
            taskVo.setTaskType(order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode()) ? order.getOrderType() : order.getScheduleType());


            taskVo.setOrderSn(order.getOrderSn());
            taskVo.setOrderAmount(order.getOrderAmount().toString());
            taskVo.setOrderStatus(order.getOrderStatus());
            // 根据订单状态赋值
            taskVo.setOrderStatusDesc(OrderStatusEnum.translate(order.getOrderStatus()));
            taskVo.setTaskStatus(order.getBusinessStatus());
            // 根据任务节点状态赋值
            taskVo.setTaskStatusDesc(OrderBusinessStatusEnum.translate(order.getBusinessStatus()));
            if (order.getOrderStatus().equals(OrderStatusEnum.REFUND.getCode())) {
                taskVo.setTaskStatus(OrderBusinessStatusEnum.REFUND.getCode());
                taskVo.setTaskStatusDesc(OrderBusinessStatusEnum.translate(taskVo.getTaskStatus()));
            }
            if (order.getOrderStatus().equals(OrderStatusEnum.CANCEL.getCode())) {
                taskVo.setTaskStatus(OrderBusinessStatusEnum.CANCEL.getCode());
                taskVo.setTaskStatusDesc(OrderBusinessStatusEnum.translate(taskVo.getTaskStatus()));
            }
            AdminUserVO adminUser = adminUserDomainService.getAdminUser(order.getAdminId());
            taskVo.setAdminName(ObjectUtils.isEmpty(adminUser) ? "" : adminUser.getRealName());
            ScheduleDetail scheduleDetail = detailMap.get(order.getScheduleDetailId());
            if (ObjectUtils.isNotEmpty(scheduleDetail)) {
                taskVo.setAdminType(order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode()) ? "医生" : "治疗师");
                taskVo.setTaskTime(
                        DateUtil.formatDateToString(scheduleDetail.getScheduleDate(), DateUtil.FORMAT_TYPE_3)
                                + " "
                                + DateUtil.formatDateToString(scheduleDetail.getStartTime(), DateUtil.FORMAT_TYPE_5)
                                + "-"
                                + DateUtil.formatDateToString(scheduleDetail.getEndTime(), DateUtil.FORMAT_TYPE_5));

            } else {
                taskVo.setAdminType("");
                taskVo.setAdminName("");
                taskVo.setTaskTime("-");
            }
            TreatmentPlan plan = treatmentPlanService.getOne(new LambdaQueryWrapper<TreatmentPlan>().eq(TreatmentPlan::getZlOrderSn, order.getOrderSn()).last("limit 1"));

            double totalDuration = 0d;
            TreatmentPlanItem treatmentPlanItem = new TreatmentPlanItem();
            if (taskVo.getTaskType().equals(OrderTaskTypeEnum.THERAPY_PROJECT.getCode()) && ObjectUtils.isNotEmpty(plan)) {
                treatmentPlanItem = treatmentPlanItemService.getOne(new LambdaQueryWrapper<TreatmentPlanItem>().eq(TreatmentPlanItem::getPlanId, plan.getId()).last("limit 1"));
                totalDuration = ObjectUtils.isNotEmpty(treatmentPlanItem)?treatmentPlanItem.getDurationPerSession():totalDuration;
            }
            if (taskVo.getTaskType().equals(OrderTaskTypeEnum.THERAPY_PLAN.getCode()) && ObjectUtils.isNotEmpty(plan)) {
                // 查出所有项目
                List<TreatmentPlanItem> itemList = treatmentPlanItemService.list(new LambdaQueryWrapper<TreatmentPlanItem>().eq(TreatmentPlanItem::getPlanId, plan.getId()).eq(TreatmentPlanItem::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));
                if (ObjectUtils.isNotEmpty(itemList)) {
                    // totalDuration = itemList.stream()
                    //         .mapToDouble(TreatmentPlanItem::getDurationPerSession)
                    //         .sum();
                    for (TreatmentPlanItem item : itemList) {
                        if (item.getDurationPerSession() != null) {
                            totalDuration += item.getDurationPerSession();
                        }
                    }

                }
            }
            taskVo.setSingleAppointmentDuration(ObjectUtils.isNotEmpty(totalDuration) ? String.valueOf(totalDuration) : 0.0 + "");

            if (order.getOrderType().equals(OrderTypeEnum.DIAGNOSIS.getCode())) {
                taskVo.setTaskDesc("医生面诊");
            } else if (order.getOrderType().equals(OrderTypeEnum.THERAPY.getCode())) {
                if (order.getScheduleType().equals(OrderTaskTypeEnum.THERAPY_PLAN.getCode())) {
                    if (ObjectUtils.isNotEmpty(plan)) {
                        // taskVo.setTaskDesc("治疗方案 " + plan.getPlanSn());
                        taskVo.setTaskDesc("治疗方案 " + plan.getPlanSn() + " 第" + plan.getSortNum()+"次");
                        // long count = treatmentPlanService.count(new LambdaQueryWrapper<TreatmentPlan>().eq(TreatmentPlan::getPlanSn, plan.getPlanSn()).eq(TreatmentPlan::getDeleted, DeletedStatusEnum.DELETED_NO.getValue()));
                        // taskVo.setTaskDesc("治疗方案 " + plan.getPlanSn() + " 第" + plan.getSortNum()+"次" +" 共"+ count+"次");
                    } else {
                        taskVo.setTaskDesc("");
                    }

                }
                if (order.getScheduleType().equals(OrderTaskTypeEnum.THERAPY_PROJECT.getCode())) {
                    taskVo.setTaskDesc(ObjectUtils.isNotEmpty(treatmentPlanItem) ? treatmentPlanItem.getItemName() : "");
                }
            }

            return taskVo;

        }).collect(Collectors.toList());

        PageVO<PatientTaskVO> pageVO = PageConvert.INSTANCE.convertPage(ordersPage);
        pageVO.setList(voList);
        return pageVO;
    }

    /**
     * 添加新的治疗（项目）
     *
     * @param dto
     * @return
     */
    @Override
    public String addNewTreatment(AddNewTreatmentDTO dto) {

        ConfirmAppointmentBO bo = new ConfirmAppointmentBO()
                .setAdminId(dto.getAdminId())
                .setAppointmentDate(dto.getAppointmentDate())
                .setOrderSn(dto.getOrderSn())
                .setScheduleDetailIds(dto.getScheduleDetailIds())
                .setSource(dto.getSource())
                .setProjectId(dto.getProjectId())
                .setPatientSn(dto.getPatientSn());

        if (ObjectUtils.isEmpty(dto.getScheduleType())) {
            throw new ServiceException("请检查参数");
        }

        // 治疗预约，是有订单的，走原来的逻辑
        if (dto.getScheduleType().equals(OrderTaskTypeEnum.THERAPY_PLAN.getCode())) {
            return orderDomainService.confirmAppointment(bo);
        } else if (dto.getScheduleType().equals(OrderTaskTypeEnum.THERAPY_PROJECT.getCode())) {
            bo.setIsUseCoupon(dto.getIsUseCoupon());
            bo.setCouponCode(dto.getCouponCode());
            return orderDomainService.confirmProjectAppointment(bo);
        }

        throw new ServiceException("不允许该类预约");

    }

    /**
     * 根据方案编号查找订单
     *
     * @param planSn
     * @return
     */
    @Override
    public List<TreatmentOrderVO> getOrderByProjectSn(String planSn) {

        // 查出方案
        List<TreatmentPlan> planList = treatmentPlanDomainService.getPlanItemProject(planSn);
        List<String> orderSns = planList.stream().map(TreatmentPlan::getZlOrderSn).collect(Collectors.toList());
        List<Orders> ordersList = orderDomainService.selectByOrderSn(orderSns);
        if (CollectionUtils.isEmpty(ordersList)) {
            return Collections.emptyList();
        }
        Map<String, TreatmentPlan> planMap = ObjectUtils.isEmpty(planList) ? Collections.emptyMap() : planList.stream().collect(Collectors.toMap(TreatmentPlan::getZlOrderSn, plan -> plan, (existing, replacement) -> replacement));
        List<TreatmentOrderVO> orderVOList = ordersList.stream().map(order -> {
            TreatmentOrderVO orderVO = new TreatmentOrderVO();
            orderVO.setOrderSn(order.getOrderSn());
            orderVO.setOrderAmount(order.getOrderAmount());
            orderVO.setSourceAmount(order.getSourceAmount());
            orderVO.setOrderStatus(order.getOrderStatus());
            orderVO.setBusinessStatus(order.getBusinessStatus());
            TreatmentPlan plan = planMap.get(order.getOrderSn());
            String patientSn = plan.getPatientSn();
            PatientAdminVO detail = patientDomainService.getPatientDetail(patientSn);
            if (ObjectUtils.isNotEmpty(detail)) {
                PatientBaseInfoVO build = PatientBaseInfoVO.builder().patientSn(patientSn).name(detail.getPatientName())
                        .build();
                orderVO.setPatientBaseInfoVO(build);
            }
            Integer scheduleDetailId = order.getScheduleDetailId();
            if (ObjectUtils.isNotEmpty(scheduleDetailId)) {
                ScheduleDetail scheduleDetail = scheduleDetailService.getById(scheduleDetailId);
                if (ObjectUtils.isNotEmpty(scheduleDetail)) {
                    Integer adminId = scheduleDetail.getAdminId();
                    AdminUserInfo userInfo = adminUserInfoService.getOne(new LambdaQueryWrapper<AdminUserInfo>().eq(AdminUserInfo::getAdminId, adminId));
                    AppointmentVO build = AppointmentVO.builder()
                            .scheduleDate(DateUtil.formatDateToString(scheduleDetail.getScheduleDate(), DateUtil.FORMAT_TYPE_3))
                            .startTime(DateUtil.formatDateToString(scheduleDetail.getStartTime(), DateUtil.FORMAT_TYPE_5))
                            .endTime(DateUtil.formatDateToString(scheduleDetail.getEndTime(), DateUtil.FORMAT_TYPE_5))
                            .week(DateUtil.convertWeekName2(scheduleDetail.getScheduleDate()))
                            .name(ObjectUtils.isNotEmpty(userInfo) ? userInfo.getRealName() : null)
                            .build();
                    orderVO.setAppointmentVO(build);
                }
            }

            orderVO.setSortNum(plan.getSortNum());
            orderVO.setVisitProject(ObjectUtils.isNotEmpty(plan) ? "治疗方案 " + plan.getPlanSn() + " 第" + plan.getSortNum() + "次" : "无");
            return orderVO;
        }).collect(Collectors.toList());

        return orderVOList;
    }

    /**
     * 根据处置方案 id 查出订单
     *
     * @param id
     * @return
     */
    @Override
    public List<MergePayOrderVO> mergeDisposalPlan(Integer id) {

        List<TreatmentPlan> planList = treatmentPlanDomainService.getTreatmentPlanById(id);
        Map<String, TreatmentPlan> planMap = planList.stream().collect(Collectors.toMap(TreatmentPlan::getZlOrderSn, plan -> plan));

        // 查出订单
        List<String> orderSns = planList.stream().map(TreatmentPlan::getZlOrderSn).collect(Collectors.toList());

        List<Orders> ordersList = orderDomainService.selectByOrderSn(orderSns);

        // 组装数据
        List<MergePayOrderVO> voList = ordersList.stream().map(order -> {
            TreatmentPlan plan = planMap.get(order.getOrderSn());
            MergePayOrderVO vo = new MergePayOrderVO();
            vo.setSortNum(plan.getSortNum());
            vo.setOrderSn(order.getOrderSn());
            vo.setOrderStatus(order.getOrderStatus());
            vo.setOrderAmount(order.getOrderAmount());
            return vo;
        }).collect(Collectors.toList());

        return voList;
    }

    /**
     * 合并支付订单列表
     *
     * @param bo
     * @return
     */
    @Override
    public List<OrderVO> getMergeOrderList(GetMergeOrderListBO bo) {
        List<Orders> ordersList = orderDomainService.selectByOrderSn(bo.getOrderSns());
        List<OrderVO> orderVOS = orderConverter.convertOrderFormat(ordersList, bo.getChannelId(), false);
        return orderVOS;
    }
}
