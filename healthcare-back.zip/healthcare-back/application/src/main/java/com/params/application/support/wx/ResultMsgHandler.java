package com.params.application.support.wx;

import com.params.pojo.bo.wx.BaseMsg;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxReqBO;

/**
 * 消息类型处理接口
 */
public interface ResultMsgHandler {

    default BaseMsg handle(WxReqBO reqBO, OfficialAccount account) {
        return null;
    }
}
