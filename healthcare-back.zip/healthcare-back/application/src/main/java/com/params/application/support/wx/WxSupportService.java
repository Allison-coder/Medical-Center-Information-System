package com.params.application.support.wx;

import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface WxSupportService {
    /**
     * 接入微信公众号
     *
     * @param request
     * @param response
     */
    void bind(HttpServletRequest request, HttpServletResponse response, WxConfigBO wxConfig);

    /**
     * 接收微信公众号消息
     *
     * @param request
     * @param response
     * @throws IOException
     */
    void processAccess(HttpServletRequest request, HttpServletResponse response, WxConfigBO wxConfig, WxReqBO req);

    WxConfigBO getWxConfigInfo(String officialCode);
}
