package com.params.application.support.wx.msghandler;

import com.alibaba.fastjson.JSONObject;
import com.params.application.support.wx.ResultMsgHandler;
import com.params.pojo.bo.wx.Article;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.pojo.bo.wx.NewsMsg;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.WxReqBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component("defaultNewsMsgHandler")
@Slf4j
public class DefaultNewsMsgHandler implements ResultMsgHandler {
    @Override
    public BaseMsg handle(WxReqBO reqBO, OfficialAccount account) {
        NewsMsg msg = new NewsMsg();
        Article article = JSONObject.parseObject(account.getConfig(), Article.class);
        msg.add(article);
        return msg;
    }
}
