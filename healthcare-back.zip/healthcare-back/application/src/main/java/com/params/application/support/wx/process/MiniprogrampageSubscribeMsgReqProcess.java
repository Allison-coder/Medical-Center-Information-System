package com.params.application.support.wx.process;

import com.alibaba.fastjson.JSONObject;
import com.params.application.support.wx.MsgReqProcess;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.BaseMsg;
import com.params.pojo.bo.wx.MiniprogrampageMsg;
import com.params.pojo.bo.wx.RespType;
import com.params.pojo.bo.wx.WxConfigBO;
import com.params.pojo.bo.wx.WxReqBO;
import com.params.rabbitmq.sender.WeiXinTextMsgSender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("miniprogrampageEventSubscribeMsgReqProcess")
@Slf4j
public class MiniprogrampageSubscribeMsgReqProcess implements MsgReqProcess {

    @Autowired
    private WeiXinTextMsgSender msgSender;

    @Override
    public BaseMsg handle(WxReqBO reqBO, WxConfigBO wxConfigBO, OfficialAccount account) {
        // 获取参数
        log.info("【医疗中心优惠券关注事件处理】");
        String fromUserName = reqBO.getFromUserName();
        log.info("用户：" + fromUserName);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("title", "test");
        jsonObject.put("appid", "wx8fd123f864f19f96");
        jsonObject.put("pagepath", "pages/index/index");
        jsonObject.put("thumb_media_id", "vmEZ5PjekIhhBO23cmuqz3uS0ueB-5QTeY48b-7_SMtZ2nW4qaSzBnmS0xE2vdOs");
        msgSender.send(fromUserName, RespType.MINIPROGRAMPAGE, jsonObject.toJSONString(), 1000L);

        MiniprogrampageMsg msg = new MiniprogrampageMsg("test", "wx8fd123f864f19f96", "pages/index/index",
                "vmEZ5PjekIhhBO23cmuqz3uS0ueB-5QTeY48b-7_SMtZ2nW4qaSzBnmS0xE2vdOs");
        return msg;
    }
}
