package com.params.application.workpanel.impl;

import com.params.application.workpanel.WorkPanelApp;
import com.params.domain.adminuser.AdminUserDomainService;
import com.params.domain.medicalrecords.MedicalRecordsDomainService;
import com.params.domain.medicalrecords.convert.MedicalRecordsConverter;
import com.params.domain.order.OrderDomainService;
import com.params.domain.schedule.ScheduleDomainService;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.entity.AdminUserInfo;
import com.params.entity.MedicalRecords;
import com.params.entity.Orders;
import com.params.entity.ScheduleDetail;
import com.params.pojo.vo.MedicalRecordPatientVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Component
@Slf4j
public class WorkPanelAppImpl implements WorkPanelApp {


    @Autowired
    private MedicalRecordsDomainService medicalRecordsDomainService;

    @Autowired
    private TreatmentPlanDomainService treatmentPlanDomainService;


    @Autowired
    private MedicalRecordsConverter medicalRecordsConverter;

    @Autowired
    private OrderDomainService orderDomainService;

    @Autowired
    private ScheduleDomainService scheduleDomainService;

    @Autowired
    private AdminUserDomainService adminUserDomainService;

    /**
     * 根据串者编号查出就诊记录
     *
     * @param patientSn
     * @return
     */
    @Override
    public List<MedicalRecordPatientVO> getMedicalRecord(String patientSn, Integer clinicId) {
        // 查出诊疗记录
        List<MedicalRecords> medicalRecordList = medicalRecordsDomainService.getMedicalRecordByPatientSn(patientSn);
        // 所有治疗单的编号
        List<String> orderSns = medicalRecordList.stream()
                .map(MedicalRecords::getOrderSn)
                .collect(Collectors.toList());
        // 退过订单编号得到订单信息
        List<Orders> ordersList = orderDomainService.selectByOrderSn(orderSns);
        // 预约
        List<Integer> scheduleIds = Optional.ofNullable(ordersList).orElse(Collections.emptyList()).stream().map(Orders::getScheduleDetailId).collect(Collectors.toList());
        List<ScheduleDetail> scheduleDetails = scheduleDomainService.selectScheduleDetails(scheduleIds);
        Map<Integer, ScheduleDetail> scheduleDetailMap = Optional.ofNullable(scheduleDetails).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(ScheduleDetail::getId, scheduleDetail -> scheduleDetail, (existing, replacement) -> replacement));

        // 医生和治疗师
        List<AdminUserInfo> adminUserInfoList = adminUserDomainService.selectAdminUserInfos(clinicId);
        Map<Integer, AdminUserInfo> adminUserInfoMap = Optional.ofNullable(adminUserInfoList).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(AdminUserInfo::getAdminId, adminUserInfo -> adminUserInfo, (existing, replacement) -> replacement));

        // 组装 vo
        List<MedicalRecordPatientVO> recordsVO = medicalRecordsConverter.convertMedicalRecordsVo(medicalRecordList, scheduleDetailMap, adminUserInfoMap);
        return recordsVO;
    }
}
