package com.params.application.support.wx;

import cn.hutool.core.util.StrUtil;
import com.google.common.base.CaseFormat;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MsgReqProcessFactoryTest {

    @Test
    void testBeanName() {
        System.out.println(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_HYPHEN, "text"));
        System.out.println(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_UNDERSCORE, "text"));
        System.out.println(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, "text"));
        System.out.println(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, "text"));
        System.out.println(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_UNDERSCORE, "text"));
        String strategy = "COUPON", msgtype = "event", event = "subscribe";
        String key = StrUtil.format("{}{}{}MsgReqProcess", CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, strategy),
                CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, msgtype),
                CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, event));
        System.out.println(key); // defaultTextMsgReqProcess    couponEventSubscribeMsgReqProcess
    }
}