package com.params.application.support.wx.process;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.junit.jupiter.api.Test;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

class CouponSubscribeMsgReqProcessTest {

    @Test
    void testMsg() {
        JSONObject extConfig = JSONObject.parseObject(getConfig());
        JSONArray customerMsg = extConfig.getJSONArray("customerMsg");
        Iterator<Object> iterator = customerMsg.iterator();
        while (iterator.hasNext()) {
            JSONObject next = (JSONObject) iterator.next();
            System.out.println(next);
            System.out.println(next.getString("msgType"));
            System.out.println(next.getString("media_id"));
        }
    }

    private String getConfig() {
        return "{\n" +
                "    \"text\": {\n" +
                "        \"content\": \"感谢关注！参数医疗助您告别痛楚，恢复如初！\\n\\n·参数医疗是由原中国奥林匹克国家队总队队医、运动医学教授专家团队领衔并结合最新康复科技及线上诊疗技术的国际化定制运动康复中心。\\n\\n·为您提供骨科术后康复、运动损伤治疗、运动前防护与运动后专项拉伸、陈旧性损伤恢复、疼痛管理、体态调整、促进青少年生长发育等服务。\\n\\n-电话热线：4006-893-909\\n-营业时间： 9:30-18:30\\n-地址：广州天河区珠江新城海明路20号107铺（广粤天地东门）\\n\\n【扫下方二维码联系在线客服\uD83D\uDC47】\"\n" +
                "    },\n" +
                "    \"qrcode\": {\n" +
                "        \"width\": 500,\n" +
                "        \"height\": 500\n" +
                "    },\n" +
                "    \"msgType\": \"text\",\n" +
                "    \"customerMsg\": [\n" +
                "        {\n" +
                "            \"msgType\": \"image\",\n" +
                "            \"media_id\": \"vmEZ5PjekIhhBO23cmuqz3qh0h7IP-QIo5gYoslrF1TYT9tT-EScPEl7ff0QltQJ\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }
}