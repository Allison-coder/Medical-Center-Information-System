package com.params.application.order.impl;

import com.params.service.ParamsConfigService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
//@DataJpaTest
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class OrderAppImplTest {

    @InjectMocks
    private OrderAppImpl orderApp;

    @Mock
    private ParamsConfigService paramsConfigService;

    @Test
    void testCreateOrderSn() {
//        String order = orderApp.createOrder(null);
//        System.out.println(order);
    }

    @BeforeEach
    void testBefore() {
//        when(paramsConfigService.getOneConfig(any())).thenReturn("{}");
        Mockito.when(paramsConfigService.getOneConfig(any())).thenReturn("{\"orderSnType\":\"random\",\"length\":8}");
    }
}