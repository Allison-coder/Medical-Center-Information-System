package com.params.bo;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Map;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 * @Create 2024/1/16
 */
@Getter
@Setter
public class WuXingBO {

    /**
     * 五行比率
     */
    private Map<String, BigDecimal> wuXingRate;

    /**
     * 十神比重
     */
    private Map<String, BigDecimal> shiShenRate;

    /**
     * 日干
     */
    private String dayGan;

    /**
     * 日干五行
     */
    private String dayGanWuXing;

    /**
     * 身体强弱
     */
    private String strength;

    /**
     * 定喜用神
     */
    private Map<String, String> dingXi;

    /**
     * 五行属性
     */
    private String wuXingAttr;

    /**
     * 月支
     */
    private String monthZhi;

    /**
     * 月支主气藏干
     */
    private String monthZhiZhuQiHideGan;
    /**
     * 月支主气藏干十神
     */
    private String monthZhiZhuQiHideGanShiShen;
}
