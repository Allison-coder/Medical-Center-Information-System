package com.params.utils;


import com.params.framework.exception.ServiceException;;
import org.springframework.util.Base64Utils;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by lf on 2018/11/01.
 */
public class RSA {

    public static final String KEY_ALGORITHM = "RSA";
    public static final String SIGNATURE_ALGORITHM_MD5 = "MD5withRSA";
    public static final String SIGNATURE_ALGORITHM_SHA = "SHA1WithRSA";

    /**
     * 创建私钥公钥到文件
     * @param baseFilePath
     * @param keyMap
     * @throws Exception
     */
    public static void createKeyToSystemFilePath(String baseFilePath,Map<String,String> keyMap) throws Exception {
        String basePath = baseFilePath==null?"D:\\test\\rsa\\":baseFilePath;
        WriteFile(keyMap.get("pubKey"),basePath+"pubKey2.txt");
        WriteFile(keyMap.get("preKey"),basePath+"preKey2.txt");
        java.awt.Desktop.getDesktop().open(new File(basePath));
    }
    /**
     * @author lf
     * 密钥创建 生成私钥与密钥
     * @throws NoSuchAlgorithmException
     * @throws IOException
     */
    public static Map<String,String> createRSAKey() throws Exception{
        SecureRandom secureRandom = new SecureRandom();
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(1024, secureRandom);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        Key publicKey = keyPair.getPublic();
        Key privateKey = keyPair.getPrivate();
        String pubKey =  Base64Utils.encodeToString((publicKey.getEncoded()));
        String preKey = Base64Utils.encodeToString(privateKey.getEncoded());
        Map keyMap = new HashMap(2);
        keyMap.put("preKey",preKey);
        keyMap.put("pubKey",pubKey);
        return  keyMap;
    }

    /**
     * 用私钥对信息生成数字签名
     * @param data  加密数据
     * @param privateKey 私钥
     * @param type  值为md5 sha
     * @return
     * @throws Exception
     */
    public static String sign(String data, String privateKey,final String type) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        PrivateKey priKey = keyFactory.generatePrivate( new PKCS8EncodedKeySpec(decryptBASE64(privateKey)));
        Signature signature = Signature.getInstance(type);
        signature.initSign(priKey);
        signature.update(data.getBytes());
        return encryptBASE64(signature.sign());
    }

    /**
     * @param data
     * @param privateKey  rsa 私钥
     * @return
     * @throws Exception
     */
    public static String signSHA1WithRSA(String data, String privateKey) {
        try {
            return sign(data,privateKey,SIGNATURE_ALGORITHM_SHA);
        } catch (Exception e) {
            throw new ServiceException("系统异常");
        }
    }

    /**
     * @param data
     * @param privateKey rsa私钥
     * @return
     * @throws Exception
     */
    public static String signMD5WithRSA(String data, String privateKey) throws Exception {
        return sign(data,privateKey,SIGNATURE_ALGORITHM_MD5);
    }

    /**
     *  签名验证 支持 md5withrsa 和shawithrsa
     * @param data
     * @param publicKey
     * @param sign
     * @param type
     * @return
     * @throws Exception
     */
    public static boolean verify(String data, String publicKey, String sign,final String type)
            throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec( decryptBASE64(publicKey)));
        Signature signature = Signature.getInstance(type);
        signature.initVerify(pubKey);
        signature.update(data.getBytes());
        return signature.verify(decryptBASE64(sign));
    }

    /**
     *  验证md5withrsa签名
     * @param data
     * @param publicKey
     * @param sign
     * @return
     */
    public static boolean verifyMD5withRSA(String data, String publicKey,String sign) throws Exception {
        return verify(data,publicKey,sign,SIGNATURE_ALGORITHM_MD5);
    }

    /**
     * @param data
     * @param publicKey
     * @param sign
     * @return
     */
    public static boolean verifySHA1WithRSA(String data, String publicKey,String sign)  {
        try {
            return verify(data,publicKey,sign,SIGNATURE_ALGORITHM_SHA);
        } catch (Exception e) {
            throw new ServiceException("系统异常");        }
    }


    /**
     * @param data
     * @return
     */
    public static byte[] decryptBASE64(String data){
        return Base64Utils.decodeFromString(data);
    }

    /**
     * @param data
     * @return
     */
    public static String encryptBASE64(String data){
        return Base64Utils.encodeToString(data.getBytes());
    }

    /**
     * @param data
     * @return
     */
    public static String encryptBASE64(byte[] data){
        return Base64Utils.encodeToString(data);
    }

    /**
     *  使用私钥进行rsa解密
     * @param data
     * @param key  私钥
     * @return
     * @throws Exception
     */
    public static String decryptByPreKeyRSA(String data, String key) throws Exception {
        byte[] keyBytes = decryptBASE64(key);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(decryptBASE64(data)));
    }

    /**
     * 使用rsa 公钥进行解密
     * @param data
     * @param key 公钥
     * @return
     * @throws Exception
     */
    public static String decryptByPubKeyRSA(String data, String key) throws Exception {
        byte[] keyBytes = decryptBASE64(key);
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key publicKey = keyFactory.generatePublic(x509KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, publicKey);
        return new String(cipher.doFinal(decryptBASE64(data)));
    }

    /**
     *  使用公钥进行加密
     * @param data
     * @param key 公钥
     * @return
     * @throws Exception
     */
    public static String encryptByPubKeyRSA(String data, String key) throws Exception {
        byte[] keyBytes = decryptBASE64(key);
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key publicKey = keyFactory.generatePublic(x509KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        return encryptBASE64(cipher.doFinal(data.getBytes()));
    }

    /**
     *  使用私钥进行加密rsa
     * @param data
     * @param key 私钥
     * @return
     * @throws Exception
     */
    public static String encryptByPreKeyRSA(String data, String key) throws Exception {
        byte[] keyBytes = decryptBASE64(key);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);
        return encryptBASE64(cipher.doFinal(data.getBytes()));
    }
    public static void WriteFile(String str,String path,boolean append) throws IOException {
        File file = new File(path);
        FileWriter writer = new FileWriter(file);
        if (append){
            writer.append(str);
        }else{
            writer.write(str);
        }
        writer.flush();
        writer.close();
    }

    public static void WriteFile(String str,String path) throws IOException {
        WriteFile(str,path,false);
    }
    public static String  ReadFile(String path) throws IOException {
        StringBuilder strB = new StringBuilder();
        FileInputStream read = new FileInputStream(new File(path));
        byte[] a = new byte[2048];
        int len = 0;
        while ((len = read.read(a))!=-1){
            strB.append( new String(a,0,len) );
        }
        read.close();
        return  strB.toString();
    }

    /**
     * 测试创建私钥公钥到文件夹
     * @throws Exception
     */
    public static void test1() throws Exception {
        String basePath = "D:\\test\\rsa\\test\\";
        createKeyToSystemFilePath(basePath,createRSAKey());
    }

    /**
     *  测试签名验证
     * @throws Exception
     */
    public static void test2() throws Exception {
        String basePath = "D:\\test\\rsa\\test\\";
        String pubKey = ReadFile(basePath + "pubKey2.txt");
        String preKey = ReadFile(basePath + "preKey2.txt");
        String content = "afqfqf";
        String sign = signSHA1WithRSA("afqfqf", preKey);
    }
    public static void test3() throws Exception {
        long startTime = System.currentTimeMillis();
        test2();
    }
    public static void test4() throws Exception {

    }

    /**
     * @author lf
     * 算法加密解密工具类 md5 rsa等
     */
    public static class ArithmeticUtil {
        private static final String SHA1ALGORITHM_NAME = "SHA1";
        private static final String MD5_ALGORITHM_NAME = "MD5";
        private static final String SHA256_ALGORITHM_NAME = "SHA-256";
        private static final String DES_ALGORITHM_NAME = "DES";
        public static final String CIPHER_ALGORITHM_ECB = "DES/ECB/PKCS5Padding";
        public static final String DEFALT_CHARSET = "utf-8";
        private static final char[] HEX_CHARS = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};


        /**
         * des 加密
         *
         * @param data
         * @param password
         * @return
         * @throws Exception
         */
        public static String desAsHex(byte[] data, byte[] password) throws Exception {
            return new String(encodeHex(cipherDoFinal(data, password, DES_ALGORITHM_NAME, CIPHER_ALGORITHM_ECB, Cipher.ENCRYPT_MODE)));
        }

        /**
         * des 解密
         *
         * @param data
         * @param password
         * @return
         * @throws Exception
         */
        public static String decryptDESFromHex(String data, String password) throws Exception {
            return new String(cipherDoFinal(hexStringToBytes(data), password.getBytes(), DES_ALGORITHM_NAME, CIPHER_ALGORITHM_ECB, Cipher.DECRYPT_MODE));
        }

        public static String md5AsHex(String data) {
            return digestAsHexString(MD5_ALGORITHM_NAME, data.getBytes());
        }

        public static String md5AsHex(String data, String salt) {
            return digestAsHexString(MD5_ALGORITHM_NAME, (data + salt).getBytes());
        }

        public static String sha1AsHex(String data) {
            return digestAsHexString(SHA1ALGORITHM_NAME, data.getBytes());
        }


        public static String sha256AsHex(byte[] data) {
            return digestAsHexString(SHA256_ALGORITHM_NAME, data);
        }

        private static MessageDigest getDigest(String algorithm) {
            try {
                return MessageDigest.getInstance(algorithm);
            } catch (NoSuchAlgorithmException var2) {
                throw new IllegalStateException("Could not find MessageDigest with algorithm \"" + algorithm + "\"", var2);
            }
        }

        private static byte[] digest(String algorithm, byte[] bytes) {
            return getDigest(algorithm).digest(bytes);
        }


        private static String digestAsHexString(String algorithm, byte[] bytes) {
            char[] hexDigest = digestAsHexChars(algorithm, bytes);
            return new String(hexDigest);
        }

        private static char[] digestAsHexChars(String algorithm, byte[] bytes) {
            byte[] digest = digest(algorithm, bytes);
            return encodeHex(digest);
        }

        public static char[] encodeHex(byte[] bytes) {
            int len = bytes.length;
            char[] chars = new char[len * 2];
            for (int i = 0; i < len; i++) {
                int b = bytes[i] & 0xFF;
                chars[i * 2] = HEX_CHARS[b >>> 4 & 15];
                chars[i * 2 + 1] = HEX_CHARS[b & 15];
            }
            return chars;
        }


        private static SecretKeyFactory secretKeyFactory(String algorithm) {
            try {
                return SecretKeyFactory.getInstance(DES_ALGORITHM_NAME);
            } catch (NoSuchAlgorithmException var2) {
                throw new IllegalStateException("Could not find MessageDigest with algorithm \"" + algorithm + "\"", var2);
            }
        }

        private static DESKeySpec getDESKeySpec(byte[] password) {
            try {
                return new DESKeySpec(password);
            } catch (InvalidKeyException var2) {
                throw new IllegalStateException("InvalidKeyException 非法密钥 \"" + password + "\"", var2);
            }
        }

        private static Cipher getCipher(String padding) {
            try {
                return Cipher.getInstance(padding);
            } catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException("NoSuchAlgorithmException \"" + padding + "\"", e);
            } catch (NoSuchPaddingException e) {
                throw new IllegalStateException("NoSuchPaddingException \"" + padding + "\"", e);
            }
        }

        private static Cipher initCipher(byte[] password, String algorithm, String padding, int mode) throws InvalidKeyException {
            Cipher cipher = getCipher(padding);
            cipher.init(mode, generateSecretKey(password, algorithm), new SecureRandom());
            return cipher;
        }

        private static SecretKey generateSecretKey(byte[] password, String algorithm) {
            try {
                return secretKeyFactory(algorithm).generateSecret(getDESKeySpec(password));
            } catch (InvalidKeySpecException e) {
                throw new IllegalStateException("InvalidKeySpecException \"" + password + "\"", e);
            }
        }


        public static String desAsHex(String data, String password) throws Exception {
            return desAsHex(data.getBytes(), password.getBytes());
        }

        private static byte[] cipherDoFinal(byte[] data, byte[] password, String algorithm, String padding, int mode) throws Exception {
            Cipher cipher = initCipher(password, algorithm, padding, mode);
            return cipher.doFinal(data);
        }

        private static byte[] hexStringToBytes(String hexString) {
            if (hexString == null || hexString.equals("")) {
                return null;
            }
            hexString = hexString.toUpperCase();
            int length = hexString.length() / 2;
            char[] hexChars = hexString.toCharArray();
            byte[] d = new byte[length];
            for (int i = 0; i < length; i++) {
                int pos = i * 2;
                d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
            }
            return d;
        }

        private static byte charToByte(char c) {
            return (byte) "0123456789ABCDEF".indexOf(c);
        }

        public static String urlEncoder(String data, String charset) {
            try {
                return URLEncoder.encode(data, charset);
            } catch (UnsupportedEncodingException e) {

                return "";
            }
        }

        public static String urlDecode(String data, String charset) {
            try {
                return URLDecoder.decode(data, charset);
            } catch (UnsupportedEncodingException e) {
                return "";
            }
        }

        public static String desAsHexString(String data, String password) {
            try {
                return desAsHex(data.getBytes(), password.getBytes());
            } catch (Exception e) {
                e.printStackTrace();
                return "";
            }
        }

        public static String decryptDESFromHexString(String data, String password) {
            try {
                return new String(cipherDoFinal(hexStringToBytes(data), password.getBytes(), DES_ALGORITHM_NAME, CIPHER_ALGORITHM_ECB, Cipher.DECRYPT_MODE));
            } catch (Exception e) {
                return "";
            }
        }



    }
}
