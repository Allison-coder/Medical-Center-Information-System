package com.params.utils;

import java.util.regex.Pattern;

/**
 * @DESCRIPTION 正则表达式的工具类
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public class RegularExpressionUtils {

    // 手机号码的正则
    private static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("^(?:\\+86)?1[3-9]\\d{9}$");


    /**
     * 验证手机号是否合法
     * @param phoneNumber 要验证的手机号
     * @return 如果手机号合法，返回 true；否则返回 false
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return false;
        }
        return PHONE_NUMBER_PATTERN.matcher(phoneNumber).matches();
    }















}
