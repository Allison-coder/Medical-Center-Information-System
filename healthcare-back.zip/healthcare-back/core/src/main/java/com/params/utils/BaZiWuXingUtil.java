package com.params.utils;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.nlf.calendar.util.LunarUtil;
import com.params.bo.WuXingBO;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

import static com.params.utils.Lunar2Util.DING_XI;
import static com.params.utils.Lunar2Util.DING_XI_PARAMS;

/**
 * <pre>
 * 八字五行计算
 * </pre>
 *
 * @version 1.0.0
 * @Create 2024/1/16
 */
public class BaZiWuXingUtil {

    public static WuXingBO calculateWuXing(String baZi) {
        String[] baZiArr = baZi.split(" ");
        List<Map<String, BigDecimal>> wuXingList = new LinkedList<>();
        // 日干
        String dayGan = baZiArr[2].substring(0, 1);
        // 日干五行
        String dayGanWuXing = LunarUtil.WU_XING_GAN.get(dayGan);
        // 月支
        String monthZhi = baZiArr[1].substring(1);

        for (int i = 0; i < baZiArr.length; i++) {
            String gan = baZiArr[i].substring(0, 1);
            String zhi = baZiArr[i].substring(1);
            String[] zhiHideGan = LunarUtil.ZHI_HIDE_GAN.get(zhi).toArray(new String[0]);
            addWuXingToMap(wuXingList, gan, zhiHideGan, Lunar2Util.WU_XING_PROPORTION.get(i));
        }

        // 五行数组
        Map<String, BigDecimal> wuXingSumMap = new HashMap<>();
        for (Map<String, BigDecimal> wuXing : wuXingList) {
            String key = wuXing.keySet().iterator().next();
            BigDecimal value = wuXing.values().iterator().next();
            wuXingSumMap.merge(key, value, BigDecimal::add);
        }

        // 总数
        BigDecimal total = BigDecimal.ZERO;
        // 五行倍数计算
        for (Map.Entry<String, BigDecimal> entry : wuXingSumMap.entrySet()) {
            Float rate = Lunar2Util.WU_XING_RATE.get(monthZhi + entry.getKey().charAt(0));
            wuXingSumMap.put(entry.getKey(), entry.getValue().multiply(BigDecimal.valueOf(rate)).setScale(3, RoundingMode.HALF_UP));
            total = total.add(wuXingSumMap.get(entry.getKey()));
        }

        // 再计算十天干五行的比重：
        for (Map.Entry<String, BigDecimal> entry : wuXingSumMap.entrySet()) {
            wuXingSumMap.put(entry.getKey(), entry.getValue().divide(total, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100F)).setScale(2, RoundingMode.HALF_UP));
        }

        // 五行
        Map<String, BigDecimal> wuXingRate = new LinkedHashMap<>();
        wuXingRate.put("金", BigDecimal.ZERO);
        wuXingRate.put("木", BigDecimal.ZERO);
        wuXingRate.put("水", BigDecimal.ZERO);
        wuXingRate.put("火", BigDecimal.ZERO);
        wuXingRate.put("土", BigDecimal.ZERO);

        // 十神
        Map<String, BigDecimal> shiShenRate = new LinkedHashMap<>();
        shiShenRate.put("偏印", BigDecimal.ZERO);
        shiShenRate.put("正印", BigDecimal.ZERO);
        shiShenRate.put("比肩", BigDecimal.ZERO);
        shiShenRate.put("劫财", BigDecimal.ZERO);
        shiShenRate.put("食神", BigDecimal.ZERO);
        shiShenRate.put("伤官", BigDecimal.ZERO);
        shiShenRate.put("偏财", BigDecimal.ZERO);
        shiShenRate.put("正财", BigDecimal.ZERO);
        shiShenRate.put("七杀", BigDecimal.ZERO);
        shiShenRate.put("正官", BigDecimal.ZERO);


        Map<String, String> dayGanToShiShenMap = Lunar2Util.DAY_GAN_TO_SHI_SHEN.get(dayGan);
        for (Map.Entry<String, BigDecimal> entry : wuXingSumMap.entrySet()) {
            String shiShen = dayGanToShiShenMap.get(entry.getKey().substring(0, 1));
            String wx = entry.getKey().substring(1);
            wuXingRate.put(wx, wuXingRate.get(wx).add(entry.getValue()));
            shiShenRate.put(shiShen, shiShenRate.get(shiShen).add(entry.getValue()));
        }

        // 判断身强身弱
        String strength = strength(dayGanWuXing, wuXingRate);
        // 定喜用神
        Map<String, String> dingXi = dingXi(dayGan, strength, wuXingRate);
        // 五行属性
        String wuXingAttr = StrUtil.format("{}{}", dayGan, LunarUtil.WU_XING_GAN.get(dayGan));

        WuXingBO wuXingBO = new WuXingBO();
        wuXingBO.setWuXingRate(wuXingRate);
        wuXingBO.setShiShenRate(shiShenRate);
        wuXingBO.setDayGan(dayGan);
        wuXingBO.setDayGanWuXing(dayGanWuXing);
        wuXingBO.setStrength(strength);
        wuXingBO.setDingXi(dingXi);
        wuXingBO.setWuXingAttr(wuXingAttr);
        // 月支
        wuXingBO.setMonthZhi(monthZhi);
        // 月支主气藏干
        wuXingBO.setMonthZhiZhuQiHideGan(LunarUtil.ZHI_HIDE_GAN.get(monthZhi).get(0));
        // 月支主气藏干十神
        wuXingBO.setMonthZhiZhuQiHideGanShiShen(LunarUtil.SHI_SHEN.get(dayGan + wuXingBO.getMonthZhiZhuQiHideGan()));

        return wuXingBO;
    }

    /**
     * 计算同类五行和异类五行的比重，根据以下规则得出身强身弱
     *
     * @param dayGanWuXing
     * @param wuXingRate
     * @return
     */
    public static String strength(String dayGanWuXing, Map<String, BigDecimal> wuXingRate) {
        // 获取同类五行
        String[] wuXingSimilar = Lunar2Util.WU_XING_SIMILAR.get(dayGanWuXing);
        BigDecimal total = BigDecimal.ZERO;
        for (String wuXing : wuXingSimilar) {
            total = total.add(wuXingRate.get(wuXing));
        }

        return total.compareTo(BigDecimal.valueOf(48f)) >= 0 ? "身强" : "身弱";
    }

    /**
     * 定喜用神（简化版）
     *
     * @param dayGan
     * @param wuXingRate
     * @return
     */
    public static Map<String, String> dingXi(String dayGan, String strength, Map<String, BigDecimal> wuXingRate) {
        Map<String, String> result = new LinkedHashMap<>();

        boolean physicalStrength = "身强".equalsIgnoreCase(strength);

        DING_XI_PARAMS.get(dayGan + strength).forEach((key, value) -> {
            String shuxing;
            switch (key) {
                case 0:
                    shuxing = physicalStrength ?
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .min(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            ) :
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .min(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            );
                    if (result.containsValue(shuxing)) {
                        String finalShuxing = shuxing;
                        List<String> tmps = Arrays.stream(value).filter(s -> !s.equalsIgnoreCase(finalShuxing)).collect(Collectors.toList());
                        shuxing = (tmps.size() == 1) ? tmps.get(0) : (physicalStrength ?
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .min(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                ) :
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .min(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                )
                        );
                    }
                    result.put(DING_XI[key], shuxing);
                    break;
                case 1:
                    shuxing = physicalStrength ?
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .sorted(Map.Entry.<String, BigDecimal>comparingByValue().reversed())
                                            .skip(1)
                                            .findFirst()
                                            .get()
                                            .getKey()
                            ) :
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .max(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            );
                    if (result.containsValue(shuxing)) {
                        String finalShuxing = shuxing;
                        List<String> tmps = Arrays.stream(value).filter(s -> !s.equalsIgnoreCase(finalShuxing)).collect(Collectors.toList());
                        shuxing = (tmps.size() == 1) ? tmps.get(0) : (physicalStrength ?
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .sorted(Map.Entry.<String, BigDecimal>comparingByValue().reversed())
                                                .skip(1)
                                                .findFirst()
                                                .get()
                                                .getKey()
                                ) :
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .max(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                )
                        );
                    }
                    result.put(DING_XI[key], shuxing);
                    break;
                case 2:
                    shuxing = physicalStrength ?
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .max(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            ) :
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .max(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            );
                    if (result.containsValue(shuxing)) {
                        String finalShuxing = shuxing;
                        List<String> tmps = Arrays.stream(value).filter(s -> !s.equalsIgnoreCase(finalShuxing)).collect(Collectors.toList());
                        shuxing = (tmps.size() == 1) ? tmps.get(0) : (physicalStrength ?
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .max(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                ) :
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .max(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                )
                        );
                    }
                    result.put(DING_XI[key], shuxing);
                    break;
                case 3:
                    shuxing = physicalStrength ?
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .min(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            ) :
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .sorted(Map.Entry.<String, BigDecimal>comparingByValue().reversed())
                                            .skip(1)
                                            .findFirst()
                                            .get()
                                            .getKey()
                            );
                    if (result.containsValue(shuxing)) {
                        String finalShuxing = shuxing;
                        List<String> tmps = Arrays.stream(value).filter(s -> !s.equalsIgnoreCase(finalShuxing)).collect(Collectors.toList());
                        shuxing = (tmps.size() == 1) ? tmps.get(0) : (physicalStrength ?
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .min(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                ) :
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .sorted(Map.Entry.<String, BigDecimal>comparingByValue().reversed())
                                                .skip(1)
                                                .findFirst()
                                                .get()
                                                .getKey()
                                )
                        );
                    }
                    result.put(DING_XI[key], shuxing);
                    break;
                case 4:
                    shuxing = physicalStrength ?
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .max(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            ) :
                            (
                                    wuXingRate.entrySet().stream()
                                            .filter(tmp -> Lists.newArrayList(value).contains(tmp.getKey()))
                                            .min(Map.Entry.comparingByValue())
                                            .get()
                                            .getKey()
                            );
                    if (result.containsValue(shuxing)) {
                        String finalShuxing = shuxing;
                        List<String> tmps = Arrays.stream(value).filter(s -> !s.equalsIgnoreCase(finalShuxing)).collect(Collectors.toList());
                        shuxing = (tmps.size() == 1) ? tmps.get(0) : (physicalStrength ?
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .max(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                ) :
                                (
                                        wuXingRate.entrySet().stream()
                                                .filter(tmp -> tmps.contains(tmp.getKey()))
                                                .min(Map.Entry.comparingByValue())
                                                .get()
                                                .getKey()
                                )
                        );
                    }
                    result.put(DING_XI[key], shuxing);
                    break;
            }

        });

        return result;
    }

    private static void addWuXingToMap(List<Map<String, BigDecimal>> wuXingList, String gan, String[] zhiHideGan, Float... factors) {
        wuXingList.add(ImmutableMap.of(StrUtil.format("{}{}", gan, LunarUtil.WU_XING_GAN.get(gan)), BigDecimal.valueOf(factors[0])));
        for (int e = 0; e < zhiHideGan.length; e++) {
            wuXingList.add(ImmutableMap.of(StrUtil.format("{}{}", zhiHideGan[e], LunarUtil.WU_XING_GAN.get(zhiHideGan[e])), BigDecimal.valueOf(factors[e + 1])));
        }
    }
}
