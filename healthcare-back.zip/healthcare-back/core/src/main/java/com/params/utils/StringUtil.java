package com.params.utils;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.ValueFilter;
import com.google.common.collect.Maps;
import com.nlf.calendar.util.LunarUtil;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtil {

    public static Map<String, String> queryStrToMap(@NotNull String queryStr) {
        if (isEmpty(queryStr)) {
            return new HashMap<>();
        }
        int start = queryStr.indexOf("?");
        if (start > 0 && queryStr.length() > start + 1) {
            queryStr = queryStr.substring(start + 1);
        }
        Map<String, String> map = Maps.newHashMap();
        String[] arr = queryStr.split("&");
        for (String kvStr : arr) {
            String[] kv = kvStr.split("=");
            if (kv.length >= 2) {
                map.put(kv[0], kv[1]);
            } else if (kv.length > 0) {
                map.put(kv[0], "");
            }
        }
        return map;
    }

    public static boolean hasBlank(String... objs) {
        if (objs == null) {
            return true;
        }
        for (Object obj : objs) {
            if (obj == null) {
                return true;
            }
        }
        return false;
    }

    public static String getYearInChinese(Integer year) {
        String y = year + "";
        StringBuilder s = new StringBuilder();
        for (int i = 0, j = y.length(); i < j; i++) {
            s.append(LunarUtil.NUMBER[y.charAt(i) - '0']);
        }
        return s.toString();
    }

    /**
     * 排序
     *
     * @param params
     * @return
     */
    private static String sortMapString(Map params, boolean ignoreCase) {
        if (params == null) {
            return "";
        }
        StringBuffer content = new StringBuffer();
        ArrayList keys = new ArrayList(params.keySet());
        if (ignoreCase) {
            Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
        } else {
            Collections.sort(keys);
        }
        String key = null;
        Object value = null;
        for (int i = 0; i < keys.size(); ++i) {
            key = (String) keys.get(i);
            value = params.get(key);
            if (value != null && !(value instanceof String)) {
                value = String.valueOf(value);
            }
            if (value == null) {
                value = "";
            }
            content.append((i == 0 ? "" : "&") + key + "=" + value);
        }
        return content.toString();
    }

    /**
     * 忽略大小写
     *
     * @param params
     * @return
     */
    public static String getSortMapStringIgnoreCase(Map params) {
        return sortMapString(params, true);
    }

    public static String getSortMapString(Map params) {
        return sortMapString(params, false);
    }


    /**
     * 根据pattern 把字符串拆分成map(根据=拆分键值)
     *
     * @param paramString
     * @param pattern
     * @return
     */
    public static Map<String, String> patternStringParamToMap(String paramString, String pattern) {
        Map paramMap = new HashMap<String, String>();
        if (StringUtils.isEmpty(paramString)) {
            return paramMap;
        }
        String[] arr = paramString.split(pattern);
        String[] arrSon = null;
        for (String vv : arr) {
            arrSon = vv.split("=");
            //解析出键值
            if (arrSon.length > 1) {
                //正确解析
                paramMap.put(arrSon[0], arrSon[1]);
            } else {
                paramMap.put(arrSon[0], "");
            }
        }
        return paramMap;
    }

    public static boolean validMobile(String mobile) {
        if (StringUtils.isEmpty(mobile)) {
            return false;
        }
        return Pattern.matches("^1\\d{10}$", mobile);
    }

    /**
     * 获取用户真实IP地址，不使用request.getRemoteAddr()的原因是有可能用户使用了代理软件方式避免真实IP地址,
     * 可是，如果通过了多级反向代理的话，X-Forwarded-For的值并不止一个，而是一串IP值
     *
     * @return ip
     */
    public static String getIpAddr(HttpServletRequest request) {
        try {
            String ip = request.getHeader("x-forwarded-for");
            if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
                // 多次反向代理后会有多个ip值，第一个ip才是真实ip
                if (ip.indexOf(",") != -1) {
                    ip = ip.split(",")[0];
                }
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("HTTP_CLIENT_IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("HTTP_X_FORWARDED_FOR");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("X-Real-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
            }
            return ip;
        } catch (Exception e) {
            return "";
        }
    }


    public static Map getRequestParam(HttpServletRequest req) {
        Map<String, String[]> requestMap = req.getParameterMap();
        Map<String, String> paramsMap = new HashMap<>();
        if (requestMap == null || requestMap.size() == 0) {
            return paramsMap;
        }
        requestMap.forEach((key, values) -> {
            String strs = "";
            for (String value : values) {
                strs = strs + value;
            }
            paramsMap.put(key, strs);
        });
        return paramsMap;
    }

    public static Map getRequestParam(Map<String, String[]> requestMap) {
        Map<String, String> paramsMap = new HashMap<>();
        if (requestMap == null || requestMap.size() == 0) {
            return paramsMap;
        }
        requestMap.forEach((key, values) -> {
            String strs = "";
            for (String value : values) {
                strs = strs + value;
            }
            paramsMap.put(key, strs);
        });
        return paramsMap;
    }

    public static boolean verityEmail(String email) {
        try {
            String check = "^([a-z0-9A-Z]+[-|_|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
            Pattern regex = Pattern.compile(check);
            Matcher matcher = regex.matcher(email);
            return matcher.matches();
        } catch (Exception e) {
            return true;
        }
    }

    public static boolean isContainsStatus(String status, String... values) {
        if (status == null || values == null) {
            return false;
        }
        for (int i = 0, size = values.length; i < size; i++) {
            if (status.equals(values[i])) {
                return true;
            }
        }
        return false;
    }

    public static Map buildRequestParam(JSONObject dataMap, String appId, String secret) {
        Map map = new HashMap();
        map.put("appId", appId);
        map.put("signType", "aSHA256");
        map.put("serialId", RandomUtil.randomStringWithLetter(32));
        map.put("timestamp", DateUtil.currentTimeString());
        map.put("sign", ArithmeticUtil.sha256AsHex(StringUtil.getSortMapString(dataMap) + "&" + secret));
        map.put("reqData", toJsonString(dataMap));
        return map;
    }

    public static String getSecretByUid(int uid) {
        String[] arr = new String[]{"2", "1", "g", "2", "q", "2", "y", "o"};
        String[] arr1 = new String[]{"1", "4", "g", "w", "b", "e", "w", "1"};
        String dstr = String.valueOf(uid);
        boolean isJ = uid % 2 == 0;
        int len = dstr.length();
        if (len >= 8) {
            return dstr.substring(dstr.length() - 8);
        } else {
            for (int i = 0; i < 8 - len; i++) {
                dstr = isJ ? (dstr + arr[i]) : (dstr + arr1[i]);
            }
            return dstr;
        }
    }

    public static String getPhotoInfoDesStr(int photoInfoId, int uid) {
        return ArithmeticUtil.desAsHexString(String.valueOf(photoInfoId), getSecretByUid(uid));
    }

    public static String toJsonString(JSONObject jsonObject) {
        return JSONObject.toJSONString(jsonObject, formatJsonValue());
    }

    public static ValueFilter formatJsonValue() {
        return new ValueFilter() {
            @Override
            public Object process(Object object, String name, Object value) {
                if (value == null) {
                    return "";
                }
                return value;
            }
        };
    }


    public static Map removeBigParam(Map<String, String> paramMap) {
        if (paramMap == null) {
            return new HashMap();
        }
        for (String key : paramMap.keySet()) {
            String vv = paramMap.get(key);
            if (vv != null && vv.length() > 1024) {
                paramMap.put(key, "big value");
            }
        }
        return paramMap;
    }

    /**
     * 是否签名正确,规则是:按参数名称a-z排序,遇到空值的参数不参加签名。
     *
     * @return boolean
     */
    public static boolean isWeixinPaySign(SortedMap<Object, Object> packageParams, String API_KEY) {
        StringBuffer sb = new StringBuffer();
        Set es = packageParams.entrySet();
        Iterator it = es.iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String k = (String) entry.getKey();
            String v = (String) entry.getValue();
            if (!"sign".equals(k) && null != v && !"".equals(v)) {
                sb.append(k + "=" + v + "&");
            }
        }
        sb.append("key=" + API_KEY);
        // 算出摘要
        String mysign = ArithmeticUtil.md5AsHex(sb.toString()).toLowerCase();
        String tenpaySign = ((String) packageParams.get("sign")).toLowerCase();
        return tenpaySign.equals(mysign);
    }

    /**
     * @return
     * @author
     * @date 2016-4-22
     * @Description：sign签名 编码格式
     * 请求参数
     */
    public static String createWeixinSign(Map<String, Object> params, String API_KEY) {
        List<String> keys = new ArrayList(params.keySet());
        Collections.sort(keys);
        StringBuffer sb = new StringBuffer();
        for (String k : keys) {
            String v = (String) params.get(k);
            if (null != v && !"".equals(v) && !"sign".equals(k) && !"key".equals(k)) {
                sb.append(k + "=" + v + "&");
            }
        }
        sb.append("key=" + API_KEY);
        String sign = ArithmeticUtil.md5AsHex(sb.toString()).toUpperCase();
        return sign;
    }

    /**
     * @param parameters 请求参数
     * @return
     * @author
     * @date 2016-4-22
     * @Description：将请求参数转换为xml格式的string
     */
    public static String getWeixinRequestXml(Map<String, Object> parameters) {
        StringBuffer sb = new StringBuffer();
        sb.append("<xml>");
        Set es = parameters.entrySet();
        Iterator it = es.iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String k = (String) entry.getKey();
            Object vv = entry.getValue();
            String v = vv == null ? "" : (String) vv;
            if ("scene_info".equalsIgnoreCase(k) || "attach".equalsIgnoreCase(k) || "body".equalsIgnoreCase(k) || "sign".equalsIgnoreCase(k)) {
                sb.append("<" + k + ">" + "<![CDATA[" + v + "]]></" + k + ">");
            } else {
                sb.append("<" + k + ">" + v + "</" + k + ">");
            }
        }
        sb.append("</xml>");
        return sb.toString();
    }

    public static String setToString(Set<String> sets) {
        StringBuffer buffer = new StringBuffer();
        for (String s : sets) {
            buffer.append(s);
        }
        return buffer.toString();
    }


    /**
     * 获取当前时间的检测配置
     *
     * @param
     * @return
     */
    public static int getCheckProccessType(String checkStr) {
        return getCheckProccessType(checkStr, new Date());
    }

    public static int getCheckProccessType(String checkStr, Date date) {
        try {
            JSONObject check = JSONObject.parseObject(checkStr);
            int checkType = check.getInteger("defaultCheckType");
            JSONArray arr = check.getJSONArray("checkArr");
            int hour = DateUtil.getHour(date);
            for (int i = 0, size = arr.size(); i < size; i++) {
                int max = arr.getJSONObject(i).getInteger("max");
                int min = arr.getJSONObject(i).getInteger("min");
                if (min <= hour && hour < max) {
                    return arr.getJSONObject(i).getInteger("checkType");
                }
            }
            return checkType;
        } catch (Exception e) {
            return 2;
        }
    }

    /**
     * 获取当前时间的处理类型
     *
     * @param checkStr
     * @return
     */
    public static int getDealProccessType(String checkStr) {
        try {
            JSONObject check = JSONObject.parseObject(checkStr);
            int dealType = check.getInteger("defaultDealType");
            JSONArray arr = check.getJSONArray("checkArr");
            int hour = DateUtil.getHour(new Date());
            for (int i = 0, size = arr.size(); i < size; i++) {
                int max = arr.getJSONObject(i).getInteger("max");
                int min = arr.getJSONObject(i).getInteger("min");
                if (min <= hour && hour < max) {
                    dealType = arr.getJSONObject(i).getInteger("dealType");
                }
            }
            int week = cn.hutool.core.date.DateUtil.dayOfWeek(new Date());
            JSONArray weekArr = check.getJSONArray("week");
            if (weekArr != null && weekArr.contains(week)) { //周末使用默认的检测策略
                return check.getInteger("defaultDealType");
            } else {
                return dealType;
            }
        } catch (Exception e) {
            return 1;
        }
    }

    /**
     * 获取相片处理模式
     *
     * @param checkStr
     * @return
     */
    public static int getPhotoDealMode(String checkStr) {
        try {
            JSONObject check = JSONObject.parseObject(checkStr);
            int dealType = check.getInteger("defaultDealMode");
            JSONArray arr = check.getJSONArray("checkArr");
            int hour = DateUtil.getHour(new Date());
            for (int i = 0, size = arr.size(); i < size; i++) {
                int max = arr.getJSONObject(i).getInteger("max");
                int min = arr.getJSONObject(i).getInteger("min");
                if (min <= hour && hour < max) {
                    dealType = arr.getJSONObject(i).getInteger("dealMode");
                }
            }
            int week = cn.hutool.core.date.DateUtil.dayOfWeek(new Date());
            JSONArray weekArr = check.getJSONArray("week");
            if (weekArr != null && weekArr.contains(week)) { //周末使用默认的检测策略
                return check.getInteger("defaultDealMode");
            } else {
                return dealType;
            }
        } catch (Exception e) {
            return 1;
        }
    }

    /**
     * 非服务时间是否需要弹框
     *
     * @return 0 表示人工处理 弹框 1 AI处理不弹
     */
    public static int needAlertNoticeNotInServiceTime(String checkStr) {
        int dealType = getDealProccessType(checkStr);
        return (dealType == 0 || dealType == 5) ? 0 : 1;
    }


    public static JSONObject getRequestHead(HttpServletRequest request) {
        JSONObject da = new JSONObject();
        da.put("appId", request.getHeader("appId"));
        da.put("token", request.getHeader("token"));
        da.put("uid", request.getHeader("userId"));
        da.put("vid", request.getHeader("vid"));
        return da;
    }

    public static boolean isEmpty(String str) {
        return str == null || "".equals(str);
    }

    public static String defaultIfBlank(String str, String defaultValue) {
        return (str == null || "".equalsIgnoreCase(str)) ? defaultValue : str;
    }

    public static String[] listToArry(List<String> list) {
        String[] arr = new String[list.size()];
        list.toArray(arr);
        return arr;
    }

    public static String getDeviceInfo(HttpServletRequest request) {
        try {
            String agent = request.getHeader("user-agent");
            Matcher mat = Pattern.compile("(\\(.*?\\))").matcher(agent);
            while (mat.find()) {
                String st = mat.group().replace("(", "").replace(")", "");
                return st.length() > 255 ? st.substring(0, 240) : st;
            }
        } catch (Exception e) {
        }
        return "";
    }

    public static JSONObject getOrderNum(String orderNumFormat) {
        String merchantPaymentInfoId = orderNumFormat.substring(orderNumFormat.length() - 4, orderNumFormat.length());
        String orderNum = orderNumFormat.substring(0, orderNumFormat.length() - 4);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("merchantPaymentInfoId", merchantPaymentInfoId);
        jsonObject.put("orderNum", orderNum);
        return jsonObject;
    }

    public static boolean compareStrings(String str1, String str2, boolean ignoreCase) {
        if (str1 != null && str2 != null) {
            return ignoreCase ? str1.equalsIgnoreCase(str2) : str1.equals(str2);
        }
        return false;
    }


    public static BigDecimal convertFee(String strFee) {
        try {
            return BigDecimal.valueOf(Double.valueOf(strFee));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * map字符串转换json字符串
     */
    public static String convertMapStr2Json(String mapString) {
        JSONObject result = new JSONObject();
        String[] dataArr = mapString.substring(1, mapString.length() - 1).split(",");
        for (String keyVal : dataArr) {
            String[] tempArr = keyVal.split("=");
            result.put((tempArr[0].trim()), tempArr[1]);
        }
        return result.toJSONString();
    }


}
