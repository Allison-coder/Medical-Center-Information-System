package com.params.utils;


import cn.hutool.core.lang.UUID;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Random;

import static com.params.utils.ArithmeticUtil.md5AsHex;

public class RandomUtil {
    /**
     * 获取随机appId
     *
     * @return
     */
    public static String randomAppId() {
        return "cs" + md5AsHex(DateUtil.currentTimeString() + randomStringWithLetter(5)).substring(0, 16);
    }



    /**
     * 生成招行随机客户协议号
     *
     * @return
     */
    public static String rndomCmbAgrNo() {
        return DateUtil.currentTimeString() + randomString(8);
    }

    /**
     * 生成随机密钥
     *
     * @return
     */
    public static String randomSecret() {
        return md5AsHex(DateUtil.currentTimeString()).substring(0, 12) + randomStringWithLetter(6);
    }

    /**
     * 获取随机文件名
     *
     * @return
     */
    public static String randomFileName() {
        return DateUtil.currentTimeString() + randomString(4);
    }


    /**
     * @param length 表示生成几位随机数
     * @return
     * @DO 生成随机数带小写字母
     * @author lf
     * a-z /97-122   A-Z /65-90  0-9 /48-57
     */
    public static String randomStringWithLetter(int length) {
        StringBuffer buffer = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            if (random.nextInt(2) == 0) {
                buffer.append((char) (random.nextInt(26) + 97));
            } else {
                buffer.append(String.valueOf(random.nextInt(10)));
            }
        }
        return buffer.toString();
    }

    public static String randomString(int length) {
        StringBuffer buffer = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            buffer.append(String.valueOf(random.nextInt(10)));
        }
        return buffer.toString();
    }

    /**
     * 生产静态文件随机数
     *
     * @param length
     * @return
     */
    public static String randomStaticFile(int length) {
        return DateUtil.currentTimeString() + randomString(4);
    }


    /**
     * 生成随机支付记录num
     *
     * @return
     */
    public static String randomTradeNum() {
        return timeStr() + randomString(8);
    }

    public static String timeStr() {
        return DateUtil.formatDateToString(new Date(), "yyMMddHHmmssSSS");
    }

    public static String randomDivideLogNum() {
        return timeStr() + randomString(8);
    }

    public static String randomPrintTaskNum() {
        return timeStr() + randomString(6);
    }

    /**
     * 订单号随机
     *
     * @return
     */
    public static String randomOrderNum() {
        return randomOrderNum("O");
    }

    /**
     * 订单号随机
     *
     * @param prefix
     * @return
     */
    public static synchronized String randomOrderNum(String prefix) {
        return prefix + timeStr() + randomString(6);
    }

    public static String randomNumPre(String pre) {
        return pre + DateUtil.formatDateToString(new Date(), "yyMMddssHHmmssSSS") + randomString(6);
    }

    public static synchronized String randomSerialNo() {
        return timeStr() + randomString(6);
    }

    /**
     * 用户openid生成
     *
     * @return
     */
    public static String randomOpenId() {
        return "csop" + DateUtil.formatDateToString(new Date(), "yyyyMMddHHmmssSS") + randomStringWithLetter(10);
    }

    public static String randomUserVid() {
        // return DateUtil.currentTimeString() + randomString(3);
        return DateUtil.currentTimeString() + UUID.randomUUID().toString(true);
    }

    /**
     * 生成一字母+指定长度随机数字
     * @param numberLength
     * @return
     */
    public static String randomStringLetterAndNum(int letterLength,int numberLength) {
        Random random = new Random();
        // 生成一个随机的小写字母

        StringBuilder letters = new StringBuilder();
        for (int i = 0; i < letterLength; i++) {
            char letter = (char) ('a' + random.nextInt(26));
            letters.append(letter);
        }



        // 根据指定的长度生成随机数字
        int maxNumber = (int) Math.pow(10, numberLength);  // 计算最大值
        int number = random.nextInt(maxNumber);  // 生成随机数字
        String formattedNumber = String.format("%0" + numberLength + "d", number);  // 格式化数字

        // 拼接生成的字母和数字
        return letters.toString() + formattedNumber;
    }

    public static String randomVeriCode(int size) {
        return randomString(size);
    }

    public static String randomMerchantCode() {
        return md5AsHex(randomStringWithLetter(16)).substring(0, 16);
    }

    public static synchronized String randomPictureId() {
        return DateUtil.formatDateToString(new Date(), "yyMMddHHmmssSSS") + randomString(6);
    }

    public static void main(String[] args) {
        long aa = Long.parseLong(DateUtil.formatDateToString(new Date(), "yyyyMMddHHmmssSSS"));
        long bb = Long.parseLong(LocalDateTime.of(2000, 1, 1, 1, 1, 1, 1).format(DateTimeFormatter.ofPattern("yyyyMMddssHHmmssSSS")));
        System.out.println(aa);
        System.out.println(bb);
        System.out.println(aa - bb);
    }
}
