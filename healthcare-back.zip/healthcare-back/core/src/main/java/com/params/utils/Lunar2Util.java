package com.params.utils;

import com.google.common.collect.ImmutableMap;
import com.nlf.calendar.util.LunarUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 * @Create 2024/1/16
 */
public class Lunar2Util extends LunarUtil {
    /**
     * 五行比重
     */
    public static final Map<Integer, Float[]> WU_XING_PROPORTION = new HashMap<Integer, Float[]>() {
        private static final long serialVersionUID = -1;

        {
            put(0, new Float[]{1F, 1.2F, 0.7F, 0.5F}); // 年柱
            put(1, new Float[]{1F, 2F, 1.2F, 0.8F}); // 月柱
            put(2, new Float[]{0F, 1.5F, 0.9F, 0.6F}); // 日柱
            put(3, new Float[]{1F, 1.2F, 0.7F, 0.5F}); // 时柱
        }
    };

    /**
     * 五行同类
     */
    public static final Map<String, String[]> WU_XING_SIMILAR = new HashMap<String, String[]>() {
        private static final long serialVersionUID = -1;

        {
            put("金", new String[]{"金", "土"});
            put("木", new String[]{"木", "水"});
            put("水", new String[]{"水", "金"});
            put("火", new String[]{"火", "木"});
            put("土", new String[]{"土", "火"});
        }
    };

    /**
     * 五行异类
     */
    public static final Map<String, String[]> WU_XING_ABERRATION = new HashMap<String, String[]>() {
        private static final long serialVersionUID = -1;

        {
            put("金", new String[]{"木", "水", "火"});
            put("木", new String[]{"金", "火", "土"});
            put("水", new String[]{"木", "火", "土"});
            put("火", new String[]{"金", "水", "土"});
            put("土", new String[]{"金", "土", "水"});
        }
    };


    /**
     * 日干转化十神
     */
    public static final Map<String, Map<String, String>> DAY_GAN_TO_SHI_SHEN = new HashMap<String, Map<String, String>>() {
        private static final long serialVersionUID = -1;

        {
            put("甲", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "比肩");
                    put("乙", "劫财");
                    put("丙", "食神");
                    put("丁", "伤官");
                    put("戊", "偏财");
                    put("己", "正财");
                    put("庚", "七杀");
                    put("辛", "正官");
                    put("壬", "偏印");
                    put("癸", "正印");
                }
            });

            put("乙", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "劫财");
                    put("乙", "比肩");
                    put("丙", "伤官");
                    put("丁", "食神");
                    put("戊", "正财");
                    put("己", "偏财");
                    put("庚", "正官");
                    put("辛", "七杀");
                    put("壬", "正印");
                    put("癸", "偏印");
                }
            });

            put("丙", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "偏印");
                    put("乙", "正印");
                    put("丙", "比肩");
                    put("丁", "劫财");
                    put("戊", "食神");
                    put("己", "伤官");
                    put("庚", "偏财");
                    put("辛", "正财");
                    put("壬", "七杀");
                    put("癸", "正官");
                }
            });

            put("丁", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "正印");
                    put("乙", "偏印");
                    put("丙", "劫财");
                    put("丁", "比肩");
                    put("戊", "伤官");
                    put("己", "食神");
                    put("庚", "正财");
                    put("辛", "偏财");
                    put("壬", "正官");
                    put("癸", "七杀");
                }
            });


            put("戊", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "七杀");
                    put("乙", "正官");
                    put("丙", "偏印");
                    put("丁", "正印");
                    put("戊", "比肩");
                    put("己", "劫财");
                    put("庚", "食神");
                    put("辛", "伤官");
                    put("壬", "偏财");
                    put("癸", "正财");
                }
            });

            put("己", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "正官");
                    put("乙", "七杀");
                    put("丙", "正印");
                    put("丁", "偏印");
                    put("戊", "劫财");
                    put("己", "比肩");
                    put("庚", "伤官");
                    put("辛", "食神");
                    put("壬", "正财");
                    put("癸", "偏财");
                }
            });

            put("庚", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "偏财");
                    put("乙", "正财");
                    put("丙", "七杀");
                    put("丁", "正官");
                    put("戊", "偏印");
                    put("己", "正印");
                    put("庚", "比肩");
                    put("辛", "劫财");
                    put("壬", "食神");
                    put("癸", "伤官");
                }
            });

            put("辛", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "正财");
                    put("乙", "偏财");
                    put("丙", "正官");
                    put("丁", "七杀");
                    put("戊", "正印");
                    put("己", "偏印");
                    put("庚", "劫财");
                    put("辛", "比肩");
                    put("壬", "伤官");
                    put("癸", "食神");
                }
            });

            put("壬", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "食神");
                    put("乙", "伤官");
                    put("丙", "偏财");
                    put("丁", "正财");
                    put("戊", "七杀");
                    put("己", "正官");
                    put("庚", "偏印");
                    put("辛", "正印");
                    put("壬", "比肩");
                    put("癸", "劫财");
                }
            });

            put("癸", new HashMap<String, String>() {
                private static final long serialVersionUID = -1;

                {
                    put("甲", "伤官");
                    put("乙", "食神");
                    put("丙", "正财");
                    put("丁", "偏财");
                    put("戊", "正官");
                    put("己", "七杀");
                    put("庚", "正印");
                    put("辛", "偏印");
                    put("壬", "劫财");
                    put("癸", "比肩");
                }
            });
        }
    };
    /**
     * 五行倍数
     */
    public static final Map<String, Float> WU_XING_RATE = new HashMap<String, Float>() {
        private static final long serialVersionUID = -1;

        {
            put("寅甲", 1.2F);
            put("寅乙", 1.15F);
            put("寅丙", 1.1F);
            put("寅丁", 1.05F);
            put("寅戊", 0.75F);
            put("寅己", 0.8F);
            put("寅庚", 0.75F);
            put("寅辛", 0.8F);
            put("寅壬", 0.95F);
            put("寅癸", 1F);
            put("卯甲", 1.15F);
            put("卯乙", 1.2F);
            put("卯丙", 1.05F);
            put("卯丁", 1.1F);
            put("卯戊", 0.8F);
            put("卯己", 0.75F);
            put("卯庚", 0.8F);
            put("卯辛", 0.75F);
            put("卯壬", 1F);
            put("卯癸", 0.95F);
            put("辰甲", 0.95F);
            put("辰乙", 0.95F);
            put("辰丙", 1F);
            put("辰丁", 1F);
            put("辰戊", 1.2F);
            put("辰己", 1.15F);
            put("辰庚", 0.85F);
            put("辰辛", 0.85F);
            put("辰壬", 0.9F);
            put("辰癸", 0.9F);
            put("巳甲", 0.95F);
            put("巳乙", 1F);
            put("巳丙", 1.2F);
            put("巳丁", 1.15F);
            put("巳戊", 1.1F);
            put("巳己", 1.05F);
            put("巳庚", 1.1F);
            put("巳辛", 1.05F);
            put("巳壬", 0.75F);
            put("巳癸", 0.8F);
            put("午甲", 1F);
            put("午乙", 0.95F);
            put("午丙", 1.15F);
            put("午丁", 1.2F);
            put("午戊", 1.05F);
            put("午己", 1.1F);
            put("午庚", 1.05F);
            put("午辛", 1.1F);
            put("午壬", 0.8F);
            put("午癸", 0.75F);
            put("未甲", 0.9F);
            put("未乙", 0.9F);
            put("未丙", 0.95F);
            put("未丁", 0.95F);
            put("未戊", 1.15F);
            put("未己", 1.2F);
            put("未庚", 1F);
            put("未辛", 1F);
            put("未壬", 0.85F);
            put("未癸", 0.85F);
            put("申甲", 0.75F);
            put("申乙", 0.8F);
            put("申丙", 0.95F);
            put("申丁", 1F);
            put("申戊", 0.95F);
            put("申己", 1F);
            put("申庚", 1.2F);
            put("申辛", 1.15F);
            put("申壬", 1.1F);
            put("申癸", 1.05F);
            put("酉甲", 0.8F);
            put("酉乙", 0.75F);
            put("酉丙", 1F);
            put("酉丁", 0.95F);
            put("酉戊", 1F);
            put("酉己", 0.95F);
            put("酉庚", 1.15F);
            put("酉辛", 1.2F);
            put("酉壬", 1.05F);
            put("酉癸", 1.1F);
            put("戌甲", 0.85F);
            put("戌乙", 0.85F);
            put("戌丙", 0.9F);
            put("戌丁", 0.9F);
            put("戌戊", 1.2F);
            put("戌己", 1.15F);
            put("戌庚", 0.95F);
            put("戌辛", 0.95F);
            put("戌壬", 1F);
            put("戌癸", 1F);
            put("亥甲", 1.1F);
            put("亥乙", 1.05F);
            put("亥丙", 0.75F);
            put("亥丁", 0.8F);
            put("亥戊", 0.85F);
            put("亥己", 0.9F);
            put("亥庚", 0.95F);
            put("亥辛", 1F);
            put("亥壬", 1.2F);
            put("亥癸", 1.15F);
            put("子甲", 1.05F);
            put("子乙", 1.1F);
            put("子丙", 0.8F);
            put("子丁", 0.75F);
            put("子戊", 0.9F);
            put("子己", 0.85F);
            put("子庚", 1F);
            put("子辛", 0.95F);
            put("子壬", 1.15F);
            put("子癸", 1.2F);
            put("丑甲", 1F);
            put("丑乙", 1F);
            put("丑丙", 0.85F);
            put("丑丁", 0.85F);
            put("丑戊", 1.15F);
            put("丑己", 1.2F);
            put("丑庚", 0.9F);
            put("丑辛", 0.9F);
            put("丑壬", 0.95F);
            put("丑癸", 0.95F);
        }
    };

    /**
     * 自坐
     */
    public static final Map<String, String> ZHIZUO = new HashMap<String, String>() {
        private static final long serialVersionUID = -1;

        {
            put("甲子", "沐浴");
            put("甲丑", "冠带");
            put("甲寅", "临官");
            put("甲卯", "帝旺");
            put("甲辰", "衰");
            put("甲巳", "病");
            put("甲午", "死");
            put("甲未", "墓");
            put("甲申", "绝");
            put("甲酉", "胎");
            put("甲戌", "养");
            put("甲亥", "长生");
            put("乙子", "病");
            put("乙丑", "衰");
            put("乙寅", "帝旺");
            put("乙卯", "临官");
            put("乙辰", "冠带");
            put("乙巳", "沐浴");
            put("乙午", "长生");
            put("乙未", "养");
            put("乙申", "胎");
            put("乙酉", "绝");
            put("乙戌", "墓");
            put("乙亥", "死");
            put("丙子", "胎");
            put("丙丑", "养");
            put("丙寅", "长生");
            put("丙卯", "沐浴");
            put("丙辰", "冠带");
            put("丙巳", "临官");
            put("丙午", "帝旺");
            put("丙未", "衰");
            put("丙申", "病");
            put("丙酉", "死");
            put("丙戌", "墓");
            put("丙亥", "绝");
            put("丁子", "绝");
            put("丁丑", "墓");
            put("丁寅", "死");
            put("丁卯", "病");
            put("丁辰", "衰");
            put("丁巳", "帝旺");
            put("丁午", "临官");
            put("丁未", "冠带");
            put("丁申", "沐浴");
            put("丁酉", "长生");
            put("丁戌", "养");
            put("丁亥", "胎");
            put("戊子", "胎");
            put("戊丑", "养");
            put("戊寅", "长生");
            put("戊卯", "沐浴");
            put("戊辰", "冠带");
            put("戊巳", "临官");
            put("戊午", "帝旺");
            put("戊未", "衰");
            put("戊申", "病");
            put("戊酉", "死");
            put("戊戌", "墓");
            put("戊亥", "绝");
            put("己子", "绝");
            put("己丑", "墓");
            put("己寅", "死");
            put("己卯", "病");
            put("己辰", "衰");
            put("己巳", "帝旺");
            put("己午", "临官");
            put("己未", "冠带");
            put("己申", "沐浴");
            put("己酉", "长生");
            put("己戌", "养");
            put("己亥", "胎");
            put("庚子", "死");
            put("庚丑", "墓");
            put("庚寅", "绝");
            put("庚卯", "胎");
            put("庚辰", "养");
            put("庚巳", "长生");
            put("庚午", "沐浴");
            put("庚未", "冠带");
            put("庚申", "临官");
            put("庚酉", "帝旺");
            put("庚戌", "衰");
            put("庚亥", "病");
            put("辛子", "长生");
            put("辛丑", "养");
            put("辛寅", "胎");
            put("辛卯", "绝");
            put("辛辰", "墓");
            put("辛巳", "死");
            put("辛午", "病");
            put("辛未", "衰");
            put("辛申", "帝旺");
            put("辛酉", "临官");
            put("辛戌", "冠带");
            put("辛亥", "沐浴");
            put("壬子", "帝旺");
            put("壬丑", "衰");
            put("壬寅", "病");
            put("壬卯", "死");
            put("壬辰", "墓");
            put("壬巳", "绝");
            put("壬午", "胎");
            put("壬未", "养");
            put("壬申", "长生");
            put("壬酉", "沐浴");
            put("壬戌", "冠带");
            put("壬亥", "临官");
            put("癸子", "临官");
            put("癸丑", "冠带");
            put("癸寅", "沐浴");
            put("癸卯", "长生");
            put("癸辰", "养");
            put("癸巳", "胎");
            put("癸午", "绝");
            put("癸未", "墓");
            put("癸申", "死");
            put("癸酉", "病");
            put("癸戌", "衰");
            put("癸亥", "帝旺");
        }
    };

    /**
     * 十神
     *
     * @param dayGan
     * @param zhi
     * @return
     */
    public static List<String> getShiShenZhi(String dayGan, String zhi) {
        List<String> hideGan = LunarUtil.ZHI_HIDE_GAN.get(zhi);
        List<String> l = new ArrayList<>(hideGan.size());
        for (String gan : hideGan) {
            l.add(LunarUtil.SHI_SHEN.get(dayGan + gan));
        }
        return l;
    }

    public static final String[] DING_XI = new String[]{"用神", "喜神", "忌神", "仇神", "闲神"};

    /**
     * 定喜用神（简化版）
     */
    public static final Map<String, Map<Integer, String[]>> DING_XI_PARAMS = new HashMap<String, Map<Integer, String[]>>() {
        private static final long serialVersionUID = -1;

        {
            put("甲身强", ImmutableMap.of(
                    0, new String[]{"金", "土", "火"},
                    1, new String[]{"金", "土", "火"},
                    2, new String[]{"水", "木"},
                    3, new String[]{"水", "木"},
                    4, new String[]{"金", "土", "火"}
            ));

            put("甲身弱", ImmutableMap.of(
                    0, new String[]{"水", "木"},
                    1, new String[]{"水", "木"},
                    2, new String[]{"金", "土", "火"},
                    3, new String[]{"金", "土", "火"},
                    4, new String[]{"金", "土", "火"}
            ));

            put("乙身强", ImmutableMap.of(
                    0, new String[]{"金", "土", "火"},
                    1, new String[]{"金", "土", "火"},
                    2, new String[]{"水", "木"},
                    3, new String[]{"水", "木"},
                    4, new String[]{"金", "土", "火"}
            ));

            put("乙身弱", ImmutableMap.of(
                    0, new String[]{"水", "木"},
                    1, new String[]{"水", "木"},
                    2, new String[]{"金", "土", "火"},
                    3, new String[]{"金", "土", "火"},
                    4, new String[]{"金", "土", "火"}
            ));

            put("丙身强", ImmutableMap.of(
                    0, new String[]{"金", "水", "土"},
                    1, new String[]{"金", "水", "土"},
                    2, new String[]{"火", "木"},
                    3, new String[]{"火", "木"},
                    4, new String[]{"金", "水", "土"}
            ));

            put("丙身弱", ImmutableMap.of(
                    0, new String[]{"火", "木"},
                    1, new String[]{"火", "木"},
                    2, new String[]{"金", "水", "土"},
                    3, new String[]{"金", "水", "土"},
                    4, new String[]{"金", "水", "土"}
            ));

            put("丁身强", ImmutableMap.of(
                    0, new String[]{"金", "水", "土"},
                    1, new String[]{"金", "水", "土"},
                    2, new String[]{"火", "木"},
                    3, new String[]{"火", "木"},
                    4, new String[]{"金", "水", "土"}
            ));

            put("丁身弱", ImmutableMap.of(
                    0, new String[]{"火", "木"},
                    1, new String[]{"火", "木"},
                    2, new String[]{"金", "水", "土"},
                    3, new String[]{"金", "水", "土"},
                    4, new String[]{"金", "水", "土"}
            ));

            put("戊身强", ImmutableMap.of(
                    0, new String[]{"金", "水", "木"},
                    1, new String[]{"金", "水", "木"},
                    2, new String[]{"火", "土"},
                    3, new String[]{"火", "土"},
                    4, new String[]{"金", "水", "木"}
            ));

            put("戊身弱", ImmutableMap.of(
                    0, new String[]{"火", "土"},
                    1, new String[]{"火", "土"},
                    2, new String[]{"金", "水", "木"},
                    3, new String[]{"金", "水", "木"},
                    4, new String[]{"金", "水", "木"}
            ));

            put("己身强", ImmutableMap.of(
                    0, new String[]{"金", "水", "木"},
                    1, new String[]{"金", "水", "木"},
                    2, new String[]{"火", "土"},
                    3, new String[]{"火", "土"},
                    4, new String[]{"金", "水", "木"}
            ));

            put("己身弱", ImmutableMap.of(
                    0, new String[]{"火", "土"},
                    1, new String[]{"火", "土"},
                    2, new String[]{"金", "水", "木"},
                    3, new String[]{"金", "水", "木"},
                    4, new String[]{"金", "水", "木"}
            ));

            put("庚身强", ImmutableMap.of(
                    0, new String[]{"水", "木", "火"},
                    1, new String[]{"水", "木", "火"},
                    2, new String[]{"金", "土"},
                    3, new String[]{"金", "土"},
                    4, new String[]{"水", "木", "火"}
            ));

            put("庚身弱", ImmutableMap.of(
                    0, new String[]{"金", "土"},
                    1, new String[]{"金", "土"},
                    2, new String[]{"水", "木", "火"},
                    3, new String[]{"水", "木", "火"},
                    4, new String[]{"水", "木", "火"}
            ));

            put("辛身强", ImmutableMap.of(
                    0, new String[]{"水", "木", "火"},
                    1, new String[]{"水", "木", "火"},
                    2, new String[]{"金", "土"},
                    3, new String[]{"金", "土"},
                    4, new String[]{"水", "木", "火"}
            ));

            put("辛身弱", ImmutableMap.of(
                    0, new String[]{"金", "土"},
                    1, new String[]{"金", "土"},
                    2, new String[]{"水", "木", "火"},
                    3, new String[]{"水", "木", "火"},
                    4, new String[]{"水", "木", "火"}
            ));

            put("壬身强", ImmutableMap.of(
                    0, new String[]{"土", "木", "火"},
                    1, new String[]{"土", "木", "火"},
                    2, new String[]{"金", "水"},
                    3, new String[]{"金", "水"},
                    4, new String[]{"土", "木", "火"}
            ));

            put("壬身弱", ImmutableMap.of(
                    0, new String[]{"金", "水"},
                    1, new String[]{"金", "水"},
                    2, new String[]{"土", "木", "火"},
                    3, new String[]{"土", "木", "火"},
                    4, new String[]{"土", "木", "火"}
            ));

            put("癸身强", ImmutableMap.of(
                    0, new String[]{"土", "木", "火"},
                    1, new String[]{"土", "木", "火"},
                    2, new String[]{"金", "水"},
                    3, new String[]{"金", "水"},
                    4, new String[]{"土", "木", "火"}
            ));

            put("癸身弱", ImmutableMap.of(
                    0, new String[]{"金", "水"},
                    1, new String[]{"金", "水"},
                    2, new String[]{"土", "木", "火"},
                    3, new String[]{"土", "木", "火"},
                    4, new String[]{"土", "木", "火"}
            ));
        }
    };
}
