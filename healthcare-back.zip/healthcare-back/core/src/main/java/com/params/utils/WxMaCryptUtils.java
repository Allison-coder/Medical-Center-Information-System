package com.params.utils;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.AlgorithmParameters;

/**
 * @author <a href="https://github.com/binarywang">Binary Wang</a>
 */
public class WxMaCryptUtils {


  /**
   * AES解密
   *
   * @param encryptedData 消息密文
   * @param ivStr         iv字符串
   */
  public static String decrypt(String sessionKey, String encryptedData, String ivStr) {
    try {
      AlgorithmParameters params = AlgorithmParameters.getInstance("AES");
      params.init(new IvParameterSpec(Base64.decodeBase64(ivStr)));

      Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(Base64.decodeBase64(sessionKey), "AES"), params);

      return new String(PKCS7Encoder.decode(cipher.doFinal(Base64.decodeBase64(encryptedData))), StandardCharsets.UTF_8);
    } catch (Exception e) {
      throw new RuntimeException("AES解密失败", e);
    }
  }

  public static void main(String[] args) {
    String decrypt = decrypt("fsFNeNlJ21h/v/6c6ASyKQ==","tl/4a8zP1iRdv+coOKcYoIl2E+q7doO0cFDjeoLIdL9otxp15XocwBQJziPLka7sECwo7DmGVMMQIpaBiu1jyjPkmnEnndawnQqEq5x1dsXjns7OnbDVF+VdE5CGhE5mogze1z2QCScklD9ddeI3ZDnfeliKxtnAFHC+6bopftd0cKrWc+t9Gj+7yGksjFC2P1G6GhmDKKDkQvjiG1fJyw==",
    "rfygj7G7tm5JkFUUkeuCew==");
    System.out.println(decrypt);
  }

}
