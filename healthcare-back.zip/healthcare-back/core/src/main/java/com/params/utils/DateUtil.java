package com.params.utils;


import cn.hutool.core.date.DatePattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class DateUtil {

    private static final Logger log = LoggerFactory.getLogger(DateUtil.class);
    public static String FORMAT_TYPE_1 = "yyyy-MM-dd HH:mm:ss";
    public static String FORMAT_TYPE_2 = "yyyy-MM-dd HH:mm:ss SSS";
    public static String FORMAT_TYPE_3 = "yyyy-MM-dd";
    public static String FORMAT_TYPE_4 = "HH:mm:ss";
    public static String FORMAT_TYPE_5 = "HH:mm";
    public static String FORMAT_TYPE_6 = "yyyy-MM";

    private static final String[] CHINESE_WEEK_DAYS = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};

    public static String formatDateToString(Date date, String format) {
//        Assert.notNull(date,"date cant`t be null");
        if (date == null) {
            return "";
        }
        return getFormat(format).format(date);
    }

    public static Date formatStrToDate(String strDate, String format) {
        try {
            return getFormat(format).parse(strDate);
        } catch (ParseException e) {
            return null;
        }
    }

    public static String formatDateToString(String dateStr, String forma) {
        SimpleDateFormat sdf = new SimpleDateFormat(forma);
        Date date = new Date();
        try {
            date = sdf.parse(dateStr);
        } catch (Exception e) {

        }
        return formatDateToString(date, forma);
    }

    public static int getHour(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.HOUR_OF_DAY);
    }

    public static Date calculationDate(Date date, Integer type, int num) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(type, num);
        return calendar.getTime();
    }

    public static boolean isWorkTime(Date date) {
        int hour = getHour(date);
        if (hour < 8 || hour >= 21) {
            return false;
        }
        return true;
    }

    /**
     * @param format
     * @return
     */
    public static String currentTimeString(String format) {
        return formatDateToString(new Date(), format);
    }

    /**
     * @return
     */
    public static String currentTimeString() {
        return formatDateToString(new Date(), "yyyyMMddHHmmss");
    }

    public static SimpleDateFormat getFormat(String format) {
        Assert.notNull(format, "format cant`t be null");
        return new SimpleDateFormat(format);
    }

    public static String calDiffTime(Date endDate, Date startDate) {
        long diff = endDate.getTime() - startDate.getTime();
        long days = diff / (1000 * 60 * 60 * 24);
        long hours = (diff - days * (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
        long minutes = (diff - days * (1000 * 60 * 60 * 24) - hours * (1000 * 60 * 60)) / (1000 * 60);
        long seconds = (diff - days * (1000 * 60 * 60 * 24) - hours * (1000 * 60 * 60) - minutes * (1000 * 60)) / (1000);
        String result = (days > 0 ? (days + "D " + String.format("%02d", hours) + ":") : "" + (hours > 0 ? (String.format("%02d", hours) + ":") : "")) + String.format("%02d", minutes) + ":" + String.format("%02d", seconds);
        return result;
    }


    public static Date formatDataByHour(Date date, String hourTime) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat(FORMAT_TYPE_3);
        SimpleDateFormat pFormat = new SimpleDateFormat(FORMAT_TYPE_1);
        String dateStr = format.format(date) + " " + hourTime;
        Date result = pFormat.parse(dateStr);
        return result;
    }

    /**
     * 判断当前时间是否在区间内
     */
    public static boolean isEffectiveDate(Date date, String startDate, String endDate, String formatStr) throws ParseException {
        String nowDate = new SimpleDateFormat(formatStr).format(date);
        Date startTime = new SimpleDateFormat(formatStr).parse(startDate);
        Date endTime = new SimpleDateFormat(formatStr).parse(endDate);
        Date nowTime = new SimpleDateFormat(formatStr).parse(nowDate);
        if (nowTime.getTime() == startTime.getTime()
                || nowTime.getTime() == endTime.getTime()) {
            return true;
        }
        long now = nowTime.getTime();
        long begin = startTime.getTime();
        long end = endTime.getTime();
        if (now > begin && now < end) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 比较 date 是否在 startDate-endDate 内
     *
     * @param time      需要比较的时间
     * @param startDate 时间区间开始
     * @param endDate   时间区间结束
     * @param pattern   时间格式
     * @return
     */
    public static boolean isInDate(Date time, String startDate, String endDate, String pattern) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        //转换为对应时区时间
        String nowDate = sdf.format(time);

        Date date = sdf.parse(nowDate);

        Date start = sdf.parse(startDate);
        Date end = sdf.parse(endDate);

        if (start.after(end) || start.equals(end)) {
            /**
             * 直接用时间判断
             */
            if (date.getTime() >= start.getTime() || date.getTime() <= end.getTime()) {
                return true;
            }

        } else {
            if (date.getTime() >= start.getTime() && date.getTime() <= end.getTime()) {
                return true;
            }
        }
        return false;
    }


    public static String currentDateString(String format) {
        return cn.hutool.core.date.DateUtil.format(new Date(), format);
    }

    public static String currentDateString() {
        return cn.hutool.core.date.DateUtil.format(new Date(), DatePattern.PURE_DATETIME_FORMAT);
    }

    public static long calcTime(Date start, Date end) {
        long l = start.getTime() - end.getTime();
        //3.分别计算相差的天、小时、分、秒
        long day = l / (24 * 60 * 60 * 1000);
//        long hour=(l/(60*60*1000)-day*24);
//        long min=((l/(60*1000))-day*24*60-hour*60);
//        long s=(l/1000-day*24*60*60-hour*60*60-min*60);
//        System.out.println(day+"天");
//        System.out.println(day+"天"+hour+"小时");
//        System.out.println(+day+"天"+hour+"小时"+min+"分");
//        System.out.println(+day+"天"+hour+"小时"+min+"分"+s+"秒");
        return day;
    }

    public static String convertWeekName(Date date) {
        String dateString = formatDateToString(date, FORMAT_TYPE_3);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(FORMAT_TYPE_3);
        LocalDate localDate = LocalDate.parse(dateString, formatter);
        DayOfWeek dayOfWeek = localDate.getDayOfWeek();
        return dayOfWeek.getDisplayName(TextStyle.FULL, Locale.SIMPLIFIED_CHINESE);
    }

    public static String convertWeekName2(Date date) {
        // 使用Calendar类获取星期信息
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        return CHINESE_WEEK_DAYS[dayOfWeek - 1];
    }

    public static Time converTime(String sourceTime) throws ParseException {
        // 使用 SimpleDateFormat 解析时间字符串
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Date date = sdf.parse(sourceTime);
        // 将 java.util.Date 转换为 java.sql.Time
        Time time = new Time(date.getTime());
        return time;


    }

    public static Date createNowDateOnly(){
        Date now = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        // 设置时、分、秒和毫秒为0，保留日期部分
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        // 获取只包含日期部分的Date对象
       return calendar.getTime();
    }


}
