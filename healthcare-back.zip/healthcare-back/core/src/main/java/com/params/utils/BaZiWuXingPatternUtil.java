package com.params.utils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 * @Create 2024/1/17
 */
public class BaZiWuXingPatternUtil {

    /**
     * 十神比重情况01
     */
    public static final Map<String, Map<Integer, String[]>> SHI_SHEN_RATE_PARAMS_01 = new HashMap<String, Map<Integer, String[]>>() {
        private static final long serialVersionUID = -1;

        {
            put("正财身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"正财", "偏财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });
            put("正财身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"正财", "偏财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });
            put("偏财身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"正财", "偏财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });
            put("偏财身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"正财", "偏财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });
            put("正官身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正官", "七杀"});
                    put(2, new String[]{"正官", "七杀"});
                    put(3, new String[]{"正官", "七杀"});
                    put(4, new String[]{"正财", "偏财"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });
            put("正官身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正官", "七杀"});
                    put(2, new String[]{"正官", "七杀"});
                    put(3, new String[]{"正官", "七杀"});
                    put(4, new String[]{"正财", "偏财"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });
            put("七杀身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {

                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正官", "七杀"});
                    put(2, new String[]{"正官", "七杀"});
                    put(3, new String[]{"正官", "七杀"});
                    put(4, new String[]{"正财", "偏财"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});

                }
            });
            put("七杀身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {

                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正官", "七杀"});
                    put(2, new String[]{"正官", "七杀"});
                    put(3, new String[]{"正官", "七杀"});
                    put(4, new String[]{"正财", "偏财"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});

                }
            });

            put("正印身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {

                    put(0, new String[]{"正印", "偏印"});
                    put(1, new String[]{"正印", "偏印"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正印", "偏印"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正财", "偏财"});
                    put(7, new String[]{"比肩", "劫财"});


                }
            });
            put("正印身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {

                    put(0, new String[]{"正印", "偏印"});
                    put(1, new String[]{"正印", "偏印"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正印", "偏印"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正财", "偏财"});
                    put(7, new String[]{"比肩", "劫财"});

                }
            });

            put("偏印身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {

                    put(0, new String[]{"正印", "偏印"});
                    put(1, new String[]{"正印", "偏印"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正印", "偏印"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正财", "偏财"});
                    put(7, new String[]{"比肩", "劫财"});


                }
            });
            put("偏印身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {

                    put(0, new String[]{"正印", "偏印"});
                    put(1, new String[]{"正印", "偏印"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正印", "偏印"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正财", "偏财"});
                    put(7, new String[]{"比肩", "劫财"});

                }
            });

            put("伤官身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"食神", "伤官"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"食神", "伤官"});
                    put(3, new String[]{"食神", "伤官"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"正财", "偏财"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});

                }
            });

            put("伤官身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"食神", "伤官"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"食神", "伤官"});
                    put(3, new String[]{"食神", "伤官"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"正财", "偏财"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});

                }
            });

            put("食神身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"食神", "伤官"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"食神", "伤官"});
                    put(3, new String[]{"食神", "伤官"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"正财", "偏财"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });

            put("食神身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"食神", "伤官"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"食神", "伤官"});
                    put(3, new String[]{"食神", "伤官"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"正财", "偏财"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"比肩", "劫财"});
                }
            });

            put("比肩身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"比肩", "劫财"});
                    put(1, new String[]{"比肩", "劫财"});
                    put(2, new String[]{"比肩", "劫财"});
                    put(3, new String[]{"比肩", "劫财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"正财", "偏财"});
                }
            });

            put("比肩身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"比肩", "劫财"});
                    put(1, new String[]{"比肩", "劫财"});
                    put(2, new String[]{"比肩", "劫财"});
                    put(3, new String[]{"比肩", "劫财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"正财", "偏财"});
                }
            });

            put("劫财身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"比肩", "劫财"});
                    put(1, new String[]{"比肩", "劫财"});
                    put(2, new String[]{"比肩", "劫财"});
                    put(3, new String[]{"比肩", "劫财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"正财", "偏财"});
                }
            });

            put("劫财身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"比肩", "劫财"});
                    put(1, new String[]{"比肩", "劫财"});
                    put(2, new String[]{"比肩", "劫财"});
                    put(3, new String[]{"比肩", "劫财"});
                    put(4, new String[]{"正官", "七杀"});
                    put(5, new String[]{"食神", "伤官"});
                    put(6, new String[]{"正印", "偏印"});
                    put(7, new String[]{"正财", "偏财"});
                }
            });
        }
    };

    /**
     * 十神比重情况02
     */
    public static final Map<String, Map<Integer, String[]>> SHI_SHEN_RATE_PARAMS_02 = new HashMap<String, Map<Integer, String[]>>() {
        private static final long serialVersionUID = -1;

        {
            put("正财身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("正财身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("偏财身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("偏财身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("正官身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("正官身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });


            put("七杀身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("七杀身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正财", "偏财"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("正印身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("正印身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("偏印身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("偏印身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正财", "偏财"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("伤官身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("伤官身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("食神身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("食神身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"正财", "偏财"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"比肩", "劫财"});
                }
            });

            put("比肩身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正财", "偏财"});
                }
            });

            put("比肩身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正财", "偏财"});
                }
            });


            put("劫财身强", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正财", "偏财"});
                }
            });

            put("劫财身弱", new LinkedHashMap<Integer, String[]>() {
                private static final long serialVersionUID = -1;

                {
                    put(0, new String[]{"正官", "七杀"});
                    put(1, new String[]{"食神", "伤官"});
                    put(2, new String[]{"正印", "偏印"});
                    put(3, new String[]{"正财", "偏财"});
                }
            });
        }
    };
}
