package com.params.utils;


import com.params.framework.exception.ServiceException;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.*;
import java.security.spec.InvalidKeySpecException;

/**
 * @author lf
 * 算法加密解密工具类 md5 rsa等
 */
public class ArithmeticUtil {
    private static final String SHA1ALGORITHM_NAME = "SHA1";
    private static final String MD5_ALGORITHM_NAME = "MD5";
    private static final String SHA256_ALGORITHM_NAME = "SHA-256";
    private static final String DES_ALGORITHM_NAME = "DES";
    public static final String CIPHER_ALGORITHM_ECB = "DES/ECB/PKCS5Padding";
    public static final String DEFALT_CHARSET = "utf-8";
    private static final char[] HEX_CHARS = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};


    /**
     * des 加密
     *
     * @param data
     * @param password
     * @return
     * @throws Exception
     */
    public static String desAsHex(byte[] data, byte[] password) throws Exception {
        return new String(encodeHex(cipherDoFinal(data, password, DES_ALGORITHM_NAME, CIPHER_ALGORITHM_ECB, Cipher.ENCRYPT_MODE)));
    }

    /**
     * des 解密
     *
     * @param data
     * @param password
     * @return
     * @throws Exception
     */
    public static String decryptDESFromHex(String data, String password) throws Exception {
        return new String(cipherDoFinal(hexStringToBytes(data), password.getBytes(), DES_ALGORITHM_NAME, CIPHER_ALGORITHM_ECB, Cipher.DECRYPT_MODE));
    }

    public static String md5AsHex(String data) {
        return digestAsHexString(MD5_ALGORITHM_NAME, data.getBytes());
    }

    public static String md5AsHex(String data, String salt) {
        return digestAsHexString(MD5_ALGORITHM_NAME, (data + salt).getBytes());
    }

    public static String sha1AsHex(String data) {
        return digestAsHexString(SHA1ALGORITHM_NAME, data.getBytes());
    }

    public static String sha256AsHex(String data) {
        try {
            return digestAsHexString(SHA256_ALGORITHM_NAME, data.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new ServiceException("服务器繁忙");
        }
    }

    public static String sha256AsHex(byte[] data) {
        return digestAsHexString(SHA256_ALGORITHM_NAME, data);
    }

    private static MessageDigest getDigest(String algorithm) {
        try {
            return MessageDigest.getInstance(algorithm);
        } catch (NoSuchAlgorithmException var2) {
            throw new IllegalStateException("Could not find MessageDigest with algorithm \"" + algorithm + "\"", var2);
        }
    }

    private static byte[] digest(String algorithm, byte[] bytes) {
        return getDigest(algorithm).digest(bytes);
    }


    private static String digestAsHexString(String algorithm, byte[] bytes) {
        char[] hexDigest = digestAsHexChars(algorithm, bytes);
        return new String(hexDigest);
    }

    private static char[] digestAsHexChars(String algorithm, byte[] bytes) {
        byte[] digest = digest(algorithm, bytes);
        return encodeHex(digest);
    }

    public static char[] encodeHex(byte[] bytes) {
        int len = bytes.length;
        char[] chars = new char[len * 2];
        for (int i = 0; i < len; i++) {
            int b = bytes[i] & 0xFF;
            chars[i * 2] = HEX_CHARS[b >>> 4 & 15];
            chars[i * 2 + 1] = HEX_CHARS[b & 15];
        }
        return chars;
    }


    private static SecretKeyFactory secretKeyFactory(String algorithm) {
        try {
            return SecretKeyFactory.getInstance(DES_ALGORITHM_NAME);
        } catch (NoSuchAlgorithmException var2) {
            throw new IllegalStateException("Could not find MessageDigest with algorithm \"" + algorithm + "\"", var2);
        }
    }

    private static DESKeySpec getDESKeySpec(byte[] password) {
        try {
            return new DESKeySpec(password);
        } catch (InvalidKeyException var2) {
            throw new IllegalStateException("InvalidKeyException 非法密钥 \"" + password + "\"", var2);
        }
    }

    private static Cipher getCipher(String padding) {
        try {
            return Cipher.getInstance(padding);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("NoSuchAlgorithmException \"" + padding + "\"", e);
        } catch (NoSuchPaddingException e) {
            throw new IllegalStateException("NoSuchPaddingException \"" + padding + "\"", e);
        }
    }

    private static Cipher initCipher(byte[] password, String algorithm, String padding, int mode) throws InvalidKeyException {
        Cipher cipher = getCipher(padding);
        cipher.init(mode, generateSecretKey(password, algorithm), new SecureRandom());
        return cipher;
    }

    private static SecretKey generateSecretKey(byte[] password, String algorithm) {
        try {
            return secretKeyFactory(algorithm).generateSecret(getDESKeySpec(password));
        } catch (InvalidKeySpecException e) {
            throw new IllegalStateException("InvalidKeySpecException \"" + password + "\"", e);
        }
    }


    public static String desAsHex(String data, String password) throws Exception {
        return desAsHex(data.getBytes(), password.getBytes());
    }

    private static byte[] cipherDoFinal(byte[] data, byte[] password, String algorithm, String padding, int mode) throws Exception {
        Cipher cipher = initCipher(password, algorithm, padding, mode);
        return cipher.doFinal(data);
    }

    private static byte[] hexStringToBytes(String hexString) {
        if (hexString == null || hexString.equals("")) {
            return null;
        }
        hexString = hexString.toUpperCase();
        int length = hexString.length() / 2;
        char[] hexChars = hexString.toCharArray();
        byte[] d = new byte[length];
        for (int i = 0; i < length; i++) {
            int pos = i * 2;
            d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
        }
        return d;
    }

    private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }

    public static String urlEncoder(String data, String charset) {
        try {
            return URLEncoder.encode(data, charset);
        } catch (UnsupportedEncodingException e) {

            return "";
        }
    }

    public static String urlDecode(String data, String charset) {
        try {
            return URLDecoder.decode(data, charset);
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }

    public static String desAsHexString(String data, String password) {
        try {
            return desAsHex(data.getBytes(), password.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String decryptDESFromHexString(String data, String password) {
        try {
            return new String(cipherDoFinal(hexStringToBytes(data), password.getBytes(), DES_ALGORITHM_NAME, CIPHER_ALGORITHM_ECB, Cipher.DECRYPT_MODE));
        } catch (Exception e) {
            return "";
        }
    }




}
