package com.params.utils;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class RandomUtilTest {

    @Test
    void testNumber() {
        System.out.println(RandomUtil.randomString(8));
    }

    @Test
    void testBig() {
        BigDecimal totalPrice = new BigDecimal(120);
        BigDecimal unitPrice = new BigDecimal(20);
        Integer finishCount = 1;
        BigDecimal refundAmount = totalPrice.subtract(unitPrice.multiply(new BigDecimal(finishCount)));
        System.out.println(refundAmount);
    }
}