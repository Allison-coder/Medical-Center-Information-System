package com.params.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Date;
import java.util.Locale;
class DateUtilTest {

    @Test
    void testDate() {
        String s = DateUtil.formatDateToString(new Date(), "yyyy-MM-dd HH:mm:ss");
        System.out.println(s);
        System.out.println(DateUtil.formatDateToString(new Date(), "yyyyMMddHHmmss"));
        System.out.println(DateUtil.formatDateToString(new Date(), "yyyyMMddHHmmssSSS"));
        System.out.println(DateUtil.formatDateToString(new Date(), "yyyyMMddHHmmssSSS"));
    }

    @Test
    void testNum() {
        BigDecimal amount = new BigDecimal("18");
        int res = amount.compareTo(BigDecimal.ZERO);
        System.out.println(res);

        BigDecimal old = new BigDecimal("15");
        int r = amount.compareTo(old);
        System.out.println(r);
    }

    @ParameterizedTest
    @ValueSource(strings = {"2024-05-17", "2024-05-18", "2024-05-19", "2024-05-20", "2024-05-21", "2024-05-22", "2024-05-23", "2024-05-24", "2024-05-25"})
    void testWeek(String dateString) {
//        String dateString = "2024-05-17";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        try {
            LocalDate date = LocalDate.parse(dateString, formatter);
            DayOfWeek dayOfWeek = date.getDayOfWeek();

            // 输出星期几
            System.out.println("The day of the week is: " + dayOfWeek);

            // 如果需要输出本地化的星期名称（例如：简体中文的“星期四”）
            System.out.println("The day of the week is: " + dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.CHINESE));
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to parse the date string.");
        }
    }

    @ParameterizedTest
    @ValueSource(strings = {"2024-05-17", "2024-05-18", "2024-05-19", "2024-05-20", "2024-05-21", "2024-05-22", "2024-05-23", "2024-05-24", "2024-05-25"})
    void testWeek2(String dateString) {
        try {
            // 假设我们有一个日期字符串
//            String dateString = "2023-03-25";
            // 定义日期格式
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            // 解析日期字符串
            Date date = dateFormat.parse(dateString);

            System.out.println(dateString+ " : " + DateUtil.convertWeekName2(date));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}