package com.params.back.controller;

import com.params.domain.science.ScienceDomainService;
import com.params.framework.vo.R;
import com.params.pojo.dto.ScienceBannerDTO;
import com.params.pojo.dto.ScienceCategoryDTO;
import com.params.pojo.dto.ScienceRecordDTO;
import com.params.pojo.dto.ScienceRecordQueryDTO;
import com.params.pojo.req.ScienceRecordQueryReq;
import com.params.pojo.req.ScienceRecordReq;
import com.params.pojo.req.ScienceRecordUpdateReq;
import com.params.pojo.vo.ScienceBannerVO;
import com.params.pojo.vo.ScienceCategoryVO;
import com.params.pojo.vo.ScienceRecordVO;
import com.params.pojo.vo.common.PageVO;
import com.params.utils.AdminSecurityHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.util.List;

@Api(tags = "内容管理")
@RestController
@RequestMapping("/science/manage")
@Validated
@Slf4j
@PreAuthorize("hasRole('ADMINISTRATOR')")
public class ScienceController {

    private ScienceDomainService scienceDomainService;

    public ScienceController(ScienceDomainService scienceDomainService) {
        this.scienceDomainService = scienceDomainService;
    }

    @GetMapping("/getBanners")
    @ApiOperation("banner列表")
    public R<List<ScienceBannerVO>> getBanners() {
        List<ScienceBannerVO> result = scienceDomainService.getBanners(AdminSecurityHolder.getClinicId());
        return R.success(result);
    }

    @PostMapping("/updateBanners")
    @ApiOperation("更新banner列表")
    public R<Boolean> updateBanners(@RequestBody @Validated List<ScienceBannerDTO> reqs) {
        boolean res = scienceDomainService.updateBanners(reqs, AdminSecurityHolder.getClinicId());
        return R.success(res);
    }

    @GetMapping("/getCategories")
    @ApiOperation("类别列表")
    public R<List<ScienceCategoryVO>> getCategories() {
        List<ScienceCategoryVO> result = scienceDomainService.getCategories(AdminSecurityHolder.getClinicId());
        return R.success(result);
    }

    @PostMapping("/updateCategories")
    @ApiOperation("更新类别列表")
    public R<Boolean> updateCategories(@RequestBody @Validated List<ScienceCategoryDTO> reqs) {
        boolean res = scienceDomainService.updateCategories(reqs, AdminSecurityHolder.getClinicId());
        return R.success(res);
    }

    @PostMapping("/createOrUpdateRecord")
    @ApiOperation("创建或更新科普内容")
    public R<Boolean> createOrUpdateRecord(@RequestBody @Validated ScienceRecordReq req) {
        ScienceRecordDTO dto = ScienceRecordDTO.builder()
                .id(req.getId())
                .title(req.getTitle())
                .url(req.getUrl())
                .urlKey(req.getUrlKey())
                .link(req.getLink())
                .categoryId(req.getCategoryId())
                .channelId(AdminSecurityHolder.getClinicId())
                .build();
        return R.success(scienceDomainService.createOrUpdateRecord(dto));
    }

    @GetMapping("/getRecords")
    @ApiOperation("科普知识列表")
    public R<PageVO<ScienceRecordVO>> getRecords(ScienceRecordQueryReq req) {
        ScienceRecordQueryDTO dto = ScienceRecordQueryDTO.builder()
                .categoryId(req.getCategoryId())
                .pageSize(req.getPageSize())
                .pageNum(req.getPageNum())
                .channelId(AdminSecurityHolder.getClinicId())
                .build();
        PageVO<ScienceRecordVO> records = scienceDomainService.getRecords(dto);
        return R.success(records);
    }

    @PostMapping("/deleteRecord/{id}")
    @ApiOperation("删除科普记录")
    public R<Boolean> deleteRecord(@PathVariable("id") @NotNull Integer id) {
        // 将对应记录 disable = 1
        return R.success(scienceDomainService.toDisable(id, AdminSecurityHolder.getClinicId()));
    }

    @PostMapping("/updateShow")
    @ApiOperation("更新首页展示")
    public R<Boolean> updateShow(@RequestBody @Validated ScienceRecordUpdateReq req) {
        // 将对应记录 是否首页展示
        return R.success(scienceDomainService.updateShow(req.getId(), req.getShow(), AdminSecurityHolder.getClinicId()));
    }
}
