package com.params.back.service;

import com.params.back.pojo.dto.SysAuthLoginReqDTO;
import com.params.component.security.core.service.SecurityAuthFrameworkService;

import javax.validation.Valid;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface SysAuthService extends SecurityAuthFrameworkService {

    /**
     * 账号登录
     *
     * @param reqVO 登录信息
     * @param userIp 用户 IP
     * @param userAgent 用户 UA
     * @return 身份令牌，使用 JWT 方式
     */
    String login(@Valid SysAuthLoginReqDTO reqVO, String userIp, String userAgent);

    void checkCurrentPwd(String username, String password);
}
