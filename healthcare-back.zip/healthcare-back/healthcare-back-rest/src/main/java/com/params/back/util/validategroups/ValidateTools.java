package com.params.back.util.validategroups;

import com.params.back.pojo.dto.SaveTreatmentPlanItemDTO;
import com.params.constant.PlanItemProjectTypeEnum;
import com.params.framework.exception.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.beanvalidation.SpringValidatorAdapter;

import javax.validation.Validator;
import java.util.List;

/**
 * @DESCRIPTION 处置方案的校验工具类
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Component
public class ValidateTools {

    @Autowired
    private Validator validator;

    public void validateItems(List<SaveTreatmentPlanItemDTO> items) throws Exception {
        if (items != null) {
            for (SaveTreatmentPlanItemDTO item : items) {
                BeanPropertyBindingResult bindingResult = new BeanPropertyBindingResult(item, "item");
                SpringValidatorAdapter validatorAdapter = new SpringValidatorAdapter(validator);

                // 根据项目类型选择验证组
                if (item.getProjectType() == PlanItemProjectTypeEnum.THERAPY.getCode()) { // 康复类型
                    validatorAdapter.validate(item, bindingResult, ValidateTherapyGroup.class);
                } else if (item.getProjectType() == PlanItemProjectTypeEnum.MEDICINE.getCode()) { // 药物类型
                    validatorAdapter.validate(item, bindingResult, ValidateMedicineGroup.class);
                }
                if (bindingResult.hasErrors()) {
                    String errorMessage = bindingResult.getAllErrors().get(0).getDefaultMessage();
                    throw new ServiceException(errorMessage);
                }
            }
        }
    }

}
