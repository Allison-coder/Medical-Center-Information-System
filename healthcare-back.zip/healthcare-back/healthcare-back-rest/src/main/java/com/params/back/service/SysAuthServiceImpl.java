package com.params.back.service;

import cn.hutool.core.util.StrUtil;
import com.params.back.convert.SysAuthConvert;
import com.params.back.pojo.dto.SysAuthLoginReqDTO;
import com.params.cachekey.SysAuthCacheKey;
import com.params.cachekey.UserCacheKey;
import com.params.component.redis.ParamsRedis;
import com.params.component.security.core.LoginUser;
import com.params.constant.SysLoginLogTypeEnum;
import com.params.constant.SysLoginResultEnum;
import com.params.entity.Admin;
import com.params.entity.AdminRole;
import com.params.framework.constant.CommonStatusEnum;
import com.params.framework.constant.UserTypeEnum;
import com.params.framework.servlet.ServletUtils;
import com.params.pojo.vo.SysLoginLogCreateReqDTO;
import com.params.service.AdminService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_BAD_CREDENTIALS;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_CAPTCHA_CODE_ERROR;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_CAPTCHA_NOT_FOUND;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_FAIL_UNKNOWN;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_USER_DISABLED;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_USER_FROZEN;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_LOGIN_USER_OCCUPY;
import static com.params.constant.errorcode.SystemErrorCodeConstants.AUTH_TOKEN_EXPIRED;
import static com.params.framework.util.ServiceExceptionUtil.exception;
import static java.util.Collections.singleton;

/**
 * <pre>
 * Auth Service 实现类
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Service
@Slf4j
public class SysAuthServiceImpl implements SysAuthService {

    private static final UserTypeEnum USER_TYPE_ENUM = UserTypeEnum.ADMIN;

    @Resource
    @Lazy // 延迟加载，因为存在相互依赖的问题
    private AuthenticationManager authenticationManager;

    @Resource
    private AdminService adminService;

    @Resource
    private SysRoleService sysRoleService;

    @Resource
    private SysCaptchaService sysCaptchaService;

    @Resource
    private SysUserSessionCoreService sysUserSessionCoreService;

    @Resource
    private ParamsRedis paramsRedis;

    @Override
    public String login(SysAuthLoginReqDTO reqVO, String userIp, String userAgent) {
        // 判断验证码是否正确
        this.verifyCaptcha(reqVO.getUsername(), reqVO.getUuid(), reqVO.getCode());

        // 使用账号密码，进行登录
        LoginUser loginUser = this.login0(reqVO.getUsername(), reqVO.getPassword());

        // 缓存登陆用户到 Redis 中，返回 sessionId 编号
        return sysUserSessionCoreService.createUserSession(loginUser, userIp, userAgent);
    }

    @Override
    public void checkCurrentPwd(String username, String password) {
        try {
            // 调用 Spring Security 的 AuthenticationManager#authenticate(...) 方法，使用账号密码进行认证
            // 在其内部，会调用到 loadUserByUsername 方法，获取 User 信息
            Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (BadCredentialsException badCredentialsException) {
            throw exception(AUTH_LOGIN_BAD_CREDENTIALS);
        } catch (DisabledException disabledException) {
            throw exception(AUTH_LOGIN_USER_DISABLED);
        } catch (AuthenticationException authenticationException) {
            throw exception(AUTH_LOGIN_FAIL_UNKNOWN);
        }
    }

    private LoginUser login0(String username, String password) {
        final SysLoginLogTypeEnum logTypeEnum = SysLoginLogTypeEnum.LOGIN_USERNAME;
        String key = UserCacheKey.LOCK_USER.getKey("kyback", username);
        // 用户验证
        Authentication authentication;
        Integer num = paramsRedis.get(key);
        if (num == null) num = 1;
        try {
            if (Integer.valueOf(100).compareTo(num) < 0) {
                log.warn("[{}.login0]账号已被冻结 username:{},num:{}", this.getClass().getSimpleName(), username, num);
                throw exception(AUTH_LOGIN_USER_FROZEN);
            }
            // 调用 Spring Security 的 AuthenticationManager#authenticate(...) 方法，使用账号密码进行认证
            // 在其内部，会调用到 loadUserByUsername 方法，获取 User 信息
            authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (BadCredentialsException badCredentialsException) {
            this.createLoginLog(username, logTypeEnum, SysLoginResultEnum.BAD_CREDENTIALS);
            paramsRedis.incr(key);
            paramsRedis.expire(key, UserCacheKey.LOCK_USER.getExpire());
            throw exception(AUTH_LOGIN_BAD_CREDENTIALS);
        } catch (DisabledException disabledException) {
            this.createLoginLog(username, logTypeEnum, SysLoginResultEnum.USER_DISABLED);
            throw exception(AUTH_LOGIN_USER_DISABLED);
        } catch (AuthenticationException authenticationException) {
            log.error("[{}.login0][username({}) 发生未知异常]", this.getClass().getSimpleName(), username, authenticationException);
            this.createLoginLog(username, logTypeEnum, SysLoginResultEnum.UNKNOWN_ERROR);
            throw exception(AUTH_LOGIN_FAIL_UNKNOWN);
        }
        // 登录成功的日志
        Assert.notNull(authentication.getPrincipal(), "Principal 不会为空");
        this.createLoginLog(username, logTypeEnum, SysLoginResultEnum.SUCCESS);
        // 删除KEY
        paramsRedis.del(key);
        return (LoginUser) authentication.getPrincipal();
    }

    @Override
    public LoginUser verifyTokenAndRefresh(String token) {
        // 获得 LoginUser
        LoginUser loginUser = sysUserSessionCoreService.getLoginUser(token);
        if (loginUser == null) {
            return null;
        }

        String userTokenCacheKey = SysAuthCacheKey.AUTH_BACKEND_TOKEN_CACHE_KEY.getKey(loginUser.getId());
        String oldToken = paramsRedis.get(userTokenCacheKey);
        if (StrUtil.isBlank(oldToken) || !StrUtil.equalsIgnoreCase(token, oldToken)) {
            String cacheKey = SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(token);
            paramsRedis.del(cacheKey);
            throw exception(AUTH_LOGIN_USER_OCCUPY); // 校验 token 时，用户被禁用的情况下，也认为 token 过期，方便前端跳转到登录界面
        }

        // 刷新 LoginUser 缓存
        return this.refreshLoginUserCache(token, loginUser);
    }

    private LoginUser refreshLoginUserCache(String token, LoginUser loginUser) {
        // 每 1/3 的 Session 超时时间，刷新 LoginUser 缓存
        if ((System.currentTimeMillis() - loginUser.getUpdateTime().getTime()) < sysUserSessionCoreService.getSessionTimeoutMillis().toMillis() / 3) {
            return loginUser;
        }

        // 重新加载 SysUserDO 信息
        Admin user = adminService.getById(loginUser.getId());
        if (user == null || !"NORMAL".equalsIgnoreCase(user.getStatus())) {
            throw exception(AUTH_TOKEN_EXPIRED); // 校验 token 时，用户被禁用的情况下，也认为 token 过期，方便前端跳转到登录界面
        }

        // 刷新 LoginUser 缓存
        LoginUser newLoginUser = this.buildLoginUser(user);
        sysUserSessionCoreService.refreshUserSession(token, newLoginUser);
        return newLoginUser;
    }

    @Override
    public LoginUser mockLogin(Long userId) {
        // 获取用户编号对应的 SysUserDO
        Admin user = adminService.getById(userId);
        if (user == null) {
            throw new UsernameNotFoundException(String.valueOf(userId));
        }
        this.createLoginLog(user.getName(), SysLoginLogTypeEnum.LOGIN_MOCK, SysLoginResultEnum.SUCCESS);

        // 创建 LoginUser 对象
        return this.buildLoginUser(user);
    }

    @Override
    public void logout(String token) {
        // 查询用户信息
        LoginUser loginUser = sysUserSessionCoreService.getLoginUser(token);
        if (loginUser == null) {
            return;
        }
        // 删除 session
        sysUserSessionCoreService.deleteUserSession(token);
        // 记录登出日志
        this.createLogoutLog(loginUser.getId(), loginUser.getUsername());
    }

    private void createLogoutLog(Integer userId, String username) {
        SysLoginLogCreateReqDTO reqDTO = new SysLoginLogCreateReqDTO();
        reqDTO.setLogType(SysLoginLogTypeEnum.LOGOUT_SELF.getType());
        // reqDTO.setTraceId(TracerUtils.getTraceId());
        reqDTO.setUserId(userId);
        reqDTO.setUserType(USER_TYPE_ENUM.getValue());
        reqDTO.setUsername(username);
        reqDTO.setUserAgent(ServletUtils.getUserAgent());
        reqDTO.setUserIp(ServletUtils.getClientIP());
        reqDTO.setResult(SysLoginResultEnum.SUCCESS.getResult());
//         loginLogCoreService.createLoginLog(reqDTO);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Admin admin = adminService.getByName(username);
        if (admin == null) {
            throw new UsernameNotFoundException(username);
        }
        return this.buildLoginUser(admin);
    }

    private LoginUser buildLoginUser(Admin user) {
        LoginUser loginUser = SysAuthConvert.INSTANCE.convert(user);
        // 补全字段
        loginUser.setRoleIds(this.getUserRoleIds(loginUser.getId()));
        // 查出角色
        List<AdminRole> rolesFromCache = sysRoleService.getRolesFromCache(loginUser.getRoleIds());
        if (CollectionUtils.isNotEmpty(rolesFromCache)){
            for (AdminRole role : rolesFromCache) {
                List<String> list = new ArrayList<>();
                list.add("ROLE_"+role.getCode());
                loginUser.setRoles(list);
            }
        }
        return loginUser;
    }

    /**
     * 获得 User 拥有的角色编号数组
     *
     * @param userId 用户编号
     * @return 角色编号数组
     */
    private Set<Integer> getUserRoleIds(Integer userId) {
        return sysRoleService.getUserRoleIds(userId, singleton(CommonStatusEnum.ENABLE.getValue()));
    }

    private void verifyCaptcha(String username, String captchaUUID, String captchaCode) {
        // 如果验证码关闭，则不进行校验
        if (!sysCaptchaService.isCaptchaEnable()) {
            return;
        }
        // 验证码不存在
        final SysLoginLogTypeEnum logTypeEnum = SysLoginLogTypeEnum.LOGIN_USERNAME;
        String code = sysCaptchaService.getCaptchaCode(captchaUUID);
        sysCaptchaService.deleteCaptchaCode(captchaUUID);
        if (code == null) {
            // 创建登录失败日志（验证码不存在）
            this.createLoginLog(username, logTypeEnum, SysLoginResultEnum.CAPTCHA_NOT_FOUND);
            throw exception(AUTH_LOGIN_CAPTCHA_NOT_FOUND);
        }
        // 验证码不正确
        if (!code.equalsIgnoreCase(captchaCode)) {
            // 创建登录失败日志（验证码不正确)
            this.createLoginLog(username, logTypeEnum, SysLoginResultEnum.CAPTCHA_CODE_ERROR);
            throw exception(AUTH_LOGIN_CAPTCHA_CODE_ERROR);
        }
        // 正确，所以要删除下验证码
//        sysCaptchaService.deleteCaptchaCode(captchaUUID);
    }

    private void createLoginLog(String username, SysLoginLogTypeEnum logTypeEnum, SysLoginResultEnum loginResult) {
        // 获得用户
        Admin user = adminService.getByName(username);
        // 插入登录日志
        SysLoginLogCreateReqDTO reqDTO = new SysLoginLogCreateReqDTO();
        reqDTO.setLogType(logTypeEnum.getType());
        // reqDTO.setTraceId(TracerUtils.getTraceId());
        if (user != null) {
            reqDTO.setUserId(user.getId());
        }
        reqDTO.setUserType(UserTypeEnum.ADMIN.getValue());
        reqDTO.setUsername(username);
        reqDTO.setUserAgent(ServletUtils.getUserAgent());
        reqDTO.setUserIp(ServletUtils.getClientIP());
        reqDTO.setResult(loginResult.getResult());
        // loginLogCoreService.createLoginLog(reqDTO);
        // 更新最后登录时间
        if (user != null && Objects.equals(SysLoginResultEnum.SUCCESS.getResult(), loginResult.getResult())) {
            adminService.updateUserLogin(user.getId(), ServletUtils.getClientIP());
        }
    }
}
