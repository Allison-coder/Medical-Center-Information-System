package com.params.back.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@ApiModel(value = "用户在线 Session Response VO", description = "相比用户基本信息来说，会多部门、用户账号等信息")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SysUserSessionPageItemRespVO {

    @ApiModelProperty(value = "Session 编号", required = true, example = "fe50b9f6-d177-44b1-8da9-72ea34f63db7")
    private String id;

    @ApiModelProperty(value = "用户 IP", required = true, example = "127.0.0.1")
    private String userIp;

    @ApiModelProperty(value = "浏览器 UserAgent", required = true, example = "Mozilla/5.0")
    private String userAgent;

    @ApiModelProperty(value = "登录时间", required = true)
    private Date createTime;

    @ApiModelProperty(value = "用户账号", required = true, example = "bug")
    private String username;
}
