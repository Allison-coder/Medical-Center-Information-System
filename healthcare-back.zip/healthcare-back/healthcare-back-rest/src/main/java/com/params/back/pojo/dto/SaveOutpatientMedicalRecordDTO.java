package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @DESCRIPTION 工作面板保存门诊病历的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@ApiModel("工作面板保存门诊病历的入参")
public class SaveOutpatientMedicalRecordDTO {

    @ApiModelProperty("患者编号")
    @NotBlank(message = "患者编号不能为空")
    private String patientSn;

    /**
     * 体温（单位：摄氏度）
     */
    @ApiModelProperty(value = "体温（单位：摄氏度）")
    private String bodyTemperature;

    /**
     * 血压（单位：毫米汞柱）
     */
    @ApiModelProperty(value = "血压（单位：毫米汞柱）")
    private String bloodPressure;
    /**
     * 身体图坐标
     */
    @ApiModelProperty(value = "身体图坐标")
    private List<ImgCoordinateDTO> imgCoordinate;

    /**
     * 脉搏（单位：次/分钟）
     */
    @ApiModelProperty(value = "脉搏（单位：次/分钟）")
    private String pulse;

    /**
     * 血氧（单位：百分比）
     */
    @ApiModelProperty(value = "血氧（单位：百分比）")
    private String bloodOxygen;

    /**
     * 开始症状
     */
    @ApiModelProperty(value = "开始症状")
    private String initialSymptoms;

    /**
     * 症状性质
     */
    @ApiModelProperty(value = "症状性质")
    private String symptomNature;

    /**
     * 疼痛程度（1-10）
     */
    @ApiModelProperty(value = "疼痛程度（1-3）从小到大 轻、中、高")
    private Integer painLevel;


    @ApiModelProperty(value = "病史及后面部份，同获取患者门诊病例配置项接口有返回格式")
    private String medicalHistory;



}
