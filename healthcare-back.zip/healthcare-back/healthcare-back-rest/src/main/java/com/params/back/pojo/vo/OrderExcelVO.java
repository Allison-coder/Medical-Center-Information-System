package com.params.back.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/11
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderExcelVO {

    private Long no;
    @ApiModelProperty(value = "支付方式", example = "1")
    private String paymentType;
    @ApiModelProperty(value = "支付方式", example = "1")
    private String paymentTypeStr;

    @ApiModelProperty(value = "手机号")
    private String mobile;

    /**
     * 姓名
     */
    @ApiModelProperty(value = "姓名")
    private String nickName;

    /**
     * 性别: 1-男 2-女 0-其它
     */
    @ApiModelProperty(value = "性别", example = "1")
    private Integer sex;

    @ApiModelProperty(value = "生日类型 1-新历 2-旧历", example = "1", hidden = false)
    private Integer birthdayType;

    /**
     * 生日  农历加日期
     */
    @ApiModelProperty(value = "生日", example = "阳历 2022-12-08 00:00:00")
    private String birthday;

    /**
     * 农历生日
     */
    @ApiModelProperty(value = "农历生日时间", example = "阳历 2022-12-08 00:00:00")
    private Date lunarBirthday;

    /**
     * 新历生日
     */
    @ApiModelProperty(value = "新历生日", example = "2022-12-08 00:00:00")
    private Date solarBirthday;

    @ApiModelProperty(value = "订单价格", example = "1.1")
    private BigDecimal orderPrice;

    @ApiModelProperty(value = "实际支付价格", example = "1.1")
    private BigDecimal payPrice;

    @ApiModelProperty(value = "订单号", example = "O20221021021020")
    private String orderSn;

    @ApiModelProperty(value = "支付时间", example = "2022-12-08 00:00:00")
    private Date payTime;

    @ApiModelProperty(value = "下单时间", example = "2022-12-08 00:00:00")
    private Date createTime;


    @ApiModelProperty(value = "WAITING_PAY-待支付 IS_PAY-已支付 CANCEL-取消 REFUND-退款 REFUNDING-退款中", example = "IS_PAY")
    private String orderStatus;

    @ApiModelProperty(value = "订单状态 ", example = "待支付")
    private String orderStatusStr;
}
