package com.params.back.controller;

import cn.hutool.core.bean.BeanUtil;
import com.params.application.order.OrderApp;
import com.params.application.patient.PatientApp;
import com.params.application.workpanel.WorkPanelApp;
import com.params.back.interceptor.NoRepeatSubmit;
import com.params.back.pojo.dto.ImgCoordinateDTO;
import com.params.back.pojo.dto.PatientSchedulesDTO;
import com.params.back.pojo.dto.SaveOutpatientMedicalRecordDTO;
import com.params.back.pojo.dto.SavePatientBasicInfoDTO;
import com.params.back.pojo.dto.SaveTreatmentPlanDTO;
import com.params.back.pojo.dto.SaveTreatmentRecordNotesDTO;
import com.params.back.util.validategroups.ValidateTools;
import com.params.constant.PlanItemProjectTypeEnum;
import com.params.domain.medicalrecords.MedicalRecordsDomainService;
import com.params.domain.order.OrderDomainService;
import com.params.domain.patient.PatientDomainService;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.domain.workpanel.WorkPanelDomainService;
import com.params.entity.MedicalRecords;
import com.params.entity.TreatmentPlan;
import com.params.entity.TreatmentPlanItem;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.CopyDisposalPlanItemProjectBO;
import com.params.pojo.bo.DisposalPlanNumDetailBO;
import com.params.pojo.bo.ImgCoordinateBO;
import com.params.pojo.bo.InterviewRecordsBO;
import com.params.pojo.bo.PatientSchedulesBO;
import com.params.pojo.bo.SaveDisposalPlanBO;
import com.params.pojo.bo.SaveDisposalPlanItemBO;
import com.params.pojo.bo.SaveOutpatientMedicalRecordBO;
import com.params.pojo.bo.SavePatientBasicInfoBO;
import com.params.pojo.bo.SaveTreatmentPlanBO;
import com.params.pojo.bo.SaveTreatmentPlanItemBO;
import com.params.pojo.req.CopyDisposalPlanItemProjectReq;
import com.params.pojo.req.CopyDisposalPlanItemReq;
import com.params.pojo.req.InterviewRecordsReq;
import com.params.pojo.req.MergeDisposalPlanConfirmReq;
import com.params.pojo.req.ReleaseOrHideInterviewRecordsReq;
import com.params.pojo.req.SaveDisposalPlanItemReq;
import com.params.pojo.req.SaveDisposalPlanReq;
import com.params.pojo.req.SaveTherapistStatementReq;
import com.params.pojo.vo.BaseTreatmentPlanVO;
import com.params.pojo.vo.InterviewRecordsVO;
import com.params.pojo.vo.MedicalRecordPatientVO;
import com.params.pojo.vo.MergePayOrderVO;
import com.params.pojo.vo.PlanProjectConfigVO;
import com.params.pojo.vo.TherapistStatementVO;
import com.params.pojo.vo.TherapyOrdersNewVO;
import com.params.pojo.vo.TherapyOrdersVO;
import com.params.pojo.vo.TreatmentPlanItemVO;
import com.params.pojo.vo.TreatmentPlanVO;
import com.params.pojo.vo.TreatmentRecordNotesVO;
import com.params.pojo.vo.WorkPanelVO;
import com.params.utils.AdminSecurityHolder;
import com.params.utils.DateUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @DESCRIPTION 工作面板
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "工作面板")
@RestController
@RequestMapping(("/panel/manage"))
public class WorkPanelController {

    private static final Logger log = LoggerFactory.getLogger(WorkPanelController.class);
    @Autowired
    private WorkPanelDomainService workPanelDomainService;

    @Autowired
    private PatientDomainService patientDomainService;

    @Autowired
    private OrderDomainService orderDomainService;

    @Autowired
    private ValidateTools validateTools;

    @Autowired
    private WorkPanelApp workPanelApp;

    @Autowired
    private MedicalRecordsDomainService medicalRecordsDomainService;

    @Autowired
    private TreatmentPlanDomainService treatmentPlanDomainService;

    @Autowired
    private OrderApp orderApp;

    @Autowired
    private PatientApp patientApp;


    // region old version interface
    @ApiOperation("获取预约日历")
    @GetMapping("/getPatientSchedules")
    public R<List<WorkPanelVO>> getPatientSchedules(@Validated PatientSchedulesDTO params) {
        PatientSchedulesBO bo = new PatientSchedulesBO().setDataStr(params.getDataStr()).setType(params.getType());
        List<WorkPanelVO> vos = workPanelDomainService.getAppointmentPatientList(bo);
        return R.success(vos);
    }

    @Deprecated
    @ApiOperation("保存处理方案")
    @PostMapping("/saveTreatmentPlan")
    @NoRepeatSubmit
    public R<Integer> saveTreatmentPlan(@RequestBody @Validated SaveTreatmentPlanDTO params) throws Exception {


        SaveTreatmentPlanBO bo = new SaveTreatmentPlanBO()
                .setOrderSn(params.getOrderSn())
                .setPlanId(params.getPlanId())
                .setAdvice(params.getAdvice())
                .setPatientSn(params.getPatientSn());

        if (CollectionUtils.isNotEmpty(params.getAddList())) {
            validateTools.validateItems(params.getAddList());
            bo.setAddList(params.getAddList().stream().map(c -> {
                SaveTreatmentPlanItemBO planItemBO = new SaveTreatmentPlanItemBO();
                if (c.getProjectType().equals(PlanItemProjectTypeEnum.MEDICINE.getCode()) && c.getTotalPrice().compareTo(new BigDecimal(0)) < 0) {
                    throw new ServiceException("药物总价不能小于0");
                }
                BeanUtil.copyProperties(c, planItemBO);
                return planItemBO;
            }).collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(params.getEditList())) {

            validateTools.validateItems(params.getEditList());
            bo.setEditList(params.getEditList().stream().map(c -> {
                if (c.getProjectType().equals(PlanItemProjectTypeEnum.MEDICINE.getCode()) && c.getTotalPrice().compareTo(new BigDecimal(0)) < 0) {
                    throw new ServiceException("药物总价不能小于0");
                }
                SaveTreatmentPlanItemBO planItemBO = new SaveTreatmentPlanItemBO();
                BeanUtil.copyProperties(c, planItemBO);
                return planItemBO;
            }).collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(params.getDelList())) {
            bo.setDelList(params.getDelList().stream().map(c -> {
                SaveTreatmentPlanItemBO planItemBO = new SaveTreatmentPlanItemBO();
                BeanUtil.copyProperties(c, planItemBO);
                return planItemBO;
            }).collect(Collectors.toList()));
        }

        return R.success(workPanelDomainService.saveTreatmentPlan(bo));
    }


    @ApiOperation("根据诊疗记录id获取 管理员和医护人员的记录")
    @GetMapping("/getTreatmentRecordNotes/{id}")
    public R<TreatmentRecordNotesVO> getTreatmentRecordNotes(@PathVariable String id) {

        TreatmentRecordNotesVO treatmentRecordNotesVO = new TreatmentRecordNotesVO();
        treatmentRecordNotesVO = workPanelDomainService.getTreatmentRecordNotes(id);
        return R.success(treatmentRecordNotesVO);
    }

    @ApiOperation("保存诊疗记录的 管理员和医护人员的记录")
    @PostMapping("/saveTreatmentRecordNotes")
    public R<Boolean> saveTreatmentRecordNotes(@RequestBody SaveTreatmentRecordNotesDTO params) {
        boolean save = workPanelDomainService.saveTreatmentRecordNotes(params.getId(), params.getAdminNotes(), params.getMedicalStaffNotes());
        return R.success(save);
    }

    @ApiOperation("查看治疗单")
    @GetMapping("/getTherapyOrders/{orderSn}")
    public R<TherapyOrdersVO> getTherapyOrders(@PathVariable String orderSn) {
        TherapyOrdersVO therapyOrdersVO = workPanelDomainService.getTherapyOrders(orderSn);
        return R.success(therapyOrdersVO);
    }

    @ApiOperation("获取处置方案的项目的配置信息")
    @GetMapping("/getPlanProjectConfig")
    public R<List<PlanProjectConfigVO>> getPlanProjectConfig() {
        List<PlanProjectConfigVO> vos = treatmentPlanDomainService.getPlanProjectConfig(null);
        return R.success(vos);
    }

    @ApiOperation("根据患者编号获取订单编号集合")
    @GetMapping("/getOrderSnsByPatientSn/{patientSn}")
    public R<List<String>> getOrderSnsByPatientSn(@PathVariable @ApiParam(name = "patientSn", value = "患者编号", required = true) String patientSn) {
        return R.success(workPanelDomainService.getOrderSnsByPatientSn(patientSn));
    }

    @ApiOperation("保存病历资料")
    @PostMapping("/saveOutpatientMedicalRecord")
    @NoRepeatSubmit
    public R<Boolean> saveOutpatientMedicalRecord(@RequestBody @Validated SaveOutpatientMedicalRecordDTO params) {
        SaveOutpatientMedicalRecordBO bo = new SaveOutpatientMedicalRecordBO();
        BeanUtil.copyProperties(params, bo);
        List<ImgCoordinateDTO> imgCoordinate = params.getImgCoordinate();
        if (CollectionUtils.isNotEmpty(imgCoordinate)) {
            bo.setImgCoordinate(imgCoordinate.stream().map(imgdto -> {
                ImgCoordinateBO coordinateBO = new ImgCoordinateBO();
                coordinateBO.setX(imgdto.getX());
                coordinateBO.setY(imgdto.getY());
                return coordinateBO;
            }).collect(Collectors.toList()));
        }
        return R.success(workPanelDomainService.saveOutpatientMedicalRecord(bo));
    }


    @ApiOperation("保存患者资料")
    @PostMapping("/savePatientBasicInfo")
    public R<Boolean> savePatientBasicInfo(@RequestBody @Validated SavePatientBasicInfoDTO params) {
        SavePatientBasicInfoBO bo = new SavePatientBasicInfoBO();
        bo.setPatientSn(params.getPatientSn());
        bo.setIdentityType(params.getIdentityType());
        bo.setGender(params.getGender());
        bo.setAge(params.getAge());
        bo.setOccupation(params.getOccupation());
        bo.setWeight(params.getWeight());
        bo.setHeight(params.getHeight());
        bo.setNationality(params.getNationality());
        bo.setLanguage(params.getLanguage());
        bo.setTranslation(params.getTranslation());
        bo.setPurpose(params.getPurpose());
        bo.setRemarks(params.getRemarks());
        return R.success(patientDomainService.savePatientBasicInfo(bo));
    }

    // endregion

    // region V1.5 变更接口 ------------------ TODO V1.5

    // 根据挂号订单号查询面诊记录
    @ApiOperation("根据挂号订单号查询面诊记录")
    @GetMapping("/getChiefComplaintAndDiagnosis/{orderSn}")
    public R<InterviewRecordsVO> getChiefComplaintAndDiagnosis(@PathVariable String orderSn) {
        return R.success(orderApp.getInterviewRecordsByOrderSn(orderSn, "HEALTH_ADMIN"));
    }


    // 保存面诊记录
    @ApiOperation("保存面诊记录")
    @PostMapping("/saveInterviewRecords")
    @NoRepeatSubmit
    public R<Boolean> saveInterviewRecords(@RequestBody @Validated InterviewRecordsReq params) {
        InterviewRecordsBO bo = new InterviewRecordsBO();
        BeanUtil.copyProperties(params, bo);
        return R.success(orderDomainService.saveInterviewRecords(bo));
    }


    // endregion

    // region V1.5 新开接口 ------------------ TODO V1.5

    // 根据面诊记录id 发布或是隐藏面诊记录
    @ApiOperation("V1.5 新开接口 发布面诊记录")
    @PostMapping("/releaseOrHideInterviewRecords")
    public R<Boolean> releaseOrHideInterviewRecords(@RequestBody @Validated ReleaseOrHideInterviewRecordsReq params) {
        return R.success(orderDomainService.releaseOrHideInterviewRecords(params.getOrderSn(), params.getReleaseStatus()));
    }

    // 根据患者编号记录查看就诊记录
    @ApiOperation("V1.5 新开接口 根据患者编号记录查看就诊记录")
    @GetMapping("/getMedicalRecord/{patientSn}")
    public R<List<MedicalRecordPatientVO>> getMedicalRecord(@ApiParam(name = "patientSn", value = "患者编号", required = true) @PathVariable String patientSn) {
        return R.success(workPanelApp.getMedicalRecord(patientSn, AdminSecurityHolder.getClinicId()));
    }

    // 根据诊疗记录id获取治疗师描述
    @ApiOperation("V1.5 新开接口 根据诊疗记录id获取治疗师描述")
    @GetMapping("/getTTherapistStatement/{id}")
    public R<TherapistStatementVO> getTTherapistStatement(@ApiParam(name = "id", value = "诊疗记录id", required = true) @PathVariable String id) {
        MedicalRecords medicalRecords = medicalRecordsDomainService.getMedicalRecordById(id);
        if (ObjectUtils.isNotEmpty(medicalRecords)) {
            TherapistStatementVO vo = new TherapistStatementVO();
            vo.setId(medicalRecords.getId());
            vo.setStatementContent(medicalRecords.getStatementContent());
            vo.setStatementModifyTime(DateUtil.formatDateToString(medicalRecords.getStatementModifyTime(), DateUtil.FORMAT_TYPE_1));
            vo.setStatementOperator(medicalRecords.getStatementOperator());
            return R.success(vo);
        }
        return R.success(null);
    }

    // 保存诊疗记录的治疗师描述
    @ApiOperation("V1.5 新开接口 保存诊疗记录的治疗师描述")
    @PostMapping("/saveTherapistStatement")
    @NoRepeatSubmit
    public R<Boolean> saveTherapistStatement(@RequestBody SaveTherapistStatementReq params) {
        return R.success(medicalRecordsDomainService.saveTherapistStatement(params.getId(), params.getStatementContent(), AdminSecurityHolder.getUserName()));
    }


    // ---------处置方案---------

    // 处置方案列表
    @ApiOperation("V1.5 新开接口 处置方案列表")
    @GetMapping("/getDisposalPlanList/{patientSn}")
    public R<List<BaseTreatmentPlanVO>> getDisposalPlanList(@ApiParam(name = "patientSn", value = "患者编号", required = true) @PathVariable String patientSn) {

        List<BaseTreatmentPlanVO> baseList = patientApp.getDisposalPlanList(patientSn, AdminSecurityHolder.getClinicId(), null, null);

        return R.success(baseList);
    }

    // 处置创建新方案按钮
    @ApiOperation("V1.5 新开接口 处置创建新方案按钮")
    @GetMapping("/createNewDisposalPlan/{patientSn}")
    @NoRepeatSubmit
    public R<BaseTreatmentPlanVO> createNewDisposalPlan(@ApiParam(name = "patientSn", value = "患者编号", required = true) @PathVariable String patientSn) {
        // 创建新的
        treatmentPlanDomainService.createNewDisposalPlan(patientSn, AdminSecurityHolder.getClinicId());
        // 把所有数据都返回
        List<BaseTreatmentPlanVO> baseList = patientApp.getDisposalPlanList(patientSn, AdminSecurityHolder.getClinicId(), null, null);
        return R.success(baseList.get(0));
    }

    // 处置方案 添加次数按钮
    @ApiOperation("V1.5 新开接口 处置方案 添加次数按钮")
    @GetMapping("/addDisposalPlanTimes/{id}")
    @NoRepeatSubmit
    public R<TreatmentPlanVO> addDisposalPlanTimes(@ApiParam(name = "id", value = "处置方案 id", required = true) @PathVariable Integer id) {
        TreatmentPlan plan = treatmentPlanDomainService.addDisposalPlanTimes(id);
        // List<BaseTreatmentPlanVO> baseList = patientApp.getDisposalPlanList(plan.getPatientSn(), AdminSecurityHolder.getClinicId());
        TreatmentPlanVO planVO = new TreatmentPlanVO();
        planVO.setId(plan.getId());
        planVO.setPatientSn(plan.getPatientSn());
        planVO.setOrderSn(plan.getZlOrderSn());
        planVO.setRecommendedTime(DateUtil.formatDateToString(plan.getRecommendedTime(), DateUtil.FORMAT_TYPE_3));
        planVO.setNoRecommended(true);
        planVO.setExpectedOutcomes(plan.getExpectedOutcomes());
        planVO.setMechanization(plan.getMechanization());
        planVO.setCreateTime(DateUtil.formatDateToString(plan.getCreateTime(), DateUtil.FORMAT_TYPE_1));
        planVO.setSortNum(plan.getSortNum());
        return R.success(planVO);
    }

    // 处置方案里面添加项目的保存
    @ApiOperation("V1.5 新开接口 处置方案里面添加项目的保存")
    @PostMapping("/saveDisposalPlanItem")
    @NoRepeatSubmit
    public R<TreatmentPlanItemVO> saveDisposalPlanItem(@RequestBody SaveDisposalPlanItemReq params) {

        if (ObjectUtils.isEmpty(params.getPreferentialPrice()) && ObjectUtils.isEmpty(params.getPriceHour())) {
            throw new ServiceException("请输入价格");
        }

        SaveDisposalPlanItemBO bo = new SaveDisposalPlanItemBO();
        BeanUtils.copyProperties(params, bo);
        bo.setClinicId(AdminSecurityHolder.getClinicId());
        bo.setUserName(AdminSecurityHolder.getUserName());
        TreatmentPlanItem item = treatmentPlanDomainService.saveDisposalPlanItem(bo);
        if (ObjectUtils.isEmpty(item)) {
            log.error("处置方案的项目保存出错 ,item is null");
            throw new ServiceException("保存失败");
        }
        TreatmentPlanItemVO vo = new TreatmentPlanItemVO();
        vo.setId(item.getId());
        vo.setPlanId(item.getPlanId());
        vo.setItemId(item.getItemId());
        vo.setProjectType(item.getProjectType());
        vo.setItemName(item.getItemName());
        vo.setUnitPrice(ObjectUtils.isNotEmpty(params.getPriceHour()) ? params.getPriceHour() : "");
        vo.setTotalPrice(item.getTotalPrice().toString());
        vo.setPreferentialPrice(ObjectUtils.isNotEmpty(params.getPriceHour()) ? params.getPriceHour() : "");
        vo.setSourceAmount(item.getSourceAmount().toString());
        vo.setDurationPerSession(item.getDurationPerSession());
        return R.success(vo);
    }

    // 复用项目
    @ApiOperation("V1.5 新开接口 复用项目")
    @PostMapping("/copyDisposalPlanItem")
    public R<List<TreatmentPlanItemVO>> copyDisposalPlanItem(@RequestBody CopyDisposalPlanItemReq params) {

        if (ObjectUtils.isEmpty(params)) {
            throw new ServiceException("参数有误");
        }

        List<CopyDisposalPlanItemProjectReq> itemProjectReqList = params.getItemProjectReqList();

        if (ObjectUtils.isEmpty(itemProjectReqList)) {
            throw new ServiceException("未选择项目");
        }

        List<CopyDisposalPlanItemProjectBO> bos = itemProjectReqList.stream().map(c -> {
            CopyDisposalPlanItemProjectBO bo = new CopyDisposalPlanItemProjectBO();
            BeanUtils.copyProperties(c, bo);
            bo.setClinicId(AdminSecurityHolder.getClinicId());
            bo.setOperator(AdminSecurityHolder.getUserName());
            return bo;
        }).collect(Collectors.toList());

       List<TreatmentPlanItem> items= treatmentPlanDomainService.copyDisposalPlanItem(bos);

       if (ObjectUtils.isNotEmpty(items)){

           List<TreatmentPlanItemVO> voList = items.stream().map(item -> {

               TreatmentPlanItemVO vo = new TreatmentPlanItemVO();
               vo.setId(item.getId());
               vo.setPlanId(item.getPlanId());
               vo.setItemId(item.getItemId());
               vo.setProjectType(item.getProjectType());
               vo.setItemName(item.getItemName());
               vo.setUnitPrice(ObjectUtils.isNotEmpty(item.getUnitPrice())?item.getUnitPrice().toString():"");
               vo.setPriceHour(ObjectUtils.isNotEmpty(item.getUnitPrice())?item.getUnitPrice().toString():"");
               vo.setTotalPrice(item.getTotalPrice().toString());
               vo.setPreferentialPrice(ObjectUtils.isNotEmpty(item.getPreferentialPrice()) ? item.getPreferentialPrice().toString() : "");
               vo.setSourceAmount(item.getSourceAmount().toString());
               vo.setDurationPerSession(item.getDurationPerSession());
               return vo;
           }).collect(Collectors.toList());
           return R.success(voList);
       }
        return R.success(null);

    }

    // 处置方案次数的删除
    @ApiOperation("V1.5 新开接口 处置方案次数的删除")
    @PostMapping("/delDisposalPlanNum/{id}")
    public R<Boolean> delDisposalPlanNum(@ApiParam(name = "id", value = "处置方案次数的id", required = true) @PathVariable Integer id) {
        return R.success(treatmentPlanDomainService.delTreatmentPlan(id));
    }

    // 处置方案里面子项的删除
    @ApiOperation("V1.5 新开接口 处置方案列表里面的删除")
    @PostMapping("/delDisposalPlanItem/{id}")
    public R<Boolean> delDisposalPlanItem(@ApiParam(name = "id", value = "处置方案列表里面的id", required = true) @PathVariable Integer id) {
        return R.success(treatmentPlanDomainService.delTreatmentPlanItemProject(id));
    }

    // 处置方案的保存
    @ApiOperation("V1.5 新开接口 处置方案的保存")
    @PostMapping("/saveDisposalPlan")
    @NoRepeatSubmit
    public R<Boolean> saveDisposalPlan(@RequestBody @Validated SaveDisposalPlanReq params) {
        SaveDisposalPlanBO bo = new SaveDisposalPlanBO();
        BeanUtils.copyProperties(params, bo);
        bo.setDisposalPlanDetailList(ObjectUtils.isEmpty(params.getDisposalPlanDetailList()) ? new ArrayList<>() : params.getDisposalPlanDetailList().stream().map(c -> {
                    DisposalPlanNumDetailBO detailBO = new DisposalPlanNumDetailBO();
                    BeanUtils.copyProperties(c, detailBO);
                    return detailBO;
                }).collect(Collectors.toList())
        );
        Boolean su = treatmentPlanDomainService.saveDisposalPlan(bo);
        return R.success(su);
    }

    // 开具方案
    @ApiOperation("V1.5 新开接口 开具方案按钮")
    @GetMapping("/openDisposalPlan/{id}")
    @NoRepeatSubmit
    public R<Boolean> openDisposalPlan(@ApiParam(name = "id", value = "处置方案id", required = true) @PathVariable Integer id) {
        return R.success(treatmentPlanDomainService.openDisposalPlan(id));
    }

    // 合并治疗单
    @ApiOperation("V1.5 新开接口 合并治疗单按钮")
    @GetMapping("/mergeDisposalPlan/{id}")
    public R<List<MergePayOrderVO>> mergeDisposalPlan(@ApiParam(name = "id", value = "处置方案id", required = true) @PathVariable Integer id) {
        // 根据治疗方案 id 查订单
        List<MergePayOrderVO> voList = orderApp.mergeDisposalPlan(id);
        return R.success(voList);
    }

    // 合并订单确认按钮 查看治疗单
    @ApiOperation("V1.5 新开接口 合并订单确认按钮")
    @PostMapping("/mergeDisposalPlanConfirm")
    public R<TherapyOrdersNewVO> mergeDisposalPlanConfirm(@RequestBody MergeDisposalPlanConfirmReq params) {
        // 判断是否为空
        if (ObjectUtils.isEmpty(params.getOrderSns())) {
            throw new ServiceException("请选择治疗单");
        }

        TherapyOrdersNewVO vo = patientApp.mergeDisposalPlanConfirm(params.getId(), params.getOrderSns());

        return R.success(vo);
    }

    // 取消方案
    @ApiOperation("V1.5 新开接口 取消方案")
    @GetMapping("/cancelDisposalPlan/{id}")
    public R<Boolean> cancelDisposalPlan(@ApiParam(name = "id", value = "处置方案id", required = true) @PathVariable Integer id) {

        return R.success(treatmentPlanDomainService.cancelDisposalPlan(id));
    }


    // endregion


    //打印治疗单

    @ApiOperation("打印治疗单")
    @GetMapping("/printTreatOrder/{id}")
    public R<TherapyOrdersNewVO> printTreatOrder(@ApiParam(name = "id", value = "处置方案id", required = true) @PathVariable Integer id) {
        List<MergePayOrderVO> mergePayOrderVOS = orderApp.mergeDisposalPlan(id);
        if (ObjectUtils.isEmpty(mergePayOrderVOS)) {
            throw new ServiceException("该方案没有治疗单");
        }
        // 根据治疗方案 id 查订单
        TherapyOrdersNewVO vo = patientApp.mergeDisposalPlanConfirm(id + "", mergePayOrderVOS.stream().map(MergePayOrderVO::getOrderSn).collect(Collectors.toList()));
        return R.success(vo);
    }


}
