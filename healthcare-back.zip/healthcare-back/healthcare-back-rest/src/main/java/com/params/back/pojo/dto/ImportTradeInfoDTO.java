package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

/**
 * <pre>
 * params-merchant.
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */

@Getter
@Setter
public class ImportTradeInfoDTO {

    private MultipartFile file;

    @ApiModelProperty(value = "物流code", required = true, example = "1ABC", hidden = false)
    private String companyCode;

}
