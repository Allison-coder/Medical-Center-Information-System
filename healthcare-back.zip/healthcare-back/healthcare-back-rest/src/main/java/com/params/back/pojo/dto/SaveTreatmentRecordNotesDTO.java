package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class SaveTreatmentRecordNotesDTO {

    @ApiModelProperty("记录ID")
    private Integer id;

    @ApiModelProperty("管理员记录")
    private String adminNotes;

    @ApiModelProperty("医护人员记录")
    private String medicalStaffNotes;

}
