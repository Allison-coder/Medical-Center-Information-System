package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@ApiModel(description = "修改密码 VO")
public class ProfileUpdatePasswdDTO {

    @ApiModelProperty(value = "当前密码、MD5", required = true, example = "6666666")
    @NotEmpty(message = "密码不能为空")
    private String currentPassword;

    @ApiModelProperty(value = "新密码、明文", required = true, example = "6666666")
    @NotEmpty(message = "新密码不能为空")
    @Length(min = 8, max = 50, message = "新密码长度为 6-50 位")
    private String password;

    @ApiModelProperty(value = "确认密码、明文", required = true, example = "6666666")
    @NotEmpty(message = "确认密码不能为空")
    @Length(min = 8, max = 50, message = "确认密码长度为 6-50 位")
    private String passwordConfirmation;


}
