package com.params.back.pojo.dto;

import lombok.Data;

/**
 * @DESCRIPTION 身体图坐标 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class ImgCoordinateDTO {
    private Double x;
    private Double y;
}
