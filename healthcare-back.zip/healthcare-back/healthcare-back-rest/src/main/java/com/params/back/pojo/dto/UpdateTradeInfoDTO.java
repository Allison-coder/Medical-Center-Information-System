package com.params.back.pojo.dto;

import com.params.pojo.vo.Shipping;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * <pre>
 * params-merchant.
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */

@Getter
@Setter
public class UpdateTradeInfoDTO {


    @ApiModelProperty(value = "orderId", required = true, example = "{}", hidden = false)
    @NotNull(message = "orderId参数不能为空")
    private Long orderId;

    @ApiModelProperty(value = "物流类型", required = true, example = "EMS", hidden = false)
    private String logisticsType;

    @ApiModelProperty(value = "物流公司名称", required = true, example = "EMS邮政", hidden = false)
    @NotNull(message = "logisticsCompany参数不能为空")
    private String logisticsCompany;
    @ApiModelProperty(value = "物流单号", required = true, example = "12333333", hidden = false)
    @NotNull(message = "logisticsNo参数不能为空")
    private String logisticsNo;
    @ApiModelProperty(value = "物流信息", required = true, example = "{}", hidden = false)
    @NotNull(message = "请输入收件人信息")
    private Shipping shipping;

}
