package com.params.back.controller;

import com.alibaba.fastjson.JSON;
import com.params.application.order.OrderApp;
import com.params.application.schedule.ScheduleApp;
import com.params.back.interceptor.NoRepeatSubmit;
import com.params.back.interceptor.NotLogin;
import com.params.back.pojo.dto.GetAppointmentTimeDTO;
import com.params.back.pojo.dto.OperateMedicalDTO;
import com.params.back.pojo.dto.PatientInfoDTO;
import com.params.domain.order.OrderDomainService;
import com.params.domain.patient.PatientDomainService;
import com.params.entity.Patient;
import com.params.framework.vo.R;
import com.params.pojo.bo.ConfirmAppointmentBO;
import com.params.pojo.bo.OperateMedicalBO;
import com.params.pojo.bo.PatientAccountBO;
import com.params.pojo.bo.PatientQueryBO;
import com.params.pojo.dto.AddNewTreatmentDTO;
import com.params.pojo.dto.PatientTasksDTO;
import com.params.pojo.req.AddNewTreatmentReq;
import com.params.pojo.req.ConfirmAppointmentReq;
import com.params.pojo.req.PatientAccountReq;
import com.params.pojo.req.PatientQueryReq;
import com.params.pojo.req.PatientTasksReq;
import com.params.pojo.vo.PatientAdminVO;
import com.params.pojo.vo.PatientTaskVO;
import com.params.pojo.vo.WorkPanelVO;
import com.params.pojo.vo.common.PageVO;
import com.params.utils.AdminSecurityHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @DESCRIPTION 患者管理
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "患者管理")
@RestController
@RequestMapping("/patient/manage")
public class PatientManageController {

    @Autowired
    private ScheduleApp scheduleApp;

    @Autowired
    private PatientDomainService patientDomainService;

    @Autowired
    private OrderDomainService orderDomainService;

    @Autowired
    private OrderApp orderApp;

    // @Autowired

    @ApiOperation("新增或修改患者信息")
    @PostMapping("/createOrUpdatePatient")
    @PreAuthorize("hasRole('ADMINISTRATOR') OR hasRole('NURSE')")
    public R<Boolean> createPatient(@RequestBody @Validated PatientInfoDTO params) {
        Patient patient = Patient.builder()
                .patientSn(params.getPatientSn())
                .identityType(params.getIdentityType())
                .name(params.getName())
                .gender(params.getGender())
                .phoneNumber(params.getPhoneNumber())
                .clinicId(AdminSecurityHolder.getClinicId())
                .build();
        boolean save = patientDomainService.createOrUpdatePatient(patient);
        return R.success(save);
    }

    @ApiOperation("报到-开始治疗（开始面诊）-结束治疗（结束面诊）")
    @PostMapping("/operateMedical")
    public R<Boolean> operateMedical(@RequestBody OperateMedicalDTO params) {
        OperateMedicalBO bo = new OperateMedicalBO().setOpeType(params.getOpeType()).setOrderSn(params.getOrderSn());
        boolean t = patientDomainService.operateMedical(bo);
        return R.success(t);
    }

    @ApiOperation("获取预约时间")
    @PostMapping("/getAppointmentTime")
    public R<List<WorkPanelVO>> getAppointmentTime(@RequestBody GetAppointmentTimeDTO params) {
        List<WorkPanelVO> vos = patientDomainService.getAppointmentTime(params.getOrderSn(), params.getScheduleDate());
        return R.success(vos);
    }


    @ApiOperation("确认预约")
    @PostMapping("/confirmAppointment")
    @NoRepeatSubmit
    public R<String> confirmAppointment(@RequestBody ConfirmAppointmentReq params) throws Exception {
        ConfirmAppointmentBO bo = new ConfirmAppointmentBO().setAdminId(params.getAdminId()).setAppointmentDate(params.getAppointmentDate()).setOrderSn(params.getOrderSn()).setScheduleDetailIds(params.getScheduleDetailIds()).setPatientSn(params.getPatientSn());
        return R.success(orderDomainService.confirmAppointment(bo));
    }

    @ApiOperation("通过订单编号取消预约")
    @GetMapping("/cancleAppiont/{orderSn}")
    public R<Boolean> cancleAppiont(@ApiParam(name = "orderSn", value = "订单编号", required = true) @PathVariable String orderSn) {
        Boolean su = scheduleApp.cancleAppiont(orderSn);
        return R.success(su);
    }

    @ApiOperation("获取患者资料")
    @GetMapping("/getPatientDetail/{patientSn}")
    public R<PatientAdminVO> getPatientDetail(@PathVariable String patientSn) {
        PatientAdminVO vo = patientDomainService.getPatientDetail(patientSn);
        return R.success(vo);
    }

    @ApiOperation("获取患者门诊病例配置项")
    @GetMapping("/clinicCaseConfig")
    @NotLogin
    public R<Object> clinicCaseConfig() {
        Object parse = JSON.parse(patientDomainService.patientParamsConfig("PATIENT_OUTPATIENT_CASES"));
        return R.success(parse);
    }

    @ApiOperation("获取面诊治疗方案配置项")
    @GetMapping("/treatmentPlanConfig")
    public R<Object> treatmentPlanConfig() {
        Object parse = JSON.parse(patientDomainService.patientParamsConfig("ORDER_TREATMENT_PLAN"));
        return R.success(parse);
    }


    //region V1.5 变更接口 ------------------ TODO V1.5
    @ApiOperation("V1.5 变更接口 患者列表")
    @GetMapping("/list")
    public R<PageVO<PatientAdminVO>> list(PatientQueryReq params) {

        PatientQueryBO patientQueryBO = new PatientQueryBO()
                .setName(params.getName())
                .setPhoneNumber(params.getPhoneNumber())
                .setPageNum(params.getPageNum())
                .setPageSize(params.getPageSize());
        PageVO<PatientAdminVO> pageVO = patientDomainService.getPageList(patientQueryBO);
        return R.success(pageVO);
    }

    //endregion


    //region V1.5 新开接口 ------------------ TODO V1.5

    // 根据患者编号查询患者当前未完成任务列表
    @ApiOperation("V1.5 新开接口 患者当前未完成任务列表")
    @GetMapping("/getPatientWorkPanel/{patientSn}")
    public R<PageVO<PatientTaskVO>> getPatientTasks(PatientTasksReq params) {
        // 实际查的就是订单
        PatientTasksDTO dto = new PatientTasksDTO();
        dto.setPatientSn(params.getPatientSn());
        dto.setPageSize(params.getPageSize());
        dto.setPageNum(params.getPageNum());
        dto.setTaskStatus(params.getTaskStatus());
        PageVO<PatientTaskVO> voPageVO = orderApp.getPatientTaskOrders(dto);
        return R.success(voPageVO);
    }

    // 预约新治疗
    @ApiOperation("V1.5 新开接口 预约新治疗")
    @PostMapping("/addNewTreatment")
    public R<String> addNewTreatment(@RequestBody AddNewTreatmentReq params) {
        AddNewTreatmentDTO dto = new AddNewTreatmentDTO();
        BeanUtils.copyProperties(params, dto);
        return R.success(orderApp.addNewTreatment(dto));
    }


    //endregion

    //region V1.5.1 新开接口 ------------------ TODO V1.5.1

    // 根据患者编号修改姓名和手机号
    @ApiOperation("V1.5.1 新开接口 根据患者编号修改姓名和手机号")
    @PostMapping("/updatePatientAccount")
    @NoRepeatSubmit
    public R<Boolean> updatePatientAccount(@RequestBody @Validated PatientAccountReq params) {
        PatientAccountBO bo = new PatientAccountBO();
        BeanUtils.copyProperties(params, bo);
        return R.success(patientDomainService.updatePatientAccount(bo));
    }


    //endregion




}
