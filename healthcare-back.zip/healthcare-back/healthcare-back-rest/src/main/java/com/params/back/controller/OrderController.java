package com.params.back.controller;

import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.params.ErrorCodeEnum;
import com.params.application.order.OrderApp;
import com.params.application.patient.PatientApp;
import com.params.back.interceptor.NoRepeatSubmit;
import com.params.back.interceptor.NotLogin;
import com.params.back.pojo.dto.ModifyPriceDTO;
import com.params.back.pojo.dto.OrderDTO;
import com.params.back.pojo.dto.OrderImportOldPatientDTO;
import com.params.back.pojo.dto.OrderSnDTO;
import com.params.constant.OrderBusinessStatusEnum;
import com.params.constant.OrderStatusEnum;
import com.params.constant.OrderTypeEnum;
import com.params.constant.RoleCodeEnum;
import com.params.constant.ValidateUtil;
import com.params.domain.adminuser.AdminUserDomainService;
import com.params.domain.order.OrderDomainService;
import com.params.domain.order.OrderRefundDomainService;
import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.entity.AdminRole;
import com.params.entity.Orders;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.OrderCreateBO;
import com.params.pojo.dto.CreateOrderDTO;
import com.params.pojo.dto.ModifyZlOrderPriceDTO;
import com.params.pojo.dto.ModifyZlOrderPriceItemDTO;
import com.params.pojo.dto.QueryOrderDTO;
import com.params.pojo.req.ModifyZlOrderPriceItemReq;
import com.params.pojo.req.ModifyZlOrderPriceReq;
import com.params.pojo.vo.OrderVO;
import com.params.pojo.vo.RefundAmountVO;
import com.params.pojo.vo.common.PageVO;
import com.params.utils.AdminSecurityHolder;
import com.params.utils.DateUtil;
import com.params.utils.RandomUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@RestController
@Api(tags = "订单管理")
@Validated
@RequestMapping("/order/manage")
public class OrderController {

    @Autowired
    private OrderApp orderApp;

    @Autowired
    private PatientApp patientApp;

    @Autowired
    private OrderDomainService orderService;

    @Autowired
    private OrderRefundDomainService orderRefundDomainService;

    @Autowired
    private AdminUserDomainService adminUserDomainService;

    @Autowired
    private TreatmentPlanDomainService treatmentPlanDomainService;

    /**
     * 开具订单，除治疗师外都可以开单
     */
    // @PreAuthorize("hasRole('DOCTOR')")
    @PreAuthorize("isAuthenticated() && !hasRole('HEAL')")
    @ApiOperation("创建订单 除治疗师外都可以开单")
    @PostMapping("/createOrder")
    @NoRepeatSubmit
    public R<String> createOrder(@RequestBody @Validated CreateOrderDTO dto) {
        OrderCreateBO bo = OrderCreateBO.builder().patientSn(dto.getPatientSn())
                .scheduleDetailId(dto.getScheduleDetailId())
                .adminId(dto.getAdminId())
                .orderType(dto.getOrderType())
                .parentOrderSn(dto.getParentOrderSn())
                .channelId(AdminSecurityHolder.getClinicId())
                .planId(dto.getPlanId())
                .isUseCoupon(dto.getIsUseCoupon())
                .build();
        String orderSn = orderService.createOrder(bo);
        return R.success(orderSn);
    }

    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("取消订单")
    @PostMapping("/cancelOrder")
    public R cancelOrder(@RequestBody @Validated OrderSnDTO dto) {
        return R.success(orderService.cancelOrder(dto.getOrderSn(), AdminSecurityHolder.getClinicId()));
    }

    @ApiOperation("修改价格")
    @PostMapping("/modifyPrice")
    public R modifyPrice(@RequestBody @Validated ModifyPriceDTO dto) {
        return R.success(orderService.modifyPrice(dto.getOrderSn(), dto.getAmount(), AdminSecurityHolder.getClinicId()));
    }

    @ApiOperation("退款金额查询")
    @GetMapping("/getRefundAmount")
    public R<RefundAmountVO> getRefundAmount(@RequestParam(value = "orderSn") @NotNull @NotEmpty(message = "订单号不能为空！") String orderSn) {
        RefundAmountVO amountVO = orderRefundDomainService.refundAmount(orderSn, AdminSecurityHolder.getClinicId());
        return R.success(amountVO);
    }

    // 申请退款并直接
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("申请退款")
    @PostMapping("/refund")
    @NoRepeatSubmit
    public R refund(@RequestBody @Validated OrderSnDTO dto) {
        boolean refund = orderRefundDomainService.refund(dto.getOrderSn(), AdminSecurityHolder.getClinicId());
        return R.success(refund);
    }

    @ApiOperation("治疗单调价")
    @PostMapping("/modifyZlOrderPrice")
    public R<Boolean> modifyZlOrderPrice(@RequestBody @Validated ModifyZlOrderPriceReq param) {

        ModifyZlOrderPriceDTO dto = new ModifyZlOrderPriceDTO();
        dto.setZlOrderSn(param.getZlOrderSn());
        List<ModifyZlOrderPriceItemReq> params = param.getParams();
        if (ObjectUtils.isEmpty(params)) {
            throw new ServiceException("价格参数有误");
        }
        List<ModifyZlOrderPriceItemDTO> itemDTOS = params.stream().map(item -> {
            ModifyZlOrderPriceItemDTO itemDTO = new ModifyZlOrderPriceItemDTO();
            itemDTO.setId(item.getId());
            itemDTO.setTotalPrice(item.getTotalPrice());
            return itemDTO;
        }).collect(Collectors.toList());

        dto.setParams(itemDTOS);

        return R.success(treatmentPlanDomainService.modifyZlOrderPrice(dto));

    }



    //region V1.5 变更接口 ------------------ TODO V1.5
    @ApiOperation("V1.5 变更接口 订单列表")
    @GetMapping("/getOrders")
    public R<PageVO<OrderVO>> getOrders(OrderDTO req) {
        // 根据患者姓名，模糊查询得到患者号
        List<String> patientSns = new ArrayList<>();
        String patientName = req.getPatientName();
        if (StrUtil.isNotBlank(patientName)) {
            patientSns = patientApp.getPatientSnsByName(patientName, AdminSecurityHolder.getClinicId());
            if (patientSns.size() <= 0) {
                return R.success(new PageVO());
            }
        }
        // 根据查询当前用户，判断查询范围
        Integer adminId = AdminSecurityHolder.getAdminId();
        // 查出当前角色
        AdminRole role = adminUserDomainService.getRoleByadminId(adminId);
        ValidateUtil.isTrue(Objects.isNull(role), ErrorCodeEnum.ROLE_NOT_FIND_ERR);
        RoleCodeEnum roleCodeEnum = RoleCodeEnum.valueOf(role.getCode());
        ValidateUtil.isTrue(Objects.isNull(roleCodeEnum), ErrorCodeEnum.ROLE_NOT_FIND_ERR);
        // 医生、治疗师只能查看自己的订单，其他角色去除adminId
        if (!(RoleCodeEnum.DOCTOR.equals(roleCodeEnum) || RoleCodeEnum.HEAL.equals(roleCodeEnum))) {
            adminId = null;
        }
        // 如果是治疗师，走另一个方法
        if (RoleCodeEnum.HEAL.equals(roleCodeEnum)) {
            QueryOrderDTO dto = QueryOrderDTO.builder()
                    .orderSn(req.getOrderSn())
                    .patientSns(patientSns)
                    .orderStatusList(req.getStatusList())
                    .pageNum(req.getPageNum())
                    .pageSize(req.getPageSize())
                    .adminId(adminId)
                    .channelId(AdminSecurityHolder.getClinicId())
                    .build();
            PageVO<OrderVO> result = orderApp.getZlOrders(dto);
            return R.success(result);
        } else {
            QueryOrderDTO dto = QueryOrderDTO.builder()
                    .orderSn(req.getOrderSn())
                    .patientSns(patientSns)
                    .orderStatusList(req.getStatusList())
                    .pageNum(req.getPageNum())
                    .pageSize(req.getPageSize())
                    .adminId(adminId)
                    .channelId(AdminSecurityHolder.getClinicId())
                    .build();
            PageVO<OrderVO> result = orderApp.getOrders(dto);
            return R.success(result);
        }

    }

    //endregion

    @ApiOperation("导入老用户订单")
    @PostMapping(value = "/importPatientOrders", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @NotLogin
    public List<String> importPatientOrders(@RequestParam("file") MultipartFile file) throws IOException {
        // 创建一个 orders DTO
        List<OrderImportOldPatientDTO> excelDataList = EasyExcel.read(file.getInputStream())
                .head(OrderImportOldPatientDTO.class)
                .sheet()
                .doReadSync();

        if (CollectionUtils.isEmpty(excelDataList)) {
            throw new ServerException("导入数据为空");
        }
        
        List<Orders> ordersList = new ArrayList<>();
        // 创建 订单实体
        excelDataList.forEach(orderNew->{
            Orders orders = new Orders();
            orders.setId(0);
            orders.setOrderSn(getOrderSn(OrderTypeEnum.getEnum(orderNew.getOrderType()).getType()));
            orders.setOrderType(orderNew.getOrderType());
            orders.setOrderAmount(orderNew.getOrderAmount());
            orders.setSourceAmount(orderNew.getOrderAmount());
            orders.setDiscountAmount(new BigDecimal("0"));
            orders.setMerchantNum("手动导入单");
            orders.setTradeNum("手动导入单");
            orders.setPayTime(new Date());
            orders.setOrderStatus(OrderStatusEnum.IS_PAY.getCode());
            orders.setBusinessStatus(OrderBusinessStatusEnum.FINISH.getCode());
            orders.setScheduleDetailId(orderNew.getScheduleDetailId());
            orders.setAdminId(orderNew.getAdminId());
            orders.setPatientSn(orderNew.getPatientSn());
            orders.setCreateAdminId(1);
            orders.setOperator("admin");
            orders.setClinicId(1);
            ordersList.add(orders);
        });

        Boolean bool= orderService.createImportPatinetOrder(ordersList);

        return new ArrayList<String>();
    }

    private String getOrderSn(String type) {
        StringBuilder sb = new StringBuilder(type);
        sb.append(getOrderSn());
        return sb.toString();
    }

    private String getOrderSn() {
        String time = DateUtil.formatDateToString(new Date(), "yyyyMMddHHmmssSSS");
        String random = RandomUtil.randomString(5);
        return time + random;
    }

}
