package com.params.back.config;

import cn.binarywang.wx.miniapp.api.WxMaService;
import cn.binarywang.wx.miniapp.api.impl.WxMaServiceImpl;
import cn.binarywang.wx.miniapp.config.impl.WxMaDefaultConfigImpl;
import com.params.framework.properties.ProxyProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @DESCRIPTION 微信小程序的配置初始化
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Slf4j
@Configuration
public class WxMaConfig {
    @Autowired
    private WxMaProperties wxMaProperties;

    /**
     * 初始化微信服务 会自动维护获取access_token
     * @return
     */
    @Bean
    public WxMaService wxMaService( ProxyProperties proxyProperties) {
        log.info("============初始化微信小程序服务============");
        WxMaDefaultConfigImpl config = new WxMaDefaultConfigImpl();
        // 设置代理
        if (proxyProperties.getEnable()){
            config.setHttpProxyHost(proxyProperties.getIp());
            config.setHttpProxyPort(proxyProperties.getPort());
        }
        config.setAppid(wxMaProperties.getAppid());
        config.setSecret(wxMaProperties.getSecret());
        WxMaService service = new WxMaServiceImpl();
        service.setWxMaConfig(config);
        return service;
    }
}