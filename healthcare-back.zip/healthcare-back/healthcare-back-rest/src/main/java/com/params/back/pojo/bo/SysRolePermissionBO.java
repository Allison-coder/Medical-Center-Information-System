package com.params.back.pojo.bo;

import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Getter
@Setter
public class SysRolePermissionBO {
    /**
     * 角色ID
     */
    private Integer roleId;
    /**
     * 权限ID
     */
    private Integer permissionId;
}
