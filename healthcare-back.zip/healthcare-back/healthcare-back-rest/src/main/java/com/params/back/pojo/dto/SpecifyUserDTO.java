package com.params.back.pojo.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * @DESCRIPTION 指定用户导入的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class SpecifyUserDTO {

    // @ApiModelProperty("手机号码")
    @ExcelProperty("手机号码")
    private String phoneNum;
}
