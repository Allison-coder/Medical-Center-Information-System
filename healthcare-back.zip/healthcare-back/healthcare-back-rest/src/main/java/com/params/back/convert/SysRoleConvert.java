package com.params.back.convert;

import com.params.entity.SysPermissionRole;
import com.params.back.pojo.bo.SysRolePermissionBO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Mapper
public interface SysRoleConvert {

    SysRoleConvert INSTANCE = Mappers.getMapper(SysRoleConvert.class);

    @Mapping(source = "adminRoleId", target = "roleId")
    @Mapping(source = "sysPermissionId", target = "permissionId")
    SysRolePermissionBO convert(SysPermissionRole bean);
}
