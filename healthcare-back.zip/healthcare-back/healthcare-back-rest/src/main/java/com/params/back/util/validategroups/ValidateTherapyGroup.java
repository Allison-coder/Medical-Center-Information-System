package com.params.back.util.validategroups;

/**
 * @DESCRIPTION 康复治疗的字段校验
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public interface ValidateTherapyGroup {
}
