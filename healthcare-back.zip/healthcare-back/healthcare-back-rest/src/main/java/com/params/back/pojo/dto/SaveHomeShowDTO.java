package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @DESCRIPTION 保存首页展示位置的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@ApiModel("参数")
public class SaveHomeShowDTO {

    @ApiModelProperty("用户id")
    private Integer adminId;

    @ApiModelProperty("排序")
    private Integer homepageDisplaySort;
}
