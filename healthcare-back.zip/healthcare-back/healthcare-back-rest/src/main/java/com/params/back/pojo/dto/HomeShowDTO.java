package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class HomeShowDTO {

    @ApiModelProperty(value = "账号 id",required = true)
    private Integer adminId;

    @ApiModelProperty(value = "展示/隐藏  0-隐藏  1-开  默认 0")
    private Integer homepageDisplaySwitch;

}
