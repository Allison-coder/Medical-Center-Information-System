package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@ApiModel("订单取消 DTO")
public class OrderSnDTO {

    @ApiModelProperty(value = "订单号", example = "1")
    @NotNull
    @NotEmpty
    private String orderSn;
}
