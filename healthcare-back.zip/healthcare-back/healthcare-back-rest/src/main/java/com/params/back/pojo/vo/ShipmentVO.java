package com.params.back.pojo.vo;

import lombok.*;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/11
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShipmentVO {

    private Long no;
    private String orderNo;
    private String sender;
    private String senderAddress;
    private String senderMobile;
    private String type;
    private String supplierName;
    private String skuSpecs;
    private Long amount;
    private String shippingName;
    private String shippingMobile;
    private String shippingAddress;
    private String logisticsCompany;
    private String logisticsNo;
    private String logisticsStatus;
}
