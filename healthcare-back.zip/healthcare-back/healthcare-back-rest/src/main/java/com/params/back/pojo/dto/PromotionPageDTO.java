package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;

/**
 * @DESCRIPTION 优惠券活动列表入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@ApiModel("优惠券活动列表入参")
@Data
public class PromotionPageDTO implements Serializable {


    @ApiModelProperty(value = "活动名称")
    private String activityName;

    @ApiModelProperty(value = "渠道名称")
    private String channelName;

    @ApiModelProperty(value = "页大小，默认10", example = "10")
    @Min(1)
    @Max(100)
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码，默认1", example = "1")
    @Min(0)
    private Integer pageNum = 1;
}
