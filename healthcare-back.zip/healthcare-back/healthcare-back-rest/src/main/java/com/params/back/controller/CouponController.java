package com.params.back.controller;

import com.params.domain.coupon.CouponDomainService;
import com.params.framework.vo.R;
import com.params.pojo.vo.CouponTypeConfigVO;
import com.params.pojo.vo.CouponTypeTempVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @DESCRIPTION 优惠券的 controller
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "优惠券管理")
@RestController
@RequestMapping("/coupon/manage")
public class CouponController {
    @Autowired
    private CouponDomainService couponDomainService;


    // 获取优惠券类型
    @ApiOperation("获取优惠券类型")
    @GetMapping("/getCouponType")
    public R<List<CouponTypeConfigVO>> getCouponType(){
        List<CouponTypeConfigVO> list =couponDomainService.getCouponType();
        return R.success(CollectionUtils.isNotEmpty(list)?list:new ArrayList<>());
    }

    // 根据类型的id获取优惠券模板
    @ApiOperation("根据类型的id获取优惠券模板")
    @GetMapping("/getCouponTempById")
    public R<List<CouponTypeTempVO>> getCouponTempById(){

        return R.success(new ArrayList<>());
    }


}
