package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

/**
 * <pre>
 * params-merchant.
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */

@Getter
@Setter
public class ImportRefundLibraryDTO {

    private MultipartFile file;

    @ApiModelProperty(value = "类型 INTERCEPT-拦截 REFUND-退款货", required = true, example = "1ABC", hidden = false)
    private String type;
}
