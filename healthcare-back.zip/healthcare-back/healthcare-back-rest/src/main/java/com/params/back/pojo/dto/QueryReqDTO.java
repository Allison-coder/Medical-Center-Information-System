package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class QueryReqDTO {

    @ApiModelProperty(value = "获取搜索条件", required = false, example = "{}", hidden = false)
    private Map<String, Object> codes;

}
