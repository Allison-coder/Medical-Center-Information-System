package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.Valid;
import java.util.List;

/**
 * @DESCRIPTION 新增或是创建活动的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class CreateOrUpDatePromotionDTO {
    /**
     * 活动的基础信息
     * id
     * 1、活动名称
     * 2、渠道名称
     * 3、活动截止日期
     * 4、活动截止时间
     * 5、是否永久有效
     * 6、领取条件
     */


    @ApiModelProperty(value = "活动 id 修改的时候必填")
    private Integer id;

    @ApiModelProperty(value = "活动名称")
    private String activityName;

    @ApiModelProperty(value = "渠道名称")
    private String channelName;

    @ApiModelProperty(value = "截止日期")
    private String expireDate;

    @ApiModelProperty(value = "截止时间")
    private String expireTime;

    @ApiModelProperty(value = "是否永久有效 0-否 1-是")
    private Integer foreverStatus;

    @ApiModelProperty(value = "领取条件 详情接口： /promotion/manage/gettingCondition ")
    private Integer gettingCondition;

    @ApiModelProperty(value = "指定用户的 电话号码")
    List<String> phoneNumbers;

    @ApiModelProperty(value = "分享文案")
    private String shareContent;

    @ApiModelProperty(value = "总价值")
    private String totalValue;

    @ApiModelProperty(value = "优惠券列表")
    @Valid
    private List<ActivityCouponDetailsDTO> activityCouponDetails;
}
