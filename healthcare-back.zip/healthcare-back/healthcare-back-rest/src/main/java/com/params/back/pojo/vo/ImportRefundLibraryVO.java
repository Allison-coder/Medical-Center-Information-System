package com.params.back.pojo.vo;

import lombok.*;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/11
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ImportRefundLibraryVO {

    private String logisticsNo;
}
