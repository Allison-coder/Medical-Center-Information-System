package com.params.back.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.ImmutableMap;
import com.params.constant.RoleCodeEnum;
import com.params.dao.AdminRoleDao;
import com.params.entity.AdminRole;
import com.params.entity.AdminRoleBind;
import com.params.service.AdminRoleBindService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Slf4j
@Service
public class SysRoleServiceImpl implements SysRoleService {
    /**
     * 定时执行 {@link #schedulePeriodicRefresh()} 的周期
     * 因为已经通过 Redis Pub/Sub 机制，所以频率不需要高
     */
    private static final long SCHEDULER_PERIOD = 5 * 60 * 1000L;

    /**
     * 角色缓存
     * key：角色编号 {@link AdminRole#getId()}
     * <p>
     * 这里声明 volatile 修饰的原因是，每次刷新时，直接修改指向
     */
    private volatile Map<Integer, AdminRole> roleCache;
    /**
     * 缓存角色的最大更新时间，用于后续的增量轮询，判断是否有更新
     */
    private volatile Date maxUpdateTime;

    @Resource
    private AdminRoleBindService adminRoleBindService;

    @Resource
    private AdminRoleDao adminRoleDao;


    @Scheduled(fixedDelay = SCHEDULER_PERIOD, initialDelay = SCHEDULER_PERIOD)
    public void schedulePeriodicRefresh() {
        initLocalCache();
    }

    /**
     * 初始化 {@link #roleCache} 缓存
     */
    @Override
    @PostConstruct
    public void initLocalCache() {
        // 获取角色列表，如果有更新
        List<AdminRole> roleList = this.loadRoleIfUpdate(maxUpdateTime);
        if (CollUtil.isEmpty(roleList)) {
            return;
        }

        // 写入缓存
        ImmutableMap.Builder<Integer, AdminRole> builder = ImmutableMap.builder();
        roleList.forEach(sysRoleDO -> builder.put(sysRoleDO.getId(), sysRoleDO));
        roleCache = builder.build();
        assert roleList.size() > 0; // 断言，避免告警
        maxUpdateTime = roleList.stream().max(Comparator.comparing(AdminRole::getModifyTime)).get().getModifyTime();
        log.info("[initLocalCache][初始化 Role 数量为 {}]", roleList.size());
    }

    /**
     * 如果角色发生变化，从数据库中获取最新的全量角色。
     * 如果未发生变化，则返回空
     *
     * @param maxUpdateTime 当前角色的最大更新时间
     *
     * @return 角色列表
     */
    private List<AdminRole> loadRoleIfUpdate(Date maxUpdateTime) {
        // 第一步，判断是否要更新。
        if (maxUpdateTime == null) { // 如果更新时间为空，说明 DB 一定有新数据
            log.info("[loadRoleIfUpdate][首次加载全量角色]");
        } else { // 判断数据库中是否有更新的角色
            if (!adminRoleDao.selectExistsByUpdateTimeAfter(maxUpdateTime)) {
                return null;
            }
            log.info("[loadRoleIfUpdate][增量加载全量角色]");
        }
        // 第二步，如果有更新，则从数据库加载所有角色
        return adminRoleDao.selectList(new LambdaQueryWrapper<>());
    }


    @Override
    public List<AdminRoleBind> getUserRoles(Integer userId) {
        LambdaQueryWrapper<AdminRoleBind> bindQueryWrapper = new LambdaQueryWrapper<>();
        bindQueryWrapper.eq(AdminRoleBind::getAdminId, userId);
        return adminRoleBindService.list(bindQueryWrapper);
    }

    @Override
    public Set<Integer> getUserRoleIds(Integer userId, Set<Integer> singleton) {
        LambdaQueryWrapper<AdminRoleBind> bindQueryWrapper = new LambdaQueryWrapper<>();
        bindQueryWrapper.eq(AdminRoleBind::getAdminId, userId);
        List<AdminRoleBind> adminRoleBinds = adminRoleBindService.list(bindQueryWrapper);
        if (CollUtil.isEmpty(adminRoleBinds)) return new HashSet<>();

        LambdaQueryWrapper<AdminRole> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.in(AdminRole::getId, adminRoleBinds.stream().map(AdminRoleBind::getRoleId).distinct().collect(Collectors.toList()));

        return adminRoleDao.selectList(queryWrapper).stream().map(AdminRole::getId).collect(Collectors.toSet());
    }

    @Override
    public List<AdminRole> getRolesFromCache(Collection<Integer> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return Collections.emptyList();
        }
        return roleCache.values().stream().filter(roleDO -> ids.contains(roleDO.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public boolean hasAnyAdmin(Collection<AdminRole> roleList) {
        if (CollectionUtil.isEmpty(roleList)) {
            return false;
        }
        return roleList.stream().anyMatch(roleDO -> RoleCodeEnum.SUPER_ADMINISTRATOR.getKey().equals(roleDO.getCode()));
    }
}
