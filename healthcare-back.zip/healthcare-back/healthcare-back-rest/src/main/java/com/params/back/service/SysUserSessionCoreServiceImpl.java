package com.params.back.service;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.cachekey.SysAuthCacheKey;
import com.params.component.redis.ParamsRedis;
import com.params.component.security.core.LoginUser;
import com.params.entity.AdminSession;
import com.params.pojo.dto.AdminSessionQueryDTO;
import com.params.service.AdminSessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Date;

/**
 * <pre>
 * 在线用户 Session Core Service 实现类
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Service
public class SysUserSessionCoreServiceImpl implements SysUserSessionCoreService {

    @Autowired
    private ParamsRedis paramsRedis;

    @Autowired
    private AdminSessionService adminSessionService;

    @Override
    public String createUserSession(LoginUser loginUser, String userIp, String userAgent) {
        // 检查是否已有有效的session
        String existingSessionId = paramsRedis.get(SysAuthCacheKey.AUTH_BACKEND_TOKEN_CACHE_KEY.getKey(loginUser.getId(), userAgent, userIp));
        if (existingSessionId != null) {
            // 检查session是否有效
            LoginUser existingLoginUser = paramsRedis.get(SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(existingSessionId));
            if (existingLoginUser != null) {
                // 重新设置Session的有效期
                paramsRedis.setEx(SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(existingSessionId), existingLoginUser, getSessionTimeoutMillis());
                paramsRedis.setEx(SysAuthCacheKey.AUTH_BACKEND_TOKEN_CACHE_KEY.getKey(loginUser.getId(), userAgent, userIp), existingSessionId, getSessionTimeoutMillis());
                refreshUserSession(existingSessionId, existingLoginUser);
                return existingSessionId;
            }
        }

        // 生成 Session 编号
        String sessionId = generateSessionId();
        // 写入 Redis 缓存
        loginUser.setUpdateTime(new Date());

        String cacheKey = SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(sessionId);
        String userTokenCacheKey = SysAuthCacheKey.AUTH_BACKEND_TOKEN_CACHE_KEY.getKey(loginUser.getId());
        paramsRedis.setEx(cacheKey, loginUser, getSessionTimeoutMillis());
        paramsRedis.setEx(userTokenCacheKey, sessionId, getSessionTimeoutMillis());

        // 写入 DB 中
        AdminSession userSession = AdminSession
                .builder()
                .id(sessionId)
                .userId(loginUser.getId())
                .userType(loginUser.getUserType())
                .userIp(userIp)
                .userAgent(userAgent)
                .username(loginUser.getUsername())
                .sessionTimeout(DateUtil.offset(DateUtil.date(), DateField.SECOND, Math.toIntExact(getSessionTimeoutMillis().getSeconds())))
                .build();
        adminSessionService.save(userSession);
        // 返回 Session 编号
        return sessionId;
    }

    @Override
    public void refreshUserSession(String sessionId, LoginUser loginUser) {
        String cacheKey = SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(sessionId);
        String userTokenCacheKey = SysAuthCacheKey.AUTH_BACKEND_TOKEN_CACHE_KEY.getKey(loginUser.getId());

        // 写入 Redis 缓存
        loginUser.setUpdateTime(new Date());
        paramsRedis.setEx(cacheKey, loginUser, getSessionTimeoutMillis());
        paramsRedis.setEx(userTokenCacheKey, sessionId, getSessionTimeoutMillis());

        // 更新 DB 中
        AdminSession updateObj = AdminSession.builder().id(sessionId).build();
        updateObj.setUsername(loginUser.getUsername());
        updateObj.setModifyTime(DateUtil.date());
        updateObj.setSessionTimeout(DateUtil.offset(DateUtil.date(), DateField.SECOND, Math.toIntExact(getSessionTimeoutMillis().getSeconds())));
        adminSessionService.updateById(updateObj);
    }

    @Override
    public void deleteUserSession(String sessionId) {
        String cacheKey = SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(sessionId);
        // 删除 Redis 缓存
        paramsRedis.del(cacheKey);
        // 删除 DB 记录
        adminSessionService.removeById(sessionId);
    }

    @Override
    public LoginUser getLoginUser(String sessionId) {
        String cacheKey = SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getKey(sessionId);
        return paramsRedis.get(cacheKey);
    }

    @Override
    public Duration getSessionTimeoutMillis() {
        return SysAuthCacheKey.AUTH_BACKEND_CACHE_KEY.getExpire();
    }

    @Override
    public Page<AdminSession> findUserSessionPage(Page<AdminSession> page, AdminSessionQueryDTO query) {
        return adminSessionService.findUserSessionPage(page, query);
    }

    /**
     * 生成 Session 编号，目前采用 UUID 算法
     *
     * @return Session 编号
     */
    private static String generateSessionId() {
        return IdUtil.fastSimpleUUID();
    }
}
