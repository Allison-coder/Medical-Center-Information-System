package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@ApiModel("价格修改 DTO")
public class ModifyPriceDTO {
    @ApiModelProperty(value = "订单号", example = "1")
    @NotNull
    private String orderSn;

    @ApiModelProperty(value = "订单新价格，只能小于原价格", example = "9")
    @NotNull
    private BigDecimal amount;
}
