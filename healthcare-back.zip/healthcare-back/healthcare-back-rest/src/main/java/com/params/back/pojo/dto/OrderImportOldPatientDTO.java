package com.params.back.pojo.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @DESCRIPTION 导入旧用户订单的实体
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class OrderImportOldPatientDTO {


    /**
     * 预约的排班id
     */
    @ExcelProperty("预约ID")
    private Integer scheduleDetailId;
    /**
     * 患者ID
     */
    @ExcelProperty("患者编号")
    private String patientSn;

    /**
     * 订单类型，1：挂号单，2：治疗单
     */
    @ExcelProperty("订单类型")
    private Integer orderType;

    /**
     *  支付金额（RMB） 单位：元
     */
    @ExcelProperty("支付金额")
    private BigDecimal orderAmount;

    /**
     * 总价（RMB） 单位：元
     */
    @ExcelProperty("总价")
    private BigDecimal sourceAmount;

    @ExcelProperty("被预约人员id")
    private Integer adminId;

}
