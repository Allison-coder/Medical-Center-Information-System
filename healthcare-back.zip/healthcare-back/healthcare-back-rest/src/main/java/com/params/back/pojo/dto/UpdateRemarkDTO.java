package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * <pre>
 * params-merchant.
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */

@Getter
@Setter
public class UpdateRemarkDTO {

    @ApiModelProperty(value = "orderId", required = true, example = "{}", hidden = false)
    @NotNull(message = "orderId参数不能为空")
    private Long orderId;

    @ApiModelProperty(value = "备注", required = true, example = "{}", hidden = false)
    private String remark;

}
