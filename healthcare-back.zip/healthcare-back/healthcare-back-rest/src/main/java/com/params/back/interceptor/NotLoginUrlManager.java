package com.params.back.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.util.Map;
import java.util.Set;
import java.util.HashSet;

/**
 * @DESCRIPTION 免登录 url 管理器
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Component
@Slf4j
public class NotLoginUrlManager {
    @Autowired
    private RequestMappingHandlerMapping requestMappingHandlerMapping;

    public Set<String> findNotLoginUrl() {
        Map<RequestMappingInfo, HandlerMethod> handlerMethods = requestMappingHandlerMapping.getHandlerMethods();
        Set<String> notLoginUrls = new HashSet<>();
        for (Map.Entry<RequestMappingInfo, HandlerMethod> entry : handlerMethods.entrySet()) {
            RequestMappingInfo key = entry.getKey();
            HandlerMethod value = entry.getValue();
            NotLogin notLogin = value.getMethodAnnotation(NotLogin.class);
            if (notLogin == null) {
                continue;
            }
            Set<String> patterns = key.getPatternsCondition().getPatterns();
            notLoginUrls.addAll(patterns);
        }
        log.info("NotLogin URLs: {}" ,notLoginUrls);
        return notLoginUrls;
    }
}