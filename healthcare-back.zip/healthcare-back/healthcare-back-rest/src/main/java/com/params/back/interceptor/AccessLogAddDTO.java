package com.params.back.interceptor;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <pre>
 * 访问日志添加 DTO
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */
@Data
@Accessors(chain = true)
public class AccessLogAddDTO implements Serializable {
    /**
     * 用户编号 - 空
     */
    public static final Integer USER_ID_NULL = 0;

    private String traceId;
    private Integer userId;
    private String username;
    private Integer userType;
    private String applicationName;
    private String serverName;
    private String uri;
    private String url;
    private String queryString;
    private String method;
    private String userAgent;
    private String ip;
    private String startTime;
    private Integer responseTime;
    private Integer errorCode;
    /**
     * 错误提示
     */
    private String errorMessage;
}
