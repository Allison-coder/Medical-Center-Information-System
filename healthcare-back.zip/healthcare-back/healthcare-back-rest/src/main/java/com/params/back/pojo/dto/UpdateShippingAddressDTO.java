package com.params.back.pojo.dto;

import com.params.pojo.vo.Shipping;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * <pre>
 * params-merchant.
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */

@Getter
@Setter
public class UpdateShippingAddressDTO {


    @ApiModelProperty(value = "orderId", required = true, example = "{}", hidden = false)
    @NotNull(message = "orderId参数不能为空")
    private Long orderId;

    @ApiModelProperty(value = "物流信息", required = true, example = "{}", hidden = false)
    @NotNull(message = "请输入收件货信息")
    private Shipping shipping;

}
