package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @DESCRIPTION 管理后台创建患者的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PatientInfoDTO implements Serializable {

    @ApiModelProperty(value = "患者编号 修改时传入", example = "0")
    private String patientSn;

    @ApiModelProperty(value = "身份类型 0: 成人  1：未成年", required = true, example = "0")
    @NotNull(message = "身份类型参数不能为空")
    private Integer identityType;

    @ApiModelProperty(value = "患者姓名", required = true, example = "张三")
    @NotNull(message = "患者姓名参数不能为空")
    private String name;

    @ApiModelProperty(value = "手机号", required = true, example = "13727147258")
    @NotNull(message = "手机号参数不能为空")
    private String phoneNumber;

    @ApiModelProperty(value = "性别 0：女；1：男", example = "1")
    private Integer gender;

    /**
     @ApiModelProperty(value = "身份证号码", example = "441802199912301234")
     private String idCardNumber;

     @ApiModelProperty(value = "年龄", example = "18")
     private Integer age;


     @ApiModelProperty(value = "职业", example = "新时代农民工")
     private String occupation;

     @ApiModelProperty(value = "婚姻状况 1-未婚 2-已婚 3-离异", example = "1")
     private Integer maritalStatus;

     @ApiModelProperty(value = "头像对应fileKey,通过upload/sign接口获取", example = "tmp/2024/05/591d3fc7f5dc2f4449ba984d6454f467cf3")
     private String fileKey;
     */
}
