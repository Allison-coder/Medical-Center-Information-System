package com.params.back.pojo.dto;

import com.params.back.util.validategroups.ValidTotalSessions;
import com.params.back.util.validategroups.ValidateMedicineGroup;
import com.params.back.util.validategroups.ValidateTherapyGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @DESCRIPTION 处置方案的细项
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@ValidTotalSessions(
        min = 1,
        max = 99,
        rangeMessage = "总次数必须在1到99之间",
        comparisonMessage = "总次数必须大于或等于频率次数", groups = {ValidateTherapyGroup.class}
)
public class SaveTreatmentPlanItemDTO implements Serializable {

    @ApiModelProperty("项目 id")
    private Integer id;

    @ApiModelProperty("患者编号")
    private String patientSn;

    @ApiModelProperty("项目id  treatment_plan_project_config 表的主键 id")
    private Integer itemId;

    @ApiModelProperty("项目类型")
    @NotNull(message = "请选择项目名称")
    private Integer projectType;

    @ApiModelProperty("项目名称")
    private String itemName;

    @ApiModelProperty("单价（RMB） 单位：元")
    private BigDecimal unitPrice;

    @ApiModelProperty("总次数")
    @NotNull(message = "康复治疗总次数必填", groups = {ValidateTherapyGroup.class})
    private Integer totalSessions;

    @ApiModelProperty("总价 （RMB） 单位：元")
    @NotNull(message = "药物总价必填", groups = {ValidateMedicineGroup.class})
    private BigDecimal totalPrice;

    @ApiModelProperty("频率")
    // @NotNull(message = "频率必填", groups = {ValidateTherapyGroup.class, ValidateMedicineGroup.class})
    @NotNull(message = "频率必填", groups = {ValidateTherapyGroup.class})
    private String frequency;

    @ApiModelProperty("频率次数")
    // @NotNull(message = "频率次数必选", groups = {ValidateTherapyGroup.class, ValidateMedicineGroup.class})
    @NotNull(message = "频率次数必选", groups = {ValidateTherapyGroup.class})
    private Integer frequencyNum;

    @ApiModelProperty("单次时长")
    @NotNull(message = "必须设置单次时长", groups = {ValidateTherapyGroup.class})
    private Double durationPerSession;

    @ApiModelProperty("描述")
    private String description;


}
