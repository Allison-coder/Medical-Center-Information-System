package com.params.back.service;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.params.dao.SysPermissionDao;
import com.params.entity.SysPermission;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Slf4j
@Service
public class SysAdminPermissionServiceImpl implements SysAdminPermissionService {

    /**
     * 定时执行 {@link #schedulePeriodicRefresh()} 的周期
     * 因为已经通过 Redis Pub/Sub 机制，所以频率不需要高
     */
    private static final long SCHEDULER_PERIOD = 5 * 60 * 1000L;

    /**
     * 权限缓存
     * key：菜单编号
     * <p>
     * 这里声明 volatile 修饰的原因是，每次刷新时，直接修改指向
     */
    private volatile Map<Integer, SysPermission> permissionCache;

    /**
     * 权限与菜单缓存
     * key：权限 {@link SysPermission#getPerms()} ()}
     * value：SysMenuDO 数组，因为一个权限可能对应多个 SysMenuDO 对象
     * <p>
     * 这里声明 volatile 修饰的原因是，每次刷新时，直接修改指向
     */
    private volatile Multimap<String, SysPermission> permissionKeyCache;

    /**
     * 缓存菜单的最大更新时间，用于后续的增量轮询，判断是否有更新
     */
    private volatile Date maxUpdateTime;

    @Resource
    private SysPermissionDao sysPermissionDao;

    @Scheduled(fixedDelay = SCHEDULER_PERIOD, initialDelay = SCHEDULER_PERIOD)
    public void schedulePeriodicRefresh() {
        initLocalCache();
    }

    @Override
    @PostConstruct
    public void initLocalCache() {
        // 获取菜单列表，如果有更新
        List<SysPermission> sysPermissions = this.loadPermissionIfUpdate(maxUpdateTime);
        if (CollUtil.isEmpty(sysPermissions)) {
            return;
        }

        // 构建缓存
        ImmutableMap.Builder<Integer, SysPermission> menuCacheBuilder = ImmutableMap.builder();
        ImmutableMultimap.Builder<String, SysPermission> permMenuCacheBuilder = ImmutableMultimap.builder();
        sysPermissions.forEach(menuDO -> {
            menuCacheBuilder.put(menuDO.getId(), menuDO);
            permMenuCacheBuilder.put(menuDO.getPerms(), menuDO);
        });
        permissionCache = menuCacheBuilder.build();
        permissionKeyCache = permMenuCacheBuilder.build();
        assert sysPermissions.size() > 0; // 断言，避免告警
        maxUpdateTime = sysPermissions.stream().max(Comparator.comparing(SysPermission::getCreateTime)).get().getCreateTime();
        log.info("[initLocalCache][缓存权限，数量为:{}]", sysPermissions.size());
    }

    private List<SysPermission> loadPermissionIfUpdate(Date maxUpdateTime) {
        // 第一步，判断是否要更新。
        if (maxUpdateTime == null) { // 如果更新时间为空，说明 DB 一定有新数据
            log.info("[loadPermissionIfUpdate][首次加载全量菜单]");
        } else { // 判断数据库中是否有更新的菜单
            if (!sysPermissionDao.selectExistsByUpdateTimeAfter(maxUpdateTime)) {
                return null;
            }
            log.info("[loadPermissionIfUpdate][增量加载全量菜单]");
        }
        // 第二步，如果有更新，则从数据库加载所有菜单
        LambdaQueryWrapper<SysPermission> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.isNotNull(SysPermission::getPerms);
        queryWrapper.eq(SysPermission::getType,"PERMISSION");
        return sysPermissionDao.selectList(queryWrapper);
    }

    @Override
    public List<SysPermission> getPermissionListByPermissionFromCache(String permission) {
        return new ArrayList<>(permissionKeyCache.get(permission));
    }
}
