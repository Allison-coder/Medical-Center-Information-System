package com.params.back;

import com.params.framework.annotation.ScanIgnore;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.annotation.PostConstruct;
import java.util.TimeZone;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Slf4j
@SpringBootApplication
@ComponentScan(basePackages = {"com.params"}, excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, classes = ScanIgnore.class))
@MapperScan("com.params.dao")
@Import(cn.hutool.extra.spring.SpringUtil.class)
@EnableScheduling
public class HealthcareBackApplication {

    @PostConstruct
    void started() {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(HealthcareBackApplication.class);
        app.setBannerMode(Banner.Mode.OFF);
        ApplicationContext ctx = app.run(args);

        String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();

        log.info("############################################### Spring Boot using profile: {} port:http://0.0.0.0:{}"
                , activeProfiles
                , ctx.getEnvironment().getProperty("local.server.port")
        );
    }

}
