package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @DESCRIPTION 保存面诊记录的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class InterviewRecordsDTO {

    @ApiModelProperty(value = "订单编号")
    @NotBlank(message = "订单编号不能为空")
    private String   orderSn;

    @ApiModelProperty(value = "患者主诉")
    private String chiefComplaint;

    @ApiModelProperty(value = "诊断")
    private String diagnosis;

    @ApiModelProperty(value = "康复发展预测")
    private String forecast;


    @ApiModelProperty(value = "治疗方案")
    private String treatmentPlan;


    @ApiModelProperty(value = "预期治疗效果")
    private String expectedOutcomes;

    @ApiModelProperty(value = "医嘱")
    private String advice;
}
