package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.List;

@Data
@ApiModel("订单查询 DTO")
public class OrderDTO {

    @ApiModelProperty(value = "订单号", example = "GH2024051710493567136231")
    private String orderSn;

    @ApiModelProperty(value = "患者姓名", example = "张三")
    private String patientName;

    @ApiModelProperty(value = "订单状态 0：待支付 1：已支付 2：已取消 3：退款中 4：已退款，支持多个", example = "0,1")
    private List<Integer> statusList;

    @ApiModelProperty(value = "页大小，默认10", example = "10")
    @Min(1)
    @Max(100)
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码，默认1", example = "1")
    @Min(1)
    private Integer pageNum = 1;
}
