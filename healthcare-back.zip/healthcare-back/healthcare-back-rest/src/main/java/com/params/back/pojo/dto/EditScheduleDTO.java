package com.params.back.pojo.dto;

import com.params.entity.Schedule;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @DESCRIPTION 修改排班的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class EditScheduleDTO implements Serializable {

    @ApiModelProperty("新增的排班")
    List<EditScheduleItemDTO> addList;


    @ApiModelProperty("修改的排班")
    List<EditScheduleItemDTO>  editList;


    @ApiModelProperty("删除的排班")
    List<EditScheduleItemDTO>  delList;

}
