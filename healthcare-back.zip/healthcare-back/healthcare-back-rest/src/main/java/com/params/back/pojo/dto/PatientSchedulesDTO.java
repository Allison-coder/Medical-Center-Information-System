package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.NonNull;
import org.springframework.web.bind.annotation.PathVariable;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @DESCRIPTION 工作面板获取患者预约情况入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PatientSchedulesDTO implements Serializable {

    // @ApiModelProperty(value = "用户id")
    // private String adminId;

    @ApiModelProperty(value = "预约类型 1-挂号预约 2-治疗预约")
    @NotNull(message = "预约类型不能为空")
    private Integer type;

    @ApiModelProperty(value = "日期",example = "2020-01-01")
    @NotNull(message = "日期不能为空")
    private String dataStr;
}
