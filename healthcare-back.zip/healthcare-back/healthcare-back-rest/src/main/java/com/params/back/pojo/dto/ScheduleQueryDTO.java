package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 管理后台的排班列表查询入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class ScheduleQueryDTO implements Serializable {

    @ApiModelProperty(value = "人员 id")
    private Integer adminId;

    // 日期 - 年-月
    @ApiModelProperty(value = "日期",example = "2022-01")
    private String  data;


}
