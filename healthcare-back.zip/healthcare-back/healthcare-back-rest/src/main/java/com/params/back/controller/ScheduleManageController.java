package com.params.back.controller;

import cn.hutool.core.util.ObjectUtil;
import com.params.back.interceptor.NoRepeatSubmit;
import com.params.back.pojo.dto.BatchAddScheduleDTO;
import com.params.back.pojo.dto.EditScheduleDTO;
import com.params.back.pojo.dto.EditScheduleItemDTO;
import com.params.back.pojo.dto.ScheduleQueryDTO;
import com.params.constant.ScheduleStatusEnum;
import com.params.domain.schedule.ScheduleDomainService;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.BatchAddScheduleBO;
import com.params.pojo.bo.ScheduleQueryBO;
import com.params.pojo.dto.OpeScheduleDTO;
import com.params.pojo.vo.RoleAdminUserVO;
import com.params.pojo.vo.ScheduleListVO;
import com.params.utils.DateUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Api(tags = "排班管理")
@RequestMapping("/schedule/manage")
@RestController
public class ScheduleManageController {

    private static final Logger log = LoggerFactory.getLogger(ScheduleManageController.class);
    @Autowired
    private ScheduleDomainService scheduleDomainService;

    @ApiOperation("排班列表")
    @GetMapping("/list")
    public R<List<ScheduleListVO>> list(ScheduleQueryDTO params) {
        ScheduleQueryBO bo = new ScheduleQueryBO().setAdminId(params.getAdminId()).setData(params.getData());
        List<ScheduleListVO> list = scheduleDomainService.selectScheduleList(bo);
        return R.success(list);
    }

    @ApiOperation("角色人员列表")
    @GetMapping("/roleLUserList")
    public R<List<RoleAdminUserVO>> roleAdminUser() {
        List<RoleAdminUserVO> list = scheduleDomainService.selectRoleAdminUser();
        return R.success(list);
    }


    @PreAuthorize("hasRole('ADMINISTRATOR') OR hasRole('NURSE')")
    @ApiOperation("编辑排班")
    @PostMapping("/editSchedule")
    @NoRepeatSubmit
    public R editSchedule(@RequestBody EditScheduleDTO params) throws Exception {
        Date paramtDate = null;
        Boolean is_del = false;
        if (CollectionUtils.isNotEmpty(params.getAddList())) {
            paramtDate = params.getAddList().get(0).getScheduleDate();
        } else if (CollectionUtils.isNotEmpty(params.getEditList())) {
            paramtDate = params.getEditList().get(0).getScheduleDate();
        } else if (CollectionUtils.isNotEmpty(params.getDelList())) {
            paramtDate = params.getDelList().get(0).getScheduleDate();
            is_del = true;
        } else {
            throw new ServiceException("没有调整的排班数据");
        }

        if (paramtDate == null) {
            throw new ServiceException("排班日期有误");
        }
        // 判断选的日期是不是大于今天
        // 创建或获取一个Date实例
        Date currentDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DATE, -1);
        Date yesterday = calendar.getTime();

        if (!is_del && paramtDate.before(yesterday)) {
            throw new ServiceException("请选择大于当前日期和时间");
        }

        List<OpeScheduleDTO> addList = null;
        if (params.getAddList() != null && params.getAddList().size() > 0) {
            addList = new ArrayList<>();
            for (EditScheduleItemDTO dto : params.getAddList()) {
                OpeScheduleDTO opeScheduleDTO = coverOpeScheduleDTO(dto, is_del);
                addList.add(opeScheduleDTO);
            }
        }
        List<OpeScheduleDTO> editList = null;
        if (params.getEditList() != null && params.getEditList().size() > 0) {
            editList = new ArrayList<>();
            for (EditScheduleItemDTO dto : params.getEditList()) {
                OpeScheduleDTO opeScheduleDTO = coverOpeScheduleDTO(dto, is_del);
                editList.add(opeScheduleDTO);
            }
        }
        List<OpeScheduleDTO> delList = null;
        if (params.getDelList() != null && params.getDelList().size() > 0) {
            delList = new ArrayList<>();
            for (EditScheduleItemDTO dto : params.getDelList()) {
                OpeScheduleDTO opeScheduleDTO = coverOpeScheduleDTO(dto, is_del);
                delList.add(opeScheduleDTO);
            }
        }
        return R.success(scheduleDomainService.editSchedule(addList, editList, delList));

    }


    @PreAuthorize("hasRole('ADMINISTRATOR') OR hasRole('NURSE')")
    @ApiOperation("批量设置排班")
    @PostMapping("/batchAddSchedule")
    public R batchAddSchedule(@RequestBody BatchAddScheduleDTO params) {

        BatchAddScheduleBO bo = new BatchAddScheduleBO()
                .setAdminId(params.getAdminId())
                .setCurrentMonth(params.getCurrentMonth())
                .setDaysOfWeek(params.getDaysOfWeek())
                .setStartTimeStr(params.getStartTimeStr())
                .setEndTimeStr(params.getEndTimeStr());
        try {
            scheduleDomainService.batchAddSchedule(bo);
        } catch (Exception e) {
            log.error("批量设置排班异常", e);
            if (e instanceof ServiceException) {
                throw new ServiceException(e.getMessage());
            }
            throw new ServiceException("服务异常");
        }
        return R.success(true);
    }

    private OpeScheduleDTO coverOpeScheduleDTO(EditScheduleItemDTO dto, Boolean is_del) throws Exception {
        if (ObjectUtil.isEmpty(dto.getStartTime())|| ObjectUtil.isEmpty(dto.getEndTime())){
            throw new ServiceException("时间不能为空");
        }
        if (!is_del
                && !dto.getScheduleDate().after(new Date())) {
            Time startTime = DateUtil.converTime(dto.getStartTime());
            Time endTime = DateUtil.converTime(dto.getEndTime());


            if (ObjectUtil.isEmpty(dto.getScheduleStatus())
                    || !dto.getScheduleStatus().equals(ScheduleStatusEnum.FOR_LEAVE.getCode())) {
            // if (ObjectUtil.isNotEmpty(dto.getScheduleStatus())
            //         && !dto.getScheduleStatus().equals(ScheduleStatusEnum.FOR_LEAVE.getCode())) {
                String currented = DateUtil.currentTimeString(DateUtil.FORMAT_TYPE_5);
                Time currentTime = DateUtil.converTime(currented);
                if (startTime.before(currentTime)) {
                    throw new ServiceException("开始时间要大于当前时间");
                }
                // 判断结束时间是否小于当前时间
                if (endTime.before(currentTime)) {
                    throw new ServiceException("结束时间要大于当前时间");
                }

                // 开始时间不能晚于结束时间
                if (startTime.after(endTime)) {
                    throw new ServiceException("开始时间不能晚于结束时间");
                }
            }

        }


        OpeScheduleDTO opeScheduleDTO = new OpeScheduleDTO();
        opeScheduleDTO.setId(dto.getId());
        opeScheduleDTO.setAdminId(dto.getAdminId());
        opeScheduleDTO.setScheduleDate(dto.getScheduleDate());
        opeScheduleDTO.setStartTime(DateUtil.converTime(dto.getStartTime()));
        opeScheduleDTO.setEndTime(DateUtil.converTime(dto.getEndTime()));
        opeScheduleDTO.setScheduleStatus(dto.getScheduleStatus());
        return opeScheduleDTO;
    }


}
