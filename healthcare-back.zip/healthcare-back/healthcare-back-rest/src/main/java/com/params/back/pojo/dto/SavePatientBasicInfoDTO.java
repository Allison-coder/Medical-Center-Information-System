package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @DESCRIPTION 保存患者资料（工作面板）
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class SavePatientBasicInfoDTO implements Serializable {


    @ApiModelProperty("患者编号")
    @NotNull(message = "患者编号不能为空")
    private String patientSn;

    @ApiModelProperty("身份类型 0: 成人  1：未成年")
    private Integer identityType;

    @ApiModelProperty("性别 0：女；1：男")
    private Integer gender;

    @ApiModelProperty("年龄")
    private Integer age;

    @ApiModelProperty("职业")
    private String occupation;

    @ApiModelProperty("身高")
    private String height;

    @ApiModelProperty("体重")
    private String weight;

    @ApiModelProperty(value = "国籍")
    private String nationality;

    @ApiModelProperty(value = "语言")
    private String language;

    @ApiModelProperty(value = "是否翻译 0：否 1：是")
    private Integer translation;

    @ApiModelProperty(value = "目的")
    private List<String> purpose;

    @ApiModelProperty(value = "备注")
    private String remarks;

}
