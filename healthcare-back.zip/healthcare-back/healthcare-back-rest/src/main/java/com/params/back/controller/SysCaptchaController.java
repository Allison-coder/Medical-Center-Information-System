package com.params.back.controller;

import com.params.back.service.SysCaptchaService;
import com.params.framework.vo.R;
import com.params.back.pojo.vo.SysCaptchaImageRespVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Api(tags = "验证码")
@RestController
public class SysCaptchaController {

    @Autowired
    private SysCaptchaService captchaService;

    @PostMapping("/v1/sys/captcha/getCaptchaImage")
    @ApiOperation("生成图片验证码")
    public R<SysCaptchaImageRespVO> getCaptchaImage() {
        return R.success(captchaService.getCaptchaImage());
    }
}
