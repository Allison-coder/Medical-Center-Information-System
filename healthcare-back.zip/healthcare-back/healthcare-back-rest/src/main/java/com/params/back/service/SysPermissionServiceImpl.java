package com.params.back.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ArrayUtil;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.params.back.convert.SysRoleConvert;
import com.params.component.security.core.util.SecurityFrameworkUtils;
import com.params.entity.AdminRole;
import com.params.entity.AdminRoleBind;
import com.params.entity.SysPermission;
import com.params.framework.util.CollectionUtil;
import com.params.back.pojo.bo.SysRolePermissionBO;
import com.params.service.SysPermissionRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <pre>
 * 权限 Service 实现类
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Slf4j
@Service("ss") // 使用 Spring Security 的缩写，方便食用
public class SysPermissionServiceImpl implements SysPermissionService {


    /**
     * LoginUser 的 Context 缓存 Key
     */
    public static final String CONTEXT_KEY = SysPermissionServiceImpl.class.getSimpleName();

    /**
     * 定时执行 {@link #schedulePeriodicRefresh()} 的周期
     * 因为已经通过 Redis Pub/Sub 机制，所以频率不需要高
     */
    private static final long SCHEDULER_PERIOD = 5 * 60 * 1000L;

    /**
     * 角色编号与权限编号的缓存映射
     * key：角色编号
     * value：权限编号的数组
     * <p>
     * 这里声明 volatile 修饰的原因是，每次刷新时，直接修改指向
     */
    private volatile Multimap<Integer, Integer> rolePermissionCache;

    /**
     * 权限编号与角色编号的缓存映射
     * key：权限编号
     * value：角色编号的数组
     * <p>
     * 这里声明 volatile 修饰的原因是，每次刷新时，直接修改指向
     */
    private volatile Multimap<Integer, Integer> permissionRoleCache;

    /**
     * 缓存权限的最大更新时间，用于后续的增量轮询，判断是否有更新
     */
    private volatile Date maxUpdateTime;

    @Resource
    private SysRoleService sysRoleService;

    @Resource
    private SysPermissionRoleService sysPermissionRoleService;

    @Resource
    private SysAdminPermissionService sysAdminPermissionService;

    @Override
    @PostConstruct
    public void initLocalCache() {
        Date now = new Date();

        List<SysRolePermissionBO> sysRolePermissionBOS = this.loadRolePermissionIfUpdate(maxUpdateTime);

        if (CollUtil.isNotEmpty(sysRolePermissionBOS)) {
            // 初始化 rolePermissionCache 和 permissionRoleCache 缓sys_permission存
            ImmutableMultimap.Builder<Integer, Integer> rolePermissionCacheBuilder = ImmutableMultimap.builder();
            ImmutableMultimap.Builder<Integer, Integer> permissionRoleCacheBuilder = ImmutableMultimap.builder();
            sysRolePermissionBOS.forEach(rolePermission -> {
                rolePermissionCacheBuilder.put(rolePermission.getRoleId(), rolePermission.getPermissionId());
                permissionRoleCacheBuilder.put(rolePermission.getPermissionId(), rolePermission.getRoleId());
            });
            rolePermissionCache = rolePermissionCacheBuilder.build();
            permissionRoleCache = permissionRoleCacheBuilder.build();
        }
        assert sysRolePermissionBOS.size() > 0; // 断言，避免告警
        maxUpdateTime = now;
//        log.info("[initLocalCache][初始化角色与菜单的关联数量为 {}]", sysRolePermissionBOS.size());
    }

    private List<SysRolePermissionBO> loadRolePermissionIfUpdate(Date maxUpdateTime) {
        // 第一步，判断是否要更新。
        if (maxUpdateTime == null) { // 如果更新时间为空，说明 DB 一定有新数据
//            log.info("[loadRoleMenuIfUpdate][首次加载全量角色与菜单的关联]");
        } else { // 判断数据库中是否有更新的角色与菜单的关联
            if (Objects.isNull(sysPermissionRoleService.selectExistsByUpdateTimeAfter(maxUpdateTime))) {
                return new ArrayList<>();
            }
//            log.info("[loadRoleMenuIfUpdate][增量加载全量角色与菜单的关联]");
        }
        // 第二步，如果有更新，则从数据库加载所有角色与菜单的关联
        return sysPermissionRoleService.list().stream().map(SysRoleConvert.INSTANCE::convert).collect(Collectors.toList());
    }

    @Override
    public Set<Integer> getUserRoleIds(Integer userId, Collection<Integer> roleStatuses) {
        List<AdminRoleBind> userRoleList = sysRoleService.getUserRoles(userId);
        // 过滤角色状态
        // if (cn.hutool.core.collection.CollectionUtil.isNotEmpty(roleStatuses)) {
        //     userRoleList.removeIf(userRoleDO -> {
        //         SysRoleDO role = roleService.getRoleFromCache(userRoleDO.getRoleId());
        //         return role == null || !roleStatuses.contains(role.getStatus());
        //     });
        // }
        return CollectionUtil.convertSet(userRoleList, AdminRoleBind::getRoleId);
    }

    @Override
    public Set<Integer> getUserRoleIdListByUserId(Integer userId) {
        return CollectionUtil.convertSet(sysRoleService.getUserRoles(userId),
                AdminRoleBind::getRoleId);
    }

    @Override
    public boolean hasPermission(String permission) {
        return hasAnyPermissions(permission);
    }

    @Override
    public boolean hasAnyPermissions(String... permissions) {
        // 如果为空，说明已经有权限
        if (ArrayUtil.isEmpty(permissions)) {
            return true;
        }

        // 获得当前登录的角色。如果为空，说明没有权限
        Set<Integer> roleIds = SecurityFrameworkUtils.getLoginUserRoleIds();
        if (CollUtil.isEmpty(roleIds)) {
            return false;
        }
        // 判断是否是超管。如果是，当然符合条件
        if (sysRoleService.hasAnyAdmin(roleIds)) {
            return true;
        }

        // 遍历权限，判断是否有一个满足
        return Arrays.stream(permissions).anyMatch(permission -> {
            List<SysPermission> sysPermissions = sysAdminPermissionService.getPermissionListByPermissionFromCache(permission);
            // 采用严格模式，如果权限找不到对应的 Menu 的话，认为
            if (CollUtil.isEmpty(sysPermissions)) {
                return false;
            }
            // 获得是否拥有该权限，任一一个
            return sysPermissions.stream().anyMatch(perm -> CollUtil.containsAny(roleIds, permissionRoleCache.get(perm.getId())));
        });
    }

    @Override
    public boolean hasRole(String role) {
        return hasAnyRoles(role);
    }

    @Override
    public boolean hasAnyRoles(String... roles) {
        // 如果为空，说明已经有权限
        if (ArrayUtil.isEmpty(roles)) {
            return true;
        }

        // 获得当前登录的角色。如果为空，说明没有权限
        Set<Integer> roleIds = SecurityFrameworkUtils.getLoginUserRoleIds();
        if (CollUtil.isEmpty(roleIds)) {
            return false;
        }
        // 判断是否是超管。如果是，当然符合条件
        if (sysRoleService.hasAnyAdmin(roleIds)) {
            return true;
        }
        Set<String> userRoles = CollectionUtil.convertSet(sysRoleService.getRolesFromCache(roleIds), AdminRole::getCode);
        return CollUtil.containsAny(userRoles, Sets.newHashSet(roles));
    }

    @Scheduled(fixedDelay = SCHEDULER_PERIOD, initialDelay = SCHEDULER_PERIOD)
    public void schedulePeriodicRefresh() {
        initLocalCache();
    }


}
