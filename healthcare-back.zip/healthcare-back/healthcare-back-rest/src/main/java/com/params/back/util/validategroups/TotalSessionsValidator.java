package com.params.back.util.validategroups;

import com.params.back.pojo.dto.SaveTreatmentPlanItemDTO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @DESCRIPTION 验证器
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public class TotalSessionsValidator implements ConstraintValidator<ValidTotalSessions, SaveTreatmentPlanItemDTO> {
    private int min;
    private int max;
    private String rangeMessage;
    private String comparisonMessage;

    @Override
    public void initialize(ValidTotalSessions constraintAnnotation) {
        this.min = constraintAnnotation.min();
        this.max = constraintAnnotation.max();
        this.rangeMessage = constraintAnnotation.rangeMessage();
        this.comparisonMessage = constraintAnnotation.comparisonMessage();
    }

    @Override
    public boolean isValid(SaveTreatmentPlanItemDTO item, ConstraintValidatorContext context) {
        if (item == null) {
            return true;
        }
        Integer totalSessions = item.getTotalSessions();
        Integer frequencyNum = item.getFrequencyNum();

        if ((totalSessions != null && (totalSessions < min || totalSessions > max))) {

            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(rangeMessage)
                    .addPropertyNode("totalSessions")
                    .addConstraintViolation();
            return false;
        }

        if (totalSessions != null && frequencyNum != null && totalSessions < frequencyNum) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(comparisonMessage)
                    .addPropertyNode("totalSessions")
                    .addConstraintViolation();
            return false;
        }

        return true;

    }
}
