package com.params.back.convert;

import com.params.component.security.core.LoginUser;
import com.params.entity.Admin;
import com.params.entity.AdminRole;
import com.params.entity.SysPermission;
import com.params.framework.constant.UserTypeEnum;
import com.params.framework.util.CollectionUtil;
import com.params.back.pojo.vo.SysAuthProfileRespVO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Mapper
public interface SysAuthConvert {

    SysAuthConvert INSTANCE = Mappers.getMapper(SysAuthConvert.class);

    @Mapping(source = "modifyTime", target = "updateTime", ignore = true) // 字段相同，但是含义不同，忽略
    @Mapping(source = "name", target = "username")
    @Mapping(source = "password", target = "password")
    @Mapping(source = "status", target = "status")
    @Mapping(source = "clinicId", target = "extend")
    LoginUser convert0(Admin bean);

    default LoginUser convert(Admin bean) {
        // 目的，为了设置 UserTypeEnum.ADMIN.getValue()
        return convert0(bean).setUserType(UserTypeEnum.ADMIN.getValue());
    }

    default SysAuthProfileRespVO convert(Admin admin, List<AdminRole> roleList, List<SysPermission> menuList) {
        return SysAuthProfileRespVO.builder()
                .user(SysAuthProfileRespVO.UserVO.builder().nickname(admin.getNickName()).build())
                .roles(CollectionUtil.convertSet(roleList, AdminRole::getCode))
                .permissions(CollectionUtil.convertSet(menuList, SysPermission::getPermissionUrl))
                .build();
    }
}
