package com.params.component.security.core;

import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.annotation.JSONField;
import com.params.framework.constant.UserStatusEnum;
import com.params.framework.constant.UserTypeEnum;
import lombok.Data;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * 登录用户信息
 * Created by jc on 2022/1/14.
 * </pre>
 *
 * @author jc
 * @version 1.0.0
 */
@Data
public class LoginUser implements UserDetails {
    /**
     * 用户类型
     * <p>
     * 关联 {@link UserTypeEnum}
     */
    private Integer userType;

    /**
     * 用户编号
     */
    private Integer id;
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;
    /**
     * 最后更新时间
     */
    private Date updateTime;
    /**
     * 状态
     */
    private String status;

    private Object extend;

    private List<String> roles;

    // ========== UserTypeEnum.ADMIN 独有字段 ==========
    /**
     * 角色编号数组
     */
    private Set<Integer> roleIds;

    // ========== 上下文 ==========
    /**
     * 上下文字段，不进行持久化
     * <p>
     * 1. 用于基于 LoginUser 维度的临时缓存
     */
    @JSONField(serialize = false)
    private Map<String, Object> context;

    @Override
    @JSONField(serialize = false) // 避免序列化
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    @JSONField(serialize = false) // 避免序列化
    public boolean isEnabled() {
        return UserStatusEnum.NORMAL.getValue().equalsIgnoreCase(status);
    }

    @Override
    @JSONField(serialize = false) // 避免序列化
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> list = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(this.roles)){
            for (String role : this.roles) {
                list.add(new SimpleGrantedAuthority(role));
            }
        }
        return list;
    }

    @Override
    @JSONField(serialize = false) // 避免序列化
    public boolean isAccountNonExpired() {
        return true; // 返回 true，不依赖 Spring Security 判断
    }

    @Override
    @JSONField(serialize = false) // 避免序列化
    public boolean isAccountNonLocked() {
        return true; // 返回 true，不依赖 Spring Security 判断
    }

    @Override
    @JSONField(serialize = false) // 避免序列化
    public boolean isCredentialsNonExpired() {
        return true;  // 返回 true，不依赖 Spring Security 判断
    }

    // ========== 上下文 ==========

    public void setContext(String key, Object value) {
        if (context == null) {
            context = new HashMap<>();
        }
        context.put(key, value);
    }

    public <T> T getContext(String key, Class<T> type) {
        return MapUtil.get(context, key, type);
    }

    public LoginUser setUserType(Integer userType) {
        this.userType = userType;
        return this;
    }
}
