package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

@ApiModel("密码验证 Request VO")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysAuthPwdReqDTO {

    @ApiModelProperty(value = "密码", required = true, example = "6666666")
    @NotEmpty(message = "密码不能为空")
    private String password;

}
