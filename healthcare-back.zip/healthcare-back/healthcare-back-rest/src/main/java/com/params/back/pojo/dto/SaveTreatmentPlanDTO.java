package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * @DESCRIPTION 保存处置方案的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class SaveTreatmentPlanDTO  implements Serializable {

    @ApiModelProperty(value = "患者编号",required = true)
    @NotNull(message = "患者编号不能为空")
    private String patientSn;

    @ApiModelProperty(value = "订单编号",required = true)
    @NotNull(message = "订单编号不能为空")
    private String orderSn;

    @ApiModelProperty("医嘱")
    @Size(max = 200,message = "医嘱不能超过200个字符")
    private String advice;

    @ApiModelProperty("方案ID 新增时为空")
    private Integer planId;

    @ApiModelProperty("新增的项目集合")
    @Valid
    List<SaveTreatmentPlanItemDTO> addList;

    @ApiModelProperty("修改的项目集合")
    @Valid
    List<SaveTreatmentPlanItemDTO> editList;

    @ApiModelProperty("删除的项目集合")
    @Valid
    List<SaveTreatmentPlanItemDTO> delList;



}
