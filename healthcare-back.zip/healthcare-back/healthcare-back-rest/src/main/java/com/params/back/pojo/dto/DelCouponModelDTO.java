package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 删除活动的优惠券入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class DelCouponModelDTO implements Serializable {


    /**
     * 优惠券(模板) id
     */
    @ApiModelProperty(value = "优惠券(模板) id", required = true)
    private Integer couPonTempId;
    /**
     * 活动id
     */
    @ApiModelProperty(value = "活动 id", required = true)
    private Integer promoId;


}
