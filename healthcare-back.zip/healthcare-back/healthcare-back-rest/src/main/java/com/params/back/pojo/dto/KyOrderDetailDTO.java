package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/11
 */
@ApiModel("订单详情 Request VO")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KyOrderDetailDTO {

    @ApiModelProperty(value = "订单ID", required = true, example = "1", hidden = false)
    @NotNull(message = "orderId参数不能为空")
    private Long orderId;
}
