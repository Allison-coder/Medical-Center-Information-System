package com.params.back.pojo.permission;

/**
 * <pre>
 *
 * 
 * </pre>
 *
 * 
 * @version 1.0.0
 */
public interface OrderPermission {

    /**
     * 查看
     */
    String VIEW = "healthcare:order:view";
    String EDIT = "healthcare:order:edit";
    String EXPORT = "healthcare:order:export";
    String IMPORT = "healthcare:order:import";
    String APPLY_REFUND = "healthcare:order:apply_refund";
    String DEAL_REFUND = "healthcare:order:deal_refund";
    String CANCEL_REFUND = "healthcare:order:cancel_refund";
    String REJECT_REFUND = "healthcare:order:reject_refund";
    String AGREE_REFUND = "healthcare:order:agree_refund";
    String REFUND_LIST = "healthcare:order:refund_list";
    String IMPORT_REFUND_LIBRARY = "healthcare:order:import:refund_library";

}
