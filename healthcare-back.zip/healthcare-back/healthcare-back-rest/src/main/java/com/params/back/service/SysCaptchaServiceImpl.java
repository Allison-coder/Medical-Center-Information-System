package com.params.back.service;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.CircleCaptcha;
import cn.hutool.core.util.IdUtil;
import com.params.back.config.CaptchaProperties;
import com.params.back.convert.SysCaptchaConvert;
import com.params.cachekey.CaptchaCacheKey;
import com.params.component.redis.ParamsRedis;
import com.params.back.pojo.vo.SysCaptchaImageRespVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 验证码 Service 实现类
 */
@Service
public class SysCaptchaServiceImpl implements SysCaptchaService {

    @Autowired
    private ParamsRedis paramsRedis;

    @Resource
    private CaptchaProperties captchaProperties;

    @Override
    public SysCaptchaImageRespVO getCaptchaImage() {

        // 生成验证码
        CircleCaptcha captcha = CaptchaUtil.createCircleCaptcha(captchaProperties.getWidth(), captchaProperties.getHeight(), 4, 30);
        // 缓存到 Redis 中
        String uuid = IdUtil.fastSimpleUUID();
        String cacheKey = CaptchaCacheKey.CAPTCHA_CACHE_KEY.getKey(uuid);
        paramsRedis.setEx(cacheKey, captcha.getCode(), captchaProperties.getTimeout());
        // 返回
        return SysCaptchaConvert.INSTANCE.convert(uuid, captcha);
    }

    @Override
    public Boolean isCaptchaEnable() {
        return captchaProperties.getEnable();
    }

    @Override
    public String getCaptchaCode(String uuid) {
        String cacheKey = CaptchaCacheKey.CAPTCHA_CACHE_KEY.getKey(uuid);
        return paramsRedis.get(cacheKey);
    }

    @Override
    public void deleteCaptchaCode(String uuid) {
        String cacheKey = CaptchaCacheKey.CAPTCHA_CACHE_KEY.getKey(uuid);
        paramsRedis.del(cacheKey);
    }
}
