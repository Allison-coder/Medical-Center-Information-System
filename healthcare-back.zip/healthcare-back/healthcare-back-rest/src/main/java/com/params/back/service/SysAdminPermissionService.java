package com.params.back.service;

import com.params.entity.SysPermission;

import java.util.List;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface SysAdminPermissionService {

    /**
     * 初始化菜单的本地缓存
     */
    void initLocalCache();

    List<SysPermission> getPermissionListByPermissionFromCache(String permission);
}
