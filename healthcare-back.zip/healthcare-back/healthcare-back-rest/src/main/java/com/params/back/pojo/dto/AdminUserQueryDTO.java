package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;

/**
 * 查询后台人员管理列表的 DTO
 */
@Data
@ApiModel("查询后台人员管理列表的 DTO")
public class AdminUserQueryDTO implements Serializable {


    @ApiModelProperty(value = "人员名称")
    private String realName;


    @ApiModelProperty(value = "用户角色ID")
    private Integer roleId;

    @ApiModelProperty(value = "页大小，默认10", example = "10")
    @Min(1)
    @Max(100)
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码，默认1", example = "1")
    @Min(0)
    private Integer pageNum = 1;


}
