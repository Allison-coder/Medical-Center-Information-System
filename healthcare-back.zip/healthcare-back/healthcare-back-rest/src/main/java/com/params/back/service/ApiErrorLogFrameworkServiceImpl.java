package com.params.back.service;

import com.params.framework.core.service.ApiErrorLogFrameworkService;
import com.params.framework.core.service.dto.ApiErrorLogCreateReqDTO;
import org.springframework.stereotype.Service;

import javax.validation.Valid;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
@Service
public class ApiErrorLogFrameworkServiceImpl implements ApiErrorLogFrameworkService {
    @Override
    public void createApiErrorLogAsync(@Valid ApiErrorLogCreateReqDTO createDTO) {

    }
}
