package com.params.back.service;

import com.params.component.security.core.service.SecurityPermissionFrameworkService;
import com.params.entity.SysPermission;
import org.springframework.lang.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * <pre>
 * 权限 Service 接口
 *
 * 提供用户-角色、角色-菜单、角色-部门的关联权限处理
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface SysPermissionService extends SecurityPermissionFrameworkService {
    /**
     * 初始化权限的本地缓存
     */
    void initLocalCache();

    /**
     * 获得用户拥有的角色编号集合
     *
     * @param userId       用户编号
     * @param roleStatuses 角色状态集合. 允许为空，为空时不过滤
     *
     * @return 角色编号集合
     */
    Set<Integer> getUserRoleIds(Integer userId, @Nullable Collection<Integer> roleStatuses);

    /**
     * 获得用户拥有的角色编号集合
     *
     * @param userId 用户编号
     *
     * @return 角色编号集合
     */
    Set<Integer> getUserRoleIdListByUserId(Integer userId);

}
