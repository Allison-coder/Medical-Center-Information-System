package com.params.back.controller;


import com.params.back.interceptor.NoRepeatSubmit;
import com.params.back.pojo.dto.AddAdminUserDTO;
import com.params.back.pojo.dto.AdminUserQueryDTO;
import com.params.back.pojo.dto.EditAdminUserDTO;
import com.params.back.pojo.dto.HomeShowDTO;
import com.params.back.pojo.dto.SaveHomeShowDTO;
import com.params.back.pojo.dto.SaveInfoDTO;
import com.params.constant.HomepageDisplayEnum;
import com.params.domain.adminuser.AdminUserDomainService;
import com.params.entity.AdminUserInfo;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.AddAdminUserBO;
import com.params.pojo.bo.EditAdminUserBO;
import com.params.pojo.bo.HomeShowBO;
import com.params.pojo.vo.AdminRoleVO;
import com.params.pojo.vo.AdminUserVO;
import com.params.pojo.vo.GetHomeShowVO;
import com.params.pojo.vo.common.PageVO;
import com.params.utils.AdminSecurityHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 后台人员列表管理
 */

@Api(tags = "人员管理")
@RestController
@RequestMapping("/admin/manage")
public class AdminUserManageController {

    @Autowired
    private AdminUserDomainService adminUserDomainService;


    /**
     * 人员管理列表
     *
     * @param params
     * @return
     */
    @ApiOperation("人员管理列表")
    @GetMapping("/list")
    public R<PageVO<AdminUserVO>> getAdminUserList(AdminUserQueryDTO params) {
        PageVO<AdminUserVO> pageVO = adminUserDomainService.getPage(params.getRealName(), params.getRoleId(), params.getPageNum(), params.getPageSize());
        return R.success(pageVO);
    }


    /**
     * 获取人员信息
     *
     * @param adminId
     * @return
     */
    @ApiOperation("获取人员信息")
    @GetMapping("/getAdminUser/{adminId}")
    public R<AdminUserVO> getAdminUser(@PathVariable @ApiParam(name = "adminId", value = "账号id", required = true) Integer adminId) {
        AdminUserVO userVO = adminUserDomainService.getAdminUser(adminId);
        return R.success(userVO);
    }


    /**
     * 添加账号
     *
     * @param params
     * @return
     */
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("添加账号")
    @PostMapping("/add")
    @NoRepeatSubmit
    public R<Boolean> add(@Validated @RequestBody AddAdminUserDTO params) {
        AddAdminUserBO addBo = new AddAdminUserBO();
        addBo.setUserName(params.getUserName());
        addBo.setPassword(params.getPassword());
        addBo.setRoleId(params.getRoleId());
        addBo.setRegistrationCount(params.getRegistrationCount());
        addBo.setEmployeeId(params.getEmployeeId());
        addBo.setChannelId(AdminSecurityHolder.getClinicId());
        boolean save = adminUserDomainService.add(addBo);
        return R.success(save);
    }

    /**
     * 编辑账号
     *
     * @param params
     * @return
     */
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("编辑账号")
    @PostMapping("/edit")
    public R<Boolean> edit(@Validated @RequestBody EditAdminUserDTO params) {
        EditAdminUserBO editBo = new EditAdminUserBO();
        BeanUtils.copyProperties(params, editBo);
        boolean t = adminUserDomainService.edit(editBo);
        return R.success(t);
    }

    /**
     * 设置首页是否展示
     *
     * @param params
     * @return
     */
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("设置首页是否展示")
    @PostMapping("/homeShow")
    public R<Boolean> homeShow(@Validated @RequestBody HomeShowDTO params) {
        HomeShowBO showBO = new HomeShowBO();
        BeanUtils.copyProperties(params, showBO);
        boolean t = adminUserDomainService.homeShow(showBO);
        return R.success(t);
    }

    /**
     * 保存人员信息
     *
     * @param params
     * @return
     */
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("保存人员信息")
    @PostMapping("/saveInfo")
    public R<Boolean> saveInfo(@Validated @RequestBody SaveInfoDTO params) {
        AdminUserInfo adminUserInfo = new AdminUserInfo();
        adminUserInfo.setAdminId(params.getAdminId());
        adminUserInfo.setRealName(params.getRealName());
        adminUserInfo.setIntroduction(params.getIntroduction());
        adminUserInfo.setSex(params.getSex());
        adminUserInfo.setAvatarUrl(params.getFileKey());

        boolean t = adminUserDomainService.saveInfo(adminUserInfo);
        return R.success(t);
    }

    /**
     * 获取首页展示的人员
     */
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("获取首页展示的人员")
    @GetMapping("/getHomeShow/{adminId}")
    public R<List<GetHomeShowVO>> getHomeShow(@PathVariable @ApiParam(name = "adminId", value = "账号id", required = true) String adminId) {
        List<GetHomeShowVO> vos = adminUserDomainService.getHomeShow(adminId);
        return R.success(vos);
    }

    // 保存首页展示位置

    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("保存 首页展示位置")
    @PostMapping("/saveHomeShow")
    public R<Boolean> saveHomeShow(@Validated @RequestBody List<SaveHomeShowDTO> params) {
        if (CollectionUtils.isEmpty(params)) {
            throw new ServiceException("参数不能为空");
        }
        List<HomeShowBO> bos = params.stream().map(item -> {
            HomeShowBO showBO = new HomeShowBO();
            showBO.setAdminId(item.getAdminId());
            showBO.setHomepageDisplaySort(item.getHomepageDisplaySort());
            showBO.setHomepageDisplaySwitch(HomepageDisplayEnum.ON_ENABLE.getCode());
            return showBO;
        }).collect(Collectors.toList());
        boolean saveShow = adminUserDomainService.saveHomeShow(bos);
        return R.success(saveShow);
    }


    /**
     * 删除账号
     *
     * @param adminId
     * @return
     */
    @PreAuthorize("hasRole('ADMINISTRATOR')")
    @ApiOperation("删除账号")
    @PostMapping("/delAdminUser/{adminId}")
    public R<Boolean> delAdminUser(@PathVariable @ApiParam(name = "adminId", value = "账号id", required = true) Integer adminId) {
        return R.success(adminUserDomainService.delAdminUser(adminId));
    }


    /**
     * 获取所有角色
     *
     * @return
     */
    @ApiOperation("获取所有角色")
    @GetMapping("/getAllRoles")
    public R<List<AdminRoleVO>> getAllRoles() {
        return R.success(adminUserDomainService.getAllRoles());
    }


}
