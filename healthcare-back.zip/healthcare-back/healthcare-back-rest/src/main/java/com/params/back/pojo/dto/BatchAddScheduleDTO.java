package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @DESCRIPTION 批量设置排班的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@ApiModel("批量设置排班的入参 DTO")
public class BatchAddScheduleDTO implements Serializable {

    @ApiModelProperty(value = "人员id",required = true)
    private Integer adminId;

    @ApiModelProperty(value = "年-月",example = "2024-05",required = true)  // TODO 参数校验
    private String currentMonth;

    @ApiModelProperty(value = "周的数组集合 [周一，周二，周三，周四，周五，周六，周日]",required = true)
    private List<String> daysOfWeek;

    @ApiModelProperty(value = "开始时间",required = true)
    private String startTimeStr;

    @ApiModelProperty(value = "结束时间",required = true)
    private String endTimeStr;


}
