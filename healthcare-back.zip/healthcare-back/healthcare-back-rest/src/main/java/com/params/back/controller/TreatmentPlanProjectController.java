package com.params.back.controller;

import com.params.domain.treatmentplan.TreatmentPlanDomainService;
import com.params.framework.vo.R;
import com.params.pojo.vo.PlanProjectConfigVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @DESCRIPTION 处置方案项目管理
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "处置方案项目管理")
@RestController
@RequestMapping("/planproject/manage")
public class TreatmentPlanProjectController {

    @Autowired
    private TreatmentPlanDomainService planProjectDomainService;

    //region V1.5 变更接口 ------------------ TODO V1.5
    // 获取项目的配置信息
    @ApiOperation("获取项目的配置信息")
    @GetMapping("/getPlanProjectConfig")
    public R<List<PlanProjectConfigVO>> getPlanProjectConfig(@ApiParam(name = "type", value = "项目类型 1-需面诊开具后才能预约的类型 2-可直接预约的类型 不传则查全部")  Integer type) {
        List<PlanProjectConfigVO> vos = planProjectDomainService.getPlanProjectConfig(type);
        return R.success(vos);
    }

    //endregion



}
