package com.params.back.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.crypto.SecureUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.params.back.convert.SysAuthConvert;
import com.params.back.pojo.dto.ProfileUpdatePasswdDTO;
import com.params.back.pojo.dto.SysAuthLoginReqDTO;
import com.params.back.pojo.vo.SysAuthLoginRespVO;
import com.params.back.pojo.vo.SysAuthProfileRespVO;
import com.params.back.service.SysAuthService;
import com.params.back.util.CheckPasswordUtil;
import com.params.component.security.core.util.SecurityFrameworkUtils;
import com.params.entity.Admin;
import com.params.entity.AdminRole;
import com.params.entity.AdminUserInfo;
import com.params.entity.SysPermission;
import com.params.framework.constant.GlobalErrorCodeConstant;
import com.params.framework.vo.R;
import com.params.service.AdminRoleService;
import com.params.service.AdminService;
import com.params.service.AdminUserInfoService;
import com.params.service.SysPermissionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.Date;
import java.util.List;

import static com.params.component.security.core.util.SecurityFrameworkUtils.getLoginUserId;
import static com.params.component.security.core.util.SecurityFrameworkUtils.getLoginUserRoleIds;
import static com.params.framework.servlet.ServletUtils.getClientIP;
import static com.params.framework.servlet.ServletUtils.getUserAgent;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
@Slf4j
@RestController
@Api(tags = "认证接口")
public class SysAuthController {

    @Resource
    private SysAuthService sysAuthService;

    @Resource
    private AdminService adminService;
    @Resource
    private AdminUserInfoService adminUserInfoService;

    @Resource
    private AdminRoleService adminRoleService;

    @Resource
    private SysPermissionService sysPermissionService;


    @PostMapping("/v1/auth/login")
    @ApiOperation("使用账号密码登录")
    public R<SysAuthLoginRespVO> login(@RequestBody @Valid SysAuthLoginReqDTO reqVO) {
        String token = sysAuthService.login(reqVO, getClientIP(), getUserAgent());
        // 返回结果
        return R.success(SysAuthLoginRespVO.builder().token(token).build());
    }

    /**
     * 修改密码
     *
     * @return
     */
    @ApiOperation("修改密码")
    @PostMapping("/v1/auth/updatePassword")
    public R<Boolean> updatePassword(@Valid @RequestBody ProfileUpdatePasswdDTO dto) {
        if (!dto.getPassword().equals(dto.getPasswordConfirmation())) {
            return R.error(GlobalErrorCodeConstant.BAD_REQUEST.getCode(), "确认密码不一致");
        }

        if (!CheckPasswordUtil.checkPasswordRule(dto.getPassword())) {
            return R.error(GlobalErrorCodeConstant.BAD_REQUEST.getCode(), "密码不符合条件，请按英文大小写数字格式填写");
        }

        Admin admin = adminService.getById(SecurityFrameworkUtils.getLoginUserId());

        if (!dto.getCurrentPassword().equals(admin.getPassword())) {
            return R.error(GlobalErrorCodeConstant.BAD_REQUEST.getCode(), "原密码不正确");
        }

        adminService.update(Wrappers.<Admin>lambdaUpdate()
                .eq(Admin::getId, admin.getId())
                .set(Admin::getPassword, SecureUtil.md5(dto.getPassword()))
                .set(Admin::getPassExpireTime, DateUtil.offsetMonth(DateUtil.date(), 1))
                .set(Admin::getModifyTime, new Date())
        );

        return R.success(true);
    }

    @PostMapping("/v1/auth/profile")
    @ApiOperation("获取登陆用户信息")
    public R<SysAuthProfileRespVO> profile() {
        // 获得用户信息
        Admin admin = adminService.getById(getLoginUserId());
        if (admin == null) {
            return null;
        }

        // 获得角色列表
        List<AdminRole> roleList = (CollUtil.isEmpty(getLoginUserRoleIds())) ? Lists.newArrayList() : adminRoleService.listByIds(getLoginUserRoleIds());

        // 菜单
        List<SysPermission> menus = sysPermissionService.getMenuListByRoleIds(getLoginUserRoleIds());
        // 拼接结果返回
        SysAuthProfileRespVO convert = SysAuthConvert.INSTANCE.convert(admin, roleList, menus);
        // 查出头像
        AdminUserInfo adminUserInfo = adminUserInfoService.getOne(Wrappers.<AdminUserInfo>lambdaQuery().eq(AdminUserInfo::getAdminId, admin.getId()).last("limit 1"));
        SysAuthProfileRespVO.UserVO user = convert.getUser();
        user.setAvatar(adminUserInfo.getAvatarUrl());
        convert.setUser(user);
        return R.success(convert);
    }
}


