package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @DESCRIPTION 操作患者诊疗的 DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@ApiModel("操作患者 DTO")
public class OperateMedicalDTO implements Serializable {

    /**
     * 订单 编号
     */
    @ApiModelProperty(value = "订单 编号")
    private String orderSn;

    /**
     * 操作类型
     */
    @ApiModelProperty(value = "操作类型 1-报到，2-开始面诊/开始治疗 3-完成面诊/结束治疗", example = "1")
    private Integer opeType;


}
