package com.params.back.interceptor;

import brave.Tracing;
import brave.propagation.TraceContext;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.servlet.ServletUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.alibaba.fastjson.JSON;
import com.params.component.security.core.LoginUser;
import com.params.component.security.core.util.SecurityFrameworkUtils;
import com.params.framework.util.HttpUtil;
import com.params.utils.AdminSecurityContext;
import com.params.utils.AdminSecurityHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

/**
 * <pre>
 * 访问日志拦截器
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */
@Component
public class AccessLogInterceptor extends HandlerInterceptorAdapter {

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * 开始时间
     */
    private static final ThreadLocal<Date> START_TIME = new ThreadLocal<>();

    @Value("${spring.application.name}")
    private String applicationName;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // if (request.getRequestURI().contains("manage")) {
            LoginUser loginUser = SecurityFrameworkUtils.getLoginUser();
            if (Objects.nonNull(loginUser)) {
                AdminSecurityContext adminSecurityContext = new AdminSecurityContext();
                adminSecurityContext.setClinicId((int)loginUser.getExtend());
                adminSecurityContext.setUsername(loginUser.getUsername());
                adminSecurityContext.setAdminId(loginUser.getId());
                AdminSecurityHolder.setContext(adminSecurityContext);
            }
        // }
        // 记录当前时间
        START_TIME.set(new Date());
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        AccessLogAddDTO accessLog = new AccessLogAddDTO();
        try {
            // 初始化 accessLog
            initAccessLog(accessLog, request);
            // 执行插入 accessLog
            // addAccessLog(accessLog);
        } catch (Throwable th) {
            // logger.error("[afterCompletion][插入访问日志({}) 发生异常({})", JSON.toJSONString(accessLog), ExceptionUtils.getRootCauseMessage(th));
        } finally {
            clear();
            AdminSecurityHolder.clear();
        }
    }

    private void initAccessLog(AccessLogAddDTO accessLog, HttpServletRequest request) {

        if (request.getRequestURI().contains("healthz")) {
            return;
        }
        // 设置用户编号
        LoginUser user = SecurityFrameworkUtils.getLoginUser();
        if (Objects.nonNull(user)) {
            accessLog.setUserId(user.getId());
            accessLog.setUsername(user.getUsername());
        } else {
            accessLog.setUserId(AccessLogAddDTO.USER_ID_NULL);
        }


        // Assert.isTrue(result != null, "result 必须非空");
//        accessLog.setErrorCode(result.getCode())
//                .setErrorMessage(result.getMessage());
        // 设置其它字段
        accessLog.setTraceId(getTraceId())
                .setApplicationName(applicationName)
                .setServerName(request.getServerName())
                .setUri(request.getRequestURI())
                .setUrl(request.getRequestURL().toString())
                .setQueryString(HttpUtil.buildQueryString(request))
                .setMethod(request.getMethod())
                .setUserAgent(HttpUtil.getUserAgent(request))
                .setIp(ServletUtil.getClientIP(request))
                .setStartTime(DateUtil.formatDateTime(START_TIME.get()))
                .setResponseTime((int) (System.currentTimeMillis() - START_TIME.get().getTime())); // 默认响应时间设为 0

        addAccessLog(accessLog);
    }

    // @Async // 异步入库
    public void addAccessLog(AccessLogAddDTO accessLog) {
        logger.info(JSON.toJSONString(accessLog));
    }

    private static void clear() {
        START_TIME.remove();
    }

    public static TraceContext getCurrentTraceContext() {
        Tracing tracing = SpringUtil.getBean(Tracing.class);
        return tracing.currentTraceContext().get();
    }

    public static String getTraceId() {
        String traceId = getCurrentTraceContext().traceIdString();
        if (StrUtil.isNotBlank(traceId)) {
            return traceId;
        }
        return UUID.randomUUID().toString();
    }

}
