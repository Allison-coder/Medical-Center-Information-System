package com.params.back.controller;

import com.params.ErrorCodeEnum;
import com.params.back.interceptor.NoRepeatSubmit;
import com.params.constant.PaymentTypeEnum;
import com.params.constant.SourceTypeEnum;
import com.params.constant.ValidateUtil;
import com.params.entity.MerchantPaymentInfo;
import com.params.framework.vo.R;
import com.params.pojo.dto.PaymentTypeResp;
import com.params.pojo.req.MergePayReq;
import com.params.pojo.vo.PayReq;
import com.params.service.MerchantPaymentInfoService;
import com.params.service.ParamsPayService;
import com.params.utils.AdminSecurityHolder;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
public class ParamsPayController {

    @Autowired
    private ParamsPayService paramsPayService;

    @Autowired
    private MerchantPaymentInfoService merchantPaymentInfoService;

    /**
     * 统一支付下单接口
     */
    @RequestMapping("paramsPay/pay")
    public R pay(@Validated PayReq payReq, HttpServletRequest request) {
        return paramsPayService.pay(payReq, request, AdminSecurityHolder.getClinicId());
    }

    /**
     * 微信扫码支付
     */
    @PostMapping("weiXinPayApi/weiXinPay")
    public R weiXinPay(@Validated String orderNum, HttpServletRequest request) {
        PayReq payReq = new PayReq();
        payReq.setOrderNum(orderNum);
        payReq.setPaymentType("WEIXIN_QRCODE_PAY");
        payReq.setSubject("诊疗服务费用");
        payReq.setNeedUser(false);
        return pay(payReq, request);
    }

    //region V1.5 变更接口 ------------------ TODO V1.5.1

    /**
     * 合并支付预下单
     * @param req
     * @param request
     * @return
     */
    @ApiOperation("V1.5.1 新开接口 获取合并支付二维码：")
    @PostMapping("/paramsPay/mergePay")
    // @NotLogin
    @NoRepeatSubmit
    public R mergePay(@RequestBody @Validated MergePayReq req, HttpServletRequest request) {
        req.setNeedUser(false);
        Integer clinicId = AdminSecurityHolder.getClinicId();
        req.setChannelId(clinicId);
        req.setSubject("诊疗费用合并支付");
        return paramsPayService.mergePay(req,request);


    }

    //endregion

    /**
     * 支付宝小程序支付回调
     */
    @RequestMapping("aliPay/aliPayNotice")
    public void aliPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.ALI_H5_PAY.name());
    }

    /**
     * 支付宝支付回调
     */
    @RequestMapping("aliPay/aliAppPayNotice")
    public void aliAppPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.ALI_APP_PAY.name());
    }

    /**
     * 支付宝扫码支付回调
     */
    @RequestMapping("aliPay/qrCodePayNotice")
    public void aliQrCodePayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.ALI_QRCODE_PAY.name());
    }

    /**
     * 微信支付回调
     */
    @RequestMapping("weiXinPayApi/weiXinPayNotice")
    public void weiXinPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.WEIXIN_JS_PAY.name());
    }

    /**
     * 微信扫码回调
     * @param request
     * @param response
     */
    @RequestMapping("weiXinPayApi/qrPayNotice")
    public void weiXinQrPayNotice(HttpServletRequest request, HttpServletResponse response) {
        paramsPayService.payNotice(request, response, PaymentTypeEnum.WEIXIN_QRCODE_PAY.name());
    }

    @GetMapping("pay/merchantPayWayDetail")
    public R merchantPayWayDetail(String source) {
        ValidateUtil.isTrue(!SourceTypeEnum.exists(source), ErrorCodeEnum.SYSTEM_ERR);
        List<MerchantPaymentInfo> infos = merchantPaymentInfoService.getMerchantPaymentInfos(AdminSecurityHolder.getClinicId(), source);
        ValidateUtil.isTrue(infos == null || infos.size() == 0, ErrorCodeEnum.SYSTEM_ERR);
        List<PaymentTypeResp> paymentTypeResps = new ArrayList<>();
        for (MerchantPaymentInfo info : infos) {
            PaymentTypeResp r = new PaymentTypeResp();
            r.setName(info.getNickName());
            r.setPaymentType(info.getPaymentType());
            r.setIconUrl(info.getIconUrl());
            r.setSource(source);
            r.setPaymentUrl(info.getPaymentUrl());
            paymentTypeResps.add(r);
        }
        return R.success(paymentTypeResps);
    }


}
