package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 保存人员信息的入参
 */
@Data
public class SaveInfoDTO implements Serializable {

    @ApiModelProperty(value = "真实名称")
    @NotNull(message = "真实名称不能为空")
    @Size(max = 5,message = "名称长度不能超过5")
    private String realName;

    @ApiModelProperty(value = "账号id")
    @NotNull(message = "账号 id不能为空")
    private Integer adminId;

    @ApiModelProperty(value = "个人介绍")
    @Size(max = 200,message = "个人介绍长度不能超过200")
    private String introduction;

    @ApiModelProperty(value = "性别 0：女；1：男")
    private Integer sex;

    @ApiModelProperty(value = "头像对应fileKey,通过upload/sign接口获取", example = "tmp/2024/05/591d3fc7f5dc2f4449ba984d6454f467cf3")
    private String fileKey;
}
