package com.params.back.util.validategroups;

/**
 * @DESCRIPTION 药物的字段校验
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public interface ValidateMedicineGroup {
}
