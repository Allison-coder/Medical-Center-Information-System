package com.params.back.controller;

import cn.binarywang.wx.miniapp.api.WxMaLinkService;
import cn.binarywang.wx.miniapp.api.WxMaQrcodeService;
import cn.binarywang.wx.miniapp.api.WxMaSchemeService;
import cn.binarywang.wx.miniapp.api.WxMaService;
import cn.binarywang.wx.miniapp.bean.scheme.WxMaGenerateSchemeRequest;
import cn.hutool.core.codec.Base64;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.application.promotion.PromotionApp;
import com.params.back.interceptor.NoRepeatSubmit;
import com.params.back.interceptor.NotLogin;
import com.params.back.pojo.dto.CreateOrUpDatePromotionDTO;
import com.params.back.pojo.dto.DelCouponModelDTO;
import com.params.back.pojo.dto.PromotionPageDTO;
import com.params.back.pojo.dto.SpecifyUserDTO;
import com.params.component.oss.service.OssService;
import com.params.domain.coupon.CouponTemplateDomainService;
import com.params.domain.patient.PatientDomainService;
import com.params.domain.promotion.PromotionDomainService;
import com.params.entity.PromotionChannels;
import com.params.framework.exception.ServiceException;
import com.params.framework.vo.R;
import com.params.pojo.bo.ActivityCouponDetailsBO;
import com.params.pojo.bo.CreateOrUpDatePromotionBO;
import com.params.pojo.vo.GettingConditionVO;
import com.params.pojo.vo.LandingPageVO;
import com.params.pojo.vo.PromotionDetailsVO;
import com.params.pojo.vo.PromotionPageVO;
import com.params.pojo.vo.common.PageVO;
import com.params.utils.DateUtil;
import com.params.utils.RegularExpressionUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @DESCRIPTION 推广
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Api(tags = "优惠券活动管理")
@RestController
@RequestMapping("/promotion/manage")
@Slf4j
public class PromotionController {

    //region 0、Interface------依赖接口
    @Autowired
    private PromotionApp promotionApp;


    @Autowired
    private PromotionDomainService promotionDomainService;


    @Autowired
    private CouponTemplateDomainService templateDomainService;

    @Autowired
    private WxMaService wxMaService;

    @Autowired
    private OssService ossService;

    @Autowired
    private PatientDomainService patientDomainService;
    //endregion

    //region 1、Action------优惠券活动列表页

    // 优惠券活动列表
    @GetMapping("/list")
    @ApiOperation("优惠券活动列表")
    public R<PageVO<PromotionPageVO>> promotionList(PromotionPageDTO params) {
        PageVO<PromotionPageVO> vo = promotionApp.promotionList(new Page<PromotionChannels>().setSize(params.getPageSize()).setCurrent(params.getPageNum()), params.getChannelName(), params.getActivityName());
        return R.success(vo);
    }

    // 根据id 获取活动详情
    @GetMapping("/details/{id}")
    @ApiOperation("根据 id 查询活动详情信息")
    public R<PromotionDetailsVO> getPromotionDetails(@PathVariable Integer id) {
        return R.success(promotionApp.getPromotionChannelById(id));
    }

    // 创建或修改活动
    @PostMapping("/createOrUpdate")
    @ApiOperation("创建或修改活动")
    @NoRepeatSubmit
    public R<Integer> createOrUpdate(@RequestBody @Validated CreateOrUpDatePromotionDTO params) {

        if (StringUtils.isBlank(params.getTotalValue())) {
            throw new ServiceException("总价值必填");
        }
        try {
            new BigDecimal(params.getTotalValue());
        } catch (NumberFormatException e) {
            throw new ServiceException("总价值格式错误");
        }

        CreateOrUpDatePromotionBO bo = new CreateOrUpDatePromotionBO();
        bo.setId(params.getId());
        bo.setActivityName(params.getActivityName());
        bo.setChannelName(params.getChannelName());
        bo.setExpireDate(params.getExpireDate());
        bo.setExpireTime(params.getExpireTime());
        bo.setForeverStatus(params.getForeverStatus());
        bo.setGettingCondition(params.getGettingCondition());
        bo.setPhoneNumbers(params.getPhoneNumbers());
        bo.setShareContent(params.getShareContent());
        bo.setTotalValue(params.getTotalValue());

        if (CollectionUtils.isNotEmpty(params.getActivityCouponDetails())) {
            List<ActivityCouponDetailsBO> couponDetailsBOS = params.getActivityCouponDetails().stream().map(c -> {
                ActivityCouponDetailsBO couponDetailsBO = new ActivityCouponDetailsBO();
                couponDetailsBO.setId(c.getId());
                couponDetailsBO.setCouponType(c.getCouponType());
                couponDetailsBO.setCouponTypeName(c.getCouponTypeName());
                couponDetailsBO.setCouponName(c.getCouponName());
                couponDetailsBO.setCouponParValue(c.getCouponParValue());
                couponDetailsBO.setDiscount(c.getDiscount());
                couponDetailsBO.setExchangeOrder(c.getExchangeOrder());
                couponDetailsBO.setProjectId(c.getProjectId());
                couponDetailsBO.setThresholdNo(c.getThresholdNo());
                couponDetailsBO.setOrderUseAmount(c.getOrderUseAmount());
                couponDetailsBO.setForeverStatus(c.getForeverStatus());
                couponDetailsBO.setExpireDate(c.getExpireDate());
                couponDetailsBO.setInstructions(c.getInstructions());
                couponDetailsBO.setAvailableProject(c.getAvailableProject());
                return couponDetailsBO;
            }).collect(Collectors.toList());
            bo.setActivityCouponDetails(couponDetailsBOS);
        }

        Integer proId = promotionDomainService.createOrUpdate(bo);
        return R.success(proId);
    }

    // 复制链接
    @ApiOperation("复制链接")
    @GetMapping("/copyLink/{id}")
    public R<String> copyLink(@PathVariable @ApiParam(name = "id", value = "活动id", required = true) Integer id) {
        // 根据id 查出渠道和活动id
        PromotionChannels promotionChannels = promotionDomainService.getChannelInfoById(id);
        if (promotionChannels == null) {
            throw new ServiceException("活动不存在");
        }

        // 如果过期时间在今天之后，直接返回生成的地址
        if (promotionChannels.getLinkExpireTime() != null && promotionChannels.getLinkExpireTime().after(DateUtil.createNowDateOnly())) {
            return R.success(promotionChannels.getWeixinLink());
        }

        WxMaSchemeService wxMaSchemeService = wxMaService.getWxMaSchemeService();
        WxMaGenerateSchemeRequest build = WxMaGenerateSchemeRequest.newBuilder()
                .jumpWxa(WxMaGenerateSchemeRequest.JumpWxa.newBuilder()
                        // .path("pages_subpack/activity/index")
                        .path(getqrCodePath().getQrCodePath())
                        .envVersion(getqrCodePath().getVersion())
                        // .query("channelCode" + promotionChannels.getChannelCode()) // 这里以后都不能再改
                        .query("scene=channelCode" + promotionChannels.getChannelCode()) // 这里以后都不能再改
                        .build())
                .isExpire(false)
                .build();

        try {
            String str = wxMaSchemeService.generate(build);
            promotionChannels.setWeixinLink(str);
            // 保存
            promotionDomainService.updatePromotionChannels(promotionChannels);
            return R.success(promotionChannels.getWeixinLink());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // 生成二维码
    @ApiOperation("生成二维码")
    @GetMapping("/generateQRCode/{id}")
    public R generateQRCode(@PathVariable @ApiParam(name = "id", value = "活动id", required = true) Integer id) {
        PromotionChannels promotionChannels = promotionDomainService.getChannelInfoById(id);
        if (promotionChannels == null) {
            throw new ServiceException("活动不存在");
        }
        try {
            WxMaQrcodeService qrcodeService = wxMaService.getQrcodeService();
            //  "channelCode"+promotionChannels.getChannelCode() 这里以后都不能再改
            File code = qrcodeService.createWxaCodeUnlimit("channelCode" + promotionChannels.getChannelCode(), getqrCodePath().getQrCodePath(), true, getqrCodePath().getVersion(), 430, true, null, true);

            byte[] bytes = Files.readAllBytes(code.toPath());
            String temp = ossService.putObject("healthcare/qrcode/" + promotionChannels.getChannelCode() + ".png", bytes);
            promotionChannels.setWeixinCodeImgUrl(temp);
            // 保存
            promotionDomainService.updatePromotionChannels(promotionChannels);
            JSONObject resp = new JSONObject();
            resp.put("qrImg", "data:image/jpeg;base64," + Base64.encode(bytes));
            resp.put("qrContent", promotionChannels.getWeixinCodeImgUrl());
            return R.success(resp);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // 删除活动
    @GetMapping("/del/{id}")
    @ApiOperation("根据 id删除活动")
    public R<Boolean> delPromotionById(@PathVariable @ApiParam(name = "id", value = "活动id", required = true) Integer id) {
        // 删除活动
        return R.success(promotionDomainService.delPromotionChannels(id));
    }

    //endregion ------      优惠券活动列表页

    //region 2、Action------添加/编辑页

    /* 获取优惠券类型 在 CouponController.java */

    // 活动领取条件配置
    @ApiOperation("活动领取条件配置")
    @GetMapping("/gettingCondition")
    @NotLogin
    public R<List<GettingConditionVO>> gettingCondition() {
        String config = patientDomainService.patientParamsConfig("GETTING_CONDITION");
        List<GettingConditionVO> list = JSONUtil.toList(config, GettingConditionVO.class);
        return R.success(list);
    }

    /* 获取治疗项目 在 TreatmentPlanProjectController */

    /* 根据优惠券的 id 获取模板 在 CouponController.java */

    // 删除活动下的优惠券（模板）
    @PostMapping("/delPromoCouponTemp")
    @ApiOperation("根据活动id和优惠券模板id 删除活动下的优惠券（模板）")
    @NotLogin
    public R<Boolean> delCouponById(@RequestBody DelCouponModelDTO param) {
        return R.success(templateDomainService.delCouponTemplateDetail(param.getCouPonTempId(), param.getPromoId()));
    }

    // 指定用户模板下载
    @ApiOperation("指定用户模板下载")
    @GetMapping("/download/template")
    @NotLogin
    public void downTemplate(HttpServletRequest request, HttpServletResponse response) {

        BufferedInputStream inputStream = null;
        OutputStream outs = null;
        String fileName = "/templates/templates.xlsx";
        try {
            ClassPathResource resource = new ClassPathResource(fileName);
            if (resource.exists()) {
                outs = response.getOutputStream();
                // 文件存在才能下载
                response.setContentType("application/octet-stream");
                response.setHeader("content-type", "application/octet-stream");
                // 设置文件名
                response.setHeader("Content-Disposition", "attachment;fileName=" + URLEncoder.encode(fileName, "UTF-8"));

                inputStream = new BufferedInputStream(resource.getInputStream());
                byte[] buffer = new byte[1024];
                while ((inputStream.read(buffer)) > 0) {
                    outs.write(buffer);
                    outs.flush();
                }
            } else {
                log.error("模板 [{}] 不存在", fileName);
            }
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outs != null) {
                try {
                    outs.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // 导入指定用户
    @ApiOperation("导入指定用户")
    @PostMapping(value = "/importExcel", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @NotLogin
    public List<String> importExcel(@RequestParam("file") MultipartFile file) throws IOException {
        List<SpecifyUserDTO> excelDataList = EasyExcel.read(file.getInputStream())
                .head(SpecifyUserDTO.class)
                .sheet()
                .doReadSync();

        // 解析返回给前端
        if (CollectionUtils.isNotEmpty(excelDataList)) {
            // List<String> bindList = excelDataList.stream().map(SpecifyUserDTO::getPhoneNum).collect(Collectors.toList());
            List<String> bindList = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(excelDataList)) {
                bindList = excelDataList.stream()
                        .map(dto -> {
                            String phoneNum = dto.getPhoneNum();
                            if (!RegularExpressionUtils.isValidPhoneNumber(phoneNum)) {
                                throw new ServiceException("手机号格式不正确");
                            }
                            return phoneNum;
                        })
                        .collect(Collectors.toList());
            }

            return bindList;
        }
        return new ArrayList<String>();
    }

    //endregion

    //region 3、Private_Action------私有方法
    private LandingPageVO getqrCodePath() {
        String config = patientDomainService.patientParamsConfig("LANDING_PAGE");
        LandingPageVO vo = JSON.parseObject(config, LandingPageVO.class);
        return vo;
    }
    //endregion

}
