package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class EditScheduleItemDTO implements Serializable {

    @ApiModelProperty("排班id")
    private Integer id;

    @ApiModelProperty("人员ID")
    private Integer adminId;

    @ApiModelProperty("排班日期")
    private Date scheduleDate;

    @ApiModelProperty("开始时间")
    private String startTime;

    @ApiModelProperty("结束时间")
    private String endTime;

    @ApiModelProperty("请假状态  0-'未请假',1-'请假'  默认 0")
    private Integer scheduleStatus;



}
