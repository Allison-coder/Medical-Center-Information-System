package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 患者治疗单预约的DTO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@ApiModel(value = "患者治疗单预约的DTO")
@Data
public class GetAppointmentTimeDTO implements Serializable {

    @ApiModelProperty(value = "订单 编号")
    private String orderSn;

    @ApiModelProperty(value = "日期")
    private String scheduleDate;
}
