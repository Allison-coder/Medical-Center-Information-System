package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 添加管理员用户DTO
 */
@Data
@ApiModel("添加管理员用户DTO")
public class AddAdminUserDTO implements Serializable {

    @ApiModelProperty(value = "账号名称")
    @NotNull(message = "账号名称不能为空")
    @Size(max = 10, message = "账号名称不能超过10位")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "账号名称只支持英文和数字")
    private String userName;

    @ApiModelProperty(value = "密码")
    @NotNull(message = "密码不能为空")
    @Size(min = 6, message = "密码不能少于6位")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "密码只支持英文和数字")
    private String password;


    @ApiModelProperty(value = "角色id")
    @NotNull(message = "角色必选")
    private Integer roleId;


    @ApiModelProperty(value = "挂号数 角色为：医生 时传入")
    private Integer registrationCount;


    @ApiModelProperty(value = "工号")
    @NotNull(message = "工号不能为空")
    @Size(min = 1, max = 10, message = "工号支持在1至10位的数字")
    @Pattern(regexp = "^[0-9]{1,10}$", message = "工号支持在1至10位的数字")
    private String employeeId;

}
