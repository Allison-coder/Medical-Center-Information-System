package com.params.back.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;

/**
 * @DESCRIPTION 患者的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PatientQueryDTO implements Serializable {

    @ApiModelProperty(value = "患者姓名")
    private String name;
    @ApiModelProperty(value = "手机号")
    private String phoneNumber;

    @ApiModelProperty(value = "页大小，默认10", example = "10")
    @Min(1)
    @Max(100)
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码，默认1", example = "1")
    @Min(0)
    private Integer pageNum = 1;

}
