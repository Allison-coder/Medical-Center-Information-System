package com.params.back.service;

import com.params.entity.AdminRole;
import com.params.entity.AdminRoleBind;
import org.springframework.lang.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface SysRoleService {

    /**
     * 初始化角色的本地缓存
     */
    void initLocalCache();

    List<AdminRoleBind> getUserRoles(Integer userId);

    Set<Integer> getUserRoleIds(Integer userId, @Nullable Set<Integer> singleton);

    /**
     * 获得角色数组，从缓存中
     *
     * @param ids 角色编号数组
     *
     * @return 角色数组
     */
    List<AdminRole> getRolesFromCache(Collection<Integer> ids);

    /**
     * 判断角色数组中，是否有管理员
     *
     * @param roleList 角色数组
     *
     * @return 是否有管理员
     */
    boolean hasAnyAdmin(Collection<AdminRole> roleList);

    /**
     * 判断角色编号数组中，是否有管理员
     *
     * @param roleIds 角色编号数组
     *
     * @return 是否有管理员
     */
    default boolean hasAnyAdmin(Set<Integer> roleIds) {
        return hasAnyAdmin(getRolesFromCache(roleIds));
    }
}
