package com.params.back.controller;

import com.params.back.WithSpringTestBase;
import com.params.back.service.SysAuthService;
import com.params.back.service.SysUserSessionCoreService;
import com.params.component.security.core.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;

import static com.params.framework.servlet.ServletUtils.getClientIP;
import static com.params.framework.servlet.ServletUtils.getUserAgent;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@AutoConfigureMockMvc
public class BaseController extends WithSpringTestBase {
    @Autowired
    protected WebApplicationContext webApplicationContext;

    @Resource
    protected MockMvc mockMvc;

    @Resource
    private SysAuthService sysAuthService;

    @Resource
    private SysUserSessionCoreService sysUserSessionCoreService;

    private String token;

    //    @Before("")
    @BeforeEach
    public void setUp() throws Exception {
        System.out.println("------------start----------------");
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        Long userId = 1L;
        LoginUser loginUser = sysAuthService.mockLogin(userId);
        String userSession = sysUserSessionCoreService.createUserSession(loginUser, getClientIP(), getUserAgent());
        token = userSession;
    }

    public String post(String url, String body) throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
                        .post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andDo(print())
                .andReturn();
        return mvcResult.getResponse().getContentAsString();
    }

    public String get(String url) throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
                        .get(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andReturn();
        return mvcResult.getResponse().getContentAsString();
    }
}
