package com.params.back.controller;

import com.alibaba.fastjson.JSONObject;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("local")
class WxSupportInternalControllerTest extends BaseController {

    @Test
    void refund() throws Exception {
        String url = "/internal/refund";
        String body = "{\"orderSn\":\"ZL2024070310464732194545\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }
}