package com.params.back.controller;

import com.alibaba.fastjson.JSONObject;
import com.params.utils.AdminSecurityHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@ActiveProfiles("local")
class ScienceControllerTest extends BaseController {

    @BeforeAll
    static void beforeAll() {
        MockedStatic<AdminSecurityHolder> mock = Mockito.mockStatic(AdminSecurityHolder.class);
        mock.when(AdminSecurityHolder::getClinicId).thenReturn(1);
        mock.when(AdminSecurityHolder::getAdminId).thenReturn(3);
    }

    @Test
    void should_result_while_getBanners() throws Exception {
        String url = "/science/manage/getBanners";
        JSONObject result = JSONObject.parseObject(get(url));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_updateBanners() throws Exception {
        String url = "/science/manage/updateBanners";
        String body = "[{\"url\":\"xxxxxxx\",\"link\":\"yyyyyy\",\"rank\":1, \"id\":1}, " +
                "{\"url\":\"xxxxxx1111x\",\"link\":\"yyy22222yyy\",\"rank\":2}]";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
//        Assertions.assertThat(result.getString("message")).isEqualTo("后台暂时无法开具挂号单");
    }
}