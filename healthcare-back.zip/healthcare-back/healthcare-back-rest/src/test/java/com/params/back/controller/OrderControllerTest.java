package com.params.back.controller;

import com.alibaba.fastjson.JSONObject;
import com.params.utils.AdminSecurityHolder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("local")
class OrderControllerTest extends BaseController {

    @BeforeAll
    static void beforeAll() {
        MockedStatic<AdminSecurityHolder> mock = Mockito.mockStatic(AdminSecurityHolder.class);
        mock.when(AdminSecurityHolder::getClinicId).thenReturn(1);
        mock.when(AdminSecurityHolder::getAdminId).thenReturn(3);
    }
    @Test
    void should_result_while_getOrders() throws Exception {
        String url = "/order/manage/getOrders?patientName=永休息休息吧";
        JSONObject result = JSONObject.parseObject(get(url));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_getOrders_by_doctor() throws Exception {
        String url = "/order/manage/getOrders";
        JSONObject result = JSONObject.parseObject(get(url));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_fail_while_createOrder_guahao() throws Exception {
        String url = "/order/manage/createOrder";
        String body = "{\"patientSn\":\"202464899454\",\"scheduleDetailId\":2,\"adminId\":3,\"orderType\":\"GH\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2002007);
        Assertions.assertThat(result.getString("message")).isEqualTo("后台暂时无法开具挂号单");
    }

    @Test
    void should_result_while_createOrder_zhiliao() throws Exception {
        String url = "/order/manage/createOrder";
        String body = "{\"patientSn\":\"202464899454\",\"scheduleDetailId\":2,\"adminId\":3,\"orderType\":\"ZL\",\"parentOrderSn\":\"GH2024051710493567136231\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_fail_while_modifyprice_amount_equal_zero() throws Exception {
        String url = "/order/manage/modifyPrice";
        String body = "{\"orderSn\":\"GH2024051710493567136231\",\"amount\":0}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2002007);
    }

    @Test
    void should_fail_while_modifyprice_amount_equal_old_amount() throws Exception {
        String url = "/order/manage/modifyPrice";
        String body = "{\"orderSn\":\"GH2024051710493567136231\",\"amount\":210}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2002007);
    }

    @Test
    void should_success_while_modifyprice_amount() throws Exception {
        String url = "/order/manage/modifyPrice";
        String body = "{\"orderSn\":\"GH2024051710493567136231\",\"amount\":0.01}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(2002007);
    }

    @Test
    void should_result_while_getRefundAmount() throws Exception {
        String url = "/order/manage/getRefundAmount?orderSn=ZL2024070221254541456534";
        JSONObject result = JSONObject.parseObject(get(url));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_refund() throws Exception {
        String url = "/order/manage/refund";
        String body = "{\"orderSn\":\"ZL2024070214515715140220\"}";
        JSONObject result = JSONObject.parseObject(post(url, body));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }

    @Test
    void should_result_while_getUders() throws Exception {

        String url = "/admin/manage/list";
        JSONObject result = JSONObject.parseObject(get(url));
        System.err.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }
}