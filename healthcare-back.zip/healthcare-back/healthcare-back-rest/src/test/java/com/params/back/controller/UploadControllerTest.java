package com.params.back.controller;

import com.alibaba.fastjson.JSONObject;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("local")
class UploadControllerTest extends BaseController {

    @Test
    void should_result_while_getOrders() throws Exception {
        String url = "/upload/sign";
        JSONObject result = JSONObject.parseObject(get(url));
        System.out.println(result);
        Assertions.assertThat(result.getInteger("code")).isEqualTo(200);
    }
}