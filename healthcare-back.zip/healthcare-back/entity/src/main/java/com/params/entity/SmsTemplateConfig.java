package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 短信模板配置表
 * </p>
 *
 * @author robot-params
 * @since 2024-06-06
 */
@Getter
@Setter
@TableName("sms_template_config")
public class SmsTemplateConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 签名
     */
    private String signature;

    /**
     * 短信模板Code
     */
    private String templateCode;

    /**
     * 短信模板名称
     */
    private String templateName;

    /**
     * 业务类型 1-挂号提醒 2-治疗提醒
     */
    private Integer type;

    /**
     * 模板内容
     */
    private String templateContent;

    /**
     * 变量属性
     */
    private String variableAttributes;

    /**
     * 变量属性配置
     */
    private String variableConfig;

    /**
     * 停用状态  0-使用 1-停用   默认0
     */
    private Integer status;


    /**
     * 延迟发送间隔 单位（小时）  默认 24
     */
    private Double delayHours;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 诊所ID
     */
    private Integer clinicId;

}
