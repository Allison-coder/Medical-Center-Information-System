package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 处置方案总表
 * </p>
 *
 * @author robot-params
 * @since 2024-08-11
 */
@Getter
@Setter
@TableName("treatment_plan_base")
public class TreatmentPlanBase implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 方案编号
     */
    private String planSn;

    /**
     * 患者编号
     */
    private String patientSn;

    /**
     * 医嘱
     */
    private String advice;

    /**
     * 是否开具方案，0表示未开具，1表示已开具
     */
    private Boolean isPlanIssued;
    /**
     * 方案的进度状态，1表示进行中，2表示已结束
     */
    private Integer speedStatus;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 是否删除，0表示未删除，1表示已删除，默认未删除
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

}
