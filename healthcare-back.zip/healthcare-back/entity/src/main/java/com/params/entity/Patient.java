package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 患者表
 * @TableName patient
 */
@TableName(value ="patient")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Patient implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 患者编号 （yyMMddHHmmssSSS+5位随机数）
     */
    private String patientSn;

    /**
     * 患者姓名
     */
    private String name;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 头像
     */
    private String avatarUrl;

    /**
     * 职业
     */
    private String occupation;

    /**
     * 性别 0：女；1：男
     */
    private Integer gender;

    /**
     * 身份类型 0: 成人  1：未成年
     */
    private Integer identityType;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 身份证号码
     */
    private String idCardNumber;

    /**
     * 累计消费
     */
    private BigDecimal totalCost;

    /**
     * 婚姻状况 1-未婚 2-已婚 3-离异
     */
    private Integer maritalStatus;



    /**
     * 体重
     */
    private String weight;

    /**
     * 身高
     */
    private String height;

    /**
     * 国籍
     */
    private String nationality;

    /**
     * 语言
     */
    private String language;

    /**
     *  是否需要翻译
     */
    private Integer translation;

    /**
     * 目的
     */
    private String purpose;

    /**
     *备注
     */
    private String remarks;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;
    /**
     * 绑定的user表的id
     */
    private Integer userId;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}