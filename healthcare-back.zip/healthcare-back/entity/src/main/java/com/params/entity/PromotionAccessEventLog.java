package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 落地页访问事件日志
 * </p>
 *
 * @author robot-params
 * @since 2024-07-25
 */
@Getter
@Setter
@TableName("promotion_access_event_log")
public class PromotionAccessEventLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 事件类型
     */
    private String eventType;

    /**
     * 活动渠道 code
     */
    private String channelCode;

    /**
     * 客户端的 openId
     */
    private String openId;

    /**
     * 设备品牌
     */
    private String systemInfoBrand;

    /**
     * 设备型号
     */
    private String systemInfoModel;

    /**
     * 设备的唯一标识符
     */
    private String deviceId;

    /**
     * 页面的唯一标识符
     */
    private String pagePath;

    /**
     * 按钮的唯一标识符
     */
    private String buttonFlag;

    /**
     * 用户ID
     */
    private Integer userId;

    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 设备系统类型
     */
    private String system;
    /**
     * 事件发生的时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

}
