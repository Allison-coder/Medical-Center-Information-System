package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 管理员用户角色关系表
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Getter
@Setter
@TableName("admin_role_bind")
public class AdminRoleBind implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 管理员用户ID
     */
    private Integer adminId;

    /**
     * 用户角色ID
     */
    private Integer roleId;


    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

}
