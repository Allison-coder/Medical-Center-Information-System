package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 在线用户表
 * </p>
 *
 * @author robot-params
 * @since 2022-12-11
 */
@Getter
@Setter
@Builder
@TableName("admin_session")
public class AdminSession implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    /**
     * 用户ID
     */
    private Integer userId;

    /**
     * 用户类型
     */
    private Integer userType;

    /**
     * 用户账号
     */
    private String username;

    /**
     * 用户 IP
     */
    private String userIp;

    /**
     * 浏览器 UA
     */
    private String userAgent;

    /**
     * 会话超时时间
     */
    private Date sessionTimeout;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

}
