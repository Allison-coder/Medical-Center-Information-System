package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用户
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Getter
@Setter
@Accessors(chain = true)
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    private Date createTime;
    private Date modifyTime;
    private Integer disable;
    private Integer version;

    private Integer memberId;

    private String memberUniqueId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 密码
     */
    private String password;
    /**
     * 唯一代码
     */
    private String uniqueCode;
    /**
     * 性别 0女,1男
     */
    private Integer sex;
    /**
     * 地区
     */
    private String region;
    /**
     * 头像url
     */
    private String faceUrl;
    /**
     * 手机号
     */
    private String mobile;
    /**
     * 邮箱地址
     */
    private String email;
    /**
     * 注册ip
     */
    private String regIp;
    /**
     * 登陆ip
     */
    private String loginIp;
    /**
     * 来源enum(ali_h5,wechat,other)
     */
    private String ch;
    /**
     * 设备型号
     */
    private String deviceInfo;
    /**
     * 状态enum(normal,disabled,pause)
     */
    private String status;
    /**
     * 登录时间
     */
    private Date loginTime;
    /**
     * 招行协议号
     */
    private String agrNo;
    /**
     * 用户详细信息
     */
    private String detailsInfo;

    private String outUserId;

}
