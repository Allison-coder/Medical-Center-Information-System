package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 推广渠道表
 * @TableName promotion_channels
 */
@TableName(value ="promotion_channels")
@Data
public class PromotionChannels implements Serializable {
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 渠道 code   唯一18位
     */
    private String channelCode;

    /**
     * 活动名称
     */
    private String activityName;


    /**
     * 微信生成的链接
     */
    private String weixinLink;

    /**
     * 微信生成的链接过期时间
     */
    private Date linkExpireTime;
    /**
     * 小程序二维码地址
     */
    private String weixinCodeImgUrl;

    /**
     * 小程序二维码地址 Base64
     */
    private String weixinCodeBase64Url;


    /**
     * 活动 code   唯一18位
     */
    private String activityCode;

    /**
     * 优惠券类型  对应 params_config 表的 COUPON_TYPE
     */
    private Integer couponType;

    /**
     * 优惠券类型名称
     */
    private String couponTypeName;

    /**
     *  配置 JSON 格式
     */
    private String contextConfig;


    /**
     * 活动开始时间
     */
    private Date startDateTime;

    /**
     * 活动结束时间
     */
    private Date expireDateTime;

    /**
     * 领取条件 配置表里 GETTING_CONDITION 的id
     */
    private Integer gettingCondition;


    /**
     * 分享文案
     */
    private String shareContent;

    /**
     * 是否永久有效 0-否 1-是
     */
    private Integer foreverStatus;

    /**
     * 活动状态 0- 未开始 1- 进行中 2-已结束
     */
    private Integer status;

    /**
     * 总价值
     */
    private BigDecimal totalValue;

    /**
     * 诊所 id（扩展字段 暂时不使用
     */
    private Integer clinicId;

    /**
     * 删除状态 0-正常 1-软删除
     */
    private Byte deleted;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date modifyTime;

    /**
     * 操作人  用户名
     */
    private String operator;
    /**
     * 修改人  用户名
     */
    private String modifyOperator;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}