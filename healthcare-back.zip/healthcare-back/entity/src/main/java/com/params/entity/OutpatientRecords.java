package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 门诊病历表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-09
 */
@Getter
@Setter
@TableName("outpatient_records")
public class OutpatientRecords implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自动递增的主键，用于唯一标识每一条病历记录
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 患者编号
     */
    private String patientSn;

    /**
     * 体温（单位：摄氏度）
     */
    private BigDecimal bodyTemperature;

    /**
     * 血压（单位：毫米汞柱）
     */
    private String bloodPressure;

    /**
     * 身体图坐标
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String imgCoordinate;

    /**
     * 脉搏（单位：次/分钟）
     */
    private Integer pulse;

    /**
     * 血氧（单位：百分比）
     */
    private BigDecimal bloodOxygen;

    /**
     * 开始症状
     */
    private String initialSymptoms;

    /**
     * 症状性质
     */
    private String symptomNature;

    /**
     * 疼痛程度（1-10）
     */
    private Integer painLevel;

    /**
     * 病史部份
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String medicalHistory;

    /**
     * 停用状态    0：启用  1：停用
     */
    private Integer status;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;

    /**
     * 创建时间，默认值为当前时间戳
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 操作人用户名
     */
    private String operator;

    /**
     * 诊所id
     */
    private Integer clinicId;

}
