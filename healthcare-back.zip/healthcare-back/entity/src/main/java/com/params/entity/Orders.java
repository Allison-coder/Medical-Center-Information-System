package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 订单表
 * @TableName orders
 */
@TableName(value ="orders")
@Data
public class Orders implements Serializable {
    /**
     * 订单ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 订单编号（两位订单类型前缀+yyyyMMddHHmmssSSS+5位随机数）
     */
    private String orderSn;

    /**
     * 父级订单 id （治疗单）
     */
    private String parentOrderSn;

    /**
     * 订单类型，1：挂号单，2：治疗单
     */
    private Integer orderType;


    /**
     * 治疗单预约类型 2-治疗方案预约 3-项目预约
     */
    private Integer scheduleType;
    /**
     *  支付金额（RMB） 单位：元
     */
    private BigDecimal orderAmount;
    /**
     * 总价（RMB） 单位：元
     */
    private BigDecimal sourceAmount;
    /**
     * 优惠金额 （RMB） 单位：元
     */
    private BigDecimal discountAmount;

    /**
     * 支付商户号
     */
    private String merchantNum;

    /**
     * 支付流水号
     */
    private String tradeNum;

    /**
     * 支付时间
     */
    private Date payTime;

    /**
     * 申请退款时间
     */
    private Date applyRefundTiapplyRefundTime;

    /**
     * 退款金额
     */
    private BigDecimal refundFee;

    /**
     * 退款时间
     */
    private Date refundTime;

    /**
     * 主诉
     */
    private String chiefComplaint;

    /**
     * 诊断
     */
    private String diagnosis;


    /**
     * 预测
     */
    private String forecast;

    /**
     * 治疗方案
     */
    private String treatmentPlan;

    /**
     * 预期治疗效果
     */
    private String expectedOutcomes;

    /**
     * 医嘱
     */
    private String advice;

    /**
     * 订单状态    0：待支付 1：已支付   2：已取消   3：退款中 4：已退款 默认未支付
     */
    private Integer orderStatus;

    /**
     * 业务节点状态   2：待预约 3：待报道  4：等待叫号  5：治疗中  6：完成
     */
    private Integer businessStatus;

    /**
     * 预约的排班id
     */
    private Integer scheduleDetailId;

    /**
     * 被预约人员id
     */
    private Integer adminId;

    /**
     * 下单的用户ID
     */
    private Integer userId;

    /**
     * 患者ID
     */
    private String patientSn;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 下单的用户ID
     */
    private Integer createAdminId;


    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}