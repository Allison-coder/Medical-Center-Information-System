package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName official_account
 */
@TableName(value ="official_account")
@Data
public class OfficialAccount implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 
     */
    private String appid;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String code;

    /**
     * 
     */
    private Object ch;

    /**
     * 公众号唯一code
     */
    private String officialCode;

    /**
     * 
     */
    private String strategy;

    /**
     * 
     */
    private Integer merchantId;

    /**
     * 
     */
    private Integer deleted;

    /**
     * 
     */
    private String remark;

    /**
     * 
     */
    private String resultMsgType;

    /**
     * 
     */
    private String config;

    /**
     * 
     */
    private String type;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 
     */
    private String extConfig;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}