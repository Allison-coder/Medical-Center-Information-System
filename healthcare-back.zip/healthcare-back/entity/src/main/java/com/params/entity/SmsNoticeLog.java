package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 短信通知记录表
 * @TableName sms_notice_log
 */
@TableName(value ="sms_notice_log")
@Data
public class SmsNoticeLog implements Serializable {
    /**
     * 通知ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 患者姓名
     */
    private String patientName;

    /**
     * 患者手机号码
     */
    private String patientPhone;

    /**
     * 推送类型 1-短信
     */
    private Integer pushType;
    /**
     * 医生姓名
     */
    private String adminName;

    /**
     * 短信模板编码
     */
    private String smsTemplateCode;

    /**
     * 短信平台签名
     */
    private String signName;

    /**
     * 触发发送的节点名称
     */
    private String noticeNode;

    /**
     * 通知参数详情
     */
    private String paramsContent;

    /**
     * 发送状态   0-失败  1-成功
     */
    private Integer status;

    /**
     * 发送结果详情
     */
    private String resultContent;

    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建时间
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}