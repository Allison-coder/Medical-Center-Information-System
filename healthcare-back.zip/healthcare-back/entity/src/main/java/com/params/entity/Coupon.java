package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 优惠券表
 * @TableName coupon
 */
@TableName(value ="coupon")
@Data
public class Coupon implements Serializable {
    /**
     * 主键 id
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 优惠券码  唯一  8位
     */
    private String couponCode;

    /**
     * 渠道 code 来源 promotion_channels 表
     */
    private String channelCode;
    /**
     * 用户名
     */
    private String userName;
    /**
     * 用户名
     */
    private Integer userId;

    /**
     * 核销状态 0-待核销 1-已核销
     */
    private Integer status;

    /**
     * 核销次数（扩展字段 暂时不用）
     */
    private Integer writeOffNum;

    /**
     * 诊所 id（扩展字段 
     */
    private Integer clinicId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date modifyTime;

    /**
     * 操作人 用户名
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除  默认0
     */
    private Integer deleted;

    /**
     * 优惠券模板ID
     */
    private Integer templateId;

    /**
     * 模板名称
     */
    private String templateName;

    /**
     * 活动渠道id
     */
    private Integer promotionChannelsId;

    /**
     * 优惠券类型名称
     */
    private String couponTypeName;

    /**
     * 优惠券类型
     */
    private Integer couponType;

    /**
     * 现金券 优惠金额（单位元）
     */
    private BigDecimal couponParValue;

    /**
     * 折扣券 优惠折扣
     */
    private String discount;

    /**
     * 是否有使用门槛 0-无门槛 1-有门槛
     */
    private Integer thresholdNo;

    /**
     * 满足门槛的金额
     */
    private BigDecimal orderUseAmount;

    /**
     * 结束日期 永久有效为否时才会有
     */
    private Date expireDate;

    /**
     * 使用说明
     */
    private String instructions;

    /**
     * 可用项目 逗号分隔
     */
    private String availableProject;

    /**
     * 兑换项目类型 1-面诊 2-治疗单
     */
    private Integer exchangeOrder;

    /**
     * 治疗项目的id
     */
    private String treatmentProjectIds;

    /**
     * 是否永久有效 0-否 1-是
     */
    private Integer foreverStatus;


    /**
     * 订单优惠券的项目id
     */
    private Integer orderUseProjectId;


    /**
     * 订单号
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String orderSn;


    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}