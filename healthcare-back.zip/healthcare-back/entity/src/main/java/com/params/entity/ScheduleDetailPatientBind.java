package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 预约表（排班-患者关系表）
 * @TableName scheduleling_patient
 */
@TableName(value ="schedule_detail_patient_bind")
@Data
public class ScheduleDetailPatientBind implements Serializable {
    /**
     * 主键 id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 排班表 id
     */
    private Integer scheduleDetailId;

    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 患者 id
     */
    private String patientSn;
    /**
     * 人员ID
     */
    private Integer adminId;
    /**
     * 是否取消 取消状态 0-正常 1-取消预约  默认0
     */
    private Integer deleted;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}