package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 诊疗记录表
 * @TableName medical_records
 */
@TableName(value ="medical_records")
@Data
public class MedicalRecords implements Serializable {
    /**
     * 记录ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 患者ID
     */
    private String patientSn;

    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 排班表id
     */
    private Integer scheduleDetailId;

    /**
     * 完成时间
     */
    private Date completionTime;

    /**
     * 医生/治疗师 id
     */
    private Integer adminId;

    /**
     * 诊疗类型 1-挂号单  2-治疗单
     */
    private Integer medicalType;

    /**
     * 当前数次
     */
    private Integer progress;

    /**
     * 总数次
     */
    private Integer totalSessions;

    /**
     * 状态   2：待预约 3：待报道  4：等待叫号  5：治疗中  6：完成
     */
    private Integer status;

    /**
     * 管理员记录
     */
    private String adminNotes;
    /**
     * 管理员记录修改时间
     */
    private Date AdminModifyTime;
    /**
     * 管理员记录操作人
     */
    private String adminOperator;

    /**
     * 医护人员记录
     */
    private String medicalStaffNotes;
    /**
     * 医护人员记录修改时间
     */
    private Date MedicalModifyTime;
    /**
     * 医护人员记录修改人员
     */
    private String medicalOperator;
    /**
     * 治疗师描述
     */
    private String statementContent;
    /**
     * 治疗师操作的时间
     */
    private Date statementModifyTime;
    /**
     * 治疗师描述的操作人
     */
    private String statementOperator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}