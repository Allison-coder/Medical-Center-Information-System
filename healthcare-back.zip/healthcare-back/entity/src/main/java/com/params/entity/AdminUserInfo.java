package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 后台人员详情表
 * @TableName admin_user_info
 */
@TableName(value ="admin_user_info")
@Data
public class AdminUserInfo implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 账号表 id
     */
    private Integer adminId;

    /**
     * 真实名称
     */
    private String realName;

    /**
     * 个人介绍
     */
    private String introduction;

    /**
     * 性别 0：女；1：男
     */
    private Integer sex;

    /**
     * 首页展示排序
     */
    private Integer homepageDisplaySort;

    /**
     * 首页展示/隐藏  0-隐藏  1-开  默认 0
     */
    private Integer homepageDisplaySwitch;

    /**
     * 诊费：单位为分  默认为0
     */
    private BigDecimal registrationAmount;

    /**
     * 挂号数：预约时间间隔内的可接诊人数
     */
    private Integer registrationCount;

    /**
     * 工号
     */
    private String employeeId;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 删除状态 0-正常 1-软删除  默认0
     */
    private Integer deleted;

    /**
     * 诊所id
     */
    private Integer clinicId;

    /**
     * 头像
     */
    private String avatarUrl;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}