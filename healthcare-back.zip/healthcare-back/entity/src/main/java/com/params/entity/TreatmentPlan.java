package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 处置方案表
 * @TableName treatment_plan
 */
@TableName(value ="treatment_plan")
@Data
public class TreatmentPlan implements Serializable {
    /**
     * 方案ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 患者ID
     */
    private String patientSn;

    /**
     * 方案编号
     */
    private String planSn;

    /**
     * 挂号单订单 编号
     */
    private String orderSn;
    /**
     * 治疗单订单编号
     */
    private String zlOrderSn;

    /**
     * 医嘱
     */
    private String advice;
    /**
     * 预期效果
     */
    private String expectedOutcomes;

    /**
     * 作用机理
     */
    private String mechanization;
    /**
     * 序号
     */
    private Integer  sortNum;

    /**
     * 创建时间
     */
    private Date createTime;


    /**
     * 是否推荐，0表示不推荐，1表示推荐，默认推荐
     */
    private Boolean noRecommended;

    /**
     * 推荐治疗时间
     */
    private Date recommendedTime;



    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 是否删除，0表示未删除，1表示已删除，默认未删除
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}