package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 科普内容记录表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-29
 */
@Getter
@Setter
@TableName("science_record")
public class ScienceRecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;
    private Integer disable;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    /**
     * 类别ID
     */
    private Integer categoryId;

    /**
     * 标题
     */
    private String title;

    /**
     * 图片url
     */
    private String url;

    /**
     * 跳转链接
     */
    private String link;

    /**
     * 是否首页展示：0-不展示，1-展示
     */
    private Integer showStatus;

    /**
     * 顺序
     */
    private Integer rank;

    /**
     * 操作人id
     */
    private Integer adminId;

    /**
     * 操作人
     */
    private String operator;
}
