package com.params.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author robot-params
 * @since 2024-01-11
 */
@Getter
@Setter
@TableName("refund_record")
public class RefundRecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 订单id
     */
    private Integer orderId;

    /**
     * 订单号
     */
    private String orderSn;

    /**
     * 退款状态(已退款 REFUND, 退款中 REFUNDING, 撤销退款 CANCEL, 待审核退款TODO)
     */
    private String refundStatus;


    private BigDecimal refundFee;

    /**
     * 申请退款操作员id
     */
    private Integer applyAdminId;

    /**
     * 执行退款操作员id
     */
    private Integer refundAdminId;

    /**
     * 执行退款操作员名称
     */
    private String refundAdminName;

    /**
     * 申请退款时间
     */
    private Date applyRefundTime;

    /**
     * 执行退款时间
     */
    private Date refundTime;

    /**
     * 是否作废
     */
    private Integer deleted;

    /**
     * 退款原因
     */
    private String refundReason;

    /**
     * 备注信息
     */
    private String remark;
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 记录回调信息
     */
    private String callbackInfo;
    private String refundRequestNo;
}
