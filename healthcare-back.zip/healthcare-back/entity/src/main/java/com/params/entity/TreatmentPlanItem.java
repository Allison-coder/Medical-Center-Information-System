package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 处置方案明细表
 * @TableName treatment_plan_item
 */
@TableName(value ="treatment_plan_item")
@Data
public class TreatmentPlanItem implements Serializable {
    /**
     * id
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 方案ID
     */
    private Integer planId;

    /**
     * 患者编号
     */
    private String patientSn;

    /**
     * 项目表的 id
     */
    private Integer  itemId;
    /**
     * 项目类型
     */
    private Integer projectType;


    /**
     * 订单号
     */
    private String orderSn;
    /**
     * 治疗单订单编号
     */
    private String zlOrderSn;

    /**
     * 项目名称
     */
    private String itemName;

    /**
     * 单价（RMB） 单位：元
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private BigDecimal unitPrice;

    /**
     * 总次数
     */
    private Integer totalSessions;
    /**
     * 支付价 （RMB） 单位：元
     */
    private BigDecimal totalPrice;


    /**
     * 优惠价格（RMB） 单位：元
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private BigDecimal preferentialPrice;


    /**
     * 总价（RMB） 单位：元
     */
    private BigDecimal sourceAmount;

    /**
     * 频率
     */
    private String frequency;

    /**
     * 频率次数
     */
    private Integer frequencyNum;

    /**
     * 单次时长
     */
    private Double durationPerSession;

    /**
     * 预计时长
     */
    private String expectedDuration;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除  默认0
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}