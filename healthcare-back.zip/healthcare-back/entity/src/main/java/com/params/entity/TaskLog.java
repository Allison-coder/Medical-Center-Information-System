package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 任务进度日志表 
 * @TableName task_log
 */
@TableName(value ="task_log")
@Data
public class TaskLog implements Serializable {
    /**
     * 任务 id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 患者id
     */
    private String patientSn;

    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 任务类型 1- 挂号单类型   2-治疗单类型
     */
    private Integer taskType;

    /**
     * 任务状态  1-待支付 2-待预约  3-待报到  4-候诊中/等候治疗  5-面诊中/治疗中  6-已完成/完成治疗 7-已取消 8-已退款
     */
    private Integer taskStatus;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}