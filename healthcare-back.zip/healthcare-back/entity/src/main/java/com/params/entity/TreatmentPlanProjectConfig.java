package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 处置方案的项目配置表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-17
 */
@Getter
@Setter
@TableName("treatment_plan_project_config")
public class TreatmentPlanProjectConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键 id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 项目类型
     */
    private Integer projectType;

    /**
     * 项目单价 单位（元）
     */
    private BigDecimal priceHour;

    /**
     * 时长默认 单位（时）
     */
    private String defaultTime;
    /**
     * 备注
     */
    private String remark;

    /**
     * 排序  0排最前
     */
    private Integer sort;


    /**
     * 是否删除，0表示未删除，1表示已删除，默认未删除
     */
    private Integer deleted;


    /**
     * 预计时长
     */
    private String expectedDuration;

    /**
     * 单次预约时长
     */
    private String singleAppointmentDuration;


    /**
     * 诊所ID
     */
    private Integer clinicId;

    /**
     * 添加时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

}
