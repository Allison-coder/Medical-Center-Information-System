package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 诊所表
 * @TableName clinic
 */
@TableName(value ="clinic")
@Data
public class Clinic implements Serializable {
    /**
     * 诊所id
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 诊所名称
     */
    private String clinicName;

    /**
     * 诊所介绍
     */
    private String clinicIntroduce;

    /**
     * 经度
     */
    private Double longitude;

    /**
     * 纬度
     */
    private Double latitude;

    /**
     * 诊所地址
     */
    private String clinicAddress;

    /**
     * 诊所状态， 0：停用 1： 启用
     */
    private Integer status;
    /**
     * 区分下哪个医疗诊所的用户端
     */
    private String appId;

    /**
     * 创建时间，默认为当前时间
     */
    private Date createTime;

    /**
     * 修改时间，默认为当前时间，更新时自动更新为当前时间
     */
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除  默认0
     */
    private Integer deleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}