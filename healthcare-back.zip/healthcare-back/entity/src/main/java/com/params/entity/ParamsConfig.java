package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 配置表
 * </p>
 *
 * @author robot-params
 * @since 2024-01-05
 */
@Getter
@Setter
@TableName("params_config")
public class ParamsConfig implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 渠道ID -1 - 全部渠道
     */
    private Integer channelId;

    /**
     * 城市ID -1 -全国
     */
    private Integer cityId;

    /**
     * 配置code
     */
    private String configCode;

    /**
     * 扩展code
     */
    private String extentConfigCode;

    /**
     * 配置内容
     */
    private String configInfo;

    /**
     * 备注
     */
    private String remark;

    /**
     * 语言版本 ZH - 中文
     */
    private String languageVersion;

    /**
     * 删除状态 0-正常 1-软删除
     */
    private Byte deleted;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 编辑时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime modifyTime;
}
