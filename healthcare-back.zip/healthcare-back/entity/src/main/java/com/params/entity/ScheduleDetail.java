package com.params.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;

/**
 * 排班明细表
 * @TableName scheduling
 */
@TableName(value ="schedule_detail")
@Data
public class ScheduleDetail implements Serializable {
    /**
     * 排班ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 日期
     */
    private Date scheduleDate;

    /**
     * 班次ID
     */
    private Integer scheduleId;
    /**
     * 人员ID
     */
    private Integer adminId;

    /**
     * 开始时间
     */
    private Time startTime;

    /**
     * 结束时间
     */
    private Time endTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}

