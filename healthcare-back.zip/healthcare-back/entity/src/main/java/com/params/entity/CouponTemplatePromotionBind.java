package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 优惠券模板-活动绑定表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-22
 */
@Getter
@Setter
@TableName("coupon_template_promotion_bind")
public class CouponTemplatePromotionBind implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 优惠券模板ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 模板名称
     */
    private String name;

    /**
     * 活动渠道id
     */
    private Integer promotionChannelsId;

    /**
     * 优惠券类型名称
     */
    private String couponTypeName;

    /**
     * 优惠券类型
     */
    private Integer couponType;

    /**
     * 现金券 优惠金额（单位元）
     */
    private BigDecimal couponParValue;

    /**
     * 折扣券 优惠折扣
     */
    private String discount;

    /**
     * 是否有使用门槛 0-无门槛 1- 有门槛
     */
    private Integer thresholdNo;

    /**
     * 满足门槛的金额
     */
    private BigDecimal orderUseAmount;

    /**
     * 结束日期 永久有效为否时才会有
     */
    private Date expireDate;

    /**
     * 使用说明
     */
    private String instructions;

    /**
     * 兑换项目类型 1-面诊 2-治疗单
     */
    private Integer exchangeOrder;

    /**
     * 可用项目 1-面诊  2-治疗 用逗号分隔
     */
    private String availableProject;

    /**
     * 治疗项目的ID
     */
    private String treatmentProjectIds;

    /**
     * 是否永久有效 0-否 1-是
     */
    private Integer foreverStatus;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 是否删除，0表示未删除，1表示已删除，默认未删除
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

}
