package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 订单的面诊记录表
 * </p>
 *
 * @author robot-params
 * @since 2024-08-10
 */
@Getter
@Setter
@TableName("orders_interview_records")
public class OrdersInterviewRecords implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 面诊记录ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 订单编号
     */
    private String patientSn;

    /**
     * 预约的排班id
     */
    private Integer scheduleDetailId;

    /**
     * 被预约人员id
     */
    private Integer adminId;

    /**
     * 主诉
     */
    private String chiefComplaint;

    /**
     * 诊断
     */
    private String diagnosis;

    /**
     * 预测
     */
    private String forecast;

    /**
     * 治疗方案
     */
    private String treatmentPlan;

    /**
     * 预期治疗效果
     */
    private String expectedOutcomes;

    /**
     * 医嘱
     */
    private String advice;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 删除状态 0-正常 1-软删除 默认0
     */
    private Integer deleted;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    /**
     * 发布状态 0-未发布 1-已发布
     */
    private Integer releaseStatus;

}
