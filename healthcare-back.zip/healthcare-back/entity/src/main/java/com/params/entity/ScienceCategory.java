package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 科普类别表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-29
 */
@Getter
@Setter
@TableName("science_category")
public class ScienceCategory implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;
    private Integer disable;

    /**
     * 诊所ID
     */
    private Integer clinicId;

    /**
     * 名称
     */
    private String name;

    /**
     * 图标url
     */
    private String url;

    /**
     * 顺序
     */
    private Integer rank;
}
