package com.params.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Getter
@Setter
@TableName("transaction_log")
public class TransactionLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 交易号
     */
    private String tradeNum;

    private BigDecimal tradeFee;

    private Integer orderId;

    private Integer merchantPaymentInfoId;

    /**
     * 电子版/纸质版/升级纸质版
     */
    private String type;

    /**
     * 暂存参数json串，支付回调用
     */
    private String param;

    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 预付单号
     */
    private String prepayId;

    /**
     * 用户id
     */
    private Integer userId;

}
