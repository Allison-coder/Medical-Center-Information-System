package com.params.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 指定用户领取表
 * </p>
 *
 * @author robot-params
 * @since 2024-07-22
 */
@Getter
@Setter
@TableName("promotion_specify_user_bind")
public class PromotionSpecifyUserBind implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键 id
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 可领取用户的手机号码
     */
    private String phoneNum;

    /**
     * 活动渠道 id
     */
    private Integer promotionId;

    /**
     * 渠道 code
     */
    private String channelCode;

    /**
     * 活动 code
     */
    private String activityCode;

    /**
     * 是否删除 0-否 1-是
     */
    private Integer deleted;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

}
