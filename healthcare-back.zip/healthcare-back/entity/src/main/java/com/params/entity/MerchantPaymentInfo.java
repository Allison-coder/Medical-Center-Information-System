package com.params.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 支付方式配置表
 * </p>
 *
 * @author lf
 * @since 2018-11-05
 */
@Data
public class MerchantPaymentInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;
    private Date createTime;
    private Date modifyTime;
    private Integer disable;
    private Integer version;
    /**
     * 渠道id
     */
    private Integer merchantId;
    /**
     * 支付方式
     */
    private String paymentType;
    /**
     * 名称
     */
    private String name;

    private String nickName;
    /**
     * 备注
     */
    private String appid;
    /**
     * 状态
     */
    private String secret;
    private String pubKey;
    private String preKey;
    private String branchNo;
    private String merchantNo;
    private String merchantSecret;
    private String payNoticeUrl;
    private String signNoticeUrl;
    private String optPwd;
    private String paymentUrl;

    private String iconUrl;

    private String remark;
    private String config;
    private Integer rank;
    private Integer scope;
    private String ch;


}
