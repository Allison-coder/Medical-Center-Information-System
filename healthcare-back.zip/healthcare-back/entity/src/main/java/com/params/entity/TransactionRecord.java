package com.params.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 支付记录表
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Getter
@Setter
@TableName("transaction_record")
public class TransactionRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    private Integer disable;

    private Integer version;

    /**
     * 订单id
     */
    private Integer orderId;

    /**
     * 流水号
     */
    private String tradeNum;

    /**
     * 支付状态
     */
    private String status;


    private String paymentType;

    /**
     * 支付平台流水号
     */
    private String serialNo;

    /**
     * 支付金额
     */
    private BigDecimal payFee;

    /**
     * 回调参数
     */
    private String callbackParams;

    /**
     * 备注
     */
    private String remark;

    /**
     * 第三方优惠金额（例如支付宝红包这些）
     */
    private BigDecimal otherCouponFee;

}
