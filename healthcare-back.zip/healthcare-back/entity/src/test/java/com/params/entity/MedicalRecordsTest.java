package com.params.entity;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MedicalRecordsTest {

    @Test
    void testStream() {
        List<MedicalRecords> records = new ArrayList<>();
        MedicalRecords one = new MedicalRecords();
        one.setStatus(0);
        MedicalRecords one1 = new MedicalRecords();
        one1.setStatus(3);
        MedicalRecords one2 = new MedicalRecords();
        one2.setStatus(0);
        MedicalRecords one3 = new MedicalRecords();
        one3.setStatus(3);
        records.add(one);
        records.add(one1);
        records.add(one2);
        records.add(one3);
        long count = records.stream().filter(x -> Integer.valueOf(3).equals(x.getStatus())).count();
        System.out.println(count);
        Integer i = Integer.valueOf(String.valueOf(count));
        System.out.println(i);
    }
}