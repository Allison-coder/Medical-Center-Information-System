package com.params.constant;

import org.springframework.util.StringUtils;

public enum ChooseReasonTypeEnum {

    SELF_REFUND("自助退款"),
    CUSTOM_REFUND("客服退款"),
    CANCEL_REFUND("取消退款"),
    ;

    public  String value;
    ChooseReasonTypeEnum(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if(StringUtils.isEmpty(type)){
            return false;
        }
        for (ChooseReasonTypeEnum ele : ChooseReasonTypeEnum.values()) {
            if (ele.toString().equals(type) ) {
                return true;
            }
        }
        return false;
    }

    public static String transfor(String status) {
        if(StringUtils.isEmpty(status)){
            return "";
        }
        for (ChooseReasonTypeEnum ele : ChooseReasonTypeEnum.values()) {
            if (ele.name().equals(status) ) {
                return ele.getValue();
            }
        }
        return "";
    }

}
