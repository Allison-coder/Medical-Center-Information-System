package com.params.constant;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @author Jincheng <oldway2012@live.com>
 * @version 1.0.0
 */
public interface KyOrderTraceEnum {

    /**
     * 轨迹状态
     */
    enum Status {
        TODO("TODO", "待执行"),
        DOING("DOING", "执行中"),
        DONE("DONE", "完成"),
        ;

        private String value;
        private String name;

        Status(String value, String name) {
            this.value = value;
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public String getName() {
            return name;
        }
    }


}
