package com.params.constant;


import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum InvoiceStatusEnum {

//    未申请:NOT_APPLY
//    申请中：APPLY_ING
//    申请成功：APPLY_SUCCESS
//    申请失败：APPLY_FAIL

    NOT_APPLY("NOT_APPLY", "未申请"),
    APPLY_ING("APPLY_ING", "申请中"),
    APPLY_SUCCESS("APPLY_SUCCESS", "申请成功"),
    APPLY_FAIL("APPLY_FAIL", "申请失败"),
    ;
    private final String value;
    private final String msg;

    public static boolean exists(String type) {
        if (StrUtil.isBlank(type)) return false;
        for (InvoiceStatusEnum ele : InvoiceStatusEnum.values()) {
            if (ele.name().equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }


    public static String translate(String status) {
        for (InvoiceStatusEnum statusEnum : InvoiceStatusEnum.values()) {
            if (statusEnum.value.equals(status)) {
                return statusEnum.msg;
            }
        }
        return null;
    }
}
