package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 处置方案的是否发布的状态
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Getter
@AllArgsConstructor
public enum TreatPlanIssuedStatusEnum {

    ISSUED(Boolean.TRUE, "开具"),
    NOT_ISSUED(Boolean.FALSE, "未开具");

    private final Boolean code;
    private final String value;
}
