package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @DESCRIPTION 创建优惠券活动的 bo
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class CreateOrUpDatePromotionBO {

    @ApiModelProperty(value = "活动 id 修改的时候必填")
    private Integer id;

    @ApiModelProperty(value = "活动名称")
    private String activityName;

    @ApiModelProperty(value = "渠道名称")
    private String channelName;

    @ApiModelProperty(value = "截止日期")
    private String expireDate;

    @ApiModelProperty(value = "截止时间")
    private String expireTime;

    @ApiModelProperty(value = "是否永久有效 0-否 1-是")
    private Integer foreverStatus;

    @ApiModelProperty(value = "领取条件 详情接口： /promotion/manage/gettingCondition ")
    private Integer gettingCondition;

    @ApiModelProperty(value = "指定用户的 电话号码")
    List<String> phoneNumbers;

    @ApiModelProperty(value = "分享文案")
    private String shareContent;

    @ApiModelProperty(value = "总价值")
    private String totalValue;

    @ApiModelProperty(value = "优惠券列表")
    private List<ActivityCouponDetailsBO> activityCouponDetails;
}
