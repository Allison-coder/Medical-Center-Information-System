package com.params.constant;


import org.springframework.util.StringUtils;

public enum TransactionRecordEnum {

    IS_PAY("已支付"),
    REFUND("已退款"),
    REFUNDING("退款中"),
    PARTIAL_REFUNDING("部分退款中"),
    PARTIAL_REFUND("部分已退款"),

    /**
     *   如回执处理失败
     */
    UNUSUAL("退款异常"),

    UPGRADE_PAPER("升级纸质版");

    public final String value;
    TransactionRecordEnum(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if(StringUtils.isEmpty(type)){
            return false;
        }
        for (TransactionRecordEnum ele : TransactionRecordEnum.values()) {
            if (ele.toString().equals(type) ) {
                return true;
            }
        }
        return false;
    }

    public static String transfor(String status) {
        if (status == null) {
            return "";
        }
        TransactionRecordEnum[] transactionRecordEnums = TransactionRecordEnum.values();
        for (int i = 0, size = transactionRecordEnums.length; i < size; i++) {
            if (transactionRecordEnums[i].name().equals(status)) {
                return transactionRecordEnums[i].getValue();
            }
        }
        return "";
    }


}
