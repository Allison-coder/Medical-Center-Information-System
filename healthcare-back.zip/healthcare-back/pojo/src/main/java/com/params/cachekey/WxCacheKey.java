package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

public class WxCacheKey extends AbstractCacheKey {

    private WxCacheKey() {
    }

    private WxCacheKey(String cacheKey) {
        super(cacheKey);
    }

    public static WxCacheKey ACCESS_TOKEN_APPID = new WxCacheKey("healthcare:wxApp:grantAccessToken:appId:{}");

    public static WxCacheKey USER_INFO = new WxCacheKey("healthcare:wxUserInfo:appId:{}:openId:{}");
}
