package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public class CaptchaCacheKey extends AbstractCacheKey {

    private CaptchaCacheKey() {
    }

    private CaptchaCacheKey(String prefix) {
        super(prefix);
    }

    private CaptchaCacheKey(String prefix, long expireSeconds) {
        super(prefix, expireSeconds);
    }

    private CaptchaCacheKey(String prefix, long timeout, TimeUnit unit) {
        super(prefix, timeout, unit);
    }

    public static CaptchaCacheKey CAPTCHA_CACHE_KEY = new CaptchaCacheKey("healthcare:captcha:{}");

}