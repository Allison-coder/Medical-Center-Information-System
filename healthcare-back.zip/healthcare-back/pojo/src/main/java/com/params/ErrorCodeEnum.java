package com.params;


public enum ErrorCodeEnum {

    SUCCESS(200, "success"),
    SUCCESS_YSS(0, "success"),

    MISS_PARAM(4001, "缺少必要参数"),
    FORMAT_PARAM(4002, "参数格式错误"),
    MISS_HEADER_PARAM(4003, "请求头缺少必要参数"),
    TOKEN_ILLEGAL(4009, "非法token"),
    Token_VALID_FIELD(4004, "token已过期"),
    PARAM_NOT_BE_NULL(4007, "参数不能为空"),

    NO_LOGIN(4004, "未进行登录"),

    AUTHENICATION_ERROR(4004, "认证失败"),

    ERROR_REQUEST(4012, "接入系统错误"),

    UNKNOWN_MERCHANT(4010, "未知渠道"),
    BAD_REQUEST(4012, "接入系统错误"),
    RESOURCE_NOT_EXIT(4013, "资源不存在"),
    BUSINESS_NOT_EXIT(4013, "业务不存在"),
    PERMISSION_NOT_MATCH(4014, "权限不匹配"),
    STATUS_NOT_ALLOW(4015, "状态不允许该操作"),
    PRINT_MACHINE_ERR(4017, "打印设备状态异常"),

    VERIFY_SIGN_FAIL(4010, "签名验证失败"),


    PAUSE_TO_USE(4011, "已暂停使用"),
    ASSISTANCE_EXISTS(4013, "当前订单已申请客服协助"),
    ADD_MERCHANT_ERROR(4014, "获取金马商户信息失败"),
    ORDER_EXISTS(4008, "该图像已经生成了订单"),
    MERCHANT_USER_NOT_MATCH(4004, "用户与渠道信息不匹配"),
    FREEDOM_PRINT_INTERFACE_ERR(4013, "任我印接口请求异常"),
    RESOLVE_FILE_ERR(4016, "解析文件资源失败"),
    TRAVEL_API_REQ_ERR(4017, "中旅接口请求异常"),
    PARAMS_CONVERT_ERR(4014, "参数类型转换异常"),
    LIVING_CHECK_TOKEN_INVALID(4019, "无效活体认证token"),
    RESOLVE_REQUEST_ERR(4014, "解析用户资源失败"),
    REPEAT_OPERATION(4015, "操作频繁，稍后重试"),
    ERR_GET_UNION_ID(4022, "获取用户unionId失败"),
    INVALID_CODE(4023, "获取微信用户信息无效code"),

    VERIFY_CODE_FAIL(4100, "验证码不正确"),

    PASSWORD_FAIL(4100, "密码不正确"),

    SERVER_ERROR(5001, "Internal Server Error"),
    REQUEST_TYPE_ERROR(5002, "不正确请求方式"),
    COUPON_EXPIRED(5008, "优惠券已过期"),
    COUPON_USED(5008, "优惠券被已使用"),
    REPEAT_UPLOAD(5010, "请勿重复上传同一张相片"),
    //方图接口请求异常
    FT_REQ_ERR(5011, "外部接口请求异常"),
    TEMPLATE_DEAL_REQ_ERR(5012, "排版照处理异常"),
    AI_DEAL_REQ_ERR(5013, "AI处理异常"),
    SYS_MISS_CONFIG(5014, "缺失系统配置项"),
    AI_CHECK_REQ_ERR(5015, "AI检测异常"),
    CONVERT_HTML_TO_IMG_ERR(5016, "HTML转图片异常"),
    DOWN_LOAD_ERR(5017, "图片下载异常"),
    DECRYPT_FT_NOTICE_DATA_ERR(5018, "解密方图回调数据异常"),
    ILLEGAL_PARAM(5019, "不合法参数"),
    LIVING_CHECK_ERR(5020, "活体检测异常"),
    IDENTITY_CERTIFY_REQ_ERR(5021, "证明校验接口请求异常"),
    THIRD_API_REQ_ERR(5021, "外部接口请求异常"),
    SYS_RESOURCE_CONF_ERR(5022, "资源未配置"),

    THIS_SERVICE_IS_NOT_IMPL(5023, "该支付方式未实现查询订单"),
    IS_NOT_IMG_TYPE(5024, "图片文件格式错误"),


    NOT_FIND_PAY_CONFIG(5026, "未找到该渠道支付配置信息"),
    NOT_FIND_PAY_TYPE(5027, "未知支付类型"),
    INVALID_LOGIN_SOURCE(5030, "未知登陆来源"),

    INVALID_RECEIPT_INFO(5031, "收货信息异常"),
    VERIFY_CODE_ERROR(5032, "验证码校验错误"),
    FILE_CANT_NULL(5033, "图片资源不能为空"),
    SENSITIVE_PARAM(5034, "输入的文字包含敏感信息，请调整文字内容"),


    COUPON_ACTIVITY_NOTSTART(8000, "活动未开始"),
    COUPON_ACTIVITY_EXPIRE(8001, "活动已结束"),
    COUPON_ACTIVITY_LIMIT(8002, "未达到活动限制"),
    COUPON_REPEAT(8003, "请勿重复领取"),
    COUPON_IZYZ_NOT(8005, "根据您的手机号查询到您不是志愿者，不符合领券资格"),
    COUPON_NOT_MOBILE(8006, "获取不到用户手机号"),
    COUPON_FREQUENTLY(8004, "操作频繁，稍后重试"),
    COUPON_NOT_EXIST(8007, "卡券不存在"),

    //钱包接口异常
    WALLET_DEDUCTION_ERR(9001, "钱包扣款异常"),
    WALLET_INFO_ERR(9002, "获取商家钱包信息异常"),


    LOGIN_IS_INVALID(9001, "链接已失效"),
    HAVE_USER_COMMENTS_IMG(9005, "您的好评截图已上传，请勿重复上传"),

    USER_NOT_AUTH(9006, "请先授权登录"),

    /**
     * 特权用户
     */
    SPECIAL_STAFF_NOT_AUTHORITY(10000, "用户未授权"),
    SPECIAL_STAFF_MOBILE_NOT_AUTHORITY(10001, "该手机无查询权限"),
    SPECIAL_STAFF_NOT_ORDER(10002, "查询不到该用户订单"),

    /**
     * 不能重复
     */
    CMB_USER_NOT_AUTH(99998, "用户沒有授权"),

    /**
     * 系统异常
     */
    SYSTEM_PARAMS_ERR(10000, "参数缺失"),

    SYSTEM_PARAMS_ERR_TEMP(10000, "网络错误，请检查网络环境"),
    SYSTEM_GET_CONFIG_ERR(10001, "获取配置异常"),
    SYSTEM_SIGN_ERR(10002, "签名校验失败"),
    SYSTEM_LOGIN_ERR(10003, "上次登陆位置与当前与渠道不匹配"),
    SYSTEM_GET_USER_ERR(10004, "获取用户详情失败"),
    SYSTEM_FACE_ERR(10005, "获取订单照片人脸信息失败"),
    SYSTEM_SHIPPING_ERR(10006, "运费信息不存在"),
    SYSTEM_ID_PHOTO_NULL_ERR(10007, "请上传证件"),
    SYSTEM_USER_BUILD_ERR(10008, "用户登陆绑定与之前不一致"),
    SYSTEM_USER_COMMONS_ERR(10009, "您的好评截图已上传，请勿重复上传"),
    SYSTEM_GET_BUSINESS_ERR(10010, "获取业务分类异常"),
    SYSTEM_GET_MERCHANT_ERR(10011, "获取渠道业务异常"),
    SYSTEM_PHOTO_NULL_ERR(10012, "证件照片不能为空"),
    SYSTEM_ERR(10013, "服务器繁忙，请稍后再试"),
    FREQUENT(10013, "请勿频繁操作"),
    SYSTEM_PERMISSION_NOT_MATCH(10014, "权限不匹配"),
    // 有意义的code,其他业务请勿使用这个枚举
    SYSTEM_BIZNO_EXIST(19999, "此参数已存在，bizNo请勿重复"),
    SYSTEM_ORDER_NOT_EXIST(19998, "订单不存在"),


    /**
     * 用户模块
     */
    USER_FREEZE_ERR(20000, "您的账号已被冻结，请联系客服解封"),
    USER_VERIFY_CODE_NULL_ERR(20001, "验证码不能为空"),
    USER_MOBILE_ERR(20002, "手机号格式不正确"),
    USER_RE_GET_CODE_ERR(20003, "请重新获取验证码"),
    USER_VERIFY_CODE_ERR(20004, "验证码校验错误"),
    USER_NOT_LOGIN_ERR(20005, "未进行登录"),
    USER_NOT_FIND_ERR(20006, "用户不存在"),
    USER_UNIONID_CANT_NULL_ERR(20007, "unionid不能为空！"),
    USER_MOBILE_REGISTERED_ERR(20008, "该手机号已经注册过了"),
    USER_VERIFY_CODE_SEND_FREQUENTLY(20009, "验证码已发送，请勿频繁发送"),

    USER_VERIFY_CODE_SEND_FREQUENTLY_1(20012, "请勿频繁发送"),
    USER_IMG_VERIFY_CODE_NULL_ERR(20010, "图形验证码不能为空"),
    USER_IMG_VERIFY_CODE_ERR(20011, "图形验证码校验错误"),

    USER_LOGIN_ERR(20012, "登陆失败,请退出页面后重新进入"),
   ROLE_NOT_FIND_ERR(20013, "角色不存在"),

    /**
     * 订单模块
     */
    ORDER_PAY_AMOUNT_ERR(30000, "支付金额不能小于0.01元"),
    ORDER_STATUS_ERR(30001, "当前订单状态不允许调整相片"),
    ORDER_BUSINESS_TYPE_ERR(30002, "当前业务类型不允许调整"),
    ORDER_IS_EDIT_ERR(30003, "当前订单相片已调整过"),
    ORDER_IS_NOT_FIND_ERR(30004, "订单记录不存在"),
    ORDER_WALLET_ERR(30005, "商家余额不足，需要商家充值后才能下单"),
    ORDER_CANT_REPHOTO_ERR(30006, "当前订单不允许免费重拍操作，请稍后重试"),
    ORDER_CAT_PAY_ERR(30007, "该订单状态不支持支付"),
    ORDER_AUTH_LOG_NOT_FIND_ERR(30008, "授权记录不存"),
    ORDER_AUTH_ERR(30008, "授权失败"),
    ORDER_AUTO_ORDER_ERR(30009, "授权码绑定的订单记录不存在"),
    ORDER_AUTO_PHOTO_ERR(30010, "授权码绑定的照片记录不存在"),
    ORDER_AUTO_FAIL_PRINT_ERR(30012, "授权失败，该订单不可代理打印"),
    ORDER_AUTO_FAIL_CLOSE_ERR(30013, "授权失败，代理打印功能已关闭"),
    ORDER_PAPER_CAN_LOGISTICS_ERR(30014, "纸质版才能选择物流信息"),
    ORDER_ADDRESS_ERR(30015, "收货地址录入不完整"),
    ORDER_CANT_PROXY_PRINT_ERR(30016, "当前订单不支持代理打印"),
    ORDER_IS_REPHOTOING_ERR(30017, "该订单相片已经重拍完成或重拍处理中，不能进行该操作"),
    ORDER_AUTH_CODE_INVALID_ERR(30018, "authCode无效"),
    ORDER_PRINT_ADDRESS_IS_NULL(30019, "请先选择自助打印地址"),
    ORDER_STATUS_CANNOT_OPERATE(30020, "当前照片已下单不允许修改配置"),
    ORDER_NOT_MOBILE(30021, "请先授权手机号码！"),
    CANCEL_REFUND_FAIL(30022, "撤销退款失败！"),
    DEAL_REFUND_FAIL(30023, "执行退款失败！"),
    REFUND_FAIL(30023, "退款失败！"),
    UNFINISHED_ORDER(30024, "存在未完成订单，请先处理！"),
    /**
     * 相片模块
     */
    PHOTO_IS_UPDATE_PAPER_ERR(40000, "已经成功升级纸质版成功"),
    PHOTO_UPLOAD_SAME_PHOTO_ERR(40000, "请勿重复上传同一张相片"),
    ORDER_CANT_EDIT_RECEPIT_ERR(10013, "不允许调整回执类相片"),
    PHOTO_STATUS_NOT_CHECK_ERR(10014, "该相片状态尚未检测通过"),
    PHOTO_IMG_TYPE_ERR(10015, "未知图像类型"),
    PHOTO_ORDER_TYPE_ERR(10016, "未知商品制式"),
    PHOTO_STATUS_CAN_NOT_OPERATION(10017, "当前照片状态不可操作"),
    PHOTO_IS_REMAKE_ING(10018, "该订单已有相片重拍处理中"),

    /**
     * 业务模块
     */
    BUSINESS_PARAMS_ERR(50000, "参数异常"),
    BUSINESS_NOT_FUND(50001, "业务不存在"),

    /**
     * 支付模块
     */
    PSY_CREATE_PAY_ORDER_ERR(60000, "预支付创建失败"),


    /**
     * 卡券模块
     */
    COUPON_IS_NOT_FUND_ERR(70000, "卡券包信息不存在"),
    COUPON_ACTIVITY_END_ERR(70001, "活动已结束"),
    COUPON_CANT_CREATE_ORDER_ERR(70002, "该活动不能创建订单"),
    COUPON_CODE_INVALID_ERR(70003, "兑换码无效"),
    COUPON_EXCHANGE_FAIL_ERR(70004, "兑换失败"),
    COUPON_IS_USING_ERR(70005, "该优惠券被其他支付占用中，请稍后再试"),
    COUPON_ALREADY_GET_ERR(70006, "您已领取该优惠券，不能重复领取哦"),
    COUPON_CANT_GET_ERR(70007, "对不起，您未达到领取要求"),
    COUPON_IS_NULL_ERR(70008, "没有可以领取的卡券"),
    COUPON_IS_GET_OVER_ERR(70009, "你来晚啦，优惠券已被抢光了"),
    COUPON_RESTRICTION_ERR(70010, "今天已达到领取限制，请明天再来"),
    COUPON_CANT_USE_ERR(70011, "卡劵不是可用状态"),
    COUPON_IS_END_ERR(70012, "卡券已过期"),
    COUPON_INVALID_ERR(70013, "无效的优惠券"),
    COUPON_IS_NOT_WAIT_USE_ERR(70014, "优惠劵不处于待使用状态"),
    COUPON_IS_NOT_USED_ERR(70015, "优惠劵不处于已使用状态"),
    COUPON_NOT_VOLUNTEER_ERR(70016, "根据您的手机号查询到您不是志愿者，不符合领券资格"),
    COUPON_FET_FAIL_ERR(70017, "领取失败,请稍后重试！"),


    COUPON_CODE_ERR(70018, "兑换码不正确"),
    COUPON_CODE_USED_ERR(70019, "兑换码已被使用"),
    COUPON_CODE_EXPIRED_ERR(70020, "兑换码已过期"),


    /**
     * 打印模块
     */
    PRINT_AUTH_ERR(80001, "权限不足！"),
    PRINT_ORDER_STATUS_SCAN_ERR(80002, "该订单状态或订单类型不支持自助扫描打印！"),
    PRINT_PHOTO_STATUS_SCAN_ERR(80003, "请等待相片处理成功再进行扫描打印哦！"),
    PRINT_ORDER_STATUS_TASK_ERR(80004, "该订单状态或订单类型不支持创建打印任务！"),
    PRINT_PHOTO_STATUS_TASK_ERR(80005, "相片状态不支持创建打印任务！"),
    PRINT_AUTH_FAIL_ERR(80007, "授权失败！"),
    PRINT_TERMINAL_LIMIT(80008, "无法通过该设备打印"),

    /**
     * 个人毕业证
     */
    STUDENT_FUN_NOT_OPEN(90000, "该业务本功能未开放"),
    STUDENT_NOT_EXIST(90001, "无法匹配到您的信息"),
    STUDENT_ORDER_EXIST(90002, "您已拍摄了个人毕业照，请勿重复拍摄"),

    /**
     * 权益活动
     */
    LIFE_INTEREST_NOT_PAY(100000, "你的权益订单未支付"),
    LIFE_INTEREST_NOT_FACE_INFO(100001, "找不到您的人脸信息"),
    LIFE_INTEREST_EXIST_FACE(100002, "人脸信息已绑定"),
    LIFE_INTEREST_EXIST_TASK_COUPON(100003, "权益套餐已发放，请勿重复绑定"),
    LIFE_INTEREST_COUPON_TASKING(100004, "权益套餐发放中，请勿重复绑定"),
    LIFE_INTEREST_NOT_EXIST(109999, "未找到您权益订单信息"),
    ;

    private int code;
    private String msg;

    public String msg() {
        return msg;
    }

    public int code() {
        return code;
    }

    ErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static ErrorCodeEnum getEnum(int code) {
        for (ErrorCodeEnum ele : ErrorCodeEnum.values()) {
            if (ele.code() == code) {
                return ele;
            }
        }
        return null;
    }
}
