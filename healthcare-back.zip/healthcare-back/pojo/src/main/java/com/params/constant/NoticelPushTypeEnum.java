package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 通知的推送类型
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Getter
@AllArgsConstructor
public enum NoticelPushTypeEnum {
    SMS(1, "短信");

    private final Integer code;
    private final String value;
}
