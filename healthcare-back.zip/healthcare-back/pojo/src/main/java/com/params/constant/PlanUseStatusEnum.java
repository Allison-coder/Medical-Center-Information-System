package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 处置方案可否创建的枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Getter
@AllArgsConstructor
public enum PlanUseStatusEnum {
    // 处置方案已使用状态：1-已使用 0-未使用
    UN_USED(0, "未使用"),
    IN_USED(1, "已使用");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (PlanUseStatusEnum planAddFlagEnum : PlanUseStatusEnum.values()) {
            if (planAddFlagEnum.code.equals(code)) {
                return planAddFlagEnum.getValue();
            }
        }
        return null;
    }

    public static PlanUseStatusEnum fromCode(Integer code) {
        for (PlanUseStatusEnum planAddFlagEnum : PlanUseStatusEnum.values()) {
            if (planAddFlagEnum.code.equals(code)) {
                return planAddFlagEnum;
            }
        }
        return null;
    }
}
