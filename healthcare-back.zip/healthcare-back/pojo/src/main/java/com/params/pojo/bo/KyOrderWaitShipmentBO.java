package com.params.pojo.bo;

import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/28
 */
@Getter
@Setter
public class KyOrderWaitShipmentBO {
    private Long id;
    private String orderNo;
    private Integer orderStatus;
    private Integer logisticsStatus;
    private String shippingMobile;
    private String shippingName;
    private String shippingAddress;
    private String supplierName;
    private String skuName;
    private Long amount;
}
