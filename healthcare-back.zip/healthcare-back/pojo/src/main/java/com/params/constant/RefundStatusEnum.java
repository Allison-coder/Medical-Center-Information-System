package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/8
 */
@Getter
@AllArgsConstructor
public enum RefundStatusEnum {

    REFUND_ING(0, "退款中"),
    REFUND(1, "退款成功"),
    REFUND_CANCEL(2, "取消退款"),

    USER_REFUND_ING(4, "用户申请退款中"),
    ;
    private final Integer value;
    private final String name;

    public static String translate(String status) {
        for (RefundStatusEnum orderPayStatusEnum : RefundStatusEnum.values()) {
            if (orderPayStatusEnum.name.equals(status)) {
                return orderPayStatusEnum.getName();
            }
        }
        return null;
    }
}
