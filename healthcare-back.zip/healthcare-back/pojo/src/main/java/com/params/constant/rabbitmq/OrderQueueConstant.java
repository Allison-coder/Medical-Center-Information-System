package com.params.constant.rabbitmq;

public class OrderQueueConstant {

    public static final String QUEUE_ORDER = "queue.auth.cancel.order";

    public static final String EXCHANGE_ORDER = "exchange.auth.cancel.order";

}
