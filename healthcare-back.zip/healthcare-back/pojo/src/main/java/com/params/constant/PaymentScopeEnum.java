package com.params.constant;

public enum PaymentScopeEnum {

    // 支付登陆通用 登陆支付同一个配置
    COMM(0),
    // 仅登陆使用 登陆配置，没有则使用通用得
    LOGIN(2),
    // 仅支付使用  获取支付配置,没有则使用通用得
    PAY(1),
    //获取用户openID配置，没有则使用登陆配置获取openid
    GET_OPENID(3);
    private Integer code;

    PaymentScopeEnum(Integer code) {
        this.code = code;
    }

    public Integer code() {
        return this.code;
    }
}
