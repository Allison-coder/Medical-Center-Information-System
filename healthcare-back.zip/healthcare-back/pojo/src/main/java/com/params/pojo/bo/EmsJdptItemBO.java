package com.params.pojo.bo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/15
 */
@Getter
@Setter
public class EmsJdptItemBO implements Serializable {

    private static final long serialVersionUID = -3464045430683741928L;

    private String waybillNo;
    private Date opTime;
    private String opCode;
    private String opName;
    private String opDesc;
    private String opOrgProvName;
    private String opOrgCity;
    private String opOrgCode;
    private String opOrgName;
    private String operatorNo;
    private String operatorName;

}
