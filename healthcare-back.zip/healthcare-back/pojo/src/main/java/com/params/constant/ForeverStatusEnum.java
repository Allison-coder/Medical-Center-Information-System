package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 是否永久有效的枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum ForeverStatusEnum {

    // 0-非永久有效 1-永久有效
    CAN_BE_EXPIRE(0, "非永久有效"),
    IS_FOEREVER(1, "永久有效"),
    ;

    /**
     * 状态值
     */
    private final Integer value;
    /**
     * 状态名
     */
    private final String name;


}
