package com.params.pojo.bo;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @DESCRIPTION 操作患者的domian入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Accessors(chain = true)
public class OperateMedicalBO {


    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 操作类型
     */
    private Integer opeType;
}
