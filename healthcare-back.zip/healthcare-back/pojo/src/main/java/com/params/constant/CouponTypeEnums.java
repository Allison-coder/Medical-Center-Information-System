package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 优惠券类型枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum CouponTypeEnums {

     FREE_COUPON(0, "免费券"),
    EIGHT_DISCOUNT_COUPON(1, "8折优惠券"),
    CASH_COUPON(2, "现金券"),
    EXCHANGE_COUPON(3, "兑换券"),
    DISCOUNT_COUPON(4, "折扣券"),
    ;

    /**
     * 状态值
     */
    private final Integer value;
    /**
     * 状态名
     */
    private final String name;

    public static String translate(Integer status) {
        for (CouponTypeEnums couponTypeEnums : CouponTypeEnums.values()) {
            if (couponTypeEnums.value.equals(status)) {
                return couponTypeEnums.getName();
            }
        }
        return null;
    }

    public static CouponTypeEnums fromValue(Integer value) {
        for (CouponTypeEnums couponTypeEnums : CouponTypeEnums.values()) {
            if (couponTypeEnums.value.equals(value)) {
                return couponTypeEnums;
            }
        }
        return null;
    }

}
