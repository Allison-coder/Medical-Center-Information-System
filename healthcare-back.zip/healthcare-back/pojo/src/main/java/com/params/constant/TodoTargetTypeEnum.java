package com.params.constant;


import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum TodoTargetTypeEnum {
    SERVICE("SERVICE", "快捷服务"),
    GUIDE("GUIDE", "办事指南"),
    ;
    private final String value;
    private final String msg;

    public static boolean exists(String type) {
        if (StrUtil.isBlank(type)) return false;
        for (TodoTargetTypeEnum ele : TodoTargetTypeEnum.values()) {
            if (ele.name().equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }
}
