package com.params.pojo.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 创建渠道码的传递参数
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PromotionChannelsBO implements Serializable {

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 优惠券类型  0-免费券 1- 8折券
     */
    private Integer couponType;

    /**
     * 大标题
     */
    private String bigTitle;

    /**
     * 小标题
     */
    private String smallTitle;

    /**
     * 自动回复文本
     */
    private String autoAckContent;


}
