package com.params.constant;

import com.params.ErrorCodeEnum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IpWhiteList {


    private static List<String> ips = new ArrayList<>();
    static {
        ips.add("210.76.73.62");
        ips.add("210.76.73.7");
        ips.add("210.76.73.29");
        ips.add("210.76.73.33");
        ips.add("210.76.73.10");
        ips.add("210.76.73.44");
        ips.add("210.76.80.86");
        ips.add("210.76.80.87");
        ips.add("210.76.80.88");
        ips.add("210.76.80.89");
        ips.add("210.76.80.90");
        ips.add("210.76.80.91");
        ips.add("210.76.80.80");
        ips.add("210.76.80.81");
        ips.add("210.76.80.82");
        ips.add("210.76.80.83");
        ips.add("210.76.80.84");
        ips.add("210.76.80.85");
        ips.add("210.76.75.56");
        ips.add("210.76.75.140");
        ips.add("210.76.75.187");
        ips.add("210.76.75.57");
        ips.add("210.76.75.24");
        ips.add("210.76.75.166");
        ips.add("210.76.75.127");
        ips.add("210.76.81.192");
        ips.add("210.76.81.193");
        ips.add("210.76.81.182");
        ips.add("210.76.81.183");
        ips.add("210.76.81.184");
        ips.add("210.76.81.185");
        ips.add("210.76.81.186");
        ips.add("210.76.81.187");
        ips.add("210.76.81.188");
        ips.add("210.76.81.189");
        ips.add("210.76.81.190");
        ips.add("210.76.81.210");
        ips.add("210.76.81.211");
        ips.add("210.76.81.212");
        ips.add("210.76.81.213");
        ips.add("210.76.81.207");
        ips.add("210.76.81.206");
        ips.add("210.76.81.209");
        ips.add("210.76.81.208");

    }


    public static void check(String ip) {

        if (ips.contains(ip)){
            return;
        }
        throw new CustomException(ErrorCodeEnum.SUCCESS);

    }


}
