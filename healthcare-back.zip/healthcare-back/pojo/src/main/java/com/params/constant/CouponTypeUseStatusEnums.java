package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 优惠券使用状态的枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum CouponTypeUseStatusEnums {
    // 1-待使用 2-已使用 3-已过期
    WAIT_FOR_USE(1, "待使用"),
    IS_USE(2, "已使用"),
    IS_EXPIRE(3, "已过期"),
    ;

    /**
     * 状态值
     */
    private final Integer value;
    /**
     * 状态名
     */
    private final String name;

    public static String translate(Integer status) {
        for (CouponTypeUseStatusEnums couponTypeEnums : CouponTypeUseStatusEnums.values()) {
            if (couponTypeEnums.value.equals(status)) {
                return couponTypeEnums.getName();
            }
        }
        return null;
    }
}
