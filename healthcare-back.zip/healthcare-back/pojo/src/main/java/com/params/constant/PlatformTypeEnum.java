package com.params.constant;


import org.springframework.util.StringUtils;

public enum PlatformTypeEnum {
    CMB("招商银行"),
    ALI_APP("支付宝"),
    ALI("支付宝"),
    H5("H5"),
    WEIXIN("微信"),
    ICBC("工商银行"),
    CCB("建设银行"),
    BOC("中国银行"),
    ABC("中国农行"),
    FENGZHUSHOU("峰助手"),
    BAIDU("百度"),
    UNKOWN("未知"),
    YOUZHENG("邮政"),
    ZIZAISHEQU("自在社区"),
    TRAVEL("中旅"),
    DIAN_GOU("点购商城"),
    WEI_LAI("未来科技"),
    PING_AN_APP("平安小程序"),
    CEB_H5("光大银行"),
    RCU_H5("农信银行"),
    DEFAULT_H5("通用H5"),
    YBB_H5("云宝宝"),
    YSH_APP("云闪付"),
    YSS_APP("粤省事小程序"),

    ;
    private String value;

    PlatformTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if (StringUtils.isEmpty(type)) {
            return false;
        }
        for (PlatformTypeEnum ele : PlatformTypeEnum.values()) {
            if (ele.toString().equals(type)) {
                return true;
            }
        }
        return false;
    }

    public static String translate(String name) {
        for (PlatformTypeEnum platformTypeEnum : PlatformTypeEnum.values()) {
            if (platformTypeEnum.name().equalsIgnoreCase(name)) {
                return platformTypeEnum.getValue();
            }
        }
        return null;
    }
}
