package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * @DESCRIPTION 批量设置排班的bo
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Accessors(chain = true)
public class BatchAddScheduleBO implements Serializable {

    @ApiModelProperty(value = "人员id")
    private Integer adminId;

    @ApiModelProperty(value = "月份")
    private String currentMonth;

    @ApiModelProperty(value = "周的数组集合",example = "[周一，周二，周三，周四，周五，周六，周日]")
    private List<String> daysOfWeek;

    @ApiModelProperty(value = "开始时间")
    private String startTimeStr;

    @ApiModelProperty(value = "结束时间")
    private String endTimeStr;
}
