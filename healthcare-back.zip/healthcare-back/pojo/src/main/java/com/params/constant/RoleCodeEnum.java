package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 角色标识枚举
 */
@Getter
@AllArgsConstructor
public enum RoleCodeEnum {

    SUPER_ADMINISTRATOR("SUPER_ADMINISTRATOR"), // 超级管理员
    ADMINISTRATOR("ADMINISTRATOR"), // 管理员
    DOCTOR("DOCTOR"), // 医生
    NURSE("NURSE"), // 护士
    HEAL("HEAL"), // 治疗师
    ;

    /**
     * 角色编码
     */
    private final String key;

}
