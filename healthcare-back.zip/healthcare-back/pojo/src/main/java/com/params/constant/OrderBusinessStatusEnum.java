package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 订单业务节点状态枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum OrderBusinessStatusEnum {
    WAITING_PAY(0, "待支付"),
    WAIT_BOOK(2, "待预约"),
    WAIT_CHECK_IN(3, "待报到"),
    WAITING_FOR_CALL(4, "等待叫号"),
    THERAPY(5, "治疗中"),
    FINISH(6, "完成"),
    CANCEL(7, "已取消"),
    REFUND(8, "已退款");
    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (OrderBusinessStatusEnum orderBusinessStatusEnum : OrderBusinessStatusEnum.values()) {
            if (orderBusinessStatusEnum.code.equals(code)) {
                return orderBusinessStatusEnum.getValue();
            }
        }
        return null;
    }
}
