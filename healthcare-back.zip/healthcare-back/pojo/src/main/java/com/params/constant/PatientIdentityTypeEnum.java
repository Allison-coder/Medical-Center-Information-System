package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 患者身份类别枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum PatientIdentityTypeEnum {

    ADULT(0, "成人"),
    JUVENILES(1, "未成年人");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (PatientIdentityTypeEnum patientIdentityTypeEnum : PatientIdentityTypeEnum.values()) {
            if (patientIdentityTypeEnum.code.equals(code)) {
                return patientIdentityTypeEnum.getValue();
            }
        }
        return null;
    }
}
