package com.params.constant.rabbitmq;

public class SmsQueueConstant {

    /**
     * 队列名称
     * - 短信通知延迟队列
     */
    public static final String QUEUE_SMS_DELAYED = "queue.delayed.message.healthcare.smsNotice";

    /**
     * 交换机名称
     * - 短信通知延迟交换机
     */
    public static final String EXCHANGE_SMS_DELAYED = "exchange.delayed.message.healthcare.smsNotice";

}
