package com.params.constant;

import org.springframework.util.StringUtils;

public enum WxMsgTypeEnum {

    COMMON_MSG("普通消息"),
//    AFTER_COUPON("派券成功"),
//    NOT_REPLY("关注后没有回复"),
//    NOT_BUY_AFTER_REPLY("回复后没有购买套餐"),
//    AFTER_REPLY_NOT_QUEUE("回复“免费”后，3分钟内没有排队"),
//    AFTER_QUEUE_NOT_BUY("排队完成后，30分钟内没有购买"),
//    NOT_ACTIVATION_LIFE_INTEREST("购买套餐后没有激活"),
;

    public final String value;
    WxMsgTypeEnum(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if(StringUtils.isEmpty(type)){
            return false;
        }
        for (WxMsgTypeEnum ele : WxMsgTypeEnum.values()) {
            if (ele.toString().equals(type) ) {
                return true;
            }
        }
        return false;
    }

    public static String transfor(String status) {
        if (status == null) {
            return "";
        }
        WxMsgTypeEnum[] orderStatusEnums = WxMsgTypeEnum.values();
        for (int i = 0, size = orderStatusEnums.length; i < size; i++) {
            if (orderStatusEnums[i].name().equals(status)) {
                return orderStatusEnums[i].getValue();
            }
        }
        return "";
    }

}
