package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 患者婚姻状态枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum PatientMaritalStatusEnum {
    UN_MARRIED(1, "未婚"),
    MARRIED(2, "已婚"),
    DIVORCE(3, "离异");
    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (PatientMaritalStatusEnum patientIdentityType : PatientMaritalStatusEnum.values()) {
            if (patientIdentityType.code.equals(code)) {
                return patientIdentityType.getValue();
            }
        }
        return null;
    }
}
