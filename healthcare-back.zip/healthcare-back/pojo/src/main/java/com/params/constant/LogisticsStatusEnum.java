package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/8
 */
@Getter
@AllArgsConstructor
public enum LogisticsStatusEnum {

    NOT_PAYMENT(0, "无需物流"),
    WAIT_SHIPMENT(1, "等待发货"),
    STOP_SHIPMENT(2, "暂停发货"),
    ALREADY_SHIPMENT(3, "已发货"),
    DELIVERED(4, "已送达"),
    REJECTED(5, "已拒收"),
//    CLOSED(9, "已关闭"),
    ;

    /**
     * 状态值
     */
    private final Integer value;
    /**
     * 状态名
     */
    private final String name;

    public static String translate(Integer status) {
        for (LogisticsStatusEnum logisticsStatusEnum : LogisticsStatusEnum.values()) {
            if (logisticsStatusEnum.value.equals(status)) {
                return logisticsStatusEnum.getName();
            }
        }
        return null;
    }
}
