package com.params.constant.rabbitmq;

/**
 * @DESCRIPTION 任务日志队列的常量
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
public class RabbitTaskLogConstant {

    public static final String QUEUE_TASK_LOG = "queue.message.healthcare.taskLog";

    public static final String EXCHANGE_TASK_LOG = "exchange.message.healthcare.taskLog";
}
