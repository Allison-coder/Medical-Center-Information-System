package com.params.constant;

import com.params.component.oss.OssGenerate;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface OssConstants {

    OssGenerate DEFAULT = new OssGenerate("cms/upload");
}
