package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public class SysAuthCacheKey extends AbstractCacheKey {

    private SysAuthCacheKey() {
    }

    private SysAuthCacheKey(String prefix) {
        super(prefix);
    }

    private SysAuthCacheKey(String prefix, long expireSeconds) {
        super(prefix, expireSeconds);
    }

    private SysAuthCacheKey(String prefix, long timeout, TimeUnit unit) {
        super(prefix, timeout, unit);
    }

    public static SysAuthCacheKey AUTH_CACHE_KEY = new SysAuthCacheKey("healthcare:auth:{}:{}");

    public static SysAuthCacheKey AUTH_BACKEND_CACHE_KEY = new SysAuthCacheKey("healthcare:auth:backend:{}", 12, TimeUnit.HOURS);
    public static SysAuthCacheKey AUTH_BACKEND_TOKEN_CACHE_KEY = new SysAuthCacheKey("healthcare:auth:backend_user:{}", 12, TimeUnit.HOURS);

}