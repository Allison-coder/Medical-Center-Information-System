package com.params.constant.errorcode;

import com.params.framework.exception.ErrorCode;

/**
 * <pre>
 * 错误码枚举类
 * 文章使用 1-001-000-000 段
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface UserErrorCodeConstants {

    // ========== 用户模块 ==========
    ErrorCode USER_NOT_AUTH = new ErrorCode(1001001, "用户未授权登录");
    ErrorCode IMAGE_CODE_NOT_EXISTS = new ErrorCode(1001002, "图像验证码不能为空");
    ErrorCode IMAGE_CODE_ERROR = new ErrorCode(1001003, "图形验证码校验错误");
    ErrorCode TEXT_CODE_ERROR = new ErrorCode(1001004, "验证码校验错误");

    ErrorCode RE_GET_CODE = new ErrorCode(1001005, "请重新获取验证码");
    ErrorCode ACCOUNT_IS_FROZEN = new ErrorCode(1001006, "账号已被冻结，请联系客服");
    ErrorCode ACCOUNT_GET_MSG_OVER = new ErrorCode(1001013, "该手机号当天获取验证码次数已达上限");

    ErrorCode ACCOUNT_IP_GET_MSG_OVER = new ErrorCode(1001014, "当天获取验证码次数已达上限");
    ErrorCode PHONE_ERROR = new ErrorCode(1001007, "手机号码格式错误");
    ErrorCode USER_VERIFY_CODE_SEND_FREQUENTLY = new ErrorCode(1001008, "验证码已发送，请勿频繁发送");
    ErrorCode USER_GET_USER_ERR = new ErrorCode(1001009, "获取用户信息异常");
    ErrorCode INVALID_LOGIN_SOURCE = new ErrorCode(1001010, "获取用户信息异常");
    ErrorCode INVALID_LOGIN_AUTH = new ErrorCode(1001011, "登陆权限异常");
    ErrorCode INVALID_LOGIN_TOKEN_AUTH = new ErrorCode(1001012, "登陆已失效");


}
