package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/8
 */
@Getter
@AllArgsConstructor
public enum RefundTypeEnum {

    RETURN_REFUND(1, "退货退款"),
    REFUND(2, "退款"),
    ;

    /**
     * 状态值
     */
    private final Integer value;
    /**
     * 状态名
     */
    private final String name;

    public static String translate(Integer status) {
        for (RefundTypeEnum refundTypeEnum : RefundTypeEnum.values()) {
            if (refundTypeEnum.value.equals(status)) {
                return refundTypeEnum.getName();
            }
        }
        return null;
    }
}
