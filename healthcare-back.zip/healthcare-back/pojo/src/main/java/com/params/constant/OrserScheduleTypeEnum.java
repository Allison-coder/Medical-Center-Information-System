package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 治疗单的预约类型
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum OrserScheduleTypeEnum {

    PLAN(2,  "治疗方案"),
    PROJECT(3,  "项目");

    private final Integer code;
    private final String value;
}
