package com.params.constant.errorcode;

import com.params.framework.exception.ErrorCode;

/**
 * <pre>
 * 错误码枚举类
 * 文章使用 1-001-000-000 段
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface OrderErrorCodeConstants {

    ErrorCode ORDER_NOT_EXISTENT = new ErrorCode(1002000, "订单不存在");
    ErrorCode ORDER_NOT_AUTH = new ErrorCode(1002001, "该订单无权限访问");
    ErrorCode ORDER_PAY_FAIL = new ErrorCode(1002002, "订单支付失败");
    ErrorCode ORDER_STATUS_ERR = new ErrorCode(1002003, "订单当前状态不允许操作");
    ErrorCode ORDER_BIND_ERR = new ErrorCode(1002004, "订单绑定失败，请稍后重试");
    ErrorCode ORDER_REPEAT_BIND_ERR = new ErrorCode(1002005, "订单请勿重复绑定");
    ErrorCode ORDER_REFUND_RECORD_NOT_EXISTENT = new ErrorCode(1003000, "退款记录不存在");
    ErrorCode ORDER_REFUND_RECORD_SENDBACK_EXISTS = new ErrorCode(1003001, "寄回信息已填写不允许操作");
    ErrorCode ORDER_REFUND_RECORD_REFUNDTYPE_ERROR = new ErrorCode(1003002, "仅退款不需要填写寄回信息");
    ErrorCode ORDER_INVOICE_IS_APPLY = new ErrorCode(1003003, "您已提交开发票申请，如需退款请联系客服处理");


}
