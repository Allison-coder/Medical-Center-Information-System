package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @DESCRIPTION 绑定优惠券和订单的bo
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class BindOrderAndCouponBO {


    @ApiModelProperty(value = "是否使用优惠券 false-不使用 true-使用")
    private Boolean isUseCoupon;

    @ApiModelProperty(value = "优惠券码 面诊单的参数")
    private String couponCode;

    @ApiModelProperty(value = "订单编码 面诊单的参数")
    private String orderSn;

    @ApiModelProperty(value = "项目id  治疗单才有")
    private Integer projectId;



}
