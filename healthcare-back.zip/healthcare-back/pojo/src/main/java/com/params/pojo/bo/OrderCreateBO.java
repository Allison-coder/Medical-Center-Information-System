package com.params.pojo.bo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderCreateBO {
    /**
     * 患者Id
     */
    private String patientSn;

    /**
     * 排班ID
     */
    private Integer scheduleDetailId;

    /**
     * 工作人员ID（医生、治疗师等）
     */
    private Integer adminId;

    /**
     * 订单类型：GH-挂号、ZL-治疗
     */
    private String orderType;

    /**
     * 挂号订单编号，当订单类型为治疗时使用  获取到的患者资料中的orderSn
     */
    private String parentOrderSn;

    /**
     * 处置方案Id 当订单类型为治疗时使用
     */
    private Integer planId;
    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 是否使用优惠券 false-不使用 true-使用
     */
    private Boolean isUseCoupon;

    /**
     * 优惠券码
     */
    private String couponCode;

    /**
     * 渠道id、诊所id
     */
    private Integer channelId;
}
