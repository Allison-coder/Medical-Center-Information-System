package com.params.constant;


import cn.hutool.core.util.StrUtil;
import com.params.ErrorCodeEnum;
import com.params.framework.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ValidateUtil {

    public static void isEmpty(boolean expression, String errorMessage) {
        if (expression) {
            throw new IllegalStateException(errorMessage);
        }
    }

    public static void isTrue(boolean expression, String errorMessage) {
        if (expression) {
            throw new ServiceException(ErrorCodeEnum.ERROR_REQUEST.code(), errorMessage);
        }
    }


    public static void isTrue(boolean expression, ErrorCodeEnum errorCodeEnum) {
        if (expression) {
            throw new ServiceException(errorCodeEnum.msg());
        }
    }

    /**
     * 期望参数为True ,false报错
     */
    public static void expectArgument(boolean expression, String message) {
        if (!expression) {
            throw new ServiceException(ErrorCodeEnum.ILLEGAL_PARAM.msg());
        }
    }

    /**
     * 不期望参数为True 则通过校验，即false通过校验
     */
    public static void notExpectArgument(boolean expression, String message) {
        if (expression) {
            throw new ServiceException(ErrorCodeEnum.ILLEGAL_PARAM.code(), message);
        }
    }

    public static void notExpectArgument(boolean expression, ErrorCodeEnum errorCodeEnum, String message) {
        if (expression) {
            throw new ServiceException(errorCodeEnum.code(), message);
        }
    }

    public static void notExpectArgument(boolean expression, ErrorCodeEnum errorCodeEnum) {
        if (expression) {
            throw new ServiceException(errorCodeEnum.msg());
        }
    }

    public static void expectArgument(boolean expression, String template, Object... args) {
        if (!expression) {
            throw new ServiceException(ErrorCodeEnum.ILLEGAL_PARAM.code(), StrUtil.format(template, args));
        }
    }

    public static void notExpectArgument(boolean expression, String template, Object... args) {
        if (!expression) {
            throw new ServiceException(ErrorCodeEnum.ILLEGAL_PARAM.code(), StrUtil.format(template, args));
        }
    }

    public static void isTrue(boolean expression, ErrorCodeEnum errorCodeEnum, String message) {
        if (expression) {
            throw new ServiceException(errorCodeEnum.code(), message);
        }
    }

    public static void isTrue(boolean expression, ErrorCodeEnum errorCodeEnum, String template, Object... args) {
        if (expression) {
            throw new ServiceException(errorCodeEnum.code(), StrUtil.format(template, args));
        }
    }


}
