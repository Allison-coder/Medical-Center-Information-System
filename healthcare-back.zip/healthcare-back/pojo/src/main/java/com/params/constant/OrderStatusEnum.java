package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *  订单的支付状态枚举
 * </pre>
 *
 * @version 1.0.0
 * @Create 2022/12/8
 */
@Getter
@AllArgsConstructor
public enum OrderStatusEnum {
     // 0：待支付 1：已支付   2：已取消   3：退款中 4：已退款 默认未支付

    WAITING_PAY(0, "待支付"),
    IS_PAY(1, "已支付"),
    CANCEL(2, "已取消"),
    REFUNDING(3, "退款中"),
    REFUND(4, "已退款");

    private final Integer code;
    private final String value;


    public static String translate(Integer code) {
        for (OrderStatusEnum orderStatusEnum : OrderStatusEnum.values()) {
            if (orderStatusEnum.code.equals(code)) {
                return orderStatusEnum.getValue();
            }
        }
        return null;
    }
}
