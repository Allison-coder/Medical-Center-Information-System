package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 处置方案的进度枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Getter
@AllArgsConstructor
public enum TreatPlanBaseSpeedStatusEnum {

    DOING(1, "进行中"),
    DONE(2, "已结束");

    private final Integer code;
    private final String value;



    public static TreatPlanBaseSpeedStatusEnum fromCode(Integer code) {
        for (TreatPlanBaseSpeedStatusEnum status : values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        return null;
    }

}
