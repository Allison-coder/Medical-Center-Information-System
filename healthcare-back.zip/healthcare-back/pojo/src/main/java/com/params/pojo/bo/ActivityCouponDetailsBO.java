package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class ActivityCouponDetailsBO {

    /* id、优惠券类型、券名称、优惠金额、使用门槛、有效期日期、有效期时间、是否长期有效、使用说明、兑换订单、优惠折扣 */
    @ApiModelProperty(value = "id  修改-删除时使用")
    private Integer id;

    @ApiModelProperty(value = "优惠券类型 ")
    private Integer couponType;

    @ApiModelProperty(value = "优惠券类型名称")
    private String couponTypeName;

    @ApiModelProperty(value = "券名称")
    private String couponName;

    @ApiModelProperty(value = " 现金券 优惠金额")
    private String couponParValue;

    @ApiModelProperty(value = " 折扣券 优惠折扣")
    private String discount;

    @ApiModelProperty(value = "兑换项目 1-面诊  2-治疗")
    private Integer exchangeOrder;

    @ApiModelProperty(value = "可用项目 1-面诊  2-治疗")
    private List<Integer> availableProject;

    @ApiModelProperty(value = "项目id列表，可用项目为 2 时 必填 如果选的全部 传 0",example = "多个选择-[1,2]，全部-[0]")
    private List<Integer> projectId;

    @ApiModelProperty(value = "是否无门槛 0-无门槛 1- 有 ")
    private Integer thresholdNo;

    @ApiModelProperty(value = "有使用门槛时的可使用金额")
    private String orderUseAmount;

    @ApiModelProperty(value = "是否永久有效 0-否 1-是")
    private Integer foreverStatus;

    @ApiModelProperty(value = "结束日期 永久有效为否时才会有")
    private String expireDate;

    @ApiModelProperty(value = "使用说明")
    private String instructions;
}
