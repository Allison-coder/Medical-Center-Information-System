package com.params.pojo.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * 修改账号的BO
 */
@Data
public class EditAdminUserBO implements Serializable {


    /**
     * 账号的 id
     */
    private Integer adminId;

    /**
     * 密码
     */
    private String password;

    /**
     * 挂号数
     */
    private Integer registrationCount;

    /**
     * 工号
     */
    private String employeeId;


}
