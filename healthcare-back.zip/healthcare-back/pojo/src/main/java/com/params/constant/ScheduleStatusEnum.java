package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 排班状态
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum ScheduleStatusEnum {

    WORK(0, "未请假"),
    FOR_LEAVE(1, "请假");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (ScheduleStatusEnum patientIdentityType : ScheduleStatusEnum.values()) {
            if (patientIdentityType.code.equals(code)) {
                return patientIdentityType.getValue();
            }
        }
        return null;
    }
}
