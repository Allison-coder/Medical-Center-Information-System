package com.params.constant;


/**
 * Created by dzl on 2018/11/7
 **/
public enum ExpressBusinessEnum {
    YZ_PACKAGE("YZ_PACKAGE", "邮政小包"),
    YZ_EMS_ECON("YZ_EMS_ECON", "邮政EMS经济快递"),
    YZ_EMS("YZ_EMS", "邮政EMS"),
    ST_EXPRESS("ST_EXPRESS", "申通快递"),
    YT_EXPRESS("YT_EXPRESS", "圆通速递"),
    SF_CITY_EXPRESS("SF_CITY_EXPRESS", "顺丰同城急送"),
    SF_DAY_EXPRESS("SF_DAY_EXPRESS", "顺丰即日"),
    SY_NEXT_MORNING("SY_NEXT_MORNING", "顺丰次晨"),
    SF_NORMAL("SF_NORMAL", "顺丰标快"),
    SF_DISCOUNT("SF_DISCOUNT", "顺丰特惠"),
    SF_ORDINARY("SF_ORDINARY", "顺丰物流普运")
    ;

    private String code;
    private String value;

    ExpressBusinessEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }
}