package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @DESCRIPTION 工作面板查预约情况的 BO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Accessors(chain = true)
public class PatientSchedulesBO implements Serializable {

    /**
     * 用户id
     */
    private Integer adminId;

    /**
     * 预约类型
     */
    private Integer type;

    /**
     * 日期
     */
    private String dataStr;
}