package com.params.pojo.bo;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
public class LoginInfoBO {
    /**
     * 用户Id
     */
    private Integer userId;

    /**
     * 用户表唯一code
     */
    private String uniqueCode;

    /**
     * 平台唯一code
     */
    private String memberUniqueId;
    /**
     * 主用户表Id
     */
    private Integer memberId;
    /**
     * 当前登陆得渠道
     */
    private Integer currentLoginMerchantId;
    /**
     * 手机号
     */
    private String mobile;


}
