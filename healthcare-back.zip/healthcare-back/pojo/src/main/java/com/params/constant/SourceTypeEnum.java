package com.params.constant;

import cn.hutool.core.util.StrUtil;
import org.springframework.util.StringUtils;

public enum SourceTypeEnum {
    DEFAULT("默认"),
    CMB_H5("招行APP"),
    ALI_H5("支付报H5"),
    WEIXIN_H5("微信H5"),
    WEIXIN("微信"),
    ALI("支付宝"),
    H5("浏览器H5"),
    ICBC_H5("工行H5"),
    HZ_ICBC_H5("工行H5"),
    WEIXIN_APP("微信小程序"),
    HEALTH_ADMIN("医疗管理后台"),
    ALI_APP("支付宝小程序"),
    CCB_H5("建设银行H5"),
    BOC_H5("中国银行H5"),
    ABC_H5("农业银行H5"),

    FENGZHUSHOU_APP("蜂助手App"),
    ZIZAISHEQU_APP("自在社区App"),
    BAIDU_APP("百度小程序"),
    UNKOWN("未知"),
    YOUZHENG_H5("邮政H5"),
    TRAVEL_H5("中旅"),
    DIAN_GOU_H5("点购商城H5"),
    WEI_LAI_H5("未来科技H5"),
    RCU_H5_PAY("农信银行"),
    PING_AN_APP("平安小程序"),
    DEFAULT_H5("未来科技H5"),
    YSF_APP("云闪付"),
    ALI_YSS_APP("粤省事-南粤-支付宝"),

    WECHAT_YSS_APP("粤省事-南粤-微信"),
    YSS_APP("粤省事"),
    ;
    private String value;

    SourceTypeEnum(String value) {

    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if (StringUtils.isEmpty(type)) {
            return false;
        }
        for (SourceTypeEnum ele : SourceTypeEnum.values()) {
            if (ele.toString().equals(type)) {
                return true;
            }
        }
        return false;
    }

    public static SourceTypeEnum transfor(String sourceType) {
        for (SourceTypeEnum ele : SourceTypeEnum.values()) {
            if (ele.toString().equals(sourceType)) {
                return ele;
            }
        }
        return UNKOWN;
    }

    public PlatformTypeEnum toPlatform() {
        if (StrUtil.equalsAny(this.name(), ALI_APP.name(), ALI_H5.name())) {
            return PlatformTypeEnum.ALI_APP;
        }
        if (StrUtil.equalsAny(this.name(), WEIXIN_H5.name(), WEIXIN_APP.name())) {
            return PlatformTypeEnum.ALI_APP;
        }
        if (StrUtil.equalsAny(this.name(), CMB_H5.name())) {
            return PlatformTypeEnum.CMB;
        }
        if (StrUtil.equalsAny(this.name(), ICBC_H5.name())) {
            return PlatformTypeEnum.ICBC;
        }
        if (StrUtil.equalsAny(this.name(), BOC_H5.name())) {
            return PlatformTypeEnum.BOC;
        }
        if (StrUtil.equalsAny(this.name(), FENGZHUSHOU_APP.name())) {
            return PlatformTypeEnum.FENGZHUSHOU;
        }
        if (StrUtil.equalsAny(this.name(), BAIDU_APP.name())) {
            return PlatformTypeEnum.BAIDU;
        }
        return PlatformTypeEnum.UNKOWN;
    }


}

