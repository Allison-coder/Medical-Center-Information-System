package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 首页展示状态的枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum HomepageDisplayEnum {

    ON_DISABLE(0, "隐藏"),
    ON_ENABLE(1, "展示");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (HomepageDisplayEnum homepageDisplayEnum : HomepageDisplayEnum.values()) {
            if (homepageDisplayEnum.code.equals(code)) {
                return homepageDisplayEnum.getValue();
            }
        }
        return null;
    }
}
