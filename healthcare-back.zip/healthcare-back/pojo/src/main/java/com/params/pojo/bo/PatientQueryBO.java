package com.params.pojo.bo;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Accessors(chain = true)
public class PatientQueryBO implements Serializable {

    /**
     * 患者姓名
     */
    private String name;


    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 页大小
     */
    private Integer pageSize = 10;

    /**
     * 页码
     */
    private Integer pageNum = 1;
}
