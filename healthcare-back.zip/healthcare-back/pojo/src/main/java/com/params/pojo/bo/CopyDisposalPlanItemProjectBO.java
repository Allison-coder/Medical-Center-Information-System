package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 复用项目的保存BO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class CopyDisposalPlanItemProjectBO implements Serializable {


    @ApiModelProperty(value = "下拉框所选的项目的id")
    private Integer itemId;

    @ApiModelProperty(value = "次数层数据的id")
    private Integer planId;

    @ApiModelProperty(value = "单次价格（RMB） 单位：元  不使用的时候传空")
    private String priceHour;

    @ApiModelProperty(value = "优惠价格（RMB） 单位：元 不使用的时候传空  填写价格的项目用这个字段")
    private String preferentialPrice;


    private Integer clinicId;

    private String operator;


}
