package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 */
public class LuckyConfigCacheKey extends AbstractCacheKey {

    private LuckyConfigCacheKey() {
    }

    private LuckyConfigCacheKey(String prefix) {
        super(prefix);
    }

    private LuckyConfigCacheKey(String prefix, long expireSeconds) {
        super(prefix, expireSeconds);
    }

    private LuckyConfigCacheKey(String prefix, long timeout, TimeUnit unit) {
        super(prefix, timeout, unit);
    }

    /**
     * channelId:config_code:language:city_id:exam_code
     */
    public static LuckyConfigCacheKey CONFIG_CACHE_KEY = new LuckyConfigCacheKey("healthcare:config:{}:{}:{}:{}:{}");

    public static LuckyConfigCacheKey CONFIG_DEL_CACHE_KEY = new LuckyConfigCacheKey("healthcare:config:*:{}:*");

    public static LuckyConfigCacheKey CONFIG_BUILD_CACHE_KEY = new LuckyConfigCacheKey("healthcare:config_build:{}:{}:{}");

    public static LuckyConfigCacheKey HOMEPAGE_BUILD_CACHE_KEY = new LuckyConfigCacheKey("healthcare:config_build:{}:{}:{}:{}:{}", 1, TimeUnit.HOURS);

    public static LuckyConfigCacheKey HOMEPAGE_DEL_BUILD_CACHE_KEY = new LuckyConfigCacheKey("healthcare:config_build:{}:*");

    public static LuckyConfigCacheKey CHANNEL_CACHE_KEY = new LuckyConfigCacheKey("healthcare:config_build:COMMON:{}");

}
