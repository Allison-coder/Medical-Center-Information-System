package com.params.pojo.bo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/15
 */
@Getter
@Setter
public class EmsJdptBO implements Serializable {
    private static final long serialVersionUID = -3822735813502366386L;

    private String code;
    private String message;

    private List<EmsJdptItemBO> body;
}
