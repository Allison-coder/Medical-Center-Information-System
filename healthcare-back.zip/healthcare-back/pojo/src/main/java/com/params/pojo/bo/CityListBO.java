package com.params.pojo.bo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by dzl on 2018/11/29
 **/
@Getter
@Setter
public class CityListBO implements Serializable {
    private static final long serialVersionUID = -549714614813506939L;
    private Integer cityId;
    private Integer cityTempId;
    private String code;
    private Integer hotable;
    private String name;
    private Integer parentId;
    private String type;
    private Integer certificationInfoId;
    private BigDecimal longitude;
    private BigDecimal latitude;
    private String pinyin;
    private String fullFight;
}
