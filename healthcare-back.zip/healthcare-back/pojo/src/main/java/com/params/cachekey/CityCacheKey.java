package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * @version 1.0.0
 */
public class CityCacheKey extends AbstractCacheKey {

    private CityCacheKey() {
    }

    private CityCacheKey(String prefix) {
        super(prefix);
    }

    private CityCacheKey(String prefix, long expireSeconds) {
        super(prefix, expireSeconds);
    }

    private CityCacheKey(String prefix, long timeout, TimeUnit unit) {
        super(prefix, timeout, unit);
    }

    public static CityCacheKey CITIES_CACHE_KEY = new CityCacheKey("healthcare:city:lists");

}
