package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 排班状态枚举
 *
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum ScheduleTypeEnum {

    OUT_CALL(1, " 出诊", "角色为医生时"),
    WORK(2, "上班", "角色为护士时"),
    RESERVATION(3, "可预约", "角色为治疗师时"),
    FOR_LEAVE(4, "请假", "所有角色可用");

    private Integer code;
    private String value;
    private String doc;

    public static String translate(Integer code) {
        for (ScheduleTypeEnum orderPayStatusEnum : ScheduleTypeEnum.values()) {
            if (orderPayStatusEnum.code.equals(code)) {
                return orderPayStatusEnum.getValue();
            }
        }
        return null;
    }
}
