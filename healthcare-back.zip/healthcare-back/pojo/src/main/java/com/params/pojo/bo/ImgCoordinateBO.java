package com.params.pojo.bo;

import lombok.Data;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class ImgCoordinateBO{
    private Double x;
    private Double y;
}
