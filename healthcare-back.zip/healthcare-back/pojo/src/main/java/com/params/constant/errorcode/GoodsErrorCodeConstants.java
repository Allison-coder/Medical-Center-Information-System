package com.params.constant.errorcode;

import com.params.framework.exception.ErrorCode;

/**
 * <pre>
 * 错误码枚举类
 * 文章使用 1-001-000-000 段
 *
 * </pre>
 *
 *
 * @version 1.0.0
 */
public interface GoodsErrorCodeConstants {

    ErrorCode GOODS_NOT_EXISTENT = new ErrorCode(1003000, "商品不存在");


}
