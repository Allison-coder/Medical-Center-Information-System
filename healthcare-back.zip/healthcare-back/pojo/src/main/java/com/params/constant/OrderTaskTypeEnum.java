package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 订单对应的任务类型
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum OrderTaskTypeEnum {

    DOCTOR_DIAGNOSIS(1, "GH", "医生面诊"),
    THERAPY_PLAN(2, "ZL", "方案治疗"),
    THERAPY_PROJECT(3, "PJ", "项目治疗"),
    ;

    private final Integer code;
    private final String type;
    private final String value;

    public static String translate(Integer code) {
        for (OrderTaskTypeEnum orderTypeEnum : OrderTaskTypeEnum.values()) {
            if (orderTypeEnum.code.equals(code)) {
                return orderTypeEnum.getValue();
            }
        }
        return null;
    }
    public static Integer getEnumCode(String typeStr) {
        for (OrderTaskTypeEnum orderTypeEnum : OrderTaskTypeEnum.values()) {
            if (orderTypeEnum.type.equals(typeStr)) {
                return orderTypeEnum.getCode();
            }
        }
        return null;
    }
    public static OrderTaskTypeEnum getEnum(Integer code) {
        for (OrderTaskTypeEnum orderTypeEnum : OrderTaskTypeEnum.values()) {
            if (orderTypeEnum.code.equals(code)) {
                return orderTypeEnum;
            }
        }
        return null;
    }

}
