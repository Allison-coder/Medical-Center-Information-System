package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.util.StringUtils;

@Getter
@AllArgsConstructor
public enum VerifyCodeEnum {

    BOUND_MOBILE("绑定手机号"),
    REGISTER("注册"),
    MOBILE_LOGIN("手机号登陆"),
    RECOVER_ORDER("找回手机号"),
    UPLOAD_IMG("上传照片"),
    SPECIAL_STAFF("特权员工"),
    ;

    public final String value;

    public static boolean exists(String type) {
        if (StringUtils.isEmpty(type)) {
            return false;
        }
        for (VerifyCodeEnum ele : VerifyCodeEnum.values()) {
            if (ele.toString().equals(type)) {
                return true;
            }
        }
        return false;
    }
}
