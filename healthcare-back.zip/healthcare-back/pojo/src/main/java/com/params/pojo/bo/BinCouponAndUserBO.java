package com.params.pojo.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 绑定用户和优惠券码的 BO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class BinCouponAndUserBO implements Serializable {

    /**
     * 优惠券码
     */
    private String couponCode;

    /**
     * 用户名
     */
    private String userName;
}
