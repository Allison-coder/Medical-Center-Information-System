package com.params.constant.rabbitmq;

public class WxRefundConstant {
    public static final String QUEUE_REFUND = "queue.message.wx.refund";

    public static final String EXCHANGE_REFUND = "exchange.message.wx.refund";

}
