package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 订单的类型枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum OrderTypeEnum {

    DIAGNOSIS(1, "GH", "面诊单"),
    THERAPY(2, "ZL", "治疗单");

    private final Integer code;
    private final String type;
    private final String value;

    public static String translate(Integer code) {
        for (OrderTypeEnum orderTypeEnum : OrderTypeEnum.values()) {
            if (orderTypeEnum.code.equals(code)) {
                return orderTypeEnum.getValue();
            }
        }
        return null;
    }
    public static Integer getEnumCode(String typeStr) {
        for (OrderTypeEnum orderTypeEnum : OrderTypeEnum.values()) {
            if (orderTypeEnum.type.equals(typeStr)) {
                return orderTypeEnum.getCode();
            }
        }
        return null;
    }
    public static OrderTypeEnum getEnum(Integer code) {
        for (OrderTypeEnum orderTypeEnum : OrderTypeEnum.values()) {
            if (orderTypeEnum.code.equals(code)) {
                return orderTypeEnum;
            }
        }
        return null;
    }

}
