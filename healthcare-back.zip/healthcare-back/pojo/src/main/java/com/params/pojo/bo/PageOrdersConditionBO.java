package com.params.pojo.bo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 查找订单的条件
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Builder
@AllArgsConstructor
public class PageOrdersConditionBO  implements Serializable {


    /**
     * 患者编号
     */
    private String patientSn;

    /**
     * 任务状态
     */
    private Integer  taskStatus;
}
