package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * </pre>
 *
 * @version 1.0.0
 * @Create 2022/12/8
 */
@Getter
@AllArgsConstructor
public enum OrderStatusEnum_bak {

    WAITING_PAY("WAITING_PAY", "等待支付"),
    IS_PAY("IS_PAY", "支付成功"),
    REFUNDING("REFUNDING", "退款中"),
    REFUND("REFUND", "退款成功"),
    CLOSE("CLOSE", "已取消"),

    CANCEL("CANCEL","撤销退款"),
    PARTIAL_REFUNDING("PARTIAL_REFUNDING","部分退款中"),
    PARTIAL_REFUND("PARTIAL_REFUND","部分已退款"),
    ;

    private final String value;
    private final String name;

    public static String translate(String status) {
        for (OrderStatusEnum_bak orderPayStatusEnum : OrderStatusEnum_bak.values()) {
            if (orderPayStatusEnum.value.equals(status)) {
                return orderPayStatusEnum.getName();
            }
        }
        return null;
    }
}
