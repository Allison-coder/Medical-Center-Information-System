
package com.params.constant;



import com.params.ErrorCodeEnum;

import java.util.Map;
import java.util.TreeMap;

public class CustomException extends RuntimeException {

    /**
     * 异常码
     */
    protected int code;
    protected String message;
    protected String enumName;
    protected Object data;

    private Map<String, String> additionalInformation = new TreeMap<String, String>();

    private static final long serialVersionUID = 3160241586346324994L;

    public CustomException(Throwable cause) {
        super(cause);
        this.code = ErrorCodeEnum.SERVER_ERROR.code();
        this.message = ErrorCodeEnum.SERVER_ERROR.msg();
        this.enumName = ErrorCodeEnum.SERVER_ERROR.name();
    }

    public CustomException(String message) {
        super(message);
        this.code = ErrorCodeEnum.SERVER_ERROR.code();
        this.message = message;
        this.enumName = ErrorCodeEnum.SERVER_ERROR.name();
    }

    public CustomException(String message, Throwable cause) {
        super(message, cause);
        this.code = ErrorCodeEnum.SERVER_ERROR.code();
        this.message = message;
        this.enumName = ErrorCodeEnum.SERVER_ERROR.name();
    }

    public CustomException(int code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }


    public CustomException(ErrorCodeEnum codeEnum, Throwable cause) {
        super(cause);
        this.code = codeEnum.code();
        this.message = codeEnum.msg();
        this.enumName = codeEnum.name();
    }

    public CustomException(ErrorCodeEnum codeEnum, String message) {
        super(message);
        this.code = codeEnum.code();
        this.message = message;
        this.enumName = codeEnum.name();

    }

    public CustomException(ErrorCodeEnum codeEnum) {
        super(codeEnum.msg());
        this.code = codeEnum.code();
        this.message = codeEnum.msg();
        this.enumName = codeEnum.name();

    }

    public CustomException(ErrorCodeEnum codeEnum, String message, String data) {
        super(message);
        this.code = codeEnum.code();
        this.message = message;
        this.data = data;
        this.enumName = codeEnum.name();

    }

    public CustomException(ErrorCodeEnum codeEnum, String message, Throwable cause) {
        super(cause);
        this.code = codeEnum.code();
        this.message = message;
        this.enumName = codeEnum.name();
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public CustomException setData(Object data) {
        this.data = data;
        return this;
    }

    public CustomException additionalInformation(String key, String value) {
        this.additionalInformation.put(key, value);
        return this;
    }

    public Map<String, String> getAdditionalInformation() {
        return this.additionalInformation;
    }

}

