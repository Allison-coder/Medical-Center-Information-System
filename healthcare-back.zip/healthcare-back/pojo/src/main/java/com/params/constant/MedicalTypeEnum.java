package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 诊疗类型的枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum MedicalTypeEnum {

    DIAGNOSIS(1, "面诊类型"),
    THERAPY(2, "治疗类型");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (MedicalTypeEnum medicalTypeEnum : MedicalTypeEnum.values()) {
            if (medicalTypeEnum.code.equals(code)) {
                return medicalTypeEnum.getValue();
            }
        }
        return null;
    }
    public static MedicalTypeEnum fromCode(Integer code) {
        for (MedicalTypeEnum medicalTypeEnum : MedicalTypeEnum.values()) {
            if (medicalTypeEnum.code.equals(code)) {
                return medicalTypeEnum;
            }
        }
        return null;
    }
}
