package com.params.pojo.bo;

import lombok.Data;

import java.util.List;

/**
 * @DESCRIPTION
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class GetMergeOrderListBO {

    /**
     * 订单号列表
     */
    List<String> orderSns;


    /**
     * 渠道 id
     */
    private Integer channelId;
}
