package com.params.constant;


/**
 * Created by dzl on 2018/11/7
 **/
public enum ExpressCompanyEnum {
    SHEN_TONG("SHEN_TONG", "申通快递"),
    YUAN_TONG("YUAN_TONG", "圆通速递"),
    YOU_ZHENG("YOU_ZHENG", "中国邮政"),
    SHUN_FENG("SHUN_FENG", "顺丰快递"),
    OTHER("OTHER", "普通物流");

    private String code;
    private String value;

    ExpressCompanyEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }

    public static String transfor(String status) {
        if (status == null) {
            return "";
        }
        ExpressCompanyEnum[] enums = ExpressCompanyEnum.values();
        for (int i = 0, size = enums.length; i < size; i++) {
            if (enums[i].name().equals(status)) {
                return enums[i].getValue();
            }
        }
        return "";
    }
}