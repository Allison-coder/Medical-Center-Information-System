package com.params.pojo.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 处置方案里面子项的保存的BO
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class SaveDisposalPlanItemBO implements Serializable {

    /**
     * 方案列表项的id 编辑时候必填
     */
    private Integer id;

    /**
     * 下拉框所选的项目的id
     */
    private Integer itemId;

    /**
     * 次数层数据的id
     */
    private Integer planId;

    /**
     * 单次价格（RMB） 单位：元  不使用的时候传空
     */
    private String priceHour;

    /**
     * 优惠价格（RMB） 单位：元 不使用的时候传空
     */
    private String preferentialPrice;


    private Integer clinicId;
    private String userName;

}
