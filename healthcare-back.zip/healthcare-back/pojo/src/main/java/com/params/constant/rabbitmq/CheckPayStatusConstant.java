package com.params.constant.rabbitmq;

public class CheckPayStatusConstant {

    public static final String QUEUE = "queue.message.healthcare.check.payStatus";

    public static final String EXCHANGE = "exchange.message.healthcare.check.payStatus";

}
