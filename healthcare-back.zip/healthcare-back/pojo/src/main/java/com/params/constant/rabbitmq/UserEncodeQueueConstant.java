package com.params.constant.rabbitmq;

public class UserEncodeQueueConstant {

    public static final String QUEUE_YSS_ENCODE = "queue.yss.user_encode";

    public static final String EXCHANGE_YSS_COMMON = "queue.yss.common";

}
