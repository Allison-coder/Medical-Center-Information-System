package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * 
 * @version 1.0.0
 */
public class UserCacheKey extends AbstractCacheKey {

    private UserCacheKey() {
    }

    private UserCacheKey(String prefix) {
        super(prefix);
    }

    private UserCacheKey(String prefix, long expireSeconds) {
        super(prefix, expireSeconds);
    }

    private UserCacheKey(String prefix, long timeout, TimeUnit unit) {
        super(prefix, timeout, unit);
    }

    public static UserCacheKey USER_CACHE_KEY = new UserCacheKey("healthcare:user:token:{}");

    public static UserCacheKey KAPTCHA_CODE_KEY = new UserCacheKey("healthcare:login:params:kaptchaKey:{}");

    public static UserCacheKey ABNORMAL_VERIFY_CODE_KEY = new UserCacheKey("healthcare:abnormalVerifyCode:#type:{}");

    public static UserCacheKey BASE_VERIFY_CODE_CACHE_KEY = new UserCacheKey("healthcare:verifyCode:#type:{}");

    public static UserCacheKey SEND_VERIFY_CODE_IP = new UserCacheKey("healthcare:sendVerifyCodeIp:{}");

    public static UserCacheKey SEND_VERIFY_CODE_IP_COUNT = new UserCacheKey("healthcare:sendVerifyCodeIpCount:{}");


    public static UserCacheKey SEND_VERIFY_CODE_TIME = new UserCacheKey("healthcare:sendVerifyCodeTime:{}");
    public static UserCacheKey LOCK_USER = new UserCacheKey("healthcare:loginPassword:{}:{}",1,TimeUnit.DAYS);




}
