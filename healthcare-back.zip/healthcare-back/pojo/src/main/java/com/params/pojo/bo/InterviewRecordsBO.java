package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @DESCRIPTION 保存面诊记录的 bo
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class InterviewRecordsBO {


    @ApiModelProperty(value = "订单编号")
    private String   orderSn;

    @ApiModelProperty(value = "主诉")
    private String chiefComplaint;

    @ApiModelProperty(value = "诊断")
    private String diagnosis;

    @ApiModelProperty(value = "预测")
    private String forecast;


    @ApiModelProperty(value = "治疗方案")
    private String treatmentPlan;


    @ApiModelProperty(value = "预期治疗效果")
    private String expectedOutcomes;

    @ApiModelProperty(value = "医嘱")
    private String advice;
}