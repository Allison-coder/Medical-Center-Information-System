package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 任务类型
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum TaskStatusEnum {
    WAITING_PAY(1, "待支付"),
    WAIT_BOOK(2, "待预约"),
    WAIT_CHECK_IN(3, "待报到"),
    WAITING_DIAGNOSIS(4, "候诊中/等候治疗"),
    THERAPY(5, "面诊中/治疗中"),
    FINISH(6, "已完成/完成治疗"),
    CANCEL(7, "已取消"),
    REFUND(8, "已退款");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (TaskStatusEnum patientIdentityType : TaskStatusEnum.values()) {
            if (patientIdentityType.code.equals(code)) {
                return patientIdentityType.getValue();
            }
        }
        return null;
    }

    public static TaskStatusEnum fromCode(Integer code) {
        for (TaskStatusEnum patientIdentityType : TaskStatusEnum.values()) {
            if (patientIdentityType.code.equals(code)) {
                return patientIdentityType;
            }
        }
        return null;
    }
}
