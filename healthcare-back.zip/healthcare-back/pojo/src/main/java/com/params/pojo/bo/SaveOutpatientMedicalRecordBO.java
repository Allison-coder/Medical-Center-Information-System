package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @DESCRIPTION 工作面板保存门诊病历的 BO 对象
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Accessors(chain = true)
public class SaveOutpatientMedicalRecordBO {

    @ApiModelProperty("患者编号")
    private String patientSn;

    /**
     * 体温（单位：摄氏度）
     */
    private String bodyTemperature;

    /**
     * 血压（单位：毫米汞柱）
     */
    private String bloodPressure;
    /**
     * 身体图坐标
     */
    private List<ImgCoordinateBO> imgCoordinate;

    /**
     * 脉搏（单位：次/分钟）
     */
    private Integer pulse;

    /**
     * 血氧（单位：百分比）
     */
    private String bloodOxygen;

    /**
     * 开始症状
     */
    private String initialSymptoms;

    /**
     * 症状性质
     */
    private String symptomNature;

    /**
     * 疼痛程度（1-3）从小到大 轻、中、高
     */
    private Integer painLevel;

    /**
     * 既往病史
     */
   private String medicalHistory;
}
