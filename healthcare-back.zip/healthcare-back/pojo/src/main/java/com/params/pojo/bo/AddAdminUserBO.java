package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 添加账号的BO
 */
@Data
public class AddAdminUserBO implements Serializable {


    /**
     * 账号名称
     */
    private String userName;

    /**
     * 密码
     */
    private String password;


    /**
     * 角色id
     */
    private Integer roleId;

    /**
     * 挂号数
     */
    private Integer registrationCount;

    /**
     * 工号
     */
    private String employeeId;

    /**
     * 渠道id、诊所id
     */
    private Integer channelId;

}
