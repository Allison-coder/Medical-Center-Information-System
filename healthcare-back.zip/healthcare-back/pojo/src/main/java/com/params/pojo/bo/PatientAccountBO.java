package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 修改患者姓名和手机号的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class PatientAccountBO implements Serializable {

    @ApiModelProperty(value = "患者编号")
    private String patientSn;

    @ApiModelProperty(value = "患者姓名")
    private String patientName;

    @ApiModelProperty(value = "手机号")
    private String phoneNumber;
}
