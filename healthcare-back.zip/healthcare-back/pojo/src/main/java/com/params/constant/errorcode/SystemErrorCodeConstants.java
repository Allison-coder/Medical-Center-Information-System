package com.params.constant.errorcode;

import com.params.framework.exception.ErrorCode;

/**
 * <pre>
 * 错误码枚举类
 * 文章使用 1-001-000-000 段
 *
 * </pre>
 *
 * @version 1.0.0
 */
public interface SystemErrorCodeConstants {

    // ========== 系统模块 2001000==========
    ErrorCode PARAMS_DEFECT = new ErrorCode(2001001, "参数缺失");
    ErrorCode SYSTEM_ERROR = new ErrorCode(2001002, "系统异常");
    ErrorCode NOT_EXISTS = new ErrorCode(2001003, "信息记录不存在");
    ErrorCode TYPE_NOT_EXISTS = new ErrorCode(2001004, "目标类型未支持");
    ErrorCode FREQUENTLY = new ErrorCode(2001005, "请勿频繁操作");
    ErrorCode ACCESS_DENIED = new ErrorCode(2001006, "权限不足");

    // ========== AUTH 模块 2002000 ==========
    ErrorCode AUTH_LOGIN_BAD_CREDENTIALS = new ErrorCode(2002000, "登录失败，账号密码不正确");
    ErrorCode AUTH_LOGIN_USER_DISABLED = new ErrorCode(2002001, "登录失败，账号被禁用");
    ErrorCode AUTH_LOGIN_FAIL_UNKNOWN = new ErrorCode(2002003, "登录失败"); // 登录失败的兜底，未知原因
    ErrorCode AUTH_LOGIN_CAPTCHA_NOT_FOUND = new ErrorCode(2002004, "验证码不存在");
    ErrorCode AUTH_LOGIN_CAPTCHA_CODE_ERROR = new ErrorCode(2002005, "验证码不正确");
    ErrorCode AUTH_THIRD_LOGIN_NOT_BIND = new ErrorCode(2002006, "未绑定账号，需要进行绑定");

    ErrorCode AUTH_TOKEN_EXPIRED = new ErrorCode(2002007, "Token 已经过期");

    ErrorCode AUTH_LOGIN_USER_FROZEN = new ErrorCode(2002008, "账号已被冻结，请联系管理员");
    ErrorCode AUTH_LOGIN_USER_OCCUPY = new ErrorCode(2002009, "账号已被占用，非本人作请尽快修改密码");
    ErrorCode UNAUTHORIZED = new ErrorCode(2002010, "不允许访问");


}
