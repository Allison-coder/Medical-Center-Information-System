package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 短信通知的状态
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum SmsStatusEnum {

    FAIL(0, "失败"),
    SUCCESS(1, "成功");

    private final Integer code;
    private final String value;
}
