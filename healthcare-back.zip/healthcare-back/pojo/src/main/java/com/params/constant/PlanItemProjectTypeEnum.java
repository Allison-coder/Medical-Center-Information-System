package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PlanItemProjectTypeEnum {
    THERAPY(1, "康复治疗"),
    MEDICINE(2, "药物");

    private final Integer code;
    private final String value;
}
