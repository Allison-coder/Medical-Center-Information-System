package com.params.constant.rabbitmq;

public class OperateLogQueueConstant {

    public static final String QUEUE_OPERATE_LOG = "queue.operate.lucky.log";

    public static final String EXCHANGE_OPERATE_LOG_COMMON = "exchange.operate.lucky.common";

}
