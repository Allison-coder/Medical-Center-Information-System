
package com.params.constant.rabbitmq;

public class InvoiceQueueConstant {

    public static final String QUEUE_ORDER = "queue.check.order.invoice";

    public static final String EXCHANGE_ORDER = "exchange.check.order.invoice";

}
