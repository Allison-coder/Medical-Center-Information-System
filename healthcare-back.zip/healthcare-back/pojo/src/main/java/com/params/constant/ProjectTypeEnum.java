package com.params.constant;


import org.springframework.util.StringUtils;

public enum ProjectTypeEnum {
    CMS("考试助手"),
    HEALTH("健康通"),

    LUCKY("算命"),
    ;
    private String value;

    ProjectTypeEnum(String value) {

    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if (StringUtils.isEmpty(type)) {
            return false;
        }
        for (ProjectTypeEnum ele : ProjectTypeEnum.values()) {
            if (ele.toString().equals(type)) {
                return true;
            }
        }
        return false;
    }
}
