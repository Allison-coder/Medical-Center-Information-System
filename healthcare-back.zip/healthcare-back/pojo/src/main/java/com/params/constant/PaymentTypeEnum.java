package com.params.constant;


import org.springframework.util.StringUtils;

public enum PaymentTypeEnum {

    CMB_APP_PAY("招行app支付", "招行支付"),
    CMB_H5_PAY("招行h5支付", "招行支付"),
    ALI_H5_PAY("支付宝h5支付", "支付宝支付"),
    WEIXIN_H5_PAY("微信h5支付", "微信支付"),
    WEIXIN_JS_PAY("微信JSAPI支付", "微信支付"),
    WEIXIN_QRCODE_PAY("微信扫码支付", "微信支付"),
    WEIXIN_APP_PAY("微信小程序支付", "微信支付"),
    PINGAN_APP_PAY("平安小程序支付", "平安支付"),
    ALI_APP_PAY("支付宝小程序支付", "支付宝支付"),
    ALI_QRCODE_PAY("支付宝扫码支付", "支付宝支付"),
    ALI_JS_PAY("支付宝JS支付", "支付宝支付"),
    ICBC_H5_PAY("工行h5支付", "工银e支付"),
    HZ_ICBC_H5_PAY("工行h5支付", "工行埋名支付"),
    CCB_APP_PAY("建设银行APP支付", "建行支付"),
    BOC_APP_PAY("中国银行APP支付", "中行支付"),
    BAIDU_APP_PAY("百度小程序支付", "百度支付"),
    FREE_TO_PAY("免支付", "免支付"),     //当价格为0时  （中旅）
    FREE_ORDER("免支付", "免支付"),//当正常价格为0时
    ZZSQ_APP_PAY("自在社区app支付", "自在社区支付"),
    SZYZ_H5_PAY("深圳邮政支付", "深圳邮政支付"),
    WLKJ_H5_PAY("未来科技", "未来科技支付"),
    ABC_APP_PAY("农业银行支付", "农业银行支付"),
    RCU_H5_PAY("农信银行", "农信银行"),
    YSF_APP("云闪付", "云闪付"),
    ZERO_FEE_TO_PAY("零元支付", "零元支付"),
    BANK_TRANSFER_PAY("银行汇款", "银行汇款"),
    WPS_APP("WPS", "WPS");

    private final String value;
    private final String nickname;

    PaymentTypeEnum(String value, String nickname) {
        this.value = value;
        this.nickname = nickname;
    }

    public String getNickname() {
        return nickname;
    }

    public String getValue() {
        return value;
    }

    public static boolean exitPaymentType(String type) {
        if (StringUtils.isEmpty(type)) {
            return false;
        }
        for (PaymentTypeEnum ele : PaymentTypeEnum.values()) {
            if (ele.toString().equals(type)) {
                return true;
            }
        }
        return false;
    }

    public static String translate(String name) {
        for (PaymentTypeEnum typeEnum : PaymentTypeEnum.values()) {
            if (typeEnum.name().equalsIgnoreCase(name)) {
                return typeEnum.getValue();
            }
        }
        return null;
    }

    public static PaymentTypeEnum translateEnum(String name) {
        for (PaymentTypeEnum typeEnum : PaymentTypeEnum.values()) {
            if (typeEnum.name().equalsIgnoreCase(name)) {
                return typeEnum;
            }
        }
        return null;
    }


    public static void main(String[] args) {
        System.out.println(translateEnum("WEIXIN_JS_PAY").nickname);
    }

}
