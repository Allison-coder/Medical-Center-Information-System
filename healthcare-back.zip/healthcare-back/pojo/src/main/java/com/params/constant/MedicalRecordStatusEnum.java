package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 诊疗记录状态枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum MedicalRecordStatusEnum {
    WAIT_BOOK(2, "待预约"),
    WAIT_CHECK_IN(3, "待报到"),
    WAITING_FOR_CALL(4, "等待叫号"),
    THERAPY(5, "治疗中"),
    FINISH(6, "完成"),
    CANCEL(7, "已取消"),
    REFUND(8, "已退款");;

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (MedicalRecordStatusEnum medicalRecordStatusEnum : MedicalRecordStatusEnum.values()) {
            if (medicalRecordStatusEnum.code.equals(code)) {
                return medicalRecordStatusEnum.getValue();
            }
        }
        return null;
    }
}
