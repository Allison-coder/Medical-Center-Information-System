package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @DESCRIPTION 确认预约的 domain 的入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
@Accessors(chain = true)
public class ConfirmAppointmentBO {

    @ApiModelProperty(value = "项目id")
    private Integer projectId;

    /**
     * 预约的日期
     */
    private String appointmentDate;

    /**
     * 预约的排班id集合
     */
    private List<Integer> scheduleDetailIds;

    /**
     * 治疗师 id
     */
    private Integer adminId;
    /**
     *  患者编号
     */
    private String patientSn;

    /**
     * 订单编号
     */
    private String orderSn;

    /**
     * 是否使用优惠券 false-不使用 true-使用
     */
    private Boolean isUseCoupon =false;

    /**
     * 优惠券码 面诊单的参数
     */
    private String couponCode;


    /**
     * 来源 WEIXIN_APP-小程序 HEALTH_ADMIN-管理后台  默认为 HEALTH_ADMIN
     */
    private String source = "HEALTH_ADMIN";
}
