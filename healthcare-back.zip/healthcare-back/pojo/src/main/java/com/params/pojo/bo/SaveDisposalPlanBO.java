package com.params.pojo.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @DESCRIPTION 处置方案保存按钮的数据
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class SaveDisposalPlanBO implements Serializable {

    /**
     * 处置方案id
     */
    private Integer id;

    /**
     * 患者编号
     */
    private String patientSn;

    /**
     * 医嘱
     */
    private String advice;
    /**
     * 每次项目里的数据
     */
    List<DisposalPlanNumDetailBO> disposalPlanDetailList;

}
