package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 优惠券的核销状态
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Getter
@AllArgsConstructor
public enum WriteOffStatusEnum {

    WRITE_ON(0, "待核销"),
    WRITE_OFF(1, "已核销");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (WriteOffStatusEnum  writeOffStatusEnum : WriteOffStatusEnum.values()) {
            if (writeOffStatusEnum.code.equals(code)) {
                return writeOffStatusEnum.getValue();
            }
        }
        return null;
    }
}
