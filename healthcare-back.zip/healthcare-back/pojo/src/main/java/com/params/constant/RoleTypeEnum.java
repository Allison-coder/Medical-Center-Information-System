package com.params.constant;

/**
 * 角色的枚举
 */
public enum RoleTypeEnum {
    ADMIN_ROLE(1, "ADMIN", "管理员"),
    DOCTOR_ROLE(2, "DOCTOR", "医生"),
    NURSE_ROLE(3, "NURSE", "护士"),
    HEAL_ROLE(4, "HEAL", "治疗师");

    private int key;
    private String code;
    private String msg;



    public Integer key() {
        return key;
    }
    public String msg() {
        return msg;
    }

    public String code() {
        return code;
    }

    RoleTypeEnum(int key, String code, String msg) {
        this.key = key;
        this.code = code;
        this.msg = msg;
    }

    public static RoleTypeEnum getEnum(int key ) {
        for (RoleTypeEnum ele : RoleTypeEnum.values()) {
            if (ele.key() == key) {
                return ele;
            }
        }
        return null;
    }
}
