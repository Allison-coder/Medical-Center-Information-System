package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 处置方案可否创建的枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */

@Getter
@AllArgsConstructor
public enum PlanAddFlagEnum {
    // 0-能 1-不能
     CAN_ADD(0, "可以创建"),
    NOT_CAN_ADD(1, "不可以创建");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (PlanAddFlagEnum planAddFlagEnum : PlanAddFlagEnum.values()) {
            if (planAddFlagEnum.code.equals(code)) {
                return planAddFlagEnum.getValue();
            }
        }
        return null;
    }
    public static PlanAddFlagEnum fromCode(Integer code) {
        for (PlanAddFlagEnum planAddFlagEnum : PlanAddFlagEnum.values()) {
            if (planAddFlagEnum.code.equals(code)) {
                return planAddFlagEnum;
            }
        }
        return null;
    }
}
