package com.params.constant;


import org.springframework.util.StringUtils;

public enum LogisticsTypeEnum {
    JDKD("EMS（邮政特快专递）"),

    ;
    private String value;

    LogisticsTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean exists(String type) {
        if (StringUtils.isEmpty(type)) {
            return false;
        }
        for (LogisticsTypeEnum ele : LogisticsTypeEnum.values()) {
            if (ele.toString().equals(type)) {
                return true;
            }
        }
        return false;
    }

    public static String translate(int index) {
        for (int i = 0; i < LogisticsTypeEnum.values().length; i++) {
            if (i == index) {
                return LogisticsTypeEnum.values()[i].getValue();
            }
        }
        return null;
    }


}
