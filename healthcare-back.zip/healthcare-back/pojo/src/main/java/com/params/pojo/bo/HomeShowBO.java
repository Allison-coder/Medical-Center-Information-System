package com.params.pojo.bo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 首页是否展示的 BO
 */
@Data
public class HomeShowBO implements Serializable {

    /**
     * 账号的 id
     */
    private Integer adminId;

    /**
     * 排序
     */
    private Integer homepageDisplaySort;

    /**
     * 展示/隐藏  0-隐藏  1-开  默认 0
     */
    private Integer homepageDisplaySwitch;


}
