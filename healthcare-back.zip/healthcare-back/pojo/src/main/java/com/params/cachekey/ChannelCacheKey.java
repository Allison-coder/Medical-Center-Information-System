package com.params.cachekey;

import com.params.component.redis.AbstractCacheKey;

import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *
 *
 * </pre>
 *
 * 
 * @version 1.0.0
 */
public class ChannelCacheKey extends AbstractCacheKey {

    private ChannelCacheKey() {
    }

    private ChannelCacheKey(String prefix) {
        super(prefix);
    }

    private ChannelCacheKey(String prefix, long expireSeconds) {
        super(prefix, expireSeconds);
    }

    private ChannelCacheKey(String prefix, long timeout, TimeUnit unit) {
        super(prefix, timeout, unit);
    }

    public static ChannelCacheKey CHANNEL_CACHE_KEY = new ChannelCacheKey("healthcare:channel:appId:{}");


}
