package com.params.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @DESCRIPTION 患者管理列表操作类型枚举
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Getter
@AllArgsConstructor
public enum PatientOperateTypeEnum {

    CHECK_IN(1, "报到"),
    START_THERAPY(2, "开始面诊/开始治疗"),
    END_THERAPY(3, "完成面诊/结束治疗");

    private final Integer code;
    private final String value;

    public static String translate(Integer code) {
        for (PatientOperateTypeEnum operateTypeEnum : PatientOperateTypeEnum.values()) {
            if (operateTypeEnum.code.equals(code)) {
                return operateTypeEnum.getValue();
            }
        }
        return null;
    }

    public static PatientOperateTypeEnum fromCode(Integer code) {
        for (PatientOperateTypeEnum operateTypeEnum : PatientOperateTypeEnum.values()) {
            if (operateTypeEnum.code.equals(code)) {
                return operateTypeEnum;
            }
        }
        return null;
    }

}
