package com.params.constant;

import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <pre>
 *
 * </pre>
 *
 *
 * @version 1.0.0
 * @Create 2022/12/8
 */
@Getter
@AllArgsConstructor
public enum RefundLibraryEnum {

    NONE("NONE", "未入库"),
    INPUT("INPUT", "已入库"),
    PART_INPUT("PART_INPUT", "部分入库"),
    LOSE("LOSE", "丢失"),
    ;

    /**
     * 状态值
     */
    private final String value;
    /**
     * 状态名
     */
    private final String name;

    public static String translate(String refundLibrary) {
        if (StrUtil.isBlank(refundLibrary)) return NONE.getName();
        for (RefundLibraryEnum logisticsStatusEnum : RefundLibraryEnum.values()) {
            if (logisticsStatusEnum.value.equalsIgnoreCase(refundLibrary)) {
                return logisticsStatusEnum.getName();
            }
        }
        return NONE.getName();
    }
}
