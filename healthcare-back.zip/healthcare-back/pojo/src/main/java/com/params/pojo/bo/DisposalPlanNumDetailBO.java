package com.params.pojo.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @DESCRIPTION 处置方案次数详情入参
 * @AUTHOR lianren.deng
 * @CREATETIME EVERYDAY IS A BEAUTIFUL DAY
 */
@Data
public class DisposalPlanNumDetailBO implements Serializable {


    /**
     * 医嘱
     */
    private String advice;

    /**
     * 作用机理
     */
    private String mechanization;

    /**
     * 预期治疗效果
     */
    private String expectedOutcomes;

    /**
     * 推存治疗时间
     */
    private String recommendedTime;

    /**
     * 是否不推荐 不推荐为true 推荐为false
     */
    private Boolean noRecommended;

    /**
     * 次数的id
     */
    private Integer id;


}
