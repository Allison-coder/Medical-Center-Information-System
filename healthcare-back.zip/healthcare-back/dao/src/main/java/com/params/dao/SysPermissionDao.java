package com.params.dao;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.SysPermission;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-11
 */
@Mapper
public interface SysPermissionDao extends BaseMapperX<SysPermission> {
    default boolean selectExistsByUpdateTimeAfter(Date maxUpdateTime) {
        LambdaQueryWrapper<SysPermission> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.select(SysPermission::getId);
        queryWrapper.gt(SysPermission::getCreateTime, maxUpdateTime);
        queryWrapper.last("LIMIT 1");
        return selectOne(queryWrapper) != null;
    }
}
