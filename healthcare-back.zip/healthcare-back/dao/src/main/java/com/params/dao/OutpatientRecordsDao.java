package com.params.dao;

import com.params.entity.OutpatientRecords;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 门诊病历表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-09
 */
@Mapper
public interface OutpatientRecordsDao extends BaseMapperX<OutpatientRecords> {

}
