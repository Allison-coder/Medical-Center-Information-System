package com.params.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.ScheduleDetailPatientBind;
import com.params.pojo.dto.AppointmentDTO;
import com.params.pojo.vo.ScheduleDateVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* @author mac
* @description 针对表【scheduleling_patient(预约表（排班-患者关系表）)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.ScheduleDetailPatientBind
*/
public interface ScheduleDetailPatientBindDao extends BaseMapperX<ScheduleDetailPatientBind> {

    boolean makeAppointment(AppointmentDTO dto);

}




