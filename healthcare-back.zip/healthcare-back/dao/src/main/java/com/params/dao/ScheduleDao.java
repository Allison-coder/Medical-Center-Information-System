package com.params.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.Schedule;
import com.params.pojo.vo.ScheduleDateVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* @author mac
* @description 针对表【schedule(班次表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.Schedule
*/
public interface ScheduleDao extends BaseMapperX<Schedule> {

}




