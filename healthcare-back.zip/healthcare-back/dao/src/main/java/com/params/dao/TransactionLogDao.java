package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.TransactionLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Mapper
public interface TransactionLogDao extends BaseMapperX<TransactionLog> {


    TransactionLog getByTradeNum( @Param("tradeNum") String tradeNum);

}
