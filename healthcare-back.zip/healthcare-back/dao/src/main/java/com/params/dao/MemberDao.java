package com.params.dao;

import com.params.entity.Member;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 用户成员 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Mapper
public interface MemberDao extends BaseMapperX<Member> {

}
