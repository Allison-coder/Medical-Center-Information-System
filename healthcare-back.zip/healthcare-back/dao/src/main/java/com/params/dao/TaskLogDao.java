package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.TaskLog;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* @author mac
* @description 针对表【task_log(任务进度日志表 )】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.TaskLog
*/
public interface TaskLogDao extends BaseMapperX<TaskLog> {

    /**
     * 根据患者sn列表查询最新的任务进度日志
     * @param patientSns
     * @return
     */
    List<TaskLog> getPatientLastTaskLog(@Param("patientSns") List<String> patientSns);

    /**
     * 通过患者id 查出所有订单的最新任务
     * @param patientSns
     * @return
     */
    List<TaskLog> getPatientAllOrdersLastTaskLog(@Param("patientSns") List<String> patientSns);


    /**
     * 通过订单编号查出订单的最新任务
     * @param orderSns
     * @return
     */
    List<TaskLog> getOrderLastTaskLogByOrderSns(@Param("orderSns") List<String> orderSns);
}




