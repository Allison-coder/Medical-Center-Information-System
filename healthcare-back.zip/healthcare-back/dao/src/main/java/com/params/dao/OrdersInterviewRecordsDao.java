package com.params.dao;

import com.params.entity.OrdersInterviewRecords;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 订单的面诊记录表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-08-10
 */
@Mapper
public interface OrdersInterviewRecordsDao extends BaseMapperX<OrdersInterviewRecords> {

}
