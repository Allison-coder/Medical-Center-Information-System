package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.OfficialAccount;
import com.params.pojo.bo.wx.OfficialAccountBO;
import org.apache.ibatis.annotations.Param;

/**
* @author mac
* @description 针对表【official_account】的数据库操作Mapper
* @createDate 2024-05-30 17:15:52
* @Entity com.params.entity.OfficialAccount
*/
public interface OfficialAccountDao extends BaseMapperX<OfficialAccount> {

    OfficialAccountBO getOfficialAccountByUserCode(@Param("uniqueCode") String uniqueCode, @Param("sourceType") String sourceType);

    OfficialAccountBO getOfficialAccountByUnionId(@Param("unionId") String uniqueCode, @Param("sourceType") String sourceType, @Param("officialCode") String officialCode);
}




