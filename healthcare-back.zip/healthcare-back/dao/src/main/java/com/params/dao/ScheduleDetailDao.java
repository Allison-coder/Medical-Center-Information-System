package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.ScheduleDetail;

/**
* @author mac
* @description 针对表【scheduling(排班明细表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.ScheduleDetail
*/
public interface ScheduleDetailDao extends BaseMapperX<ScheduleDetail> {

}




