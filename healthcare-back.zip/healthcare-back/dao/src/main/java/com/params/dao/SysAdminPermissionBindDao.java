package com.params.dao;

import com.params.entity.SysAdminPermissionBind;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-11
 */
@Mapper
public interface SysAdminPermissionBindDao extends BaseMapperX<SysAdminPermissionBind> {

}
