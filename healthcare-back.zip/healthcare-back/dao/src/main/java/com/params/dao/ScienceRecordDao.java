package com.params.dao;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.ScienceRecord;
import com.params.pojo.dto.ScienceRecordQueryDTO;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 科普内容记录表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-29
 */
public interface ScienceRecordDao extends BaseMapperX<ScienceRecord> {

    IPage<ScienceRecord> getRecords(Page<ScienceRecord> page, @Param("dto") ScienceRecordQueryDTO dto);
}
