package com.params.dao;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.entity.RefundRecord;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.pojo.vo.AdminRefundListReq;
import com.params.pojo.vo.RefundListVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-01-11
 */
@Mapper
public interface RefundRecordDao extends BaseMapperX<RefundRecord> {

    Page<RefundListVO> findByPage(Page<RefundListVO> page, @Param("ew") AdminRefundListReq req);

    long findCountByPage(@Param("ew") AdminRefundListReq req);
}
