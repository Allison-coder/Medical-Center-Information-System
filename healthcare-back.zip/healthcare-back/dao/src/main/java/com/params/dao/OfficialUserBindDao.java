package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.OfficialUserBind;

/**
* @author mac
* @description 针对表【official_user_bind】的数据库操作Mapper
* @createDate 2024-06-03 10:48:27
* @Entity com.params.entity.OfficialUserBind
*/
public interface OfficialUserBindDao extends BaseMapperX<OfficialUserBind> {

}




