package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.TransactionLog;
import com.params.entity.TransactionRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 支付记录表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Mapper
public interface TransactionRecordDao extends BaseMapperX<TransactionRecord> {

    TransactionLog selectTransactionLogByTradeNum(String tradeNum);


}
