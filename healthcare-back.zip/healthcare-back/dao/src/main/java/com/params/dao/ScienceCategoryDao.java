package com.params.dao;

import com.params.entity.ScienceCategory;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 科普类别表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-29
 */
@Mapper
public interface ScienceCategoryDao extends BaseMapperX<ScienceCategory> {

}
