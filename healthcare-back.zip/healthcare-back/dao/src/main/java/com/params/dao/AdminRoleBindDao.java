package com.params.dao;

import com.params.entity.AdminRoleBind;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 管理员用户角色关系表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Mapper
public interface AdminRoleBindDao extends BaseMapperX<AdminRoleBind> {

}
