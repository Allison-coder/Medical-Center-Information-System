package com.params.dao;


import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.MerchantPaymentInfo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 支付方式配置表 Mapper 接口
 * </p>
 *
 * @author lf
 * @since 2018-11-05
 */
@Mapper
public interface MerchantPaymentInfoDao extends BaseMapperX<MerchantPaymentInfo> {

}
