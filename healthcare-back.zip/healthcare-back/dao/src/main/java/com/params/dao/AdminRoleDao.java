package com.params.dao;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.AdminRole;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;

/**
 * <p>
 * 用户角色表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Mapper
public interface AdminRoleDao extends BaseMapperX<AdminRole> {

    default boolean selectExistsByUpdateTimeAfter(Date maxUpdateTime) {
        LambdaQueryWrapper<AdminRole> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.select(AdminRole::getId);
        queryWrapper.gt(AdminRole::getModifyTime, maxUpdateTime);
        queryWrapper.last("LIMIT 1");
        return selectOne(queryWrapper) != null;
    }
}
