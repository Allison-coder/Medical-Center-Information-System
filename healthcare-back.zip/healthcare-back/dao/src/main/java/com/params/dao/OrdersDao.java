package com.params.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.Orders;
import com.params.pojo.dto.QueryOrderDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* @author mac
* @description 针对表【orders(订单表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.Orders
*/
public interface OrdersDao extends BaseMapperX<Orders> {

    IPage<Orders> getOrders(Page<Orders> page, @Param("dto") QueryOrderDTO dto);

    List<Orders> getPatientLastOrders(@Param("patientSns") List<String> patientSns);

    Page<Orders> cusPageGetOrdersJoinSchedule(Page<Orders> page,  @Param(Constants.WRAPPER) Wrapper<Orders> wrapper);
}




