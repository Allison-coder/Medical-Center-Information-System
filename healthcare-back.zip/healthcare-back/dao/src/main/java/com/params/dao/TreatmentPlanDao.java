package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.TreatmentPlan;

/**
* @author mac
* @description 针对表【treatment_plan(处置方案表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.TreatmentPlan
*/
public interface TreatmentPlanDao extends BaseMapperX<TreatmentPlan> {

}




