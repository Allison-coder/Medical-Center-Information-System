package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.SysPermissionRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.Date;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-11
 */
@Mapper
public interface SysPermissionRoleDao extends BaseMapperX<SysPermissionRole> {

    @Select("SELECT id FROM sys_permission_role WHERE create_time > #{maxUpdateTime} LIMIT 1")
    Long selectExistsByUpdateTimeAfter(Date maxUpdateTime);
}
