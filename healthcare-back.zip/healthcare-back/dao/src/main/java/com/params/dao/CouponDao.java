package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.Coupon;

/**
* @author mac
* @description 针对表【coupon(优惠券表)】的数据库操作Mapper
* @createDate 2024-05-29 16:10:08
* @Entity com.params.entity.Coupon
*/
public interface CouponDao extends BaseMapperX<Coupon> {

}




