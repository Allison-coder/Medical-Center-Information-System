package com.params.dao;

import com.params.entity.TreatmentPlanBase;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 处置方案总表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-08-11
 */
@Mapper
public interface TreatmentPlanBaseDao extends BaseMapperX<TreatmentPlanBase> {

}
