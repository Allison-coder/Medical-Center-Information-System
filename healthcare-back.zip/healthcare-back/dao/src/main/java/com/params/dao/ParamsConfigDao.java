package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.ParamsConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 配置表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-01-05
 */
@Mapper
public interface ParamsConfigDao extends BaseMapperX<ParamsConfig> {

}
