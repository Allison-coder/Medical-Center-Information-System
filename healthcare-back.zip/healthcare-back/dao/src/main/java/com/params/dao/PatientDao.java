package com.params.dao;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.Patient;
import com.params.pojo.vo.PlanFollowUpVO;
import org.apache.ibatis.annotations.Param;

/**
* @author mac
* @description 针对表【patient(患者表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.Patient
*/
public interface PatientDao extends BaseMapperX<Patient> {

    Page<PlanFollowUpVO> cusPageGetPlanFollowUp(IPage<PlanFollowUpVO> page, @Param(Constants.WRAPPER) Wrapper<PlanFollowUpVO> queryWrapper);

}




