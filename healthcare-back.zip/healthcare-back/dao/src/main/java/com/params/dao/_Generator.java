package com.params.dao;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.generator.config.ConstVal;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.params.component.mybaits.generator.GeneratorUtil;
import com.params.component.mybaits.generator.config.GeneratePackageInfoConfig;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * <pre>
 * params.
 *
 * </pre>
 *
 * 
 * @version 1.0.0
 */
public class _Generator {

    public static String scanner(String tip) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        sb.append("请输入" + tip + "：");
        System.out.println(sb.toString());
        if (scanner.hasNext()) {
            String ipt = scanner.next();
            if (StringUtils.isNotBlank(ipt)) {
                return ipt;
            }
        }
        throw new RuntimeException("请输入正确的" + tip + "！");
    }

    public static void main(String[] args) {
        String include = scanner("表名，多个英文逗号分割");
        String projectPath = System.getProperty("user.dir");
        List<GeneratePackageInfoConfig> generatePackageInfoConfigs = new ArrayList<>();
        generatePackageInfoConfigs.add(new GeneratePackageInfoConfig()
                .setPath(OutputFile.entity)
                .setModule(ConstVal.ENTITY)
                .setOutputDir(String.format("%s/%s/src/main/java", projectPath, "params-entity")));
        generatePackageInfoConfigs.add(new GeneratePackageInfoConfig()
                .setOutputDir(String.format("%s/%s/src/main/java", projectPath, "params-dao"))
                .setPath(OutputFile.mapper)
                .setModule(ConstVal.MAPPER));
        generatePackageInfoConfigs.add(new GeneratePackageInfoConfig()
//                .setPath(OutputFile.xml)
                .setModule(ConstVal.XML)
                .setOutputDir(String.format("%s/%s/src/main/resources/mappers", projectPath, "params-dao")));
        generatePackageInfoConfigs.add(new GeneratePackageInfoConfig()
                .setOutputDir(String.format("%s/%s/src/main/java", projectPath, "params-service"))
                .setPath(OutputFile.service)
                .setModule(ConstVal.SERVICE));
        generatePackageInfoConfigs.add(new GeneratePackageInfoConfig()
                .setOutputDir(String.format("%s/%s/src/main/java", projectPath, "params-service"))
                .setPath(OutputFile.serviceImpl)
                .setModule(ConstVal.SERVICE_IMPL));

        GeneratorUtil.Config c = new GeneratorUtil.Config()
                .setProjectPath(projectPath)
                .setOutputDir("/src/main/java")
                .setDbUrl("jdbc:mysql://172.31.210.60:3306/healthcare?characterEncoding=UTF-8&autoReconnect=true&failOverReadOnly=false&useSSL=false&tinyInt1isBit=false")
                .setDbUsername("dev")
                .setDbPassword("qDNfK6StYr6LgNPJ")
                .setParent("com.params")
                .setInclude(include)
                .setGeneratePackageInfoConfigs(generatePackageInfoConfigs);

        GeneratorUtil.run(c);
    }
}

