package com.params.dao;

import com.params.component.mybaits.QueryWrapperX;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.AdminSession;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 在线用户表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-11
 */
@Mapper
public interface AdminSessionDao extends BaseMapperX<AdminSession> {

    default List<AdminSession> selectListBySessionTimoutLt() {
        return selectList(new QueryWrapperX<AdminSession>().lt("session_timeout", new Date()));
    }
}
