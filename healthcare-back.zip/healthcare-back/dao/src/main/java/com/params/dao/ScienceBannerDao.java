package com.params.dao;

import com.params.entity.ScienceBanner;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 科普banner表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-29
 */
@Mapper
public interface ScienceBannerDao extends BaseMapperX<ScienceBanner> {

}
