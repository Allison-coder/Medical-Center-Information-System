package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.SmsNoticeLog;

/**
* @author mac
* @description 针对表【sms_notice_log(短信通知记录表)】的数据库操作Mapper
* @createDate 2024-06-06 15:35:19
* @Entity com.params.entity.SmsNoticeLog
*/
public interface SmsNoticeLogDao extends BaseMapperX<SmsNoticeLog> {

}




