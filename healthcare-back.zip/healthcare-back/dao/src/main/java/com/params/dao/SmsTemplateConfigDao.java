package com.params.dao;

import com.params.entity.SmsTemplateConfig;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 短信模板配置表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-06-06
 */
@Mapper
public interface SmsTemplateConfigDao extends BaseMapperX<SmsTemplateConfig> {

}
