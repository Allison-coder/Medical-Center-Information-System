package com.params.dao;

import com.params.entity.City;
import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.pojo.bo.CityListBO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2022-12-07
 */
@Mapper
public interface CityDao extends BaseMapperX<City> {

    List<CityListBO> getCityList();
}
