package com.params.dao;

import com.params.entity.TreatmentPlanProjectConfig;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 处置方案的项目配置表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-17
 */
@Mapper
public interface TreatmentPlanProjectConfigDao extends BaseMapperX<TreatmentPlanProjectConfig> {

}
