package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.Clinic;

/**
* @author mac
* @description 针对表【clinic(诊所表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.Clinic
*/
public interface ClinicDao extends BaseMapperX<Clinic> {

}




