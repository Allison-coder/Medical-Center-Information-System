package com.params.dao;

import com.params.entity.CouponTemplatePromotionBind;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 优惠券模板-活动绑定表 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-22
 */
@Mapper
public interface CouponTemplatePromotionBindDao extends BaseMapperX<CouponTemplatePromotionBind> {

}
