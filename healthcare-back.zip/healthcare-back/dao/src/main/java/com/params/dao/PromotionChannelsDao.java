package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.PromotionChannels;

/**
* @author mac
* @description 针对表【promotion_channels(推广渠道表)】的数据库操作Mapper
* @createDate 2024-05-29 16:10:08
* @Entity com.params.entity.PromotionChannels
*/
public interface PromotionChannelsDao extends BaseMapperX<PromotionChannels> {

}




