package com.params.dao;

import com.params.component.mybaits.mapper.BaseMapperX;
import com.params.entity.TreatmentPlanItem;

/**
* @author mac
* @description 针对表【treatment_plan_item(处置方案明细表)】的数据库操作Mapper
* @createDate 2024-05-15 11:16:08
* @Entity com.params.entity.TreatmentPlanItem
*/
public interface TreatmentPlanItemDao extends BaseMapperX<TreatmentPlanItem> {

}




