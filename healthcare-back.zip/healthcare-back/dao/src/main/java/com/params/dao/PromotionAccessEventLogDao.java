package com.params.dao;

import com.params.entity.PromotionAccessEventLog;
import com.params.component.mybaits.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 落地页访问事件日志 Mapper 接口
 * </p>
 *
 * @author robot-params
 * @since 2024-07-25
 */
@Mapper
public interface PromotionAccessEventLogDao extends BaseMapperX<PromotionAccessEventLog> {

}
